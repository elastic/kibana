module.exports = function (server, options) {
};
