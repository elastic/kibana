export default {
  app: {},
  counter: 0
};
