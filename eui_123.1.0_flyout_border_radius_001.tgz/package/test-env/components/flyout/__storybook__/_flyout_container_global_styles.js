"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.FlyoutContainerGlobalStyles = exports.FlyoutBorderRadiusStyle = void 0;
var _react = _interopRequireDefault(require("react"));
var _react2 = require("@emotion/react");
var _services = require("../../../services");
/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */

var FlyoutContainerGlobalStyles = exports.FlyoutContainerGlobalStyles = function FlyoutContainerGlobalStyles() {
  var _useEuiTheme = (0, _services.useEuiTheme)(),
    euiTheme = _useEuiTheme.euiTheme;
  return (0, _react2.jsx)(_react2.Global, {
    styles: "\n        html {\n          background-color: ".concat(euiTheme.colors.body, ";\n        }\n\n        body,\n        #storybook-root,\n        #story-wrapper {\n          block-size: 100%;\n        }\n\n        #story-wrapper {\n          padding: ").concat(euiTheme.size.base, ";\n          background-color: ").concat(euiTheme.colors.backgroundBasePlain, ";\n          border-radius: ").concat(euiTheme.border.radius.frame, ";\n        }\n      ")
  });
};
var FlyoutBorderRadiusStyle = exports.FlyoutBorderRadiusStyle = function FlyoutBorderRadiusStyle() {
  var _useEuiTheme2 = (0, _services.useEuiTheme)(),
    euiTheme = _useEuiTheme2.euiTheme;
  return (0, _react2.jsx)(_react2.Global, {
    styles: ":root { --euiFlyoutBorderRadius: ".concat(euiTheme.border.radius.frame, "; }")
  });
};