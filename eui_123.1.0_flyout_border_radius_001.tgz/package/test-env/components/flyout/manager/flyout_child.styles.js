"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.euiFlyoutChildStyles = void 0;
var _react = require("@emotion/react");
function _EMOTION_STRINGIFIED_CSS_ERROR__() { return "You have tried to stringify object returned from `css` function. It isn't supposed to be used directly (e.g. as value of the `className` prop), but rather handed to emotion so it can handle it (e.g. as value of `css` prop)."; } /*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */
var euiFlyoutChildStyles = exports.euiFlyoutChildStyles = {
  sideBySideChild: process.env.NODE_ENV === "production" ? {
    name: "fg0a1y-sideBySideChild",
    styles: "--euiFlyoutBorderRadius:0px!important;label:sideBySideChild;"
  } : {
    name: "fg0a1y-sideBySideChild",
    styles: "--euiFlyoutBorderRadius:0px!important;label:sideBySideChild;",
    toString: _EMOTION_STRINGIFIED_CSS_ERROR__
  }
};