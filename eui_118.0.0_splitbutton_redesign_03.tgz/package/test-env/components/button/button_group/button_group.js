"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.EuiButtonGroup = void 0;
var _extends2 = _interopRequireDefault(require("@babel/runtime/helpers/extends"));
var _objectWithoutProperties2 = _interopRequireDefault(require("@babel/runtime/helpers/objectWithoutProperties"));
var _classnames = _interopRequireDefault(require("classnames"));
var _propTypes = _interopRequireDefault(require("prop-types"));
var _react = _interopRequireDefault(require("react"));
var _services = require("../../../services");
var _accessibility = require("../../accessibility");
var _button_group_button = require("./button_group_button");
var _button_group = require("./button_group.styles");
var _react2 = require("@emotion/react");
var _excluded = ["className", "buttonSize", "color", "idSelected", "idToSelectedMap", "isDisabled", "hasAriaDisabled", "isFullWidth", "isIconOnly", "legend", "name", "onChange", "options", "type"];
/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */
var EuiButtonGroup = exports.EuiButtonGroup = function EuiButtonGroup(_ref) {
  var className = _ref.className,
    _ref$buttonSize = _ref.buttonSize,
    buttonSize = _ref$buttonSize === void 0 ? 's' : _ref$buttonSize,
    _ref$color = _ref.color,
    color = _ref$color === void 0 ? 'text' : _ref$color,
    _ref$idSelected = _ref.idSelected,
    idSelected = _ref$idSelected === void 0 ? '' : _ref$idSelected,
    _ref$idToSelectedMap = _ref.idToSelectedMap,
    idToSelectedMap = _ref$idToSelectedMap === void 0 ? {} : _ref$idToSelectedMap,
    _ref$isDisabled = _ref.isDisabled,
    isDisabled = _ref$isDisabled === void 0 ? false : _ref$isDisabled,
    _ref$hasAriaDisabled = _ref.hasAriaDisabled,
    hasAriaDisabled = _ref$hasAriaDisabled === void 0 ? false : _ref$hasAriaDisabled,
    _ref$isFullWidth = _ref.isFullWidth,
    isFullWidth = _ref$isFullWidth === void 0 ? false : _ref$isFullWidth,
    _ref$isIconOnly = _ref.isIconOnly,
    isIconOnly = _ref$isIconOnly === void 0 ? false : _ref$isIconOnly,
    legend = _ref.legend,
    name = _ref.name,
    onChange = _ref.onChange,
    _ref$options = _ref.options,
    options = _ref$options === void 0 ? [] : _ref$options,
    _ref$type = _ref.type,
    type = _ref$type === void 0 ? 'single' : _ref$type,
    rest = (0, _objectWithoutProperties2.default)(_ref, _excluded);
  var wrapperCssStyles = [_button_group.euiButtonGroupStyles.euiButtonGroup, isFullWidth && _button_group.euiButtonGroupStyles.fullWidth];
  var styles = (0, _services.useEuiMemoizedStyles)(_button_group.euiButtonGroupButtonsStyles);
  var cssStyles = [styles.euiButtonGroup__buttons, isFullWidth && styles.fullWidth, styles[buttonSize]];
  var classes = (0, _classnames.default)('euiButtonGroup', {
    'euiButtonGroup-isDisabled': isDisabled
  }, className);
  var typeIsSingle = type === 'single';
  var groupDisabledProps = {
    disabled: hasAriaDisabled ? undefined : isDisabled,
    'aria-disabled': hasAriaDisabled ? isDisabled : undefined
  };
  return (0, _react2.jsx)("fieldset", (0, _extends2.default)({
    css: wrapperCssStyles,
    className: classes
  }, rest, groupDisabledProps), (0, _react2.jsx)(_accessibility.EuiScreenReaderOnly, null, (0, _react2.jsx)("legend", null, legend)), (0, _react2.jsx)("div", {
    css: cssStyles,
    className: "euiButtonGroup__buttons"
  }, options.map(function (option) {
    return (0, _react2.jsx)(_button_group_button.EuiButtonGroupButton, (0, _extends2.default)({
      key: option.id,
      isDisabled: isDisabled,
      hasAriaDisabled: hasAriaDisabled
    }, option, {
      onClick: typeIsSingle ? function () {
        return onChange(option.id, option.value);
      } : function () {
        return onChange(option.id);
      },
      isSelected: typeIsSingle ? option.id === idSelected : idToSelectedMap[option.id],
      color: color,
      size: buttonSize,
      isIconOnly: isIconOnly
    }));
  })));
};
EuiButtonGroup.propTypes = {
  className: _propTypes.default.string,
  "aria-label": _propTypes.default.string,
  "data-test-subj": _propTypes.default.string,
  css: _propTypes.default.any,
  isDisabled: _propTypes.default.bool,
  hasAriaDisabled: _propTypes.default.bool,
  /**
       * Typical sizing is `s`. Medium `m` size should be reserved for major features.
       * `compressed` is meant to be used alongside and within compressed forms.
       */
  buttonSize: _propTypes.default.oneOf(["s", "m", "compressed"]),
  /**
       * Expands the whole group to the full width of the container.
       * Each button gets equal widths no matter the content
       */
  isFullWidth: _propTypes.default.bool,
  /**
       * Hides the label to only show the `iconType` provided by the `option`
       */
  isIconOnly: _propTypes.default.bool,
  /**
       * A hidden group title (required for accessibility)
       */
  legend: _propTypes.default.string.isRequired,
  /**
       * Any of the named color palette options.
       *
       * Do not use the following colors for standalone buttons directly,
       * they exist to serve other components:
       *  - accent
       *  - warning
       */
  color: _propTypes.default.any,
  /**
           * Default for `type` is single so it can also be excluded
           */
  /**
       * Actual type is `'single' | 'multi'`.
       * Determines how the selection of the group should be handled.
       * With `'single'` only one option can be selected at a time (similar to radio group).
       * With `'multi'` multiple options selected (similar to checkbox group).
       */
  type: _propTypes.default.oneOfType([_propTypes.default.oneOfType([_propTypes.default.oneOf(["single", "multi"]), _propTypes.default.oneOf(["single"])]), _propTypes.default.oneOf(["multi"])]),
  /**
       * An array of {@link EuiButtonGroupOptionProps}
       */
  options: _propTypes.default.arrayOf(_propTypes.default.shape({
    /**
       * Each option must have a unique `id` for maintaining selection
       */
    id: _propTypes.default.string.isRequired,
    /**
       * Each option must have a `label` even for icons which will be applied as the `aria-label`
       */
    label: _propTypes.default.node.isRequired,
    /**
       * The value of the radio input.
       */
    value: _propTypes.default.any,
    /**
       * The type of the underlying HTML button
       */
    type: _propTypes.default.any,
    /**
       * By default, will use the button text for the native browser title.
       *
       * This can be either customized or unset via `title: ''` if necessary.
       */
    title: _propTypes.default.any,
    /**
       * Optional custom tooltip content for the button
       */
    toolTipContent: _propTypes.default.node,
    /**
       * Optional props to pass to the underlying **[EuiToolTip](/#/display/tooltip)**
       */
    toolTipProps: _propTypes.default.any,
    className: _propTypes.default.string,
    "aria-label": _propTypes.default.string,
    "data-test-subj": _propTypes.default.string,
    css: _propTypes.default.any,
    /**
       * Controls the disabled behavior via the native `disabled` attribute.
       */
    isDisabled: _propTypes.default.bool,
    /**
       * NOTE: Beta feature, may be changed or removed in the future
       *
       * Changes the native `disabled` attribute to `aria-disabled` to preserve focusability.
       * This results in a semantically disabled button without the default browser handling of the disabled state.
       *
       * Use e.g. when a disabled button should have a tooltip.
       */
    hasAriaDisabled: _propTypes.default.bool
  }).isRequired).isRequired,
  /**
           * @deprecated No longer needed. You can safely remove this prop entirely
           */
  name: _propTypes.default.string,
  /**
           * Styles the selected option to look selected (usually with `fill`)
           * Required by and only used in `type='single'`.
           */
  idSelected: _propTypes.default.string,
  /**
           * Multi: Returns the `id` of the clicked option
           */
  /**
           * Single: Returns the `id` of the clicked option and the `value`
           */
  onChange: _propTypes.default.func,
  /**
           * A map of `id`s as keys with the selected boolean values.
           * Required by and only used in `type='multi'`.
           */
  idToSelectedMap: _propTypes.default.shape({})
};