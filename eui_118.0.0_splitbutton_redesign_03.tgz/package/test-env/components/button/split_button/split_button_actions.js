"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
var _typeof = require("@babel/runtime/helpers/typeof");
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.EuiSplitButtonActionSecondary = exports.EuiSplitButtonActionPrimary = void 0;
var _extends2 = _interopRequireDefault(require("@babel/runtime/helpers/extends"));
var _defineProperty2 = _interopRequireDefault(require("@babel/runtime/helpers/defineProperty"));
var _objectWithoutProperties2 = _interopRequireDefault(require("@babel/runtime/helpers/objectWithoutProperties"));
var _react = _interopRequireWildcard(require("react"));
var _propTypes = _interopRequireDefault(require("prop-types"));
var _classnames = _interopRequireDefault(require("classnames"));
var _services = require("../../../services");
var _popover = require("../../popover");
var _tool_tip = require("../../tool_tip");
var _button = require("../button");
var _button_display = require("../button_display/_button_display");
var _button_icon = require("../button_icon");
var _split_button = require("./split_button.styles");
var _split_button_context = require("./split_button_context");
var _react2 = require("@emotion/react");
var _excluded = ["className", "isIconOnly", "tooltipProps"],
  _excluded2 = ["fill", "isDisabled", "isLoading", "size"],
  _excluded3 = ["className", "popoverProps", "tooltipProps"],
  _excluded4 = ["fill", "isDisabled", "isLoading", "size"];
/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */
function _getRequireWildcardCache(e) { if ("function" != typeof WeakMap) return null; var r = new WeakMap(), t = new WeakMap(); return (_getRequireWildcardCache = function _getRequireWildcardCache(e) { return e ? t : r; })(e); }
function _interopRequireWildcard(e, r) { if (!r && e && e.__esModule) return e; if (null === e || "object" != _typeof(e) && "function" != typeof e) return { default: e }; var t = _getRequireWildcardCache(r); if (t && t.has(e)) return t.get(e); var n = { __proto__: null }, a = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var u in e) if ("default" !== u && {}.hasOwnProperty.call(e, u)) { var i = a ? Object.getOwnPropertyDescriptor(e, u) : null; i && (i.get || i.set) ? Object.defineProperty(n, u, i) : n[u] = e[u]; } return n.default = e, t && t.set(e, n), n; }
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { (0, _defineProperty2.default)(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
var EuiSplitButtonActionPrimary = exports.EuiSplitButtonActionPrimary = function EuiSplitButtonActionPrimary(_ref) {
  var className = _ref.className,
    isIconOnly = _ref.isIconOnly,
    tooltipProps = _ref.tooltipProps,
    rest = (0, _objectWithoutProperties2.default)(_ref, _excluded);
  var euiThemeContext = (0, _services.useEuiTheme)();
  var _useContext = (0, _react.useContext)(_split_button_context.EuiSplitButtonContext),
    fill = _useContext.fill,
    isDisabled = _useContext.isDisabled,
    isLoading = _useContext.isLoading,
    size = _useContext.size,
    sharedRest = (0, _objectWithoutProperties2.default)(_useContext, _excluded2);
  var _isDisabled = !!isDisabled || (0, _button_display.isButtonDisabled)(rest);
  var _isLoading = !!isLoading || !!rest.isLoading;
  var display = fill ? 'fill' : 'base';
  var classes = (0, _classnames.default)('euiSplitButtonActionPrimary', className);
  var styles = (0, _react.useMemo)(function () {
    return (0, _split_button.euiSplitButtonActionStyles)(euiThemeContext, size);
  }, [euiThemeContext, size]);
  var actionProps = _objectSpread(_objectSpread(_objectSpread({}, rest), sharedRest), {}, {
    size: size,
    isDisabled: _isDisabled,
    isLoading: _isLoading,
    css: [styles.euiSplitButtonActionPrimary],
    className: classes
  });
  var actionButtonProps = _objectSpread(_objectSpread({}, actionProps), {}, {
    fill: fill
  });
  var actionIconProps = _objectSpread(_objectSpread({}, actionProps), {}, {
    display: display
  });
  var button = isIconOnly ? (0, _react2.jsx)(_button_icon.EuiButtonIcon, actionIconProps) : (0, _react2.jsx)(_button.EuiButton, actionButtonProps);
  return tooltipProps ? (0, _react2.jsx)(_tool_tip.EuiToolTip, tooltipProps, button) : button;
};
EuiSplitButtonActionPrimary.propTypes = {
  /**
     * Controls the disabled behavior via the native `disabled` attribute.
     */
  isDisabled: _propTypes.default.bool,
  /**
     * NOTE: Beta feature, may be changed or removed in the future
     *
     * Changes the native `disabled` attribute to `aria-disabled` to preserve focusability.
     * This results in a semantically disabled button without the default browser handling of the disabled state.
     *
     * Use e.g. when a disabled button should have a tooltip.
     */
  hasAriaDisabled: _propTypes.default.bool,
  /**
     * Enables rendering an `EuiToolTip` with the passed props.
     */
  tooltipProps: _propTypes.default.any,
  /**
       * Toggles the render as `EuiButtonIcon`.
       */
  isIconOnly: _propTypes.default.bool
};
var EuiSplitButtonActionSecondary = exports.EuiSplitButtonActionSecondary = function EuiSplitButtonActionSecondary(_ref2) {
  var className = _ref2.className,
    popoverProps = _ref2.popoverProps,
    tooltipProps = _ref2.tooltipProps,
    rest = (0, _objectWithoutProperties2.default)(_ref2, _excluded3);
  var euiThemeContext = (0, _services.useEuiTheme)();
  var _useContext2 = (0, _react.useContext)(_split_button_context.EuiSplitButtonContext),
    fill = _useContext2.fill,
    isDisabled = _useContext2.isDisabled,
    isLoading = _useContext2.isLoading,
    size = _useContext2.size,
    sharedRest = (0, _objectWithoutProperties2.default)(_useContext2, _excluded4);
  var _isDisabled = !!isDisabled || (0, _button_display.isButtonDisabled)(rest);
  var _isLoading = !!isLoading || !!rest.isLoading;
  var display = fill ? 'fill' : 'base';
  var classes = (0, _classnames.default)('euiSplitButtonActionSecondary', className);
  var styles = (0, _react.useMemo)(function () {
    return (0, _split_button.euiSplitButtonActionStyles)(euiThemeContext, size);
  }, [euiThemeContext, size]);
  var actionProps = _objectSpread(_objectSpread(_objectSpread({}, rest), sharedRest), {}, {
    size: size,
    display: display,
    // enforce chevronSingleDown icon when a popover is rendered
    iconType: popoverProps != null ? 'chevronSingleDown' : rest.iconType,
    isDisabled: _isDisabled,
    isLoading: _isLoading,
    css: [styles.euiSplitButtonActionSecondary],
    className: classes
  });
  var button = (0, _react2.jsx)(_button_icon.EuiButtonIcon, actionProps);
  var action = tooltipProps ? (0, _react2.jsx)(_tool_tip.EuiToolTip, tooltipProps, button) : button;
  return popoverProps ? (0, _react2.jsx)(_popover.EuiPopover, (0, _extends2.default)({
    anchorPosition: "downCenter"
  }, popoverProps, {
    button: action
  })) : action;
};
EuiSplitButtonActionSecondary.propTypes = {
  isDisabled: _propTypes.default.bool,
  hasAriaDisabled: _propTypes.default.bool,
  /**
     * Enables rendering an `EuiToolTip` with the passed props.
     */
  tooltipProps: _propTypes.default.any,
  /**
       * Enables rendering an `EuiPopover` with the passed props.
       * When passed the secondary action icon will be fixed to `arrowDown`.
       */
  popoverProps: _propTypes.default.any
};