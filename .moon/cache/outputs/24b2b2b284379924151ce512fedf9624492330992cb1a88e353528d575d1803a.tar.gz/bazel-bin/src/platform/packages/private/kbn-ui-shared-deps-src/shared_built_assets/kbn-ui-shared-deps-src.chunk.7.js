"use strict";
(self["webpackChunk_kbnSharedDeps_"] = self["webpackChunk_kbnSharedDeps_"] || []).push([[7],{

/***/ 1240:
/*!***********************************************************************************************!*\
  !*** ../../shared/kbn-ebt-tools/src/performance_metrics/context/measure_interaction/index.ts ***!
  \***********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   measureInteraction: () => (/* binding */ measureInteraction)
/* harmony export */ });
/* harmony import */ var _kbn_timerange__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @kbn/timerange */ 1241);
/* harmony import */ var _performance_markers__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../performance_markers */ 1138);
/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the "Elastic License
 * 2.0", the "GNU Affero General Public License v3.0 only", and the "Server Side
 * Public License v 1"; you may not use this file except in compliance with, at
 * your election, the "Elastic License 2.0", the "GNU Affero General Public
 * License v3.0 only", or the "Server Side Public License, v 1".
 */



function measureInteraction(pathname) {
  performance.mark(_performance_markers__WEBPACK_IMPORTED_MODULE_1__.perfomanceMarkers.startPageChange);
  return {
    /**
     * Marks the end of the page ready state and measures the performance between the start of the page change and the end of the page ready state.
     * @param pathname - The pathname of the page.
     * @param customMetrics - Custom metrics to be included in the performance measure.
     */
    pageReady(eventData) {
      let performanceMeta;
      performance.mark(_performance_markers__WEBPACK_IMPORTED_MODULE_1__.perfomanceMarkers.endPageReady);
      if (eventData !== null && eventData !== void 0 && eventData.meta) {
        const {
          rangeFrom,
          rangeTo
        } = eventData.meta;

        // Convert the date range  to epoch timestamps (in milliseconds)
        const dateRangesInEpoch = (0,_kbn_timerange__WEBPACK_IMPORTED_MODULE_0__.getDateRange)({
          from: rangeFrom,
          to: rangeTo
        });
        performanceMeta = {
          queryRangeSecs: (0,_kbn_timerange__WEBPACK_IMPORTED_MODULE_0__.getTimeDifferenceInSeconds)(dateRangesInEpoch),
          queryOffsetSecs: rangeTo === 'now' ? 0 : (0,_kbn_timerange__WEBPACK_IMPORTED_MODULE_0__.getOffsetFromNowInSeconds)(dateRangesInEpoch.endDate)
        };
      }
      if (performance.getEntriesByName(_performance_markers__WEBPACK_IMPORTED_MODULE_1__.perfomanceMarkers.startPageChange).length > 0 && performance.getEntriesByName(_performance_markers__WEBPACK_IMPORTED_MODULE_1__.perfomanceMarkers.endPageReady).length > 0) {
        performance.measure(`[ttfmp:initial] - ${pathname}`, {
          detail: {
            eventName: 'kibana:plugin_render_time',
            type: 'kibana:performance',
            customMetrics: eventData === null || eventData === void 0 ? void 0 : eventData.customMetrics,
            meta: {
              ...performanceMeta,
              isInitialLoad: true
            }
          },
          start: _performance_markers__WEBPACK_IMPORTED_MODULE_1__.perfomanceMarkers.startPageChange,
          end: _performance_markers__WEBPACK_IMPORTED_MODULE_1__.perfomanceMarkers.endPageReady
        });

        // Clean up the marks once the measure is done
        performance.clearMarks(_performance_markers__WEBPACK_IMPORTED_MODULE_1__.perfomanceMarkers.startPageChange);
        performance.clearMarks(_performance_markers__WEBPACK_IMPORTED_MODULE_1__.perfomanceMarkers.endPageReady);
      }
      if (performance.getEntriesByName(_performance_markers__WEBPACK_IMPORTED_MODULE_1__.perfomanceMarkers.startPageRefresh).length > 0 && performance.getEntriesByName(_performance_markers__WEBPACK_IMPORTED_MODULE_1__.perfomanceMarkers.endPageReady).length > 0) {
        performance.measure(`[ttfmp:refresh] - ${pathname}`, {
          detail: {
            eventName: 'kibana:plugin_render_time',
            type: 'kibana:performance',
            customMetrics: eventData === null || eventData === void 0 ? void 0 : eventData.customMetrics,
            meta: {
              ...performanceMeta,
              isInitialLoad: false
            }
          },
          start: _performance_markers__WEBPACK_IMPORTED_MODULE_1__.perfomanceMarkers.startPageRefresh,
          end: _performance_markers__WEBPACK_IMPORTED_MODULE_1__.perfomanceMarkers.endPageReady
        });

        // // Clean up the marks once the measure is done
        performance.clearMarks(_performance_markers__WEBPACK_IMPORTED_MODULE_1__.perfomanceMarkers.startPageRefresh);
        performance.clearMarks(_performance_markers__WEBPACK_IMPORTED_MODULE_1__.perfomanceMarkers.endPageReady);
      }
    },
    pageRefreshStart() {
      performance.mark(_performance_markers__WEBPACK_IMPORTED_MODULE_1__.perfomanceMarkers.startPageRefresh);
    }
  };
}

/***/ }),

/***/ 1239:
/*!******************************************************************************************!*\
  !*** ../../shared/kbn-ebt-tools/src/performance_metrics/context/performance_context.tsx ***!
  \******************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   PerformanceContextProvider: () => (/* binding */ PerformanceContextProvider),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ 76);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _elastic_apm_rum_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @elastic/apm-rum-core */ 1109);
/* harmony import */ var react_router_dom__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-router-dom */ 974);
/* harmony import */ var _use_performance_context__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./use_performance_context */ 1137);
/* harmony import */ var _measure_interaction__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./measure_interaction */ 1240);
/* harmony import */ var _emotion_react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @emotion/react */ 90);
/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the "Elastic License
 * 2.0", the "GNU Affero General Public License v3.0 only", and the "Server Side
 * Public License v 1"; you may not use this file except in compliance with, at
 * your election, the "Elastic License 2.0", the "GNU Affero General Public
 * License v3.0 only", or the "Server Side Public License, v 1".
 */







function PerformanceContextProvider({
  children
}) {
  const [isRendered, setIsRendered] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
  const location = (0,react_router_dom__WEBPACK_IMPORTED_MODULE_2__.useLocation)();
  const interaction = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(() => (0,_measure_interaction__WEBPACK_IMPORTED_MODULE_4__.measureInteraction)(location.pathname), [location.pathname]);
  react__WEBPACK_IMPORTED_MODULE_0___default().useEffect(() => {
    (0,_elastic_apm_rum_core__WEBPACK_IMPORTED_MODULE_1__.afterFrame)(() => {
      setIsRendered(true);
    });
    return () => {
      setIsRendered(false);
      performance.clearMeasures(location.pathname);
    };
  }, [location.pathname]);
  const api = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(() => ({
    onPageReady(eventData) {
      if (isRendered) {
        interaction.pageReady(eventData);
      }
    },
    onPageRefreshStart() {
      interaction.pageRefreshStart();
    }
  }), [isRendered, interaction]);
  return (0,_emotion_react__WEBPACK_IMPORTED_MODULE_5__.jsx)(_use_performance_context__WEBPACK_IMPORTED_MODULE_3__.PerformanceContext.Provider, {
    value: api
  }, children);
}
// dynamic import
// eslint-disable-next-line import/no-default-export
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (PerformanceContextProvider);

/***/ }),

/***/ 1241:
/*!*******************************************!*\
  !*** ../../shared/kbn-timerange/index.ts ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   getDateISORange: () => (/* reexport safe */ _src__WEBPACK_IMPORTED_MODULE_0__.getDateISORange),
/* harmony export */   getDateRange: () => (/* reexport safe */ _src__WEBPACK_IMPORTED_MODULE_0__.getDateRange),
/* harmony export */   getOffsetFromNowInSeconds: () => (/* reexport safe */ _src__WEBPACK_IMPORTED_MODULE_0__.getOffsetFromNowInSeconds),
/* harmony export */   getTimeDifferenceInSeconds: () => (/* reexport safe */ _src__WEBPACK_IMPORTED_MODULE_0__.getTimeDifferenceInSeconds)
/* harmony export */ });
/* harmony import */ var _src__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./src */ 1242);
/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the "Elastic License
 * 2.0", the "GNU Affero General Public License v3.0 only", and the "Server Side
 * Public License v 1"; you may not use this file except in compliance with, at
 * your election, the "Elastic License 2.0", the "GNU Affero General Public
 * License v3.0 only", or the "Server Side Public License, v 1".
 */



/***/ }),

/***/ 1242:
/*!***********************************************!*\
  !*** ../../shared/kbn-timerange/src/index.ts ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   getDateISORange: () => (/* binding */ getDateISORange),
/* harmony export */   getDateRange: () => (/* binding */ getDateRange),
/* harmony export */   getOffsetFromNowInSeconds: () => (/* binding */ getOffsetFromNowInSeconds),
/* harmony export */   getTimeDifferenceInSeconds: () => (/* binding */ getTimeDifferenceInSeconds)
/* harmony export */ });
/* harmony import */ var _kbn_datemath__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @kbn/datemath */ 983);
/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the "Elastic License
 * 2.0", the "GNU Affero General Public License v3.0 only", and the "Server Side
 * Public License v 1"; you may not use this file except in compliance with, at
 * your election, the "Elastic License 2.0", the "GNU Affero General Public
 * License v3.0 only", or the "Server Side Public License, v 1".
 */


function getParsedDate(rawDate, options = {}) {
  if (rawDate) {
    const parsed = _kbn_datemath__WEBPACK_IMPORTED_MODULE_0__["default"].parse(rawDate, options);
    if (parsed && parsed.isValid()) {
      return parsed.toDate();
    }
  }
}
function getRanges({
  from,
  to
}) {
  const start = getParsedDate(from);
  const end = getParsedDate(to, {
    roundUp: true
  });
  if (!start || !end || start > end) {
    throw new Error(`Invalid Dates: from: ${from}, to: ${to}`);
  }
  const startDate = start.toISOString();
  const endDate = end.toISOString();
  return {
    startDate,
    endDate
  };
}
function getDateRange({
  from,
  to
}) {
  const {
    startDate,
    endDate
  } = getRanges({
    from,
    to
  });
  return {
    startDate: new Date(startDate).getTime(),
    endDate: new Date(endDate).getTime()
  };
}
function getDateISORange({
  from,
  to
}) {
  const {
    startDate,
    endDate
  } = getRanges({
    from,
    to
  });
  return {
    startDate,
    endDate
  };
}
function getTimeDifferenceInSeconds({
  startDate,
  endDate
}) {
  if (!startDate || !endDate || startDate > endDate) {
    throw new Error(`Invalid Dates: from: ${startDate}, to: ${endDate}`);
  }
  const rangeInSeconds = (endDate - startDate) / 1000;
  return Math.round(rangeInSeconds);
}
function getOffsetFromNowInSeconds(epochDate) {
  const now = Date.now();
  return Math.round((epochDate - now) / 1000);
}

/***/ })

}]);
//# sourceMappingURL=kbn-ui-shared-deps-src.chunk.7.js.map