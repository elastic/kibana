"use strict";
(self["webpackChunk_kbnSharedDeps_"] = self["webpackChunk_kbnSharedDeps_"] || []).push([[2],{

/***/ 1181:
/*!************************************************************************!*\
  !*** ../../../../../node_modules/monaco-languageserver-types/index.js ***!
  \************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   fromCodeAction: () => (/* reexport safe */ _lib_codeAction_js__WEBPACK_IMPORTED_MODULE_0__.fromCodeAction),
/* harmony export */   fromCodeActionContext: () => (/* reexport safe */ _lib_codeActionContext_js__WEBPACK_IMPORTED_MODULE_1__.fromCodeActionContext),
/* harmony export */   fromCodeActionTriggerType: () => (/* reexport safe */ _lib_codeActionTriggerType_js__WEBPACK_IMPORTED_MODULE_2__.fromCodeActionTriggerType),
/* harmony export */   fromCodeLens: () => (/* reexport safe */ _lib_codeLens_js__WEBPACK_IMPORTED_MODULE_3__.fromCodeLens),
/* harmony export */   fromColor: () => (/* reexport safe */ _lib_color_js__WEBPACK_IMPORTED_MODULE_4__.fromColor),
/* harmony export */   fromColorInformation: () => (/* reexport safe */ _lib_colorInformation_js__WEBPACK_IMPORTED_MODULE_5__.fromColorInformation),
/* harmony export */   fromColorPresentation: () => (/* reexport safe */ _lib_colorPresentation_js__WEBPACK_IMPORTED_MODULE_6__.fromColorPresentation),
/* harmony export */   fromCommand: () => (/* reexport safe */ _lib_command_js__WEBPACK_IMPORTED_MODULE_7__.fromCommand),
/* harmony export */   fromCompletionContext: () => (/* reexport safe */ _lib_completionContext_js__WEBPACK_IMPORTED_MODULE_8__.fromCompletionContext),
/* harmony export */   fromCompletionItem: () => (/* reexport safe */ _lib_completionItem_js__WEBPACK_IMPORTED_MODULE_9__.fromCompletionItem),
/* harmony export */   fromCompletionItemKind: () => (/* reexport safe */ _lib_completionItemKind_js__WEBPACK_IMPORTED_MODULE_10__.fromCompletionItemKind),
/* harmony export */   fromCompletionItemTag: () => (/* reexport safe */ _lib_completionItemTag_js__WEBPACK_IMPORTED_MODULE_11__.fromCompletionItemTag),
/* harmony export */   fromCompletionList: () => (/* reexport safe */ _lib_completionList_js__WEBPACK_IMPORTED_MODULE_12__.fromCompletionList),
/* harmony export */   fromCompletionTriggerKind: () => (/* reexport safe */ _lib_completionTriggerKind_js__WEBPACK_IMPORTED_MODULE_13__.fromCompletionTriggerKind),
/* harmony export */   fromDefinition: () => (/* reexport safe */ _lib_definition_js__WEBPACK_IMPORTED_MODULE_14__.fromDefinition),
/* harmony export */   fromDocumentHighlight: () => (/* reexport safe */ _lib_documentHighlight_js__WEBPACK_IMPORTED_MODULE_15__.fromDocumentHighlight),
/* harmony export */   fromDocumentHighlightKind: () => (/* reexport safe */ _lib_documentHighlightKind_js__WEBPACK_IMPORTED_MODULE_16__.fromDocumentHighlightKind),
/* harmony export */   fromDocumentSymbol: () => (/* reexport safe */ _lib_documentSymbol_js__WEBPACK_IMPORTED_MODULE_17__.fromDocumentSymbol),
/* harmony export */   fromFoldingRange: () => (/* reexport safe */ _lib_foldingRange_js__WEBPACK_IMPORTED_MODULE_18__.fromFoldingRange),
/* harmony export */   fromFormattingOptions: () => (/* reexport safe */ _lib_formattingOptions_js__WEBPACK_IMPORTED_MODULE_19__.fromFormattingOptions),
/* harmony export */   fromHover: () => (/* reexport safe */ _lib_hover_js__WEBPACK_IMPORTED_MODULE_20__.fromHover),
/* harmony export */   fromInlayHint: () => (/* reexport safe */ _lib_inlayHint_js__WEBPACK_IMPORTED_MODULE_21__.fromInlayHint),
/* harmony export */   fromInlayHintKind: () => (/* reexport safe */ _lib_inlayHintKind_js__WEBPACK_IMPORTED_MODULE_22__.fromInlayHintKind),
/* harmony export */   fromInlayHintLabelPart: () => (/* reexport safe */ _lib_inlayHintLabelPart_js__WEBPACK_IMPORTED_MODULE_23__.fromInlayHintLabelPart),
/* harmony export */   fromLink: () => (/* reexport safe */ _lib_link_js__WEBPACK_IMPORTED_MODULE_24__.fromLink),
/* harmony export */   fromLocation: () => (/* reexport safe */ _lib_location_js__WEBPACK_IMPORTED_MODULE_25__.fromLocation),
/* harmony export */   fromLocationLink: () => (/* reexport safe */ _lib_locationLink_js__WEBPACK_IMPORTED_MODULE_26__.fromLocationLink),
/* harmony export */   fromMarkdownString: () => (/* reexport safe */ _lib_markdownString_js__WEBPACK_IMPORTED_MODULE_27__.fromMarkdownString),
/* harmony export */   fromMarkerData: () => (/* reexport safe */ _lib_markerData_js__WEBPACK_IMPORTED_MODULE_28__.fromMarkerData),
/* harmony export */   fromMarkerSeverity: () => (/* reexport safe */ _lib_markerSeverity_js__WEBPACK_IMPORTED_MODULE_29__.fromMarkerSeverity),
/* harmony export */   fromMarkerTag: () => (/* reexport safe */ _lib_markerTag_js__WEBPACK_IMPORTED_MODULE_30__.fromMarkerTag),
/* harmony export */   fromParameterInformation: () => (/* reexport safe */ _lib_parameterInformation_js__WEBPACK_IMPORTED_MODULE_32__.fromParameterInformation),
/* harmony export */   fromPosition: () => (/* reexport safe */ _lib_position_js__WEBPACK_IMPORTED_MODULE_33__.fromPosition),
/* harmony export */   fromRange: () => (/* reexport safe */ _lib_range_js__WEBPACK_IMPORTED_MODULE_34__.fromRange),
/* harmony export */   fromRelatedInformation: () => (/* reexport safe */ _lib_relatedInformation_js__WEBPACK_IMPORTED_MODULE_35__.fromRelatedInformation),
/* harmony export */   fromSelectionRange: () => (/* reexport safe */ _lib_selectionRange_js__WEBPACK_IMPORTED_MODULE_36__.fromSelectionRange),
/* harmony export */   fromSignatureHelp: () => (/* reexport safe */ _lib_signatureHelp_js__WEBPACK_IMPORTED_MODULE_38__.fromSignatureHelp),
/* harmony export */   fromSignatureHelpContext: () => (/* reexport safe */ _lib_signatureHelpContext_js__WEBPACK_IMPORTED_MODULE_37__.fromSignatureHelpContext),
/* harmony export */   fromSignatureHelpTriggerKind: () => (/* reexport safe */ _lib_signatureHelpTriggerKind_js__WEBPACK_IMPORTED_MODULE_39__.fromSignatureHelpTriggerKind),
/* harmony export */   fromSignatureInformation: () => (/* reexport safe */ _lib_signatureInformation_js__WEBPACK_IMPORTED_MODULE_40__.fromSignatureInformation),
/* harmony export */   fromSingleEditOperation: () => (/* reexport safe */ _lib_singleEditOperation_js__WEBPACK_IMPORTED_MODULE_41__.fromSingleEditOperation),
/* harmony export */   fromSymbolKind: () => (/* reexport safe */ _lib_symbolKind_js__WEBPACK_IMPORTED_MODULE_42__.fromSymbolKind),
/* harmony export */   fromSymbolTag: () => (/* reexport safe */ _lib_symbolTag_js__WEBPACK_IMPORTED_MODULE_43__.fromSymbolTag),
/* harmony export */   fromTextEdit: () => (/* reexport safe */ _lib_textEdit_js__WEBPACK_IMPORTED_MODULE_44__.fromTextEdit),
/* harmony export */   fromWorkspaceEdit: () => (/* reexport safe */ _lib_workspaceEdit_js__WEBPACK_IMPORTED_MODULE_45__.fromWorkspaceEdit),
/* harmony export */   fromWorkspaceFileEdit: () => (/* reexport safe */ _lib_workspaceFileEdit_js__WEBPACK_IMPORTED_MODULE_46__.fromWorkspaceFileEdit),
/* harmony export */   fromWorkspaceFileEditOptions: () => (/* reexport safe */ _lib_workspaceFileEditOptions_js__WEBPACK_IMPORTED_MODULE_47__.fromWorkspaceFileEditOptions),
/* harmony export */   setMonaco: () => (/* reexport safe */ _lib_monaco_js__WEBPACK_IMPORTED_MODULE_31__.setMonaco),
/* harmony export */   toCodeAction: () => (/* reexport safe */ _lib_codeAction_js__WEBPACK_IMPORTED_MODULE_0__.toCodeAction),
/* harmony export */   toCodeActionContext: () => (/* reexport safe */ _lib_codeActionContext_js__WEBPACK_IMPORTED_MODULE_1__.toCodeActionContext),
/* harmony export */   toCodeActionTriggerType: () => (/* reexport safe */ _lib_codeActionTriggerType_js__WEBPACK_IMPORTED_MODULE_2__.toCodeActionTriggerType),
/* harmony export */   toCodeLens: () => (/* reexport safe */ _lib_codeLens_js__WEBPACK_IMPORTED_MODULE_3__.toCodeLens),
/* harmony export */   toColor: () => (/* reexport safe */ _lib_color_js__WEBPACK_IMPORTED_MODULE_4__.toColor),
/* harmony export */   toColorInformation: () => (/* reexport safe */ _lib_colorInformation_js__WEBPACK_IMPORTED_MODULE_5__.toColorInformation),
/* harmony export */   toColorPresentation: () => (/* reexport safe */ _lib_colorPresentation_js__WEBPACK_IMPORTED_MODULE_6__.toColorPresentation),
/* harmony export */   toCommand: () => (/* reexport safe */ _lib_command_js__WEBPACK_IMPORTED_MODULE_7__.toCommand),
/* harmony export */   toCompletionContext: () => (/* reexport safe */ _lib_completionContext_js__WEBPACK_IMPORTED_MODULE_8__.toCompletionContext),
/* harmony export */   toCompletionItem: () => (/* reexport safe */ _lib_completionItem_js__WEBPACK_IMPORTED_MODULE_9__.toCompletionItem),
/* harmony export */   toCompletionItemKind: () => (/* reexport safe */ _lib_completionItemKind_js__WEBPACK_IMPORTED_MODULE_10__.toCompletionItemKind),
/* harmony export */   toCompletionItemTag: () => (/* reexport safe */ _lib_completionItemTag_js__WEBPACK_IMPORTED_MODULE_11__.toCompletionItemTag),
/* harmony export */   toCompletionList: () => (/* reexport safe */ _lib_completionList_js__WEBPACK_IMPORTED_MODULE_12__.toCompletionList),
/* harmony export */   toCompletionTriggerKind: () => (/* reexport safe */ _lib_completionTriggerKind_js__WEBPACK_IMPORTED_MODULE_13__.toCompletionTriggerKind),
/* harmony export */   toDefinition: () => (/* reexport safe */ _lib_definition_js__WEBPACK_IMPORTED_MODULE_14__.toDefinition),
/* harmony export */   toDocumentHighlight: () => (/* reexport safe */ _lib_documentHighlight_js__WEBPACK_IMPORTED_MODULE_15__.toDocumentHighlight),
/* harmony export */   toDocumentHighlightKind: () => (/* reexport safe */ _lib_documentHighlightKind_js__WEBPACK_IMPORTED_MODULE_16__.toDocumentHighlightKind),
/* harmony export */   toDocumentSymbol: () => (/* reexport safe */ _lib_documentSymbol_js__WEBPACK_IMPORTED_MODULE_17__.toDocumentSymbol),
/* harmony export */   toFoldingRange: () => (/* reexport safe */ _lib_foldingRange_js__WEBPACK_IMPORTED_MODULE_18__.toFoldingRange),
/* harmony export */   toFormattingOptions: () => (/* reexport safe */ _lib_formattingOptions_js__WEBPACK_IMPORTED_MODULE_19__.toFormattingOptions),
/* harmony export */   toHover: () => (/* reexport safe */ _lib_hover_js__WEBPACK_IMPORTED_MODULE_20__.toHover),
/* harmony export */   toInlayHint: () => (/* reexport safe */ _lib_inlayHint_js__WEBPACK_IMPORTED_MODULE_21__.toInlayHint),
/* harmony export */   toInlayHintKind: () => (/* reexport safe */ _lib_inlayHintKind_js__WEBPACK_IMPORTED_MODULE_22__.toInlayHintKind),
/* harmony export */   toInlayHintLabelPart: () => (/* reexport safe */ _lib_inlayHintLabelPart_js__WEBPACK_IMPORTED_MODULE_23__.toInlayHintLabelPart),
/* harmony export */   toLink: () => (/* reexport safe */ _lib_link_js__WEBPACK_IMPORTED_MODULE_24__.toLink),
/* harmony export */   toLocation: () => (/* reexport safe */ _lib_location_js__WEBPACK_IMPORTED_MODULE_25__.toLocation),
/* harmony export */   toLocationLink: () => (/* reexport safe */ _lib_locationLink_js__WEBPACK_IMPORTED_MODULE_26__.toLocationLink),
/* harmony export */   toMarkdownString: () => (/* reexport safe */ _lib_markdownString_js__WEBPACK_IMPORTED_MODULE_27__.toMarkdownString),
/* harmony export */   toMarkerData: () => (/* reexport safe */ _lib_markerData_js__WEBPACK_IMPORTED_MODULE_28__.toMarkerData),
/* harmony export */   toMarkerSeverity: () => (/* reexport safe */ _lib_markerSeverity_js__WEBPACK_IMPORTED_MODULE_29__.toMarkerSeverity),
/* harmony export */   toMarkerTag: () => (/* reexport safe */ _lib_markerTag_js__WEBPACK_IMPORTED_MODULE_30__.toMarkerTag),
/* harmony export */   toParameterInformation: () => (/* reexport safe */ _lib_parameterInformation_js__WEBPACK_IMPORTED_MODULE_32__.toParameterInformation),
/* harmony export */   toPosition: () => (/* reexport safe */ _lib_position_js__WEBPACK_IMPORTED_MODULE_33__.toPosition),
/* harmony export */   toRange: () => (/* reexport safe */ _lib_range_js__WEBPACK_IMPORTED_MODULE_34__.toRange),
/* harmony export */   toRelatedInformation: () => (/* reexport safe */ _lib_relatedInformation_js__WEBPACK_IMPORTED_MODULE_35__.toRelatedInformation),
/* harmony export */   toSelectionRange: () => (/* reexport safe */ _lib_selectionRange_js__WEBPACK_IMPORTED_MODULE_36__.toSelectionRange),
/* harmony export */   toSignatureHelp: () => (/* reexport safe */ _lib_signatureHelp_js__WEBPACK_IMPORTED_MODULE_38__.toSignatureHelp),
/* harmony export */   toSignatureHelpContext: () => (/* reexport safe */ _lib_signatureHelpContext_js__WEBPACK_IMPORTED_MODULE_37__.toSignatureHelpContext),
/* harmony export */   toSignatureHelpTriggerKind: () => (/* reexport safe */ _lib_signatureHelpTriggerKind_js__WEBPACK_IMPORTED_MODULE_39__.toSignatureHelpTriggerKind),
/* harmony export */   toSignatureInformation: () => (/* reexport safe */ _lib_signatureInformation_js__WEBPACK_IMPORTED_MODULE_40__.toSignatureInformation),
/* harmony export */   toSingleEditOperation: () => (/* reexport safe */ _lib_singleEditOperation_js__WEBPACK_IMPORTED_MODULE_41__.toSingleEditOperation),
/* harmony export */   toSymbolKind: () => (/* reexport safe */ _lib_symbolKind_js__WEBPACK_IMPORTED_MODULE_42__.toSymbolKind),
/* harmony export */   toSymbolTag: () => (/* reexport safe */ _lib_symbolTag_js__WEBPACK_IMPORTED_MODULE_43__.toSymbolTag),
/* harmony export */   toTextEdit: () => (/* reexport safe */ _lib_textEdit_js__WEBPACK_IMPORTED_MODULE_44__.toTextEdit),
/* harmony export */   toWorkspaceEdit: () => (/* reexport safe */ _lib_workspaceEdit_js__WEBPACK_IMPORTED_MODULE_45__.toWorkspaceEdit),
/* harmony export */   toWorkspaceFileEdit: () => (/* reexport safe */ _lib_workspaceFileEdit_js__WEBPACK_IMPORTED_MODULE_46__.toWorkspaceFileEdit),
/* harmony export */   toWorkspaceFileEditOptions: () => (/* reexport safe */ _lib_workspaceFileEditOptions_js__WEBPACK_IMPORTED_MODULE_47__.toWorkspaceFileEditOptions)
/* harmony export */ });
/* harmony import */ var _lib_codeAction_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./lib/codeAction.js */ 1182);
/* harmony import */ var _lib_codeActionContext_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./lib/codeActionContext.js */ 1193);
/* harmony import */ var _lib_codeActionTriggerType_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./lib/codeActionTriggerType.js */ 1194);
/* harmony import */ var _lib_codeLens_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./lib/codeLens.js */ 1195);
/* harmony import */ var _lib_color_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./lib/color.js */ 1197);
/* harmony import */ var _lib_colorInformation_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./lib/colorInformation.js */ 1198);
/* harmony import */ var _lib_colorPresentation_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./lib/colorPresentation.js */ 1199);
/* harmony import */ var _lib_command_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./lib/command.js */ 1196);
/* harmony import */ var _lib_completionContext_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./lib/completionContext.js */ 1200);
/* harmony import */ var _lib_completionItem_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./lib/completionItem.js */ 1202);
/* harmony import */ var _lib_completionItemKind_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./lib/completionItemKind.js */ 1203);
/* harmony import */ var _lib_completionItemTag_js__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./lib/completionItemTag.js */ 1204);
/* harmony import */ var _lib_completionList_js__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./lib/completionList.js */ 1207);
/* harmony import */ var _lib_completionTriggerKind_js__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./lib/completionTriggerKind.js */ 1201);
/* harmony import */ var _lib_definition_js__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./lib/definition.js */ 1208);
/* harmony import */ var _lib_documentHighlight_js__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./lib/documentHighlight.js */ 1210);
/* harmony import */ var _lib_documentHighlightKind_js__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ./lib/documentHighlightKind.js */ 1211);
/* harmony import */ var _lib_documentSymbol_js__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ./lib/documentSymbol.js */ 1212);
/* harmony import */ var _lib_foldingRange_js__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ./lib/foldingRange.js */ 1215);
/* harmony import */ var _lib_formattingOptions_js__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ./lib/formattingOptions.js */ 1216);
/* harmony import */ var _lib_hover_js__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! ./lib/hover.js */ 1217);
/* harmony import */ var _lib_inlayHint_js__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! ./lib/inlayHint.js */ 1218);
/* harmony import */ var _lib_inlayHintKind_js__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! ./lib/inlayHintKind.js */ 1219);
/* harmony import */ var _lib_inlayHintLabelPart_js__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! ./lib/inlayHintLabelPart.js */ 1220);
/* harmony import */ var _lib_link_js__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! ./lib/link.js */ 1222);
/* harmony import */ var _lib_location_js__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! ./lib/location.js */ 1209);
/* harmony import */ var _lib_locationLink_js__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! ./lib/locationLink.js */ 1223);
/* harmony import */ var _lib_markdownString_js__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! ./lib/markdownString.js */ 1205);
/* harmony import */ var _lib_markerData_js__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! ./lib/markerData.js */ 1183);
/* harmony import */ var _lib_markerSeverity_js__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(/*! ./lib/markerSeverity.js */ 1184);
/* harmony import */ var _lib_markerTag_js__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(/*! ./lib/markerTag.js */ 1186);
/* harmony import */ var _lib_monaco_js__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(/*! ./lib/monaco.js */ 1185);
/* harmony import */ var _lib_parameterInformation_js__WEBPACK_IMPORTED_MODULE_32__ = __webpack_require__(/*! ./lib/parameterInformation.js */ 1224);
/* harmony import */ var _lib_position_js__WEBPACK_IMPORTED_MODULE_33__ = __webpack_require__(/*! ./lib/position.js */ 1221);
/* harmony import */ var _lib_range_js__WEBPACK_IMPORTED_MODULE_34__ = __webpack_require__(/*! ./lib/range.js */ 1187);
/* harmony import */ var _lib_relatedInformation_js__WEBPACK_IMPORTED_MODULE_35__ = __webpack_require__(/*! ./lib/relatedInformation.js */ 1188);
/* harmony import */ var _lib_selectionRange_js__WEBPACK_IMPORTED_MODULE_36__ = __webpack_require__(/*! ./lib/selectionRange.js */ 1225);
/* harmony import */ var _lib_signatureHelpContext_js__WEBPACK_IMPORTED_MODULE_37__ = __webpack_require__(/*! ./lib/signatureHelpContext.js */ 1226);
/* harmony import */ var _lib_signatureHelp_js__WEBPACK_IMPORTED_MODULE_38__ = __webpack_require__(/*! ./lib/signatureHelp.js */ 1227);
/* harmony import */ var _lib_signatureHelpTriggerKind_js__WEBPACK_IMPORTED_MODULE_39__ = __webpack_require__(/*! ./lib/signatureHelpTriggerKind.js */ 1229);
/* harmony import */ var _lib_signatureInformation_js__WEBPACK_IMPORTED_MODULE_40__ = __webpack_require__(/*! ./lib/signatureInformation.js */ 1228);
/* harmony import */ var _lib_singleEditOperation_js__WEBPACK_IMPORTED_MODULE_41__ = __webpack_require__(/*! ./lib/singleEditOperation.js */ 1206);
/* harmony import */ var _lib_symbolKind_js__WEBPACK_IMPORTED_MODULE_42__ = __webpack_require__(/*! ./lib/symbolKind.js */ 1213);
/* harmony import */ var _lib_symbolTag_js__WEBPACK_IMPORTED_MODULE_43__ = __webpack_require__(/*! ./lib/symbolTag.js */ 1214);
/* harmony import */ var _lib_textEdit_js__WEBPACK_IMPORTED_MODULE_44__ = __webpack_require__(/*! ./lib/textEdit.js */ 1190);
/* harmony import */ var _lib_workspaceEdit_js__WEBPACK_IMPORTED_MODULE_45__ = __webpack_require__(/*! ./lib/workspaceEdit.js */ 1189);
/* harmony import */ var _lib_workspaceFileEdit_js__WEBPACK_IMPORTED_MODULE_46__ = __webpack_require__(/*! ./lib/workspaceFileEdit.js */ 1191);
/* harmony import */ var _lib_workspaceFileEditOptions_js__WEBPACK_IMPORTED_MODULE_47__ = __webpack_require__(/*! ./lib/workspaceFileEditOptions.js */ 1192);

















































/***/ }),

/***/ 1182:
/*!*********************************************************************************!*\
  !*** ../../../../../node_modules/monaco-languageserver-types/lib/codeAction.js ***!
  \*********************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   fromCodeAction: () => (/* binding */ fromCodeAction),
/* harmony export */   toCodeAction: () => (/* binding */ toCodeAction)
/* harmony export */ });
/* harmony import */ var _markerData_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./markerData.js */ 1183);
/* harmony import */ var _workspaceEdit_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./workspaceEdit.js */ 1189);


/**
 * Convert a Monaco editor code action to an LSP code action.
 *
 * @param codeAction The Monaco code action to convert.
 * @returns The code action as an LSP code action.
 */
function fromCodeAction(codeAction) {
  const result = {
    title: codeAction.title
  };
  if (codeAction.diagnostics) {
    result.diagnostics = codeAction.diagnostics.map(_markerData_js__WEBPACK_IMPORTED_MODULE_0__.fromMarkerData);
  }
  if (codeAction.disabled != null) {
    result.disabled = {
      reason: codeAction.disabled
    };
  }
  if (codeAction.edit) {
    result.edit = (0,_workspaceEdit_js__WEBPACK_IMPORTED_MODULE_1__.fromWorkspaceEdit)(codeAction.edit);
  }
  if (codeAction.isPreferred != null) {
    result.isPreferred = codeAction.isPreferred;
  }
  if (codeAction.kind) {
    result.kind = codeAction.kind;
  }
  return result;
}
/**
 * Convert an LSP code action to a Monaco editor code action.
 *
 * @param codeAction The LSP code action to convert.
 * @param options Additional options needed to construct the Monaco code action.
 * @returns The code action as Monaco editor code action.
 */
function toCodeAction(codeAction, options) {
  const result = {
    title: codeAction.title,
    isPreferred: codeAction.isPreferred
  };
  if (codeAction.diagnostics) {
    result.diagnostics = codeAction.diagnostics.map(diagnostic => (0,_markerData_js__WEBPACK_IMPORTED_MODULE_0__.toMarkerData)(diagnostic, options));
  }
  if (codeAction.disabled) {
    result.disabled = codeAction.disabled.reason;
  }
  if (codeAction.edit) {
    result.edit = (0,_workspaceEdit_js__WEBPACK_IMPORTED_MODULE_1__.toWorkspaceEdit)(codeAction.edit);
  }
  if (codeAction.isPreferred != null) {
    result.isPreferred = codeAction.isPreferred;
  }
  if (codeAction.kind) {
    result.kind = codeAction.kind;
  }
  return result;
}

/***/ }),

/***/ 1193:
/*!****************************************************************************************!*\
  !*** ../../../../../node_modules/monaco-languageserver-types/lib/codeActionContext.js ***!
  \****************************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   fromCodeActionContext: () => (/* binding */ fromCodeActionContext),
/* harmony export */   toCodeActionContext: () => (/* binding */ toCodeActionContext)
/* harmony export */ });
/* harmony import */ var _codeActionTriggerType_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./codeActionTriggerType.js */ 1194);
/* harmony import */ var _markerData_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./markerData.js */ 1183);
/* harmony import */ var _monaco_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./monaco.js */ 1185);



/**
 * Convert a Monaco editor code action context to an LSP code action context.
 *
 * @param codeActionContext The Monaco code action context to convert.
 * @returns The code action context as an LSP code action context.
 */
function fromCodeActionContext(codeActionContext) {
  const result = {
    diagnostics: codeActionContext.markers.map(_markerData_js__WEBPACK_IMPORTED_MODULE_1__.fromMarkerData),
    triggerKind: (0,_codeActionTriggerType_js__WEBPACK_IMPORTED_MODULE_0__.fromCodeActionTriggerType)(codeActionContext.trigger)
  };
  if (codeActionContext.only != null) {
    result.only = [codeActionContext.only];
  }
  return result;
}
/**
 * Convert an LSP code action context to a Monaco editor code action context.
 *
 * @param codeActionContext The LSP code action context to convert.
 * @param options Additional options needed to construct the Monaco code action context.
 * @returns The code action context as Monaco editor code action context.
 */
function toCodeActionContext(codeActionContext, options) {
  var _a, _b;
  const {
    CodeActionTriggerType
  } = (0,_monaco_js__WEBPACK_IMPORTED_MODULE_2__.getMonaco)().languages;
  const result = {
    markers: codeActionContext.diagnostics.map(diagnostic => (0,_markerData_js__WEBPACK_IMPORTED_MODULE_1__.toMarkerData)(diagnostic, options)),
    trigger: (0,_codeActionTriggerType_js__WEBPACK_IMPORTED_MODULE_0__.fromCodeActionTriggerType)((_a = codeActionContext.triggerKind) !== null && _a !== void 0 ? _a : CodeActionTriggerType.Auto)
  };
  if ((_b = codeActionContext.only) === null || _b === void 0 ? void 0 : _b[0]) {
    result.only = codeActionContext.only[0];
  }
  return result;
}

/***/ }),

/***/ 1194:
/*!********************************************************************************************!*\
  !*** ../../../../../node_modules/monaco-languageserver-types/lib/codeActionTriggerType.js ***!
  \********************************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   fromCodeActionTriggerType: () => (/* binding */ fromCodeActionTriggerType),
/* harmony export */   toCodeActionTriggerType: () => (/* binding */ toCodeActionTriggerType)
/* harmony export */ });
/**
 * Convert a Monaco editor code action trigger type to an LSP completion item kind.
 *
 * @param type The Monaco code action trigger type to convert.
 * @returns The code action trigger type as an LSP completion item kind.
 */
function fromCodeActionTriggerType(type) {
  return type;
}
/**
 * Convert an LSP completion item kind to a Monaco editor code action trigger type.
 *
 * @param kind The LSP completion item kind to convert.
 * @returns The completion item kind as Monaco editor code action trigger type.
 */
function toCodeActionTriggerType(kind) {
  return kind;
}

/***/ }),

/***/ 1195:
/*!*******************************************************************************!*\
  !*** ../../../../../node_modules/monaco-languageserver-types/lib/codeLens.js ***!
  \*******************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   fromCodeLens: () => (/* binding */ fromCodeLens),
/* harmony export */   toCodeLens: () => (/* binding */ toCodeLens)
/* harmony export */ });
/* harmony import */ var _command_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./command.js */ 1196);
/* harmony import */ var _range_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./range.js */ 1187);


/**
 * Convert a Monaco editor code lens to an LSP code lens.
 *
 * @param codeLens The Monaco code lens to convert.
 * @returns The code lens as an LSP code lens.
 */
function fromCodeLens(codeLens) {
  const result = {
    range: (0,_range_js__WEBPACK_IMPORTED_MODULE_1__.fromRange)(codeLens.range)
  };
  if (codeLens.command) {
    result.command = (0,_command_js__WEBPACK_IMPORTED_MODULE_0__.fromCommand)(codeLens.command);
  }
  return result;
}
/**
 * Convert an LSP code lens to a Monaco editor code lens.
 *
 * @param codeLens The LSP code lens to convert.
 * @returns The code lens as Monaco editor code lens.
 */
function toCodeLens(codeLens) {
  const result = {
    range: (0,_range_js__WEBPACK_IMPORTED_MODULE_1__.toRange)(codeLens.range)
  };
  if (codeLens.command) {
    result.command = (0,_command_js__WEBPACK_IMPORTED_MODULE_0__.toCommand)(codeLens.command);
  }
  return result;
}

/***/ }),

/***/ 1197:
/*!****************************************************************************!*\
  !*** ../../../../../node_modules/monaco-languageserver-types/lib/color.js ***!
  \****************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   fromColor: () => (/* binding */ fromColor),
/* harmony export */   toColor: () => (/* binding */ toColor)
/* harmony export */ });
/**
 * Convert a Monaco editor color to an LSP color.
 *
 * @param color The Monaco color to convert.
 * @returns The color as an LSP color.
 */
function fromColor(color) {
  return {
    red: color.red,
    blue: color.blue,
    green: color.green,
    alpha: color.alpha
  };
}
/**
 * Convert an LSP color to a Monaco editor color.
 *
 * @param color The LSP color to convert.
 * @returns The color as Monaco editor color.
 */
function toColor(color) {
  return {
    red: color.red,
    blue: color.blue,
    green: color.green,
    alpha: color.alpha
  };
}

/***/ }),

/***/ 1198:
/*!***************************************************************************************!*\
  !*** ../../../../../node_modules/monaco-languageserver-types/lib/colorInformation.js ***!
  \***************************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   fromColorInformation: () => (/* binding */ fromColorInformation),
/* harmony export */   toColorInformation: () => (/* binding */ toColorInformation)
/* harmony export */ });
/* harmony import */ var _color_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./color.js */ 1197);
/* harmony import */ var _range_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./range.js */ 1187);


/**
 * Convert a Monaco editor color information to an LSP color information.
 *
 * @param colorInformation The Monaco color information to convert.
 * @returns The color information as an LSP color information.
 */
function fromColorInformation(colorInformation) {
  return {
    range: (0,_range_js__WEBPACK_IMPORTED_MODULE_1__.fromRange)(colorInformation.range),
    color: (0,_color_js__WEBPACK_IMPORTED_MODULE_0__.fromColor)(colorInformation.color)
  };
}
/**
 * Convert an LSP color information to a Monaco editor color information.
 *
 * @param colorInformation The LSP color information to convert.
 * @returns The color information as Monaco editor color information.
 */
function toColorInformation(colorInformation) {
  return {
    range: (0,_range_js__WEBPACK_IMPORTED_MODULE_1__.toRange)(colorInformation.range),
    color: (0,_color_js__WEBPACK_IMPORTED_MODULE_0__.toColor)(colorInformation.color)
  };
}

/***/ }),

/***/ 1199:
/*!****************************************************************************************!*\
  !*** ../../../../../node_modules/monaco-languageserver-types/lib/colorPresentation.js ***!
  \****************************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   fromColorPresentation: () => (/* binding */ fromColorPresentation),
/* harmony export */   toColorPresentation: () => (/* binding */ toColorPresentation)
/* harmony export */ });
/* harmony import */ var _textEdit_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./textEdit.js */ 1190);

/**
 * Convert a Monaco editor color presentation to an LSP color presentation.
 *
 * @param colorPresentation The Monaco color presentation to convert.
 * @returns The color presentation as an LSP color presentation.
 */
function fromColorPresentation(colorPresentation) {
  const result = {
    label: colorPresentation.label
  };
  if (colorPresentation.textEdit) {
    result.textEdit = (0,_textEdit_js__WEBPACK_IMPORTED_MODULE_0__.fromTextEdit)(colorPresentation.textEdit);
  }
  if (colorPresentation.additionalTextEdits) {
    result.additionalTextEdits = colorPresentation.additionalTextEdits.map(_textEdit_js__WEBPACK_IMPORTED_MODULE_0__.fromTextEdit);
  }
  return result;
}
/**
 * Convert an LSP color presentation to a Monaco editor color presentation.
 *
 * @param colorPresentation The LSP color presentation to convert.
 * @returns The color presentation as Monaco editor color presentation.
 */
function toColorPresentation(colorPresentation) {
  const result = {
    label: colorPresentation.label
  };
  if (colorPresentation.textEdit) {
    result.textEdit = (0,_textEdit_js__WEBPACK_IMPORTED_MODULE_0__.toTextEdit)(colorPresentation.textEdit);
  }
  if (colorPresentation.additionalTextEdits) {
    result.additionalTextEdits = colorPresentation.additionalTextEdits.map(_textEdit_js__WEBPACK_IMPORTED_MODULE_0__.toTextEdit);
  }
  return result;
}

/***/ }),

/***/ 1196:
/*!******************************************************************************!*\
  !*** ../../../../../node_modules/monaco-languageserver-types/lib/command.js ***!
  \******************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   fromCommand: () => (/* binding */ fromCommand),
/* harmony export */   toCommand: () => (/* binding */ toCommand)
/* harmony export */ });
/**
 * Convert a Monaco editor command to an LSP command.
 *
 * @param command The Monaco command to convert.
 * @returns The command as an LSP command.
 */
function fromCommand(command) {
  const result = {
    title: command.title,
    command: command.id
  };
  if (command.arguments) {
    result.arguments = command.arguments;
  }
  return result;
}
/**
 * Convert an LSP command to a Monaco editor command.
 *
 * @param command The LSP command to convert.
 * @returns The command as Monaco editor command.
 */
function toCommand(command) {
  const result = {
    title: command.title,
    id: command.command
  };
  if (command.arguments) {
    result.arguments = command.arguments;
  }
  return result;
}

/***/ }),

/***/ 1200:
/*!****************************************************************************************!*\
  !*** ../../../../../node_modules/monaco-languageserver-types/lib/completionContext.js ***!
  \****************************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   fromCompletionContext: () => (/* binding */ fromCompletionContext),
/* harmony export */   toCompletionContext: () => (/* binding */ toCompletionContext)
/* harmony export */ });
/* harmony import */ var _completionTriggerKind_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./completionTriggerKind.js */ 1201);

/**
 * Convert a Monaco editor completion context to an LSP completion context.
 *
 * @param completionContext The Monaco completion context to convert.
 * @returns The completion context as an LSP completion context.
 */
function fromCompletionContext(completionContext) {
  const result = {
    triggerKind: (0,_completionTriggerKind_js__WEBPACK_IMPORTED_MODULE_0__.fromCompletionTriggerKind)(completionContext.triggerKind)
  };
  if (completionContext.triggerCharacter != null) {
    result.triggerCharacter = completionContext.triggerCharacter;
  }
  return result;
}
/**
 * Convert an LSP completion context to a Monaco editor completion context.
 *
 * @param completionContext The LSP completion context to convert.
 * @returns The completion context as Monaco editor completion context.
 */
function toCompletionContext(completionContext) {
  const result = {
    triggerKind: (0,_completionTriggerKind_js__WEBPACK_IMPORTED_MODULE_0__.toCompletionTriggerKind)(completionContext.triggerKind)
  };
  if (completionContext.triggerCharacter != null) {
    result.triggerCharacter = completionContext.triggerCharacter;
  }
  return result;
}

/***/ }),

/***/ 1202:
/*!*************************************************************************************!*\
  !*** ../../../../../node_modules/monaco-languageserver-types/lib/completionItem.js ***!
  \*************************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   fromCompletionItem: () => (/* binding */ fromCompletionItem),
/* harmony export */   toCompletionItem: () => (/* binding */ toCompletionItem)
/* harmony export */ });
/* harmony import */ var _command_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./command.js */ 1196);
/* harmony import */ var _completionItemKind_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./completionItemKind.js */ 1203);
/* harmony import */ var _completionItemTag_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./completionItemTag.js */ 1204);
/* harmony import */ var _markdownString_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./markdownString.js */ 1205);
/* harmony import */ var _monaco_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./monaco.js */ 1185);
/* harmony import */ var _range_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./range.js */ 1187);
/* harmony import */ var _singleEditOperation_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./singleEditOperation.js */ 1206);







/**
 * Convert a Monaco editor completion item range to an LSP completion item text edit.
 *
 * @param edit The Monaco completion item range to convert.
 * @param newText The text of the text edit.
 * @returns The completion item range as an LSP completion item text edit.
 */
function fromCompletionItemRange(edit, newText) {
  if ('insert' in edit) {
    return {
      newText,
      insert: (0,_range_js__WEBPACK_IMPORTED_MODULE_5__.fromRange)(edit.insert),
      replace: (0,_range_js__WEBPACK_IMPORTED_MODULE_5__.fromRange)(edit.replace)
    };
  }
  return {
    newText,
    range: (0,_range_js__WEBPACK_IMPORTED_MODULE_5__.fromRange)(edit)
  };
}
/**
 * Convert a Monaco editor completion item to an LSP completion item.
 *
 * @param completionItem The Monaco completion item to convert.
 * @returns The completion item as an LSP completion item.
 */
function fromCompletionItem(completionItem) {
  const {
    CompletionItemInsertTextRule
  } = (0,_monaco_js__WEBPACK_IMPORTED_MODULE_4__.getMonaco)().languages;
  const result = {
    kind: (0,_completionItemKind_js__WEBPACK_IMPORTED_MODULE_1__.fromCompletionItemKind)(completionItem.kind),
    label: typeof completionItem.label === 'string' ? completionItem.label : completionItem.label.label,
    textEdit: fromCompletionItemRange(completionItem.range, completionItem.insertText)
  };
  if (completionItem.additionalTextEdits) {
    result.additionalTextEdits = completionItem.additionalTextEdits.map(_singleEditOperation_js__WEBPACK_IMPORTED_MODULE_6__.fromSingleEditOperation);
  }
  if (completionItem.command) {
    result.command = (0,_command_js__WEBPACK_IMPORTED_MODULE_0__.fromCommand)(completionItem.command);
  }
  if (completionItem.commitCharacters) {
    result.commitCharacters = completionItem.commitCharacters;
  }
  if (completionItem.detail != null) {
    result.detail = completionItem.detail;
  }
  if (typeof completionItem.documentation === 'string') {
    result.documentation = completionItem.documentation;
  } else if (completionItem.documentation) {
    result.documentation = (0,_markdownString_js__WEBPACK_IMPORTED_MODULE_3__.fromMarkdownString)(completionItem.documentation);
  }
  if (completionItem.filterText != null) {
    result.filterText = completionItem.filterText;
  }
  if (completionItem.insertTextRules === CompletionItemInsertTextRule.InsertAsSnippet) {
    result.insertTextFormat = 2;
  } else if (completionItem.insertTextRules === CompletionItemInsertTextRule.KeepWhitespace) {
    result.insertTextMode = 2;
  }
  if (completionItem.preselect != null) {
    result.preselect = completionItem.preselect;
  }
  if (completionItem.sortText != null) {
    result.sortText = completionItem.sortText;
  }
  if (completionItem.tags) {
    result.tags = completionItem.tags.map(_completionItemTag_js__WEBPACK_IMPORTED_MODULE_2__.fromCompletionItemTag);
  }
  return result;
}
/**
 * Convert an LSP completion item text edit to a Monaco editor range.
 *
 * @param edit The LSP completion item text edit to convert.
 * @returns The completion item text edit as Monaco editor range.
 */
function toCompletionItemRange(edit) {
  if ('range' in edit) {
    return (0,_range_js__WEBPACK_IMPORTED_MODULE_5__.toRange)(edit.range);
  }
  if ('insert' in edit && 'replace' in edit) {
    return {
      insert: (0,_range_js__WEBPACK_IMPORTED_MODULE_5__.toRange)(edit.insert),
      replace: (0,_range_js__WEBPACK_IMPORTED_MODULE_5__.toRange)(edit.replace)
    };
  }
  return (0,_range_js__WEBPACK_IMPORTED_MODULE_5__.toRange)(edit);
}
/**
 * Convert an LSP completion item to a Monaco editor completion item.
 *
 * @param completionItem The LSP completion item to convert.
 * @param options Additional options needed to construct the Monaco completion item.
 * @returns The completion item as Monaco editor completion item.
 */
function toCompletionItem(completionItem, options) {
  var _a, _b, _c, _d, _e;
  const {
    CompletionItemInsertTextRule,
    CompletionItemKind
  } = (0,_monaco_js__WEBPACK_IMPORTED_MODULE_4__.getMonaco)().languages;
  const itemDefaults = (_a = options.itemDefaults) !== null && _a !== void 0 ? _a : {};
  const textEdit = (_b = completionItem.textEdit) !== null && _b !== void 0 ? _b : itemDefaults.editRange;
  const commitCharacters = (_c = completionItem.commitCharacters) !== null && _c !== void 0 ? _c : itemDefaults.commitCharacters;
  const insertTextFormat = (_d = completionItem.insertTextFormat) !== null && _d !== void 0 ? _d : itemDefaults.insertTextFormat;
  const insertTextMode = (_e = completionItem.insertTextMode) !== null && _e !== void 0 ? _e : itemDefaults.insertTextMode;
  let text = completionItem.insertText;
  let range;
  if (textEdit) {
    range = toCompletionItemRange(textEdit);
    if ('newText' in textEdit) {
      text = textEdit.newText;
    }
  } else {
    range = {
      ...options.range
    };
  }
  const result = {
    insertText: text !== null && text !== void 0 ? text : '',
    kind: completionItem.kind == null ? CompletionItemKind.Text : (0,_completionItemKind_js__WEBPACK_IMPORTED_MODULE_1__.toCompletionItemKind)(completionItem.kind),
    label: completionItem.label,
    range
  };
  if (completionItem.additionalTextEdits) {
    result.additionalTextEdits = completionItem.additionalTextEdits.map(_singleEditOperation_js__WEBPACK_IMPORTED_MODULE_6__.toSingleEditOperation);
  }
  if (completionItem.command) {
    result.command = (0,_command_js__WEBPACK_IMPORTED_MODULE_0__.toCommand)(completionItem.command);
  }
  if (commitCharacters) {
    result.commitCharacters = commitCharacters;
  }
  if (completionItem.detail != null) {
    result.detail = completionItem.detail;
  }
  if (typeof completionItem.documentation === 'string') {
    result.documentation = completionItem.documentation;
  } else if (completionItem.documentation) {
    result.documentation = (0,_markdownString_js__WEBPACK_IMPORTED_MODULE_3__.toMarkdownString)(completionItem.documentation);
  }
  if (completionItem.filterText != null) {
    result.filterText = completionItem.filterText;
  }
  if (insertTextFormat === 2) {
    result.insertTextRules = CompletionItemInsertTextRule.InsertAsSnippet;
  } else if (insertTextMode === 2) {
    result.insertTextRules = CompletionItemInsertTextRule.KeepWhitespace;
  }
  if (completionItem.preselect != null) {
    result.preselect = completionItem.preselect;
  }
  if (completionItem.sortText != null) {
    result.sortText = completionItem.sortText;
  }
  if (completionItem.tags) {
    result.tags = completionItem.tags.map(_completionItemTag_js__WEBPACK_IMPORTED_MODULE_2__.toCompletionItemTag);
  }
  return result;
}

/***/ }),

/***/ 1203:
/*!*****************************************************************************************!*\
  !*** ../../../../../node_modules/monaco-languageserver-types/lib/completionItemKind.js ***!
  \*****************************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   fromCompletionItemKind: () => (/* binding */ fromCompletionItemKind),
/* harmony export */   toCompletionItemKind: () => (/* binding */ toCompletionItemKind)
/* harmony export */ });
/* harmony import */ var _monaco_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./monaco.js */ 1185);

/**
 * Convert a Monaco editor completion item kind to an LSP completion item kind.
 *
 * @param kind The Monaco completion item kind to convert.
 * @returns The completion item kind as an LSP completion item kind.
 */
function fromCompletionItemKind(kind) {
  const {
    CompletionItemKind
  } = (0,_monaco_js__WEBPACK_IMPORTED_MODULE_0__.getMonaco)().languages;
  if (kind === CompletionItemKind.Text) {
    return 1;
  }
  if (kind === CompletionItemKind.Method) {
    return 2;
  }
  if (kind === CompletionItemKind.Function) {
    return 3;
  }
  if (kind === CompletionItemKind.Constructor) {
    return 4;
  }
  if (kind === CompletionItemKind.Field) {
    return 5;
  }
  if (kind === CompletionItemKind.Variable) {
    return 6;
  }
  if (kind === CompletionItemKind.Class) {
    return 7;
  }
  if (kind === CompletionItemKind.Interface) {
    return 8;
  }
  if (kind === CompletionItemKind.Module) {
    return 9;
  }
  if (kind === CompletionItemKind.Property) {
    return 10;
  }
  if (kind === CompletionItemKind.Unit) {
    return 11;
  }
  if (kind === CompletionItemKind.Value) {
    return 12;
  }
  if (kind === CompletionItemKind.Enum) {
    return 13;
  }
  if (kind === CompletionItemKind.Keyword) {
    return 14;
  }
  if (kind === CompletionItemKind.Snippet) {
    return 15;
  }
  if (kind === CompletionItemKind.Color) {
    return 16;
  }
  if (kind === CompletionItemKind.File) {
    return 17;
  }
  if (kind === CompletionItemKind.Reference) {
    return 18;
  }
  if (kind === CompletionItemKind.Folder) {
    return 19;
  }
  if (kind === CompletionItemKind.EnumMember) {
    return 20;
  }
  if (kind === CompletionItemKind.Constant) {
    return 21;
  }
  if (kind === CompletionItemKind.Struct) {
    return 22;
  }
  if (kind === CompletionItemKind.Event) {
    return 23;
  }
  if (kind === CompletionItemKind.Operator) {
    return 24;
  }
  if (kind === CompletionItemKind.TypeParameter) {
    return 25;
  }
}
/**
 * Convert an LSP completion item kind to a Monaco editor completion item kind.
 *
 * @param kind The LSP completion item kind to convert.
 * @returns The completion item kind as Monaco editor completion item kind.
 */
function toCompletionItemKind(kind) {
  const {
    CompletionItemKind
  } = (0,_monaco_js__WEBPACK_IMPORTED_MODULE_0__.getMonaco)().languages;
  if (kind === 1) {
    return CompletionItemKind.Text;
  }
  if (kind === 2) {
    return CompletionItemKind.Method;
  }
  if (kind === 3) {
    return CompletionItemKind.Function;
  }
  if (kind === 4) {
    return CompletionItemKind.Constructor;
  }
  if (kind === 5) {
    return CompletionItemKind.Field;
  }
  if (kind === 6) {
    return CompletionItemKind.Variable;
  }
  if (kind === 7) {
    return CompletionItemKind.Class;
  }
  if (kind === 8) {
    return CompletionItemKind.Interface;
  }
  if (kind === 9) {
    return CompletionItemKind.Module;
  }
  if (kind === 10) {
    return CompletionItemKind.Property;
  }
  if (kind === 11) {
    return CompletionItemKind.Unit;
  }
  if (kind === 12) {
    return CompletionItemKind.Value;
  }
  if (kind === 13) {
    return CompletionItemKind.Enum;
  }
  if (kind === 14) {
    return CompletionItemKind.Keyword;
  }
  if (kind === 15) {
    return CompletionItemKind.Snippet;
  }
  if (kind === 16) {
    return CompletionItemKind.Color;
  }
  if (kind === 17) {
    return CompletionItemKind.File;
  }
  if (kind === 18) {
    return CompletionItemKind.Reference;
  }
  if (kind === 19) {
    return CompletionItemKind.Folder;
  }
  if (kind === 20) {
    return CompletionItemKind.EnumMember;
  }
  if (kind === 21) {
    return CompletionItemKind.Constant;
  }
  if (kind === 22) {
    return CompletionItemKind.Struct;
  }
  if (kind === 23) {
    return CompletionItemKind.Event;
  }
  if (kind === 24) {
    return CompletionItemKind.Operator;
  }
  // Kind === 25
  return CompletionItemKind.TypeParameter;
}

/***/ }),

/***/ 1204:
/*!****************************************************************************************!*\
  !*** ../../../../../node_modules/monaco-languageserver-types/lib/completionItemTag.js ***!
  \****************************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   fromCompletionItemTag: () => (/* binding */ fromCompletionItemTag),
/* harmony export */   toCompletionItemTag: () => (/* binding */ toCompletionItemTag)
/* harmony export */ });
/**
 * Convert a Monaco editor completion item tag to an LSP completion item tag.
 *
 * @param tag The Monaco completion item tag to convert.
 * @returns The completion item tag as an LSP completion item tag.
 */
function fromCompletionItemTag(tag) {
  return tag;
}
/**
 * Convert an LSP completion item tag to a Monaco editor completion item tag.
 *
 * @param tag The LSP completion item tag to convert.
 * @returns The completion item tag as Monaco editor completion item tag.
 */
function toCompletionItemTag(tag) {
  return tag;
}

/***/ }),

/***/ 1207:
/*!*************************************************************************************!*\
  !*** ../../../../../node_modules/monaco-languageserver-types/lib/completionList.js ***!
  \*************************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   fromCompletionList: () => (/* binding */ fromCompletionList),
/* harmony export */   toCompletionList: () => (/* binding */ toCompletionList)
/* harmony export */ });
/* harmony import */ var _completionItem_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./completionItem.js */ 1202);

/**
 * Convert a Monaco editor completion list to an LSP completion list.
 *
 * @param completionList The Monaco completion list to convert.
 * @returns The completion list as an LSP completion list.
 */
function fromCompletionList(completionList) {
  return {
    isIncomplete: Boolean(completionList.incomplete),
    items: completionList.suggestions.map(_completionItem_js__WEBPACK_IMPORTED_MODULE_0__.fromCompletionItem)
  };
}
/**
 * Convert an LSP completion list to a Monaco editor completion list.
 *
 * @param completionList The LSP completion list to convert.
 * @param options Additional options needed to construct the Monaco completion list.
 * @returns The completion list as Monaco editor completion list.
 */
function toCompletionList(completionList, options) {
  return {
    incomplete: Boolean(completionList.isIncomplete),
    suggestions: completionList.items.map(item => (0,_completionItem_js__WEBPACK_IMPORTED_MODULE_0__.toCompletionItem)(item, {
      range: options.range,
      itemDefaults: completionList.itemDefaults
    }))
  };
}

/***/ }),

/***/ 1201:
/*!********************************************************************************************!*\
  !*** ../../../../../node_modules/monaco-languageserver-types/lib/completionTriggerKind.js ***!
  \********************************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   fromCompletionTriggerKind: () => (/* binding */ fromCompletionTriggerKind),
/* harmony export */   toCompletionTriggerKind: () => (/* binding */ toCompletionTriggerKind)
/* harmony export */ });
/* harmony import */ var _monaco_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./monaco.js */ 1185);

/**
 * Convert a Monaco editor completion trigger kind to an LSP completion trigger kind.
 *
 * @param kind The Monaco completion trigger kind to convert.
 * @returns The completion trigger kind as an LSP completion trigger kind.
 */
function fromCompletionTriggerKind(kind) {
  const {
    CompletionTriggerKind
  } = (0,_monaco_js__WEBPACK_IMPORTED_MODULE_0__.getMonaco)().languages;
  if (kind === CompletionTriggerKind.Invoke) {
    return 1;
  }
  if (kind === CompletionTriggerKind.TriggerCharacter) {
    return 2;
  }
  // Kind === TriggerForIncompleteCompletions.
  return 3;
}
/**
 * Convert an LSP completion trigger kind to a Monaco editor completion trigger kind.
 *
 * @param kind The LSP completion trigger kind to convert.
 * @returns The completion trigger kind as Monaco editor completion trigger kind.
 */
function toCompletionTriggerKind(kind) {
  const {
    CompletionTriggerKind
  } = (0,_monaco_js__WEBPACK_IMPORTED_MODULE_0__.getMonaco)().languages;
  if (kind === 1) {
    return CompletionTriggerKind.Invoke;
  }
  if (kind === 2) {
    return CompletionTriggerKind.TriggerCharacter;
  }
  // Kind === 3
  return CompletionTriggerKind.TriggerForIncompleteCompletions;
}

/***/ }),

/***/ 1208:
/*!*********************************************************************************!*\
  !*** ../../../../../node_modules/monaco-languageserver-types/lib/definition.js ***!
  \*********************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   fromDefinition: () => (/* binding */ fromDefinition),
/* harmony export */   toDefinition: () => (/* binding */ toDefinition)
/* harmony export */ });
/* harmony import */ var _location_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./location.js */ 1209);

/**
 * Convert a Monaco editor definition to an LSP definition.
 *
 * @param definition The Monaco definition to convert.
 * @returns The definition as an LSP definition.
 */
function fromDefinition(definition) {
  if (Array.isArray(definition)) {
    return definition.map(_location_js__WEBPACK_IMPORTED_MODULE_0__.fromLocation);
  }
  return (0,_location_js__WEBPACK_IMPORTED_MODULE_0__.fromLocation)(definition);
}
/**
 * Convert an LSP definition to a Monaco editor definition.
 *
 * @param definition The LSP definition to convert.
 * @returns The definition as Monaco editor definition.
 */
function toDefinition(definition) {
  if (Array.isArray(definition)) {
    return definition.map(_location_js__WEBPACK_IMPORTED_MODULE_0__.toLocation);
  }
  return (0,_location_js__WEBPACK_IMPORTED_MODULE_0__.toLocation)(definition);
}

/***/ }),

/***/ 1210:
/*!****************************************************************************************!*\
  !*** ../../../../../node_modules/monaco-languageserver-types/lib/documentHighlight.js ***!
  \****************************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   fromDocumentHighlight: () => (/* binding */ fromDocumentHighlight),
/* harmony export */   toDocumentHighlight: () => (/* binding */ toDocumentHighlight)
/* harmony export */ });
/* harmony import */ var _documentHighlightKind_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./documentHighlightKind.js */ 1211);
/* harmony import */ var _range_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./range.js */ 1187);


/**
 * Convert a Monaco editor document highlight to an LSP document highlight.
 *
 * @param documentHighlight The Monaco document highlight to convert.
 * @returns The document highlight as an LSP document highlight.
 */
function fromDocumentHighlight(documentHighlight) {
  const result = {
    range: (0,_range_js__WEBPACK_IMPORTED_MODULE_1__.fromRange)(documentHighlight.range)
  };
  if (documentHighlight.kind != null) {
    result.kind = (0,_documentHighlightKind_js__WEBPACK_IMPORTED_MODULE_0__.fromDocumentHighlightKind)(documentHighlight.kind);
  }
  return result;
}
/**
 * Convert an LSP document highlight to a Monaco editor document highlight.
 *
 * @param documentHighlight The LSP document highlight to convert.
 * @returns The document highlight as Monaco editor document highlight.
 */
function toDocumentHighlight(documentHighlight) {
  const result = {
    range: (0,_range_js__WEBPACK_IMPORTED_MODULE_1__.toRange)(documentHighlight.range)
  };
  if (documentHighlight.kind != null) {
    result.kind = (0,_documentHighlightKind_js__WEBPACK_IMPORTED_MODULE_0__.toDocumentHighlightKind)(documentHighlight.kind);
  }
  return result;
}

/***/ }),

/***/ 1211:
/*!********************************************************************************************!*\
  !*** ../../../../../node_modules/monaco-languageserver-types/lib/documentHighlightKind.js ***!
  \********************************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   fromDocumentHighlightKind: () => (/* binding */ fromDocumentHighlightKind),
/* harmony export */   toDocumentHighlightKind: () => (/* binding */ toDocumentHighlightKind)
/* harmony export */ });
/* harmony import */ var _monaco_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./monaco.js */ 1185);

/**
 * Convert a Monaco editor document highlight kind to an LSP document highlight kind.
 *
 * @param kind The Monaco document highlight kind to convert.
 * @returns The document highlight kind as an LSP document highlight kind.
 */
function fromDocumentHighlightKind(kind) {
  const {
    DocumentHighlightKind
  } = (0,_monaco_js__WEBPACK_IMPORTED_MODULE_0__.getMonaco)().languages;
  if (kind === DocumentHighlightKind.Read) {
    return 2;
  }
  if (kind === DocumentHighlightKind.Write) {
    return 3;
  }
  return 1;
}
/**
 * Convert an LSP document highlight kind to a Monaco editor document highlight kind.
 *
 * @param kind The LSP document highlight kind to convert.
 * @returns The document highlight kind as Monaco editor document highlight kind.
 */
function toDocumentHighlightKind(kind) {
  const {
    DocumentHighlightKind
  } = (0,_monaco_js__WEBPACK_IMPORTED_MODULE_0__.getMonaco)().languages;
  if (kind === 2) {
    return DocumentHighlightKind.Read;
  }
  if (kind === 3) {
    return DocumentHighlightKind.Write;
  }
  return DocumentHighlightKind.Text;
}

/***/ }),

/***/ 1212:
/*!*************************************************************************************!*\
  !*** ../../../../../node_modules/monaco-languageserver-types/lib/documentSymbol.js ***!
  \*************************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   fromDocumentSymbol: () => (/* binding */ fromDocumentSymbol),
/* harmony export */   toDocumentSymbol: () => (/* binding */ toDocumentSymbol)
/* harmony export */ });
/* harmony import */ var _range_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./range.js */ 1187);
/* harmony import */ var _symbolKind_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./symbolKind.js */ 1213);
/* harmony import */ var _symbolTag_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./symbolTag.js */ 1214);



/**
 * Convert a Monaco editor document symbol to an LSP document symbol.
 *
 * @param documentSymbol The Monaco document symbol to convert.
 * @returns The document symbol as an LSP document symbol.
 */
function fromDocumentSymbol(documentSymbol) {
  const result = {
    detail: documentSymbol.detail,
    kind: (0,_symbolKind_js__WEBPACK_IMPORTED_MODULE_1__.fromSymbolKind)(documentSymbol.kind),
    name: documentSymbol.name,
    range: (0,_range_js__WEBPACK_IMPORTED_MODULE_0__.fromRange)(documentSymbol.range),
    selectionRange: (0,_range_js__WEBPACK_IMPORTED_MODULE_0__.fromRange)(documentSymbol.selectionRange),
    tags: documentSymbol.tags.map(_symbolTag_js__WEBPACK_IMPORTED_MODULE_2__.fromSymbolTag)
  };
  if (documentSymbol.children) {
    result.children = documentSymbol.children.map(fromDocumentSymbol);
  }
  return result;
}
/**
 * Convert an LSP document symbol to a Monaco editor document symbol.
 *
 * @param documentSymbol The LSP document symbol to convert.
 * @returns The document symbol as Monaco editor document symbol.
 */
function toDocumentSymbol(documentSymbol) {
  var _a, _b, _c;
  const result = {
    detail: (_a = documentSymbol.detail) !== null && _a !== void 0 ? _a : '',
    kind: (0,_symbolKind_js__WEBPACK_IMPORTED_MODULE_1__.toSymbolKind)(documentSymbol.kind),
    name: documentSymbol.name,
    range: (0,_range_js__WEBPACK_IMPORTED_MODULE_0__.toRange)(documentSymbol.range),
    selectionRange: (0,_range_js__WEBPACK_IMPORTED_MODULE_0__.toRange)(documentSymbol.selectionRange),
    tags: (_c = (_b = documentSymbol.tags) === null || _b === void 0 ? void 0 : _b.map(_symbolTag_js__WEBPACK_IMPORTED_MODULE_2__.toSymbolTag)) !== null && _c !== void 0 ? _c : []
  };
  if (documentSymbol.children) {
    result.children = documentSymbol.children.map(toDocumentSymbol);
  }
  return result;
}

/***/ }),

/***/ 1215:
/*!***********************************************************************************!*\
  !*** ../../../../../node_modules/monaco-languageserver-types/lib/foldingRange.js ***!
  \***********************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   fromFoldingRange: () => (/* binding */ fromFoldingRange),
/* harmony export */   toFoldingRange: () => (/* binding */ toFoldingRange)
/* harmony export */ });
/**
 * Convert a Monaco editor folding range to an LSP folding range.
 *
 * @param foldingRange The Monaco folding range to convert.
 * @returns The folding range as an LSP folding range.
 */
function fromFoldingRange(foldingRange) {
  const result = {
    startLine: foldingRange.start - 1,
    endLine: foldingRange.end - 1
  };
  if (foldingRange.kind != null) {
    result.kind = foldingRange.kind.value;
  }
  return result;
}
/**
 * Convert an LSP folding range to a Monaco editor folding range.
 *
 * @param foldingRange The LSP folding range to convert.
 * @returns The folding range as Monaco editor folding range.
 */
function toFoldingRange(foldingRange) {
  const result = {
    start: foldingRange.startLine + 1,
    end: foldingRange.endLine + 1
  };
  if (foldingRange.kind != null) {
    result.kind = {
      value: foldingRange.kind
    };
  }
  return result;
}

/***/ }),

/***/ 1216:
/*!****************************************************************************************!*\
  !*** ../../../../../node_modules/monaco-languageserver-types/lib/formattingOptions.js ***!
  \****************************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   fromFormattingOptions: () => (/* binding */ fromFormattingOptions),
/* harmony export */   toFormattingOptions: () => (/* binding */ toFormattingOptions)
/* harmony export */ });
/**
 * Convert a Monaco editor formatting options to an LSP formatting options.
 *
 * @param formattingOptions The Monaco formatting options to convert.
 * @returns The formatting options as an LSP formatting options.
 */
function fromFormattingOptions(formattingOptions) {
  return {
    insertSpaces: formattingOptions.insertSpaces,
    tabSize: formattingOptions.tabSize
  };
}
/**
 * Convert an LSP formatting options to a Monaco editor formatting options.
 *
 * @param formattingOptions The LSP formatting options to convert.
 * @returns The formatting options as Monaco editor formatting options.
 */
function toFormattingOptions(formattingOptions) {
  return {
    insertSpaces: formattingOptions.insertSpaces,
    tabSize: formattingOptions.tabSize
  };
}

/***/ }),

/***/ 1217:
/*!****************************************************************************!*\
  !*** ../../../../../node_modules/monaco-languageserver-types/lib/hover.js ***!
  \****************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   fromHover: () => (/* binding */ fromHover),
/* harmony export */   toHover: () => (/* binding */ toHover)
/* harmony export */ });
/* harmony import */ var _markdownString_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./markdownString.js */ 1205);
/* harmony import */ var _range_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./range.js */ 1187);


/**
 * Convert a Monaco editor hover to an LSP hover.
 *
 * @param hover The Monaco hover to convert.
 * @returns The hover as an LSP hover.
 */
function fromHover(hover) {
  const result = {
    contents: (0,_markdownString_js__WEBPACK_IMPORTED_MODULE_0__.fromMarkdownString)(hover.contents[0])
  };
  if (hover.range) {
    result.range = (0,_range_js__WEBPACK_IMPORTED_MODULE_1__.fromRange)(hover.range);
  }
  return result;
}
/**
 * Get value of a marked string.
 *
 * @param value The marked string to get the value from.
 * @returns The value of the marked string.
 */
function getDeprecatedMarkupValue(value) {
  if (typeof value === 'string') {
    return {
      value
    };
  }
  return {
    value: `\`\`\`${value.language}\n${value.value}\n\`\`\``
  };
}
/**
 * Convert LSP hover item contents to a Monaco markdown string.
 *
 * @param contents The LSP hover contents to convert.
 * @returns The hover contents as a Monaco markdown string.
 */
function toHoverContents(contents) {
  if (typeof contents === 'string' || 'language' in contents) {
    return [getDeprecatedMarkupValue(contents)];
  }
  if (Array.isArray(contents)) {
    return contents.map(getDeprecatedMarkupValue);
  }
  return [(0,_markdownString_js__WEBPACK_IMPORTED_MODULE_0__.toMarkdownString)(contents)];
}
/**
 * Convert an LSP hover to a Monaco editor hover.
 *
 * @param hover The LSP hover to convert.
 * @returns The hover as Monaco editor hover.
 */
function toHover(hover) {
  const result = {
    contents: toHoverContents(hover.contents)
  };
  if (hover.range) {
    result.range = (0,_range_js__WEBPACK_IMPORTED_MODULE_1__.toRange)(hover.range);
  }
  return result;
}

/***/ }),

/***/ 1218:
/*!********************************************************************************!*\
  !*** ../../../../../node_modules/monaco-languageserver-types/lib/inlayHint.js ***!
  \********************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   fromInlayHint: () => (/* binding */ fromInlayHint),
/* harmony export */   toInlayHint: () => (/* binding */ toInlayHint)
/* harmony export */ });
/* harmony import */ var _inlayHintKind_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./inlayHintKind.js */ 1219);
/* harmony import */ var _inlayHintLabelPart_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./inlayHintLabelPart.js */ 1220);
/* harmony import */ var _markdownString_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./markdownString.js */ 1205);
/* harmony import */ var _position_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./position.js */ 1221);
/* harmony import */ var _textEdit_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./textEdit.js */ 1190);





/**
 * Convert a Monaco editor inlay hint to an LSP inlay hint.
 *
 * @param inlayHint The Monaco inlay hint to convert.
 * @returns The inlay hint as an LSP inlay hint.
 */
function fromInlayHint(inlayHint) {
  const result = {
    label: typeof inlayHint.label === 'string' ? inlayHint.label : inlayHint.label.map(_inlayHintLabelPart_js__WEBPACK_IMPORTED_MODULE_1__.fromInlayHintLabelPart),
    position: (0,_position_js__WEBPACK_IMPORTED_MODULE_3__.fromPosition)(inlayHint.position)
  };
  if (inlayHint.kind != null) {
    result.kind = (0,_inlayHintKind_js__WEBPACK_IMPORTED_MODULE_0__.fromInlayHintKind)(inlayHint.kind);
  }
  if (inlayHint.paddingLeft != null) {
    result.paddingLeft = inlayHint.paddingLeft;
  }
  if (inlayHint.paddingRight != null) {
    result.paddingRight = inlayHint.paddingRight;
  }
  if (inlayHint.textEdits) {
    result.textEdits = inlayHint.textEdits.map(_textEdit_js__WEBPACK_IMPORTED_MODULE_4__.fromTextEdit);
  }
  if (typeof inlayHint.tooltip === 'string') {
    result.tooltip = inlayHint.tooltip;
  } else if (inlayHint.tooltip) {
    result.tooltip = (0,_markdownString_js__WEBPACK_IMPORTED_MODULE_2__.fromMarkdownString)(inlayHint.tooltip);
  }
  return result;
}
/**
 * Convert an LSP inlay hint to a Monaco editor inlay hint.
 *
 * @param inlayHint The LSP inlay hint to convert.
 * @returns The inlay hint as Monaco editor inlay hint.
 */
function toInlayHint(inlayHint) {
  const result = {
    label: typeof inlayHint.label === 'string' ? inlayHint.label : inlayHint.label.map(_inlayHintLabelPart_js__WEBPACK_IMPORTED_MODULE_1__.toInlayHintLabelPart),
    position: (0,_position_js__WEBPACK_IMPORTED_MODULE_3__.toPosition)(inlayHint.position)
  };
  if (inlayHint.kind != null) {
    result.kind = (0,_inlayHintKind_js__WEBPACK_IMPORTED_MODULE_0__.toInlayHintKind)(inlayHint.kind);
  }
  if (inlayHint.paddingLeft != null) {
    result.paddingLeft = inlayHint.paddingLeft;
  }
  if (inlayHint.paddingRight != null) {
    result.paddingRight = inlayHint.paddingRight;
  }
  if (inlayHint.textEdits) {
    result.textEdits = inlayHint.textEdits.map(_textEdit_js__WEBPACK_IMPORTED_MODULE_4__.toTextEdit);
  }
  if (typeof inlayHint.tooltip === 'string') {
    result.tooltip = inlayHint.tooltip;
  } else if (inlayHint.tooltip) {
    result.tooltip = (0,_markdownString_js__WEBPACK_IMPORTED_MODULE_2__.toMarkdownString)(inlayHint.tooltip);
  }
  return result;
}

/***/ }),

/***/ 1219:
/*!************************************************************************************!*\
  !*** ../../../../../node_modules/monaco-languageserver-types/lib/inlayHintKind.js ***!
  \************************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   fromInlayHintKind: () => (/* binding */ fromInlayHintKind),
/* harmony export */   toInlayHintKind: () => (/* binding */ toInlayHintKind)
/* harmony export */ });
/**
 * Convert a Monaco editor inlay hint kind to an LSP inlay hint kind.
 *
 * @param inlayHintKind The Monaco inlay hint kind to convert.
 * @returns The inlay hint kind as an LSP inlay hint kind.
 */
function fromInlayHintKind(inlayHintKind) {
  return inlayHintKind;
}
/**
 * Convert an LSP inlay hint kind to a Monaco editor inlay hint kind.
 *
 * @param inlayHintKind The LSP inlay hint kind to convert.
 * @returns The inlay hint kind as Monaco editor inlay hint kind.
 */
function toInlayHintKind(inlayHintKind) {
  return inlayHintKind;
}

/***/ }),

/***/ 1220:
/*!*****************************************************************************************!*\
  !*** ../../../../../node_modules/monaco-languageserver-types/lib/inlayHintLabelPart.js ***!
  \*****************************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   fromInlayHintLabelPart: () => (/* binding */ fromInlayHintLabelPart),
/* harmony export */   toInlayHintLabelPart: () => (/* binding */ toInlayHintLabelPart)
/* harmony export */ });
/* harmony import */ var _command_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./command.js */ 1196);
/* harmony import */ var _location_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./location.js */ 1209);
/* harmony import */ var _markdownString_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./markdownString.js */ 1205);



/**
 * Convert a Monaco editor inlay hint label part to an LSP inlay hint label part.
 *
 * @param inlayHintLabelPart The Monaco inlay hint label part to convert.
 * @returns The inlay hint label part as an LSP inlay hint label part.
 */
function fromInlayHintLabelPart(inlayHintLabelPart) {
  const result = {
    value: inlayHintLabelPart.label
  };
  if (inlayHintLabelPart.command) {
    result.command = (0,_command_js__WEBPACK_IMPORTED_MODULE_0__.fromCommand)(inlayHintLabelPart.command);
  }
  if (inlayHintLabelPart.location) {
    result.location = (0,_location_js__WEBPACK_IMPORTED_MODULE_1__.fromLocation)(inlayHintLabelPart.location);
  }
  if (typeof inlayHintLabelPart.tooltip === 'string') {
    result.tooltip = inlayHintLabelPart.tooltip;
  } else if (inlayHintLabelPart.tooltip) {
    result.tooltip = (0,_markdownString_js__WEBPACK_IMPORTED_MODULE_2__.fromMarkdownString)(inlayHintLabelPart.tooltip);
  }
  return result;
}
/**
 * Convert an LSP inlay hint label part to a Monaco editor inlay hint label part.
 *
 * @param inlayHintLabelPart The LSP inlay hint label part to convert.
 * @returns The inlay hint label part as Monaco editor inlay hint label part.
 */
function toInlayHintLabelPart(inlayHintLabelPart) {
  const result = {
    label: inlayHintLabelPart.value
  };
  if (inlayHintLabelPart.command) {
    result.command = (0,_command_js__WEBPACK_IMPORTED_MODULE_0__.toCommand)(inlayHintLabelPart.command);
  }
  if (inlayHintLabelPart.location) {
    result.location = (0,_location_js__WEBPACK_IMPORTED_MODULE_1__.toLocation)(inlayHintLabelPart.location);
  }
  if (typeof inlayHintLabelPart.tooltip === 'string') {
    result.tooltip = inlayHintLabelPart.tooltip;
  } else if (inlayHintLabelPart.tooltip) {
    result.tooltip = (0,_markdownString_js__WEBPACK_IMPORTED_MODULE_2__.toMarkdownString)(inlayHintLabelPart.tooltip);
  }
  return result;
}

/***/ }),

/***/ 1222:
/*!***************************************************************************!*\
  !*** ../../../../../node_modules/monaco-languageserver-types/lib/link.js ***!
  \***************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   fromLink: () => (/* binding */ fromLink),
/* harmony export */   toLink: () => (/* binding */ toLink)
/* harmony export */ });
/* harmony import */ var _monaco_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./monaco.js */ 1185);
/* harmony import */ var _range_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./range.js */ 1187);


/**
 * Convert a Monaco editor link to an LSP document link.
 *
 * @param link The Monaco link to convert.
 * @returns The link as an LSP document link.
 */
function fromLink(link) {
  const result = {
    range: (0,_range_js__WEBPACK_IMPORTED_MODULE_1__.fromRange)(link.range)
  };
  if (link.tooltip != null) {
    result.tooltip = link.tooltip;
  }
  if (link.url != null) {
    result.target = String(link.url);
  }
  return result;
}
/**
 * Convert an LSP document link to a Monaco editor link.
 *
 * @param documentLink The LSP document link to convert.
 * @returns The document link as Monaco editor link.
 */
function toLink(documentLink) {
  const {
    Uri
  } = (0,_monaco_js__WEBPACK_IMPORTED_MODULE_0__.getMonaco)();
  const result = {
    range: (0,_range_js__WEBPACK_IMPORTED_MODULE_1__.toRange)(documentLink.range)
  };
  if (documentLink.tooltip != null) {
    result.tooltip = documentLink.tooltip;
  }
  if (documentLink.target != null) {
    result.url = Uri.parse(documentLink.target);
  }
  return result;
}

/***/ }),

/***/ 1209:
/*!*******************************************************************************!*\
  !*** ../../../../../node_modules/monaco-languageserver-types/lib/location.js ***!
  \*******************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   fromLocation: () => (/* binding */ fromLocation),
/* harmony export */   toLocation: () => (/* binding */ toLocation)
/* harmony export */ });
/* harmony import */ var _monaco_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./monaco.js */ 1185);
/* harmony import */ var _range_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./range.js */ 1187);


/**
 * Convert a Monaco editor location to an LSP location.
 *
 * @param location The Monaco location to convert.
 * @returns The location as an LSP location.
 */
function fromLocation(location) {
  return {
    range: (0,_range_js__WEBPACK_IMPORTED_MODULE_1__.fromRange)(location.range),
    uri: String(location.uri)
  };
}
/**
 * Convert an LSP location to a Monaco editor location.
 *
 * @param location The LSP location to convert.
 * @returns The location as Monaco editor location.
 */
function toLocation(location) {
  const {
    Uri
  } = (0,_monaco_js__WEBPACK_IMPORTED_MODULE_0__.getMonaco)();
  return {
    range: (0,_range_js__WEBPACK_IMPORTED_MODULE_1__.toRange)(location.range),
    uri: Uri.parse(location.uri)
  };
}

/***/ }),

/***/ 1223:
/*!***********************************************************************************!*\
  !*** ../../../../../node_modules/monaco-languageserver-types/lib/locationLink.js ***!
  \***********************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   fromLocationLink: () => (/* binding */ fromLocationLink),
/* harmony export */   toLocationLink: () => (/* binding */ toLocationLink)
/* harmony export */ });
/* harmony import */ var _monaco_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./monaco.js */ 1185);
/* harmony import */ var _range_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./range.js */ 1187);


/**
 * Convert a Monaco editor location link to an LSP location link.
 *
 * @param locationLink The Monaco location link to convert.
 * @returns The location link as an LSP location link.
 */
function fromLocationLink(locationLink) {
  const result = {
    targetRange: (0,_range_js__WEBPACK_IMPORTED_MODULE_1__.fromRange)(locationLink.range),
    targetSelectionRange: locationLink.targetSelectionRange ? (0,_range_js__WEBPACK_IMPORTED_MODULE_1__.fromRange)(locationLink.targetSelectionRange) : (0,_range_js__WEBPACK_IMPORTED_MODULE_1__.fromRange)(locationLink.range),
    targetUri: String(locationLink.uri)
  };
  if (locationLink.originSelectionRange) {
    result.originSelectionRange = (0,_range_js__WEBPACK_IMPORTED_MODULE_1__.fromRange)(locationLink.originSelectionRange);
  }
  return result;
}
/**
 * Convert an LSP location link to a Monaco editor location link.
 *
 * @param locationLink The LSP location link to convert.
 * @returns The location link as Monaco editor location link.
 */
function toLocationLink(locationLink) {
  const {
    Uri
  } = (0,_monaco_js__WEBPACK_IMPORTED_MODULE_0__.getMonaco)();
  const result = {
    range: (0,_range_js__WEBPACK_IMPORTED_MODULE_1__.toRange)(locationLink.targetRange),
    targetSelectionRange: (0,_range_js__WEBPACK_IMPORTED_MODULE_1__.toRange)(locationLink.targetSelectionRange),
    uri: Uri.parse(locationLink.targetUri)
  };
  if (locationLink.originSelectionRange) {
    result.originSelectionRange = (0,_range_js__WEBPACK_IMPORTED_MODULE_1__.toRange)(locationLink.originSelectionRange);
  }
  return result;
}

/***/ }),

/***/ 1205:
/*!*************************************************************************************!*\
  !*** ../../../../../node_modules/monaco-languageserver-types/lib/markdownString.js ***!
  \*************************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   fromMarkdownString: () => (/* binding */ fromMarkdownString),
/* harmony export */   toMarkdownString: () => (/* binding */ toMarkdownString)
/* harmony export */ });
/**
 * Convert a Monaco editor markdown string to an LSP markup content.
 *
 * @param markdownString The Monaco markdown string to convert.
 * @returns The markdown string as an LSP markup content.
 */
function fromMarkdownString(markdownString) {
  return {
    kind: 'markdown',
    value: markdownString.value
  };
}
/**
 * Convert an LSP markup content to a Monaco editor markdown string.
 *
 * @param markupContent The LSP markup content to convert.
 * @returns The markup content as a Monaco editor markdown string.
 */
function toMarkdownString(markupContent) {
  return {
    value: markupContent.value
  };
}

/***/ }),

/***/ 1183:
/*!*********************************************************************************!*\
  !*** ../../../../../node_modules/monaco-languageserver-types/lib/markerData.js ***!
  \*********************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   fromMarkerData: () => (/* binding */ fromMarkerData),
/* harmony export */   toMarkerData: () => (/* binding */ toMarkerData)
/* harmony export */ });
/* harmony import */ var _markerSeverity_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./markerSeverity.js */ 1184);
/* harmony import */ var _markerTag_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./markerTag.js */ 1186);
/* harmony import */ var _monaco_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./monaco.js */ 1185);
/* harmony import */ var _range_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./range.js */ 1187);
/* harmony import */ var _relatedInformation_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./relatedInformation.js */ 1188);





/**
 * Convert a Monaco editor marker data to an LSP diagnostic.
 *
 * @param markerData The Monaco marker data to convert.
 * @returns The marker data as an LSP diagnostic.
 */
function fromMarkerData(markerData) {
  const diagnostic = {
    message: markerData.message,
    range: (0,_range_js__WEBPACK_IMPORTED_MODULE_3__.fromRange)(markerData),
    severity: (0,_markerSeverity_js__WEBPACK_IMPORTED_MODULE_0__.fromMarkerSeverity)(markerData.severity)
  };
  if (typeof markerData.code === 'string') {
    diagnostic.code = markerData.code;
  } else if (markerData.code != null) {
    diagnostic.code = markerData.code.value;
    diagnostic.codeDescription = {
      href: String(markerData.code.target)
    };
  }
  if (markerData.relatedInformation) {
    diagnostic.relatedInformation = markerData.relatedInformation.map(_relatedInformation_js__WEBPACK_IMPORTED_MODULE_4__.fromRelatedInformation);
  }
  if (markerData.tags) {
    diagnostic.tags = markerData.tags.map(_markerTag_js__WEBPACK_IMPORTED_MODULE_1__.fromMarkerTag);
  }
  if (markerData.source != null) {
    diagnostic.source = markerData.source;
  }
  return diagnostic;
}
/**
 * Convert an LSP diagnostic to a Monaco editor marker data.
 *
 * @param diagnostic The LSP diagnostic to convert.
 * @param options Additional options needed to construct the Monaco marker data.
 * @returns The diagnostic as Monaco editor marker data.
 */
function toMarkerData(diagnostic, options) {
  var _a;
  const {
    MarkerSeverity,
    Uri
  } = (0,_monaco_js__WEBPACK_IMPORTED_MODULE_2__.getMonaco)();
  const markerData = {
    ...(0,_range_js__WEBPACK_IMPORTED_MODULE_3__.toRange)(diagnostic.range),
    message: diagnostic.message,
    severity: diagnostic.severity ? (0,_markerSeverity_js__WEBPACK_IMPORTED_MODULE_0__.toMarkerSeverity)(diagnostic.severity) : (_a = options === null || options === void 0 ? void 0 : options.defaultSeverity) !== null && _a !== void 0 ? _a : MarkerSeverity.Error
  };
  if (diagnostic.code != null) {
    markerData.code = diagnostic.codeDescription == null ? String(diagnostic.code) : {
      value: String(diagnostic.code),
      target: Uri.parse(diagnostic.codeDescription.href)
    };
  }
  if (diagnostic.relatedInformation) {
    markerData.relatedInformation = diagnostic.relatedInformation.map(_relatedInformation_js__WEBPACK_IMPORTED_MODULE_4__.toRelatedInformation);
  }
  if (diagnostic.tags) {
    markerData.tags = diagnostic.tags.map(_markerTag_js__WEBPACK_IMPORTED_MODULE_1__.toMarkerTag);
  }
  if (diagnostic.source != null) {
    markerData.source = diagnostic.source;
  }
  return markerData;
}

/***/ }),

/***/ 1184:
/*!*************************************************************************************!*\
  !*** ../../../../../node_modules/monaco-languageserver-types/lib/markerSeverity.js ***!
  \*************************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   fromMarkerSeverity: () => (/* binding */ fromMarkerSeverity),
/* harmony export */   toMarkerSeverity: () => (/* binding */ toMarkerSeverity)
/* harmony export */ });
/* harmony import */ var _monaco_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./monaco.js */ 1185);

/**
 * Convert a Monaco editor marker severity to an LSP diagnostic severity.
 *
 * @param severity The Monaco marker severity to convert.
 * @returns The marker severity as an LSP diagnostic severity.
 */
function fromMarkerSeverity(severity) {
  const {
    MarkerSeverity
  } = (0,_monaco_js__WEBPACK_IMPORTED_MODULE_0__.getMonaco)();
  if (severity === MarkerSeverity.Error) {
    return 1;
  }
  if (severity === MarkerSeverity.Warning) {
    return 2;
  }
  if (severity === MarkerSeverity.Info) {
    return 3;
  }
  // Severity === MarkerSeverity.Hint
  return 4;
}
/**
 * Convert an LSP diagnostic severity to a Monaco editor marker severity.
 *
 * @param severity The LSP diagnostic severity to convert.
 * @returns The diagnostic severity as Monaco editor marker severity.
 */
function toMarkerSeverity(severity) {
  const {
    MarkerSeverity
  } = (0,_monaco_js__WEBPACK_IMPORTED_MODULE_0__.getMonaco)();
  if (severity === 1) {
    return MarkerSeverity.Error;
  }
  if (severity === 2) {
    return MarkerSeverity.Warning;
  }
  if (severity === 3) {
    return MarkerSeverity.Info;
  }
  // Severity === 4
  return MarkerSeverity.Hint;
}

/***/ }),

/***/ 1186:
/*!********************************************************************************!*\
  !*** ../../../../../node_modules/monaco-languageserver-types/lib/markerTag.js ***!
  \********************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   fromMarkerTag: () => (/* binding */ fromMarkerTag),
/* harmony export */   toMarkerTag: () => (/* binding */ toMarkerTag)
/* harmony export */ });
/**
 * Convert a Monaco editor marker tag to an LSP diagnostic tag.
 *
 * @param tag The Monaco marker tag to convert.
 * @returns The marker tag as an LSP diagnostic tag.
 */
function fromMarkerTag(tag) {
  return tag;
}
/**
 * Convert an LSP diagnostic tag to a Monaco editor marker tag.
 *
 * @param tag The LSP diagnostic tag to convert.
 * @returns The diagnostic tag as Monaco editor marker tag.
 */
function toMarkerTag(tag) {
  return tag;
}

/***/ }),

/***/ 1185:
/*!*****************************************************************************!*\
  !*** ../../../../../node_modules/monaco-languageserver-types/lib/monaco.js ***!
  \*****************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   getMonaco: () => (/* binding */ getMonaco),
/* harmony export */   setMonaco: () => (/* binding */ setMonaco)
/* harmony export */ });
let monacoEditor;
/**
 * Get the Monaco editor module
 *
 * @returns The Monaco editor module
 */
function getMonaco() {
  if (!monacoEditor) {
    throw new Error('Monaco is undefined. Call setMonaco(monaco) first.');
  }
  return monacoEditor;
}
/**
 * Set the Monaco editor module to use.
 *
 * @param monaco The Monaco editor module
 */
function setMonaco(monaco) {
  monacoEditor = monaco;
}

/***/ }),

/***/ 1224:
/*!*******************************************************************************************!*\
  !*** ../../../../../node_modules/monaco-languageserver-types/lib/parameterInformation.js ***!
  \*******************************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   fromParameterInformation: () => (/* binding */ fromParameterInformation),
/* harmony export */   toParameterInformation: () => (/* binding */ toParameterInformation)
/* harmony export */ });
/* harmony import */ var _markdownString_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./markdownString.js */ 1205);

/**
 * Convert a Monaco editor parameter information to an LSP parameter information.
 *
 * @param parameterInformation The Monaco parameter information to convert.
 * @returns The parameter information as an LSP parameter information.
 */
function fromParameterInformation(parameterInformation) {
  const result = {
    label: parameterInformation.label
  };
  if (typeof parameterInformation.documentation === 'string') {
    result.documentation = parameterInformation.documentation;
  } else if (parameterInformation.documentation) {
    result.documentation = (0,_markdownString_js__WEBPACK_IMPORTED_MODULE_0__.fromMarkdownString)(parameterInformation.documentation);
  }
  return result;
}
/**
 * Convert an LSP parameter information to a Monaco editor parameter information.
 *
 * @param parameterInformation The LSP parameter information to convert.
 * @returns The parameter information as Monaco editor parameter information.
 */
function toParameterInformation(parameterInformation) {
  const result = {
    label: parameterInformation.label
  };
  if (typeof parameterInformation.documentation === 'string') {
    result.documentation = parameterInformation.documentation;
  } else if (parameterInformation.documentation) {
    result.documentation = (0,_markdownString_js__WEBPACK_IMPORTED_MODULE_0__.toMarkdownString)(parameterInformation.documentation);
  }
  return result;
}

/***/ }),

/***/ 1221:
/*!*******************************************************************************!*\
  !*** ../../../../../node_modules/monaco-languageserver-types/lib/position.js ***!
  \*******************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   fromPosition: () => (/* binding */ fromPosition),
/* harmony export */   toPosition: () => (/* binding */ toPosition)
/* harmony export */ });
/**
 * Convert a Monaco editor position to an LSP range.
 *
 * @param position The Monaco position to convert.
 * @returns The position as an LSP position.
 */
function fromPosition(position) {
  return {
    character: position.column - 1,
    line: position.lineNumber - 1
  };
}
/**
 * Convert an LSP position to a Monaco editor position.
 *
 * @param position The LSP position to convert.
 * @returns The position as Monaco editor position.
 */
function toPosition(position) {
  return {
    lineNumber: position.line + 1,
    column: position.character + 1
  };
}

/***/ }),

/***/ 1187:
/*!****************************************************************************!*\
  !*** ../../../../../node_modules/monaco-languageserver-types/lib/range.js ***!
  \****************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   fromRange: () => (/* binding */ fromRange),
/* harmony export */   toRange: () => (/* binding */ toRange)
/* harmony export */ });
/**
 * Convert a Monaco editor range to an LSP range.
 *
 * @param range The Monaco range to convert.
 * @returns The range as an LSP range.
 */
function fromRange(range) {
  return {
    start: {
      line: range.startLineNumber - 1,
      character: range.startColumn - 1
    },
    end: {
      line: range.endLineNumber - 1,
      character: range.endColumn - 1
    }
  };
}
/**
 * Convert an LSP range to a Monaco editor range.
 *
 * @param range The LSP range to convert.
 * @returns The range as Monaco editor range.
 */
function toRange(range) {
  return {
    startLineNumber: range.start.line + 1,
    startColumn: range.start.character + 1,
    endLineNumber: range.end.line + 1,
    endColumn: range.end.character + 1
  };
}

/***/ }),

/***/ 1188:
/*!*****************************************************************************************!*\
  !*** ../../../../../node_modules/monaco-languageserver-types/lib/relatedInformation.js ***!
  \*****************************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   fromRelatedInformation: () => (/* binding */ fromRelatedInformation),
/* harmony export */   toRelatedInformation: () => (/* binding */ toRelatedInformation)
/* harmony export */ });
/* harmony import */ var _monaco_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./monaco.js */ 1185);
/* harmony import */ var _range_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./range.js */ 1187);


/**
 * Convert a Monaco editor related information to an LSP diagnostic related information.
 *
 * @param relatedInformation The Monaco related information to convert.
 * @returns The related information as an LSP diagnostic related information.
 */
function fromRelatedInformation(relatedInformation) {
  return {
    location: {
      range: (0,_range_js__WEBPACK_IMPORTED_MODULE_1__.fromRange)(relatedInformation),
      uri: String(relatedInformation.resource)
    },
    message: relatedInformation.message
  };
}
/**
 * Convert an LSP diagnostic related information to a Monaco editor related information.
 *
 * @param relatedInformation The LSP diagnostic related information to convert.
 * @returns The diagnostic related information as Monaco editor related information.
 */
function toRelatedInformation(relatedInformation) {
  const {
    Uri
  } = (0,_monaco_js__WEBPACK_IMPORTED_MODULE_0__.getMonaco)();
  return {
    ...(0,_range_js__WEBPACK_IMPORTED_MODULE_1__.toRange)(relatedInformation.location.range),
    message: relatedInformation.message,
    resource: Uri.parse(relatedInformation.location.uri)
  };
}

/***/ }),

/***/ 1225:
/*!*************************************************************************************!*\
  !*** ../../../../../node_modules/monaco-languageserver-types/lib/selectionRange.js ***!
  \*************************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   fromSelectionRange: () => (/* binding */ fromSelectionRange),
/* harmony export */   toSelectionRange: () => (/* binding */ toSelectionRange)
/* harmony export */ });
/* harmony import */ var _range_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./range.js */ 1187);

/**
 * Convert a Monaco editor selection range to an LSP selection range.
 *
 * @param selectionRange The Monaco selection range to convert.
 * @returns The selection range as an LSP selection range.
 */
function fromSelectionRange(selectionRange) {
  return {
    range: (0,_range_js__WEBPACK_IMPORTED_MODULE_0__.fromRange)(selectionRange.range)
  };
}
/**
 * Convert an LSP selection range to a Monaco editor selection range.
 *
 * @param selectionRange The LSP selection range to convert.
 * @returns The selection range as Monaco editor selection range.
 */
function toSelectionRange(selectionRange) {
  return {
    range: (0,_range_js__WEBPACK_IMPORTED_MODULE_0__.toRange)(selectionRange.range)
  };
}

/***/ }),

/***/ 1227:
/*!************************************************************************************!*\
  !*** ../../../../../node_modules/monaco-languageserver-types/lib/signatureHelp.js ***!
  \************************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   fromSignatureHelp: () => (/* binding */ fromSignatureHelp),
/* harmony export */   toSignatureHelp: () => (/* binding */ toSignatureHelp)
/* harmony export */ });
/* harmony import */ var _signatureInformation_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./signatureInformation.js */ 1228);

/**
 * Convert a Monaco editor signature help to an LSP signature help.
 *
 * @param signatureHelp The Monaco signature help to convert.
 * @returns The signature help as an LSP signature help.
 */
function fromSignatureHelp(signatureHelp) {
  return {
    activeParameter: signatureHelp.activeParameter,
    activeSignature: signatureHelp.activeSignature,
    signatures: signatureHelp.signatures.map(_signatureInformation_js__WEBPACK_IMPORTED_MODULE_0__.fromSignatureInformation)
  };
}
/**
 * Convert an LSP signature help to a Monaco editor signature help.
 *
 * @param signatureHelp The LSP signature help to convert.
 * @returns The signature help as Monaco editor signature help.
 */
function toSignatureHelp(signatureHelp) {
  var _a, _b;
  return {
    activeParameter: (_a = signatureHelp.activeParameter) !== null && _a !== void 0 ? _a : 0,
    activeSignature: (_b = signatureHelp.activeSignature) !== null && _b !== void 0 ? _b : 0,
    signatures: signatureHelp.signatures.map(_signatureInformation_js__WEBPACK_IMPORTED_MODULE_0__.toSignatureInformation)
  };
}

/***/ }),

/***/ 1226:
/*!*******************************************************************************************!*\
  !*** ../../../../../node_modules/monaco-languageserver-types/lib/signatureHelpContext.js ***!
  \*******************************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   fromSignatureHelpContext: () => (/* binding */ fromSignatureHelpContext),
/* harmony export */   toSignatureHelpContext: () => (/* binding */ toSignatureHelpContext)
/* harmony export */ });
/* harmony import */ var _signatureHelp_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./signatureHelp.js */ 1227);
/* harmony import */ var _signatureHelpTriggerKind_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./signatureHelpTriggerKind.js */ 1229);


/**
 * Convert a Monaco editor signature help context to an LSP signature help context.
 *
 * @param signatureHelpContext The Monaco signature help context to convert.
 * @returns The signature help context as an LSP signature help context.
 */
function fromSignatureHelpContext(signatureHelpContext) {
  const result = {
    isRetrigger: signatureHelpContext.isRetrigger,
    triggerKind: (0,_signatureHelpTriggerKind_js__WEBPACK_IMPORTED_MODULE_1__.fromSignatureHelpTriggerKind)(signatureHelpContext.triggerKind)
  };
  if (signatureHelpContext.triggerCharacter != null) {
    result.triggerCharacter = signatureHelpContext.triggerCharacter;
  }
  if (signatureHelpContext.activeSignatureHelp) {
    result.activeSignatureHelp = (0,_signatureHelp_js__WEBPACK_IMPORTED_MODULE_0__.fromSignatureHelp)(signatureHelpContext.activeSignatureHelp);
  }
  return result;
}
/**
 * Convert an LSP signature help context to a Monaco editor signature help context.
 *
 * @param signatureHelpContext The LSP signature help context to convert.
 * @returns The signature help context as Monaco editor signature help context.
 */
function toSignatureHelpContext(signatureHelpContext) {
  const result = {
    isRetrigger: signatureHelpContext.isRetrigger,
    triggerKind: (0,_signatureHelpTriggerKind_js__WEBPACK_IMPORTED_MODULE_1__.fromSignatureHelpTriggerKind)(signatureHelpContext.triggerKind)
  };
  if (signatureHelpContext.triggerCharacter != null) {
    result.triggerCharacter = signatureHelpContext.triggerCharacter;
  }
  if (signatureHelpContext.activeSignatureHelp) {
    result.activeSignatureHelp = (0,_signatureHelp_js__WEBPACK_IMPORTED_MODULE_0__.toSignatureHelp)(signatureHelpContext.activeSignatureHelp);
  }
  return result;
}

/***/ }),

/***/ 1229:
/*!***********************************************************************************************!*\
  !*** ../../../../../node_modules/monaco-languageserver-types/lib/signatureHelpTriggerKind.js ***!
  \***********************************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   fromSignatureHelpTriggerKind: () => (/* binding */ fromSignatureHelpTriggerKind),
/* harmony export */   toSignatureHelpTriggerKind: () => (/* binding */ toSignatureHelpTriggerKind)
/* harmony export */ });
/**
 * Convert a Monaco editor signature help trigger kind to an LSP signature help trigger kind.
 *
 * @param signatureHelpTriggerKind The Monaco signature help trigger kind to convert.
 * @returns The signature help trigger kind as an LSP signature help trigger kind.
 */
function fromSignatureHelpTriggerKind(signatureHelpTriggerKind) {
  return signatureHelpTriggerKind;
}
/**
 * Convert an LSP signature help trigger kind to a Monaco editor signature help trigger kind.
 *
 * @param signatureHelpTriggerKind The LSP signature help trigger kind to convert.
 * @returns The signature help trigger kind as Monaco editor signature help trigger kind.
 */
function toSignatureHelpTriggerKind(signatureHelpTriggerKind) {
  return signatureHelpTriggerKind;
}

/***/ }),

/***/ 1228:
/*!*******************************************************************************************!*\
  !*** ../../../../../node_modules/monaco-languageserver-types/lib/signatureInformation.js ***!
  \*******************************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   fromSignatureInformation: () => (/* binding */ fromSignatureInformation),
/* harmony export */   toSignatureInformation: () => (/* binding */ toSignatureInformation)
/* harmony export */ });
/* harmony import */ var _markdownString_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./markdownString.js */ 1205);
/* harmony import */ var _parameterInformation_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./parameterInformation.js */ 1224);


/**
 * Convert a Monaco editor signature information to an LSP signature information.
 *
 * @param signatureInformation The Monaco signature information to convert.
 * @returns The signature information as an LSP signature information.
 */
function fromSignatureInformation(signatureInformation) {
  const result = {
    label: signatureInformation.label,
    parameters: signatureInformation.parameters.map(_parameterInformation_js__WEBPACK_IMPORTED_MODULE_1__.fromParameterInformation)
  };
  if (typeof signatureInformation.documentation === 'string') {
    result.documentation = signatureInformation.documentation;
  } else if (signatureInformation.documentation) {
    result.documentation = (0,_markdownString_js__WEBPACK_IMPORTED_MODULE_0__.fromMarkdownString)(signatureInformation.documentation);
  }
  if (signatureInformation.activeParameter != null) {
    result.activeParameter = signatureInformation.activeParameter;
  }
  return result;
}
/**
 * Convert an LSP signature information to a Monaco editor signature information.
 *
 * @param signatureInformation The LSP signature information to convert.
 * @returns The signature information as Monaco editor signature information.
 */
function toSignatureInformation(signatureInformation) {
  var _a, _b;
  const result = {
    label: signatureInformation.label,
    parameters: (_b = (_a = signatureInformation.parameters) === null || _a === void 0 ? void 0 : _a.map(_parameterInformation_js__WEBPACK_IMPORTED_MODULE_1__.toParameterInformation)) !== null && _b !== void 0 ? _b : []
  };
  if (typeof signatureInformation.documentation === 'string') {
    result.documentation = signatureInformation.documentation;
  } else if (signatureInformation.documentation) {
    result.documentation = (0,_markdownString_js__WEBPACK_IMPORTED_MODULE_0__.toMarkdownString)(signatureInformation.documentation);
  }
  if (signatureInformation.activeParameter != null) {
    result.activeParameter = signatureInformation.activeParameter;
  }
  return result;
}

/***/ }),

/***/ 1206:
/*!******************************************************************************************!*\
  !*** ../../../../../node_modules/monaco-languageserver-types/lib/singleEditOperation.js ***!
  \******************************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   fromSingleEditOperation: () => (/* binding */ fromSingleEditOperation),
/* harmony export */   toSingleEditOperation: () => (/* binding */ toSingleEditOperation)
/* harmony export */ });
/* harmony import */ var _range_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./range.js */ 1187);

/**
 * Convert a Monaco editor single edit operation to an LSP text edit.
 *
 * @param singleEditOperation The Monaco single edit operation to convert.
 * @returns The single edit operation as an LSP text edit.
 */
function fromSingleEditOperation(singleEditOperation) {
  var _a;
  return {
    newText: (_a = singleEditOperation.text) !== null && _a !== void 0 ? _a : '',
    range: (0,_range_js__WEBPACK_IMPORTED_MODULE_0__.fromRange)(singleEditOperation.range)
  };
}
/**
 * Convert an LSP text edit to a Monaco editor single edit operation.
 *
 * @param textEdit The LSP text edit to convert.
 * @returns The text edit as Monaco editor single edit operation.
 */
function toSingleEditOperation(textEdit) {
  return {
    range: (0,_range_js__WEBPACK_IMPORTED_MODULE_0__.toRange)(textEdit.range),
    text: textEdit.newText
  };
}

/***/ }),

/***/ 1213:
/*!*********************************************************************************!*\
  !*** ../../../../../node_modules/monaco-languageserver-types/lib/symbolKind.js ***!
  \*********************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   fromSymbolKind: () => (/* binding */ fromSymbolKind),
/* harmony export */   toSymbolKind: () => (/* binding */ toSymbolKind)
/* harmony export */ });
/* harmony import */ var _monaco_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./monaco.js */ 1185);

/**
 * Convert a Monaco editor symbol kind to an LSP symbol kind.
 *
 * @param symbolKind The Monaco symbol kind to convert.
 * @returns The symbol kind as an LSP symbol kind.
 */
function fromSymbolKind(symbolKind) {
  const {
    SymbolKind
  } = (0,_monaco_js__WEBPACK_IMPORTED_MODULE_0__.getMonaco)().languages;
  if (symbolKind === SymbolKind.File) {
    return 1;
  }
  if (symbolKind === SymbolKind.Module) {
    return 2;
  }
  if (symbolKind === SymbolKind.Namespace) {
    return 3;
  }
  if (symbolKind === SymbolKind.Package) {
    return 4;
  }
  if (symbolKind === SymbolKind.Class) {
    return 5;
  }
  if (symbolKind === SymbolKind.Method) {
    return 6;
  }
  if (symbolKind === SymbolKind.Property) {
    return 7;
  }
  if (symbolKind === SymbolKind.Field) {
    return 8;
  }
  if (symbolKind === SymbolKind.Constructor) {
    return 9;
  }
  if (symbolKind === SymbolKind.Enum) {
    return 10;
  }
  if (symbolKind === SymbolKind.Interface) {
    return 11;
  }
  if (symbolKind === SymbolKind.Function) {
    return 12;
  }
  if (symbolKind === SymbolKind.Variable) {
    return 13;
  }
  if (symbolKind === SymbolKind.Constant) {
    return 14;
  }
  if (symbolKind === SymbolKind.String) {
    return 15;
  }
  if (symbolKind === SymbolKind.Number) {
    return 16;
  }
  if (symbolKind === SymbolKind.Boolean) {
    return 17;
  }
  if (symbolKind === SymbolKind.Array) {
    return 18;
  }
  if (symbolKind === SymbolKind.Object) {
    return 19;
  }
  if (symbolKind === SymbolKind.Key) {
    return 20;
  }
  if (symbolKind === SymbolKind.Null) {
    return 21;
  }
  if (symbolKind === SymbolKind.EnumMember) {
    return 22;
  }
  if (symbolKind === SymbolKind.Struct) {
    return 23;
  }
  if (symbolKind === SymbolKind.Event) {
    return 24;
  }
  if (symbolKind === SymbolKind.Operator) {
    return 25;
  }
  // SymbolKind === SymbolKind.TypeParameter
  return 26;
}
/**
 * Convert an LSP symbol kind to a Monaco editor symbol kind.
 *
 * @param symbolKind The LSP symbol kind to convert.
 * @returns The symbol kind as Monaco editor symbol kind.
 */
function toSymbolKind(symbolKind) {
  const {
    SymbolKind
  } = (0,_monaco_js__WEBPACK_IMPORTED_MODULE_0__.getMonaco)().languages;
  if (symbolKind === 1) {
    return SymbolKind.File;
  }
  if (symbolKind === 2) {
    return SymbolKind.Module;
  }
  if (symbolKind === 3) {
    return SymbolKind.Namespace;
  }
  if (symbolKind === 4) {
    return SymbolKind.Package;
  }
  if (symbolKind === 5) {
    return SymbolKind.Class;
  }
  if (symbolKind === 6) {
    return SymbolKind.Method;
  }
  if (symbolKind === 7) {
    return SymbolKind.Property;
  }
  if (symbolKind === 8) {
    return SymbolKind.Field;
  }
  if (symbolKind === 9) {
    return SymbolKind.Constructor;
  }
  if (symbolKind === 10) {
    return SymbolKind.Enum;
  }
  if (symbolKind === 11) {
    return SymbolKind.Interface;
  }
  if (symbolKind === 12) {
    return SymbolKind.Function;
  }
  if (symbolKind === 13) {
    return SymbolKind.Variable;
  }
  if (symbolKind === 14) {
    return SymbolKind.Constant;
  }
  if (symbolKind === 15) {
    return SymbolKind.String;
  }
  if (symbolKind === 16) {
    return SymbolKind.Number;
  }
  if (symbolKind === 17) {
    return SymbolKind.Boolean;
  }
  if (symbolKind === 18) {
    return SymbolKind.Array;
  }
  if (symbolKind === 19) {
    return SymbolKind.Object;
  }
  if (symbolKind === 20) {
    return SymbolKind.Key;
  }
  if (symbolKind === 21) {
    return SymbolKind.Null;
  }
  if (symbolKind === 22) {
    return SymbolKind.EnumMember;
  }
  if (symbolKind === 23) {
    return SymbolKind.Struct;
  }
  if (symbolKind === 24) {
    return SymbolKind.Event;
  }
  if (symbolKind === 25) {
    return SymbolKind.Operator;
  }
  // SymbolKind === 26
  return SymbolKind.TypeParameter;
}

/***/ }),

/***/ 1214:
/*!********************************************************************************!*\
  !*** ../../../../../node_modules/monaco-languageserver-types/lib/symbolTag.js ***!
  \********************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   fromSymbolTag: () => (/* binding */ fromSymbolTag),
/* harmony export */   toSymbolTag: () => (/* binding */ toSymbolTag)
/* harmony export */ });
/**
 * Convert a Monaco editor symbol tag to an LSP symbol tag.
 *
 * @param symbolTag The Monaco symbol tag to convert.
 * @returns The symbol tag as an LSP symbol tag.
 */
function fromSymbolTag(symbolTag) {
  return symbolTag;
}
/**
 * Convert an LSP symbol tag to a Monaco editor symbol tag.
 *
 * @param symbolTag The LSP symbol tag to convert.
 * @returns The symbol tag as Monaco editor symbol tag.
 */
function toSymbolTag(symbolTag) {
  return symbolTag;
}

/***/ }),

/***/ 1190:
/*!*******************************************************************************!*\
  !*** ../../../../../node_modules/monaco-languageserver-types/lib/textEdit.js ***!
  \*******************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   fromTextEdit: () => (/* binding */ fromTextEdit),
/* harmony export */   toTextEdit: () => (/* binding */ toTextEdit)
/* harmony export */ });
/* harmony import */ var _range_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./range.js */ 1187);

/**
 * Convert a Monaco editor text edit to an LSP text edit.
 *
 * @param textEdit The Monaco text edit to convert.
 * @returns The text edit as an LSP text edit.
 */
function fromTextEdit(textEdit) {
  return {
    range: (0,_range_js__WEBPACK_IMPORTED_MODULE_0__.fromRange)(textEdit.range),
    newText: textEdit.text
  };
}
/**
 * Convert an LSP text edit to a Monaco editor text edit.
 *
 * @param textEdit The LSP text edit to convert.
 * @returns The text edit as Monaco editor text edit.
 */
function toTextEdit(textEdit) {
  return {
    range: (0,_range_js__WEBPACK_IMPORTED_MODULE_0__.toRange)(textEdit.range),
    text: textEdit.newText
  };
}

/***/ }),

/***/ 1189:
/*!************************************************************************************!*\
  !*** ../../../../../node_modules/monaco-languageserver-types/lib/workspaceEdit.js ***!
  \************************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   fromWorkspaceEdit: () => (/* binding */ fromWorkspaceEdit),
/* harmony export */   toWorkspaceEdit: () => (/* binding */ toWorkspaceEdit)
/* harmony export */ });
/* harmony import */ var _monaco_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./monaco.js */ 1185);
/* harmony import */ var _textEdit_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./textEdit.js */ 1190);
/* harmony import */ var _workspaceFileEdit_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./workspaceFileEdit.js */ 1191);



/**
 * Convert a Monaco editor workspace edit to an LSP workspace edit.
 *
 * @param workspaceEdit The Monaco workspace edit to convert.
 * @returns The workspace edit as an LSP workspace edit.
 */
function fromWorkspaceEdit(workspaceEdit) {
  const changes = {};
  const documentChanges = [];
  const textDocumentMap = new Map();
  for (const edit of workspaceEdit.edits) {
    if ('resource' in edit) {
      const uri = String(edit.resource);
      if (edit.versionId == null) {
        changes[uri] = [];
        changes[uri].push((0,_textEdit_js__WEBPACK_IMPORTED_MODULE_1__.fromTextEdit)(edit.textEdit));
      } else {
        let versionMap = textDocumentMap.get(uri);
        if (!versionMap) {
          versionMap = new Map();
          textDocumentMap.set(uri, versionMap);
        }
        let textDocumentEdits = versionMap.get(edit.versionId);
        if (!textDocumentEdits) {
          textDocumentEdits = [];
          versionMap.set(edit.versionId, textDocumentEdits);
          documentChanges.push({
            textDocument: {
              uri,
              version: edit.versionId
            },
            edits: textDocumentEdits
          });
        }
        textDocumentEdits.push((0,_textEdit_js__WEBPACK_IMPORTED_MODULE_1__.fromTextEdit)(edit.textEdit));
      }
    } else {
      documentChanges.push((0,_workspaceFileEdit_js__WEBPACK_IMPORTED_MODULE_2__.fromWorkspaceFileEdit)(edit));
    }
  }
  return {
    changes,
    documentChanges
  };
}
/**
 * Convert an LSP text edit and uri to a Monaco editor workspace text edit.
 *
 * @param textEdit The LSP text edit to convert.
 * @param uri The uri of the workspace text edit.
 * @param versionId The version ID of the workspace text edit.
 * @returns The text edit and uri as Monaco editor workspace text edit.
 */
function toWorkspaceTextEdit(textEdit, uri, versionId) {
  const {
    Uri
  } = (0,_monaco_js__WEBPACK_IMPORTED_MODULE_0__.getMonaco)();
  return {
    resource: Uri.parse(uri),
    versionId,
    textEdit: (0,_textEdit_js__WEBPACK_IMPORTED_MODULE_1__.toTextEdit)(textEdit)
  };
}
/**
 * Convert an LSP workspace edit to a Monaco editor workspace edit.
 *
 * @param workspaceEdit The LSP workspace edit to convert.
 * @returns The workspace edit as Monaco editor workspace edit.
 */
function toWorkspaceEdit(workspaceEdit) {
  var _a;
  const edits = [];
  if (workspaceEdit.changes) {
    for (const [uri, textEdits] of Object.entries(workspaceEdit.changes)) {
      for (const textEdit of textEdits) {
        edits.push(toWorkspaceTextEdit(textEdit, uri));
      }
    }
  }
  if (workspaceEdit.documentChanges) {
    for (const documentChange of workspaceEdit.documentChanges) {
      if ('textDocument' in documentChange) {
        for (const textEdit of documentChange.edits) {
          edits.push(toWorkspaceTextEdit(textEdit, documentChange.textDocument.uri, (_a = documentChange.textDocument.version) !== null && _a !== void 0 ? _a : undefined));
        }
      } else {
        edits.push((0,_workspaceFileEdit_js__WEBPACK_IMPORTED_MODULE_2__.toWorkspaceFileEdit)(documentChange));
      }
    }
  }
  return {
    edits
  };
}

/***/ }),

/***/ 1191:
/*!****************************************************************************************!*\
  !*** ../../../../../node_modules/monaco-languageserver-types/lib/workspaceFileEdit.js ***!
  \****************************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   fromWorkspaceFileEdit: () => (/* binding */ fromWorkspaceFileEdit),
/* harmony export */   toWorkspaceFileEdit: () => (/* binding */ toWorkspaceFileEdit)
/* harmony export */ });
/* harmony import */ var _monaco_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./monaco.js */ 1185);
/* harmony import */ var _workspaceFileEditOptions_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./workspaceFileEditOptions.js */ 1192);


/**
 * Convert Monaco editor workspace file edit options to LSP workspace file edit options.
 *
 * @param workspaceFileEdit The Monaco workspace file edit options to convert.
 * @returns The range as LSP workspace file edit options.
 */
function fromWorkspaceFileEdit(workspaceFileEdit) {
  let result;
  if (workspaceFileEdit.oldResource) {
    result = workspaceFileEdit.newResource ? {
      kind: 'rename',
      oldUri: String(workspaceFileEdit.oldResource),
      newUri: String(workspaceFileEdit.newResource)
    } : {
      kind: 'delete',
      uri: String(workspaceFileEdit.oldResource)
    };
  } else if (workspaceFileEdit.newResource) {
    result = {
      kind: 'create',
      uri: String(workspaceFileEdit.newResource)
    };
  } else {
    throw new Error('Could not convert workspace file edit to language server type', {
      cause: workspaceFileEdit
    });
  }
  if (workspaceFileEdit.options) {
    result.options = (0,_workspaceFileEditOptions_js__WEBPACK_IMPORTED_MODULE_1__.fromWorkspaceFileEditOptions)(workspaceFileEdit.options);
  }
  return result;
}
/**
 * Convert an LSP workspace file edit to a Monaco editor workspace file edit.
 *
 * @param workspaceFileEdit The LSP workspace file edit to convert.
 * @returns The workspace file edit options Monaco editor workspace file edit options.
 */
function toWorkspaceFileEdit(workspaceFileEdit) {
  const {
    Uri
  } = (0,_monaco_js__WEBPACK_IMPORTED_MODULE_0__.getMonaco)();
  const result = workspaceFileEdit.kind === 'create' ? {
    newResource: Uri.parse(workspaceFileEdit.uri)
  } : workspaceFileEdit.kind === 'delete' ? {
    oldResource: Uri.parse(workspaceFileEdit.uri)
  } : {
    oldResource: Uri.parse(workspaceFileEdit.oldUri),
    newResource: Uri.parse(workspaceFileEdit.newUri)
  };
  if (workspaceFileEdit.options) {
    result.options = (0,_workspaceFileEditOptions_js__WEBPACK_IMPORTED_MODULE_1__.toWorkspaceFileEditOptions)(workspaceFileEdit.options);
  }
  return result;
}

/***/ }),

/***/ 1192:
/*!***********************************************************************************************!*\
  !*** ../../../../../node_modules/monaco-languageserver-types/lib/workspaceFileEditOptions.js ***!
  \***********************************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   fromWorkspaceFileEditOptions: () => (/* binding */ fromWorkspaceFileEditOptions),
/* harmony export */   toWorkspaceFileEditOptions: () => (/* binding */ toWorkspaceFileEditOptions)
/* harmony export */ });
/**
 * Convert Monaco editor workspace file edit options to LSP workspace file edit options.
 *
 * @param options The Monaco workspace file edit options to convert.
 * @returns The range as LSP workspace file edit options.
 */
function fromWorkspaceFileEditOptions(options) {
  const result = {};
  if (options.ignoreIfExists != null) {
    result.ignoreIfExists = options.ignoreIfExists;
  }
  if (options.ignoreIfNotExists != null) {
    result.ignoreIfNotExists = options.ignoreIfNotExists;
  }
  if (options.overwrite != null) {
    result.overwrite = options.overwrite;
  }
  if (options.recursive != null) {
    result.recursive = options.recursive;
  }
  return result;
}
/**
 * Convert LSP workspace file edit options to Monaco editor workspace file edit options.
 *
 * @param options The LSP workspace file edit options to convert.
 * @returns The workspace file edit options Monaco editor workspace file edit options.
 */
function toWorkspaceFileEditOptions(options) {
  const result = {};
  if (options.ignoreIfExists != null) {
    result.ignoreIfExists = options.ignoreIfExists;
  }
  if (options.ignoreIfNotExists != null) {
    result.ignoreIfNotExists = options.ignoreIfNotExists;
  }
  if (options.overwrite != null) {
    result.overwrite = options.overwrite;
  }
  if (options.recursive != null) {
    result.recursive = options.recursive;
  }
  return result;
}

/***/ }),

/***/ 1230:
/*!************************************************************************!*\
  !*** ../../../../../node_modules/monaco-marker-data-provider/index.js ***!
  \************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   registerMarkerDataProvider: () => (/* binding */ registerMarkerDataProvider)
/* harmony export */ });
/**
 * Register a marker data provider that can provide marker data for a model.
 *
 * @param monaco The Monaco editor module.
 * @param languageSelector The language id to register the provider for.
 * @param provider The provider that can provide marker data.
 * @returns A disposable.
 */
function registerMarkerDataProvider(monaco, languageSelector, provider) {
  const listeners = new Map();
  const matchesLanguage = model => {
    if (languageSelector === '*') {
      return true;
    }
    const languageId = model.getLanguageId();
    return Array.isArray(languageSelector) ? languageSelector.includes(languageId) : languageSelector === languageId;
  };
  const doValidate = async model => {
    const markers = await provider.provideMarkerData(model);
    // The model have have been disposed by the time marker data has been fetched.
    if (!model.isDisposed() && matchesLanguage(model)) {
      monaco.editor.setModelMarkers(model, provider.owner, markers !== null && markers !== void 0 ? markers : []);
    }
  };
  const onModelAdd = model => {
    if (!matchesLanguage(model)) {
      return;
    }
    let handle;
    listeners.set(String(model.uri), model.onDidChangeContent(() => {
      clearTimeout(handle);
      handle = setTimeout(() => {
        doValidate(model);
      }, 500);
    }));
    doValidate(model);
  };
  const onModelRemoved = model => {
    monaco.editor.setModelMarkers(model, provider.owner, []);
    const uriStr = String(model.uri);
    const listener = listeners.get(uriStr);
    if (listener) {
      listener.dispose();
      listeners.delete(uriStr);
    }
  };
  const disposables = [monaco.editor.onDidCreateModel(onModelAdd), monaco.editor.onWillDisposeModel(model => {
    var _provider$doReset;
    onModelRemoved(model);
    (_provider$doReset = provider.doReset) === null || _provider$doReset === void 0 ? void 0 : _provider$doReset.call(provider, model);
  }), monaco.editor.onDidChangeModelLanguage(event => {
    var _provider$doReset2;
    onModelRemoved(event.model);
    onModelAdd(event.model);
    (_provider$doReset2 = provider.doReset) === null || _provider$doReset2 === void 0 ? void 0 : _provider$doReset2.call(provider, event.model);
  })];
  for (const model of monaco.editor.getModels()) {
    onModelAdd(model);
  }
  return {
    dispose() {
      for (const uri of listeners.keys()) {
        onModelRemoved(monaco.editor.getModel(monaco.Uri.parse(uri)));
      }
      while (disposables.length) {
        disposables.pop().dispose();
      }
    }
  };
}

/***/ }),

/***/ 1231:
/*!******************************************************************!*\
  !*** ../../../../../node_modules/monaco-worker-manager/index.js ***!
  \******************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   createWorkerManager: () => (/* binding */ createWorkerManager)
/* harmony export */ });
/**
 * Create a worker manager.
 *
 * A worker manager is an object which deals with Monaco based web workers, such as cleanups and
 * idle timeouts.
 *
 * @param monaco - The Monaco editor module.
 * @param options - The options of the worker manager.
 * @returns The worker manager.
 */
function createWorkerManager(monaco, options) {
  let {
    createData,
    interval = 30000,
    label,
    moduleId,
    stopWhenIdleFor = 120000
  } = options;
  let worker;
  let lastUsedTime = 0;
  let disposed = false;
  const stopWorker = () => {
    if (worker) {
      worker.dispose();
      worker = undefined;
    }
  };
  const intervalId = setInterval(() => {
    if (!worker) {
      return;
    }
    const timePassedSinceLastUsed = Date.now() - lastUsedTime;
    if (timePassedSinceLastUsed > stopWhenIdleFor) {
      stopWorker();
    }
  }, interval);
  return {
    dispose() {
      disposed = true;
      clearInterval(intervalId);
      stopWorker();
    },
    getWorker(...resources) {
      if (disposed) {
        throw new Error('Worker manager has been disposed');
      }
      lastUsedTime = Date.now();
      if (!worker) {
        worker = monaco.editor.createWebWorker({
          createData,
          label,
          moduleId
        });
      }
      return worker.withSyncedResources(resources);
    },
    updateCreateData(newCreateData) {
      createData = newCreateData;
      stopWorker();
    }
  };
}

/***/ }),

/***/ 1180:
/*!********************************************************!*\
  !*** ../../../../../node_modules/monaco-yaml/index.js ***!
  \********************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   configureMonacoYaml: () => (/* binding */ configureMonacoYaml)
/* harmony export */ });
/* harmony import */ var monaco_languageserver_types__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! monaco-languageserver-types */ 1181);
/* harmony import */ var monaco_marker_data_provider__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! monaco-marker-data-provider */ 1230);
/* harmony import */ var monaco_worker_manager__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! monaco-worker-manager */ 1231);
// src/index.ts




// src/languageFeatures.ts

function createMarkerDataProvider(getWorker) {
  return {
    owner: "yaml",
    async provideMarkerData(model) {
      const worker = await getWorker(model.uri);
      const diagnostics = await worker.doValidation(String(model.uri));
      return diagnostics == null ? void 0 : diagnostics.map((diagnostic) => (0,monaco_languageserver_types__WEBPACK_IMPORTED_MODULE_0__.toMarkerData)(diagnostic));
    },
    async doReset(model) {
      const worker = await getWorker(model.uri);
      await worker.resetSchema(String(model.uri));
    }
  };
}
function createCompletionItemProvider(getWorker) {
  return {
    triggerCharacters: [" ", ":"],
    async provideCompletionItems(model, position) {
      const resource = model.uri;
      const wordInfo = model.getWordUntilPosition(position);
      const worker = await getWorker(resource);
      const info = await worker.doComplete(String(resource), (0,monaco_languageserver_types__WEBPACK_IMPORTED_MODULE_0__.fromPosition)(position));
      if (info) {
        return (0,monaco_languageserver_types__WEBPACK_IMPORTED_MODULE_0__.toCompletionList)(info, {
          range: {
            startLineNumber: position.lineNumber,
            startColumn: wordInfo.startColumn,
            endLineNumber: position.lineNumber,
            endColumn: wordInfo.endColumn
          }
        });
      }
    }
  };
}
function createDefinitionProvider(getWorker) {
  return {
    async provideDefinition(model, position) {
      const resource = model.uri;
      const worker = await getWorker(resource);
      const locationLinks = await worker.doDefinition(String(resource), (0,monaco_languageserver_types__WEBPACK_IMPORTED_MODULE_0__.fromPosition)(position));
      return locationLinks == null ? void 0 : locationLinks.map(monaco_languageserver_types__WEBPACK_IMPORTED_MODULE_0__.toLocationLink);
    }
  };
}
function createHoverProvider(getWorker) {
  return {
    async provideHover(model, position) {
      const resource = model.uri;
      const worker = await getWorker(resource);
      const info = await worker.doHover(String(resource), (0,monaco_languageserver_types__WEBPACK_IMPORTED_MODULE_0__.fromPosition)(position));
      if (info) {
        return (0,monaco_languageserver_types__WEBPACK_IMPORTED_MODULE_0__.toHover)(info);
      }
    }
  };
}
function createDocumentSymbolProvider(getWorker) {
  return {
    async provideDocumentSymbols(model) {
      const resource = model.uri;
      const worker = await getWorker(resource);
      const items = await worker.findDocumentSymbols(String(resource));
      return items == null ? void 0 : items.map(monaco_languageserver_types__WEBPACK_IMPORTED_MODULE_0__.toDocumentSymbol);
    }
  };
}
function createDocumentFormattingEditProvider(getWorker) {
  return {
    async provideDocumentFormattingEdits(model) {
      const resource = model.uri;
      const worker = await getWorker(resource);
      const edits = await worker.format(String(resource));
      return edits == null ? void 0 : edits.map(monaco_languageserver_types__WEBPACK_IMPORTED_MODULE_0__.toTextEdit);
    }
  };
}
function createLinkProvider(getWorker) {
  return {
    async provideLinks(model) {
      const resource = model.uri;
      const worker = await getWorker(resource);
      const links = await worker.findLinks(String(resource));
      if (links) {
        return {
          links: links.map(monaco_languageserver_types__WEBPACK_IMPORTED_MODULE_0__.toLink)
        };
      }
    }
  };
}
function createCodeActionProvider(getWorker) {
  return {
    async provideCodeActions(model, range, context) {
      const resource = model.uri;
      const worker = await getWorker(resource);
      const codeActions = await worker.getCodeAction(
        String(resource),
        (0,monaco_languageserver_types__WEBPACK_IMPORTED_MODULE_0__.fromRange)(range),
        (0,monaco_languageserver_types__WEBPACK_IMPORTED_MODULE_0__.fromCodeActionContext)(context)
      );
      if (codeActions) {
        return {
          actions: codeActions.map((codeAction) => (0,monaco_languageserver_types__WEBPACK_IMPORTED_MODULE_0__.toCodeAction)(codeAction)),
          dispose() {
          }
        };
      }
    }
  };
}
function createFoldingRangeProvider(getWorker) {
  return {
    async provideFoldingRanges(model) {
      const resource = model.uri;
      const worker = await getWorker(resource);
      const foldingRanges = await worker.getFoldingRanges(String(resource));
      return foldingRanges == null ? void 0 : foldingRanges.map(monaco_languageserver_types__WEBPACK_IMPORTED_MODULE_0__.toFoldingRange);
    }
  };
}

// src/index.ts
function configureMonacoYaml(monaco, options) {
  const createData = {
    completion: true,
    customTags: [],
    enableSchemaRequest: false,
    format: true,
    isKubernetes: false,
    hover: true,
    schemas: [],
    validate: true,
    yamlVersion: "1.2",
    ...options
  };
  (0,monaco_languageserver_types__WEBPACK_IMPORTED_MODULE_0__.setMonaco)(monaco);
  monaco.languages.register({
    id: "yaml",
    extensions: [".yaml", ".yml"],
    aliases: ["YAML", "yaml", "YML", "yml"],
    mimetypes: ["application/x-yaml"]
  });
  const worker = (0,monaco_worker_manager__WEBPACK_IMPORTED_MODULE_2__.createWorkerManager)(monaco, {
    label: "yaml",
    moduleId: "monaco-yaml/yaml.worker",
    createData
  });
  let markerDataProvider = (0,monaco_marker_data_provider__WEBPACK_IMPORTED_MODULE_1__.registerMarkerDataProvider)(
    monaco,
    "yaml",
    createMarkerDataProvider(worker.getWorker)
  );
  const disposables = [
    worker,
    monaco.languages.registerCompletionItemProvider(
      "yaml",
      createCompletionItemProvider(worker.getWorker)
    ),
    monaco.languages.registerHoverProvider("yaml", createHoverProvider(worker.getWorker)),
    monaco.languages.registerDefinitionProvider("yaml", createDefinitionProvider(worker.getWorker)),
    monaco.languages.registerDocumentSymbolProvider(
      "yaml",
      createDocumentSymbolProvider(worker.getWorker)
    ),
    monaco.languages.registerDocumentFormattingEditProvider(
      "yaml",
      createDocumentFormattingEditProvider(worker.getWorker)
    ),
    monaco.languages.registerLinkProvider("yaml", createLinkProvider(worker.getWorker)),
    monaco.languages.registerCodeActionProvider("yaml", createCodeActionProvider(worker.getWorker)),
    monaco.languages.registerFoldingRangeProvider(
      "yaml",
      createFoldingRangeProvider(worker.getWorker)
    ),
    monaco.languages.setLanguageConfiguration("yaml", {
      comments: {
        lineComment: "#"
      },
      brackets: [
        ["{", "}"],
        ["[", "]"],
        ["(", ")"]
      ],
      autoClosingPairs: [
        { open: "{", close: "}" },
        { open: "[", close: "]" },
        { open: "(", close: ")" },
        { open: '"', close: '"' },
        { open: "'", close: "'" }
      ],
      surroundingPairs: [
        { open: "{", close: "}" },
        { open: "[", close: "]" },
        { open: "(", close: ")" },
        { open: '"', close: '"' },
        { open: "'", close: "'" }
      ],
      onEnterRules: [
        {
          beforeText: /:\s*$/,
          action: { indentAction: monaco.languages.IndentAction.Indent }
        }
      ]
    })
  ];
  return {
    dispose() {
      for (const disposable of disposables) {
        disposable.dispose();
      }
    },
    update(newOptions) {
      worker.updateCreateData(Object.assign(createData, newOptions));
      markerDataProvider.dispose();
      markerDataProvider = (0,monaco_marker_data_provider__WEBPACK_IMPORTED_MODULE_1__.registerMarkerDataProvider)(
        monaco,
        "yaml",
        createMarkerDataProvider(worker.getWorker)
      );
    }
  };
}

//# sourceMappingURL=index.js.map


/***/ })

}]);
//# sourceMappingURL=kbn-ui-shared-deps-src.chunk.2.js.map