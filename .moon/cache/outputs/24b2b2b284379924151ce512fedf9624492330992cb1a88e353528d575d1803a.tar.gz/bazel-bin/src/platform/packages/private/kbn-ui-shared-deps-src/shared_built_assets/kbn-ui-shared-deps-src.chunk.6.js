"use strict";
(self["webpackChunk_kbnSharedDeps_"] = self["webpackChunk_kbnSharedDeps_"] || []).push([[6],{

/***/ 1177:
/*!**************************************************************************!*\
  !*** ../../shared/kbn-monaco/src/languages/esql/lib/esql_line_tokens.ts ***!
  \**************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ESQLLineTokens: () => (/* binding */ ESQLLineTokens)
/* harmony export */ });
/* harmony import */ var _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/defineProperty */ 750);
/* harmony import */ var _esql_state__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./esql_state */ 1178);

/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the "Elastic License
 * 2.0", the "GNU Affero General Public License v3.0 only", and the "Server Side
 * Public License v 1"; you may not use this file except in compliance with, at
 * your election, the "Elastic License 2.0", the "GNU Affero General Public
 * License v3.0 only", or the "Server Side Public License, v 1".
 */



/** @internal **/
class ESQLLineTokens {
  constructor(tokens, line) {
    (0,_babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "endState", void 0);
    (0,_babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "tokens", void 0);
    this.endState = new _esql_state__WEBPACK_IMPORTED_MODULE_1__.ESQLState();
    this.endState.setLineNumber(line);
    this.tokens = tokens;
  }
}

/***/ }),

/***/ 1178:
/*!********************************************************************!*\
  !*** ../../shared/kbn-monaco/src/languages/esql/lib/esql_state.ts ***!
  \********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ESQLState: () => (/* binding */ ESQLState)
/* harmony export */ });
/* harmony import */ var _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/defineProperty */ 750);

/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the "Elastic License
 * 2.0", the "GNU Affero General Public License v3.0 only", and the "Server Side
 * Public License v 1"; you may not use this file except in compliance with, at
 * your election, the "Elastic License 2.0", the "GNU Affero General Public
 * License v3.0 only", or the "Server Side Public License, v 1".
 */

/** @internal **/
class ESQLState {
  constructor() {
    (0,_babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "lastLine", 0);
  }
  setLineNumber(n) {
    this.lastLine = n;
  }
  getLineNumber() {
    return this.lastLine;
  }
  clone() {
    const newState = new ESQLState();
    newState.setLineNumber(this.lastLine);
    return newState;
  }
  equals(other) {
    return false;
  }
}

/***/ }),

/***/ 1176:
/*!********************************************************************!*\
  !*** ../../shared/kbn-monaco/src/languages/esql/lib/esql_token.ts ***!
  \********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ESQLToken: () => (/* binding */ ESQLToken)
/* harmony export */ });
/* harmony import */ var _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/defineProperty */ 750);
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./constants */ 783);

/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the "Elastic License
 * 2.0", the "GNU Affero General Public License v3.0 only", and the "Server Side
 * Public License v 1"; you may not use this file except in compliance with, at
 * your election, the "Elastic License 2.0", the "GNU Affero General Public
 * License v3.0 only", or the "Server Side Public License, v 1".
 */



/** @internal **/
class ESQLToken {
  constructor(ruleName, startIndex, stopIndex) {
    (0,_babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "scopes", void 0);
    this.startIndex = startIndex;
    this.stopIndex = stopIndex;
    this.scopes = ruleName.toLowerCase() + _constants__WEBPACK_IMPORTED_MODULE_1__.ESQL_TOKEN_POSTFIX;
  }
}

/***/ }),

/***/ 1179:
/*!****************************************************************************!*\
  !*** ../../shared/kbn-monaco/src/languages/esql/lib/esql_token_helpers.ts ***!
  \****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   addFunctionTokens: () => (/* binding */ addFunctionTokens),
/* harmony export */   mergeTokens: () => (/* binding */ mergeTokens)
/* harmony export */ });
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./constants */ 783);
/* harmony import */ var _esql_token__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./esql_token */ 1176);
/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the "Elastic License
 * 2.0", the "GNU Affero General Public License v3.0 only", and the "Server Side
 * Public License v 1"; you may not use this file except in compliance with, at
 * your election, the "Elastic License 2.0", the "GNU Affero General Public
 * License v3.0 only", or the "Server Side Public License, v 1".
 */



function nonNullable(value) {
  return value != null;
}
function addFunctionTokens(tokens) {
  // need to trim spaces as "abs (arg)" is still valid as function
  const myTokensWithoutSpaces = tokens.filter(({
    scopes
  }) => scopes !== 'expr_ws' + _constants__WEBPACK_IMPORTED_MODULE_0__.ESQL_TOKEN_POSTFIX);
  // find out all unquoted_identifiers index
  const possiblyFunctions = myTokensWithoutSpaces.map((t, i) => t.scopes === 'unquoted_identifier' + _constants__WEBPACK_IMPORTED_MODULE_0__.ESQL_TOKEN_POSTFIX ? i : undefined).filter(nonNullable);

  // then check if the token next is an opening bracket
  for (const index of possiblyFunctions) {
    var _myTokensWithoutSpace;
    if (((_myTokensWithoutSpace = myTokensWithoutSpaces[index + 1]) === null || _myTokensWithoutSpace === void 0 ? void 0 : _myTokensWithoutSpace.scopes) === 'lp' + _constants__WEBPACK_IMPORTED_MODULE_0__.ESQL_TOKEN_POSTFIX) {
      // set the custom "functions" token (only used in theming)
      myTokensWithoutSpaces[index].scopes = 'functions' + _constants__WEBPACK_IMPORTED_MODULE_0__.ESQL_TOKEN_POSTFIX;
    }
  }
  return [...tokens];
}
const mergeRules = [[['nulls', 'expr_ws', 'first'], 'nulls_order'], [['nulls', 'expr_ws', 'last'], 'nulls_order'], [['integer', 'unquoted_identifier'], 'timespan_literal'], [['integer_literal', 'expr_ws', 'unquoted_identifier'], 'timespan_literal']];
function mergeTokens(tokens) {
  for (const [scopes, newScope] of mergeRules) {
    let foundAnyMatches = false;
    do {
      foundAnyMatches = false;
      for (let i = 0; i < tokens.length; i++) {
        if (tokens[i].scopes === scopes[0] + _constants__WEBPACK_IMPORTED_MODULE_0__.ESQL_TOKEN_POSTFIX) {
          // first matched so look ahead if there's room
          if (i + scopes.length > tokens.length) {
            continue;
          }
          let match = true;
          for (let j = 1; j < scopes.length; j++) {
            if (tokens[i + j].scopes !== scopes[j] + _constants__WEBPACK_IMPORTED_MODULE_0__.ESQL_TOKEN_POSTFIX) {
              match = false;
              break;
            }
          }
          if (match) {
            foundAnyMatches = true;
            const mergedToken = new _esql_token__WEBPACK_IMPORTED_MODULE_1__.ESQLToken(newScope, tokens[i].startIndex, tokens[i + scopes.length - 1].stopIndex);
            tokens.splice(i, scopes.length, mergedToken);
          }
        }
      }
    } while (foundAnyMatches);
  }
  return tokens;
}

/***/ }),

/***/ 1175:
/*!******************************************************************************!*\
  !*** ../../shared/kbn-monaco/src/languages/esql/lib/esql_tokens_provider.ts ***!
  \******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ESQLTokensProvider: () => (/* binding */ ESQLTokensProvider)
/* harmony export */ });
/* harmony import */ var antlr4__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! antlr4 */ 908);
/* harmony import */ var _kbn_esql_ast__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @kbn/esql-ast */ 909);
/* harmony import */ var _kbn_esql_ast__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @kbn/esql-ast */ 907);
/* harmony import */ var _esql_token__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./esql_token */ 1176);
/* harmony import */ var _esql_line_tokens__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./esql_line_tokens */ 1177);
/* harmony import */ var _esql_state__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./esql_state */ 1178);
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./constants */ 783);
/* harmony import */ var _esql_token_helpers__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./esql_token_helpers */ 1179);
/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the "Elastic License
 * 2.0", the "GNU Affero General Public License v3.0 only", and the "Server Side
 * Public License v 1"; you may not use this file except in compliance with, at
 * your election, the "Elastic License 2.0", the "GNU Affero General Public
 * License v3.0 only", or the "Server Side Public License, v 1".
 */








const EOF = -1;
class ESQLTokensProvider {
  getInitialState() {
    return new _esql_state__WEBPACK_IMPORTED_MODULE_3__.ESQLState();
  }
  tokenize(line, prevState) {
    const errorStartingPoints = [];
    const errorListener = new _kbn_esql_ast__WEBPACK_IMPORTED_MODULE_6__.ESQLErrorListener();
    // This has the drawback of not styling any ESQL wrong query as
    // | from ...
    const cleanedLine = prevState.getLineNumber() && line.trimStart()[0] === '|' ? line.trimStart().substring(1) : line;
    const inputStream = antlr4__WEBPACK_IMPORTED_MODULE_0__.CharStreams.fromString(cleanedLine);
    const lexer = (0,_kbn_esql_ast__WEBPACK_IMPORTED_MODULE_7__.getLexer)(inputStream, errorListener);
    let done = false;
    const myTokens = [];
    do {
      let token;
      try {
        token = lexer.nextToken();
      } catch (e) {
        token = null;
      }
      if (token == null) {
        done = true;
      } else {
        if (token.type === EOF) {
          done = true;
        } else {
          const tokenTypeName = lexer.symbolicNames[token.type];
          if (tokenTypeName) {
            const indexOffset = cleanedLine === line ? 0 : line.length - cleanedLine.length;
            const myToken = new _esql_token__WEBPACK_IMPORTED_MODULE_1__.ESQLToken(tokenTypeName, token.start + indexOffset, token.stop + indexOffset);
            myTokens.push(myToken);
          }
        }
      }
    } while (!done);
    for (const e of errorStartingPoints) {
      myTokens.push(new _esql_token__WEBPACK_IMPORTED_MODULE_1__.ESQLToken('error' + _constants__WEBPACK_IMPORTED_MODULE_4__.ESQL_TOKEN_POSTFIX, e));
    }
    myTokens.sort((a, b) => a.startIndex - b.startIndex);

    // special treatment for functions
    // the previous custom Kibana grammar baked functions directly as tokens, so highlight was easier
    // The ES grammar doesn't have the token concept of "function"
    const tokensWithFunctions = (0,_esql_token_helpers__WEBPACK_IMPORTED_MODULE_5__.addFunctionTokens)(myTokens);
    (0,_esql_token_helpers__WEBPACK_IMPORTED_MODULE_5__.mergeTokens)(tokensWithFunctions);
    return new _esql_line_tokens__WEBPACK_IMPORTED_MODULE_2__.ESQLLineTokens(tokensWithFunctions, prevState.getLineNumber() + 1);
  }
}

/***/ }),

/***/ 1174:
/*!***************************************************************!*\
  !*** ../../shared/kbn-monaco/src/languages/esql/lib/index.ts ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ESQLTokensProvider: () => (/* reexport safe */ _esql_tokens_provider__WEBPACK_IMPORTED_MODULE_0__.ESQLTokensProvider)
/* harmony export */ });
/* harmony import */ var _esql_tokens_provider__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./esql_tokens_provider */ 1175);
/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the "Elastic License
 * 2.0", the "GNU Affero General Public License v3.0 only", and the "Server Side
 * Public License v 1"; you may not use this file except in compliance with, at
 * your election, the "Elastic License 2.0", the "GNU Affero General Public
 * License v3.0 only", or the "Server Side Public License, v 1".
 */



/***/ })

}]);
//# sourceMappingURL=kbn-ui-shared-deps-src.chunk.6.js.map