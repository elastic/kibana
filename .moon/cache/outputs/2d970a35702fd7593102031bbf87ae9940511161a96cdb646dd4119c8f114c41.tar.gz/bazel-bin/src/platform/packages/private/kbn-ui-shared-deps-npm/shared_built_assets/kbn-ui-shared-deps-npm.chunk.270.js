"use strict";
(self["webpackChunk_kbnSharedDeps_npm_"] = self["webpackChunk_kbnSharedDeps_npm_"] || []).push([[270],{

/***/ 4126:
/*!***************************************************************************************************!*\
  !*** ../../../../../node_modules/@elastic/eui/optimize/es/components/icon/assets/logo_haproxy.js ***!
  \***************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   icon: () => (/* binding */ icon)
/* harmony export */ });
/* harmony import */ var _babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/extends */ 590);
/* harmony import */ var _babel_runtime_helpers_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @babel/runtime/helpers/objectWithoutProperties */ 1810);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ 667);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _services__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../services */ 1622);
/* harmony import */ var _emotion_react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @emotion/react */ 1784);


var _excluded = ["title", "titleId"];
/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */

// THIS IS A GENERATED FILE. DO NOT MODIFY MANUALLY. @see scripts/compile-icons.js




var EuiIconLogoHaproxy = function EuiIconLogoHaproxy(_ref) {
  var title = _ref.title,
    titleId = _ref.titleId,
    props = (0,_babel_runtime_helpers_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_1__["default"])(_ref, _excluded);
  var generateId = (0,_services__WEBPACK_IMPORTED_MODULE_3__.htmlIdGenerator)('logo_haproxy');
  return (0,_emotion_react__WEBPACK_IMPORTED_MODULE_4__.jsx)("svg", (0,_babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0__["default"])({
    xmlns: "http://www.w3.org/2000/svg",
    width: 32,
    height: 32,
    fill: "none",
    viewBox: "0 0 32 32",
    "aria-labelledby": titleId
  }, props), title ? (0,_emotion_react__WEBPACK_IMPORTED_MODULE_4__.jsx)("title", {
    id: titleId
  }, title) : null, (0,_emotion_react__WEBPACK_IMPORTED_MODULE_4__.jsx)("g", {
    clipPath: "url(#".concat(generateId('a'), ")")
  }, (0,_emotion_react__WEBPACK_IMPORTED_MODULE_4__.jsx)("path", {
    stroke: "#05486D",
    strokeMiterlimit: 10,
    strokeWidth: 0.12,
    d: "m16.05 13.237-3.11-3.612"
  }), (0,_emotion_react__WEBPACK_IMPORTED_MODULE_4__.jsx)("path", {
    stroke: "#05486D",
    strokeMiterlimit: 10,
    strokeWidth: 0.06,
    d: "m6.117 10.528 2.509 3.512"
  }), (0,_emotion_react__WEBPACK_IMPORTED_MODULE_4__.jsx)("path", {
    stroke: "#05486D",
    strokeMiterlimit: 10,
    strokeWidth: 0.12,
    d: "m16.05 13.237 3.11-3.612M19.863 17.15l3.712-3.11M19.863 17.15l3.712 3.311M19.16 24.575l-3.11-3.511M12.94 24.575l3.11-3.511M8.625 20.26l3.512-3.11M8.625 14.04l3.512 3.11M16.05 13.238l-7.425.802M16.05 13.238l7.525.802M19.863 17.15l-.702-7.525M19.863 17.15l-.702 7.425M23.575 20.461l-7.525.602M8.625 20.261l7.425.803M12.94 24.575l-.803-7.425M12.94 9.625l-.803 7.525"
  }), (0,_emotion_react__WEBPACK_IMPORTED_MODULE_4__.jsx)("path", {
    stroke: "#05486D",
    strokeMiterlimit: 10,
    strokeWidth: 0.06,
    d: "m5.114 15.043 3.511-1.003M9.328 7.117l3.612 2.509M13.743 5.512l-.803 4.113M13.743 5.512l5.418 4.113M18.358 5.512l.803 4.113M22.773 7.117 19.16 9.626M25.983 10.528l-6.822-.903M23.575 14.04l2.408-3.512M23.575 14.04l3.412 1.003M23.575 14.04l3.412 5.217M18.358 5.512 12.94 9.625M23.576 14.04l-.803-6.923M23.575 20.462l3.412-1.204M23.575 20.462l3.412-5.418M23.575 20.461l2.408 3.312M23.576 20.461l-.803 6.723M19.16 24.575l3.613 2.609M19.16 24.575l6.823-.802M19.16 24.575l-.802 4.214M19.16 24.575l-5.417 4.214M12.94 24.575l.803 4.214M12.94 24.575l5.418 4.214M12.94 24.575l-3.612 2.609M12.94 24.575l-6.823-.802M8.626 20.261l-2.509 3.512M8.625 20.261l.703 6.923M8.625 20.26l-3.511-1.002M8.625 14.04l-3.511 5.217M8.625 20.26l-3.511-5.217M9.328 7.117l-.703 6.923M6.117 10.528l6.823-.903"
  }), (0,_emotion_react__WEBPACK_IMPORTED_MODULE_4__.jsx)("path", {
    stroke: "#083D5F",
    strokeMiterlimit: 10,
    strokeWidth: 0.05,
    d: "M9.327 7.117 6.72 5.813M9.328 7.117l-.201-2.91M13.742 5.512 9.127 4.207M13.742 5.512l-2.006-2.509M13.743 5.512l.802-2.91M9.328 7.117l2.408-4.114M18.358 5.512l-3.813-2.91M18.358 5.512l-.803-3.01M13.743 5.512l3.812-3.01M18.358 5.512l2.007-2.509M22.773 7.117l-2.408-4.114M22.773 7.117l.301-2.91M18.358 5.512l4.716-1.305M22.773 7.117l2.709-1.405M22.773 7.117l4.716.703M25.983 10.528l1.505-2.709M25.984 10.528l-.502-4.816M25.983 10.528l3.11-.3M25.983 10.528l4.214 2.308M26.987 15.044l2.107-4.817M26.987 15.043l3.21-2.207M26.987 15.043l3.612.703M26.987 19.258l3.612-3.512M26.987 19.258l3.712-.703M26.987 15.043l3.712 3.512M26.987 19.258l3.11 2.107M25.983 23.773l4.114-2.409M25.983 23.773l3.11.3M26.987 19.258l2.107 4.816M25.983 23.773l1.505 2.709M25.984 23.773l-.502 4.715M25.482 28.488l-2.71-1.304M22.773 27.184l.2 2.91M22.773 27.184l4.716-.703M22.773 27.184l-2.408 4.114M18.358 28.79l2.007 2.508M18.358 28.79l4.615 1.304M18.358 28.79l-.803 3.01M18.358 28.79l-3.813 3.01M13.743 28.79l.802 3.01M13.743 28.79l3.812 3.01M13.742 28.79l-2.006 2.508M9.328 27.184l2.408 4.114M13.742 28.79l-4.615 1.404M9.328 27.184l-.201 3.01M9.328 27.184l-2.71 1.404M6.117 23.773l.502 4.816M9.328 27.184l-4.716-.703M6.117 23.773l-1.505 2.709M6.117 23.773l-3.11.3M6.117 23.773l-4.214-2.409M5.114 19.258l-3.21 2.107M5.114 19.258 1.4 18.555M5.114 19.258l-2.107 4.816M5.114 15.043 1.4 18.555M5.114 19.258 1.4 15.746M5.114 15.043l-3.11-2.106M5.114 15.043l-3.713.703M5.114 15.044l-2.007-4.817M6.117 10.528l-3.01-.3M6.117 10.528l-4.114 2.408M6.117 10.528 4.712 7.92M6.117 10.528l.602-4.715M9.328 7.117l-4.616.803"
  }), (0,_emotion_react__WEBPACK_IMPORTED_MODULE_4__.jsx)("path", {
    fill: "#006DA8",
    d: "M13.943 15.244h-3.612v3.592h3.612v-3.592ZM17.756 11.331h-3.612v3.592h3.612v-3.592ZM17.756 19.157h-3.612v3.592h3.612v-3.592ZM21.669 15.244h-3.612v3.592h3.612v-3.592Z"
  }), (0,_emotion_react__WEBPACK_IMPORTED_MODULE_4__.jsx)("path", {
    fill: "#2F77BC",
    d: "M20.365 8.421h-2.509V10.9h2.509V8.42ZM14.144 8.321h-2.509v2.478h2.509V8.321ZM9.83 12.836H7.32v2.478H9.83v-2.478ZM9.83 18.956H7.32v2.479H9.83v-2.479ZM24.679 18.956H22.17v2.479h2.509v-2.479ZM24.679 12.736H22.17v2.478h2.509v-2.478Z"
  }), (0,_emotion_react__WEBPACK_IMPORTED_MODULE_4__.jsx)("path", {
    fill: "#139BD7",
    d: "M6.92 9.625H5.314v1.676H6.92V9.625ZM10.13 6.214H8.526v1.675h1.606V6.214ZM14.445 4.609h-1.606v1.675h1.606V4.61ZM5.916 14.14H4.311v1.676h1.605V14.14ZM26.786 9.826H25.08v1.646h1.706V9.826ZM23.575 6.415H21.87V8.06h1.705V6.415ZM19.26 4.81h-1.705v1.645h1.706V4.809ZM27.689 14.441h-1.605v1.646h1.605V14.44Z"
  }), (0,_emotion_react__WEBPACK_IMPORTED_MODULE_4__.jsx)("path", {
    fill: "#2F77BC",
    d: "M14.144 23.27h-2.509v2.479h2.509v-2.478ZM20.264 23.27h-2.508v2.479h2.508v-2.478Z"
  }), (0,_emotion_react__WEBPACK_IMPORTED_MODULE_4__.jsx)("path", {
    fill: "#139BD7",
    d: "M26.685 22.77H25.08v1.675h1.605v-1.676ZM23.375 26.08H21.77v1.676h1.605V26.08ZM19.06 27.686h-1.605v1.675h1.605v-1.675ZM27.589 18.254h-1.606v1.676h1.606v-1.676ZM6.92 22.97H5.214v1.646H6.92V22.97ZM10.03 26.381H8.325v1.646h1.705V26.38ZM14.445 27.987h-1.706v1.645h1.706v-1.645ZM5.816 18.355H4.21V20h1.606v-1.645Z"
  }), (0,_emotion_react__WEBPACK_IMPORTED_MODULE_4__.jsx)("path", {
    fill: "#03A9DA",
    d: "M7.12 5.311h-.903v.933h.903v-.933ZM1.903 15.244H1v.933h.903v-.933ZM25.782 5.21h-.903v.934h.903V5.21ZM2.505 12.335h-.903v.933h.903v-.934ZM12.137 2.502h-.903v.933h.903v-.933ZM3.508 9.726h-.903v.933h.903v-.933ZM5.113 7.318H4.21v.933h.903v-.933ZM9.629 3.806h-.903v.903h.903v-.903ZM15.047 2.1h-.903v.903h.903V2.1ZM23.374 3.605h-.903v.933h.903v-.933ZM29.295 9.726h-.903v.933h.903v-.933ZM30.498 12.335h-.903v.933h.903v-.934ZM27.69 7.318h-.904v.933h.903v-.933ZM30.9 15.144h-.903v.933h.903v-.933ZM17.856 2h-.903v.933h.903V2ZM20.665 2.602h-.903v.933h.903v-.933Z"
  }), (0,_emotion_react__WEBPACK_IMPORTED_MODULE_4__.jsx)("path", {
    fill: "#03A9DA",
    d: "M7.12 5.311h-.903v.933h.903v-.933ZM1.903 15.244H1v.933h.903v-.933ZM25.782 5.21h-.903v.934h.903V5.21ZM2.505 12.335h-.903v.933h.903v-.934ZM12.137 2.502h-.903v.933h.903v-.933ZM3.508 9.726h-.903v.933h.903v-.933ZM5.113 7.318H4.21v.933h.903v-.933ZM9.629 3.806h-.903v.903h.903v-.903ZM15.047 2.1h-.903v.903h.903V2.1ZM23.374 3.605h-.903v.933h.903v-.933ZM29.295 9.726h-.903v.933h.903v-.933ZM30.498 12.335h-.903v.933h.903v-.934ZM27.69 7.318h-.904v.933h.903v-.933ZM30.9 15.144h-.903v.933h.903v-.933ZM17.856 2h-.903v.933h.903V2ZM20.665 2.602h-.903v.933h.903v-.933ZM25.682 27.886h-.903v.933h.903v-.933ZM31 17.953h-.903v.933H31v-.933ZM7.12 27.987h-.903v.933h.903v-.933ZM30.398 20.763h-.903v.933h.903v-.933ZM20.665 30.596h-.903v.933h.903v-.933ZM29.295 23.371h-.903v.933h.903v-.933ZM27.69 25.78h-.904v.932h.903v-.933ZM23.274 29.793h-.903v.902h.903v-.902ZM17.756 31.498h-.903v.903h.903v-.903ZM9.428 29.492h-.903v.933h.903v-.933ZM3.508 23.472h-.903v.933h.903v-.933ZM2.304 20.863h-.903v.933h.903v-.933ZM5.013 25.88H4.11v.933h.903v-.933ZM1.903 17.953H1v.933h.903v-.933ZM14.947 31.498h-.903v.933h.902v-.933ZM12.137 30.596h-.903v.933h.903v-.933Z"
  })), (0,_emotion_react__WEBPACK_IMPORTED_MODULE_4__.jsx)("defs", null, (0,_emotion_react__WEBPACK_IMPORTED_MODULE_4__.jsx)("clipPath", {
    id: generateId('a')
  }, (0,_emotion_react__WEBPACK_IMPORTED_MODULE_4__.jsx)("path", {
    fill: "#fff",
    d: "M0 0h32v32H0V0Z"
  }))));
};
var icon = EuiIconLogoHaproxy;

/***/ })

}]);
//# sourceMappingURL=kbn-ui-shared-deps-npm.chunk.270.js.map