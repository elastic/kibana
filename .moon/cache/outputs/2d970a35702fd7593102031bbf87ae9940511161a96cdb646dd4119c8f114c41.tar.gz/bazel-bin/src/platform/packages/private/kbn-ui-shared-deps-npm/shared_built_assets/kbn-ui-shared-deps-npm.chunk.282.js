"use strict";
(self["webpackChunk_kbnSharedDeps_npm_"] = self["webpackChunk_kbnSharedDeps_npm_"] || []).push([[282],{

/***/ 4138:
/*!*************************************************************************************************!*\
  !*** ../../../../../node_modules/@elastic/eui/optimize/es/components/icon/assets/logo_mysql.js ***!
  \*************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   icon: () => (/* binding */ icon)
/* harmony export */ });
/* harmony import */ var _babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/extends */ 590);
/* harmony import */ var _babel_runtime_helpers_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @babel/runtime/helpers/objectWithoutProperties */ 1810);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ 667);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _emotion_react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @emotion/react */ 1784);


var _excluded = ["title", "titleId"];
/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */

// THIS IS A GENERATED FILE. DO NOT MODIFY MANUALLY. @see scripts/compile-icons.js



var EuiIconLogoMysql = function EuiIconLogoMysql(_ref) {
  var title = _ref.title,
    titleId = _ref.titleId,
    props = (0,_babel_runtime_helpers_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_1__["default"])(_ref, _excluded);
  return (0,_emotion_react__WEBPACK_IMPORTED_MODULE_3__.jsx)("svg", (0,_babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0__["default"])({
    xmlns: "http://www.w3.org/2000/svg",
    width: 32,
    height: 32,
    viewBox: "0 0 32 32",
    "aria-labelledby": titleId
  }, props), title ? (0,_emotion_react__WEBPACK_IMPORTED_MODULE_3__.jsx)("title", {
    id: titleId
  }, title) : null, (0,_emotion_react__WEBPACK_IMPORTED_MODULE_3__.jsx)("g", {
    fill: "#00546B"
  }, (0,_emotion_react__WEBPACK_IMPORTED_MODULE_3__.jsx)("path", {
    d: "M29.456 24.276c-1.74-.043-3.088.131-4.219.61-.326.13-.848.13-.892.543.174.174.196.457.348.696.261.435.718 1.022 1.131 1.327.457.348.914.696 1.392 1 .848.522 1.805.827 2.631 1.349.48.304.957.695 1.436 1.022.24.173.391.456.696.565v-.065c-.153-.196-.196-.479-.348-.696-.218-.218-.435-.413-.653-.63a10.316 10.316 0 0 0-2.261-2.197c-.696-.479-2.219-1.131-2.501-1.936l-.044-.043c.479-.044 1.044-.218 1.5-.348.74-.196 1.414-.153 2.175-.348.348-.087.696-.196 1.044-.305v-.195c-.391-.392-.674-.914-1.087-1.284-1.11-.957-2.327-1.892-3.588-2.674-.675-.435-1.545-.718-2.262-1.088-.261-.13-.696-.196-.848-.413-.392-.479-.61-1.11-.892-1.675a54.922 54.922 0 0 1-1.783-3.784c-.392-.848-.63-1.696-1.11-2.479-2.24-3.697-4.675-5.937-8.416-8.134-.804-.456-1.761-.652-2.783-.891-.544-.022-1.088-.065-1.631-.087-.348-.152-.696-.566-1-.761-1.24-.783-4.437-2.48-5.35-.24-.588 1.414.87 2.806 1.37 3.524.37.5.848 1.065 1.109 1.63.152.37.195.762.347 1.153.348.957.675 2.023 1.131 2.914.24.457.5.936.805 1.349.174.239.478.348.544.74-.305.434-.327 1.087-.5 1.63-.783 2.458-.479 5.502.63 7.307.348.544 1.175 1.74 2.284 1.284.978-.392.76-1.632 1.043-2.719.066-.261.022-.435.153-.609v.044c.304.609.609 1.196.891 1.805.675 1.065 1.849 2.174 2.828 2.914.522.391.935 1.065 1.587 1.305v-.066h-.043c-.13-.195-.327-.282-.5-.435-.392-.39-.827-.87-1.131-1.304-.914-1.218-1.719-2.567-2.436-3.958-.348-.675-.653-1.414-.935-2.088-.13-.261-.13-.653-.348-.783-.327.478-.805.892-1.044 1.479-.413.935-.457 2.088-.61 3.284-.086.021-.043 0-.086.043-.696-.174-.935-.891-1.196-1.5-.653-1.545-.761-4.024-.196-5.807.152-.457.805-1.892.544-2.327-.13-.413-.566-.652-.805-.979a8.764 8.764 0 0 1-.783-1.392c-.522-1.217-.783-2.566-1.348-3.784-.261-.565-.718-1.152-1.087-1.674-.414-.587-.87-1-1.197-1.697-.108-.239-.26-.63-.087-.891.044-.174.13-.24.305-.283.283-.24 1.087.065 1.37.196.805.326 1.479.63 2.153 1.087.304.218.63.631 1.022.74h.457c.696.152 1.479.043 2.131.239 1.153.37 2.196.913 3.132 1.5a19.294 19.294 0 0 1 6.785 7.438c.261.5.37.957.609 1.479.457 1.066 1.022 2.153 1.479 3.197.456 1.022.891 2.066 1.544 2.914.326.457 1.63.696 2.218.935.435.196 1.11.37 1.5.61.74.456 1.48.978 2.175 1.478.348.26 1.436.805 1.501 1.24Z"
  }), (0,_emotion_react__WEBPACK_IMPORTED_MODULE_3__.jsx)("path", {
    d: "M7.273 5.378c-.37 0-.63.043-.891.109v.043h.043c.174.348.479.587.696.892.174.348.326.696.5 1.044l.044-.044c.304-.217.457-.565.457-1.087-.131-.152-.153-.305-.261-.457-.13-.218-.414-.326-.588-.5Z"
  })));
};
var icon = EuiIconLogoMysql;

/***/ })

}]);
//# sourceMappingURL=kbn-ui-shared-deps-npm.chunk.282.js.map