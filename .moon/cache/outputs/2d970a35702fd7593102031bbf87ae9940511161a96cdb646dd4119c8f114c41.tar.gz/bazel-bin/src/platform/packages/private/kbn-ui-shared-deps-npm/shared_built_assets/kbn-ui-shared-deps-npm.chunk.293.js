"use strict";
(self["webpackChunk_kbnSharedDeps_npm_"] = self["webpackChunk_kbnSharedDeps_npm_"] || []).push([[293],{

/***/ 4149:
/*!**************************************************************************************************!*\
  !*** ../../../../../node_modules/@elastic/eui/optimize/es/components/icon/assets/logo_sketch.js ***!
  \**************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   icon: () => (/* binding */ icon)
/* harmony export */ });
/* harmony import */ var _babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/extends */ 590);
/* harmony import */ var _babel_runtime_helpers_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @babel/runtime/helpers/objectWithoutProperties */ 1810);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ 667);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _emotion_react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @emotion/react */ 1784);


var _excluded = ["title", "titleId"];
/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */

// THIS IS A GENERATED FILE. DO NOT MODIFY MANUALLY. @see scripts/compile-icons.js



var EuiIconLogoSketch = function EuiIconLogoSketch(_ref) {
  var title = _ref.title,
    titleId = _ref.titleId,
    props = (0,_babel_runtime_helpers_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_1__["default"])(_ref, _excluded);
  return (0,_emotion_react__WEBPACK_IMPORTED_MODULE_3__.jsx)("svg", (0,_babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0__["default"])({
    xmlns: "http://www.w3.org/2000/svg",
    width: 32,
    height: 32,
    viewBox: "0 0 32 32",
    "aria-labelledby": titleId
  }, props), title ? (0,_emotion_react__WEBPACK_IMPORTED_MODULE_3__.jsx)("title", {
    id: titleId
  }, title) : null, (0,_emotion_react__WEBPACK_IMPORTED_MODULE_3__.jsx)("g", {
    fill: "none"
  }, (0,_emotion_react__WEBPACK_IMPORTED_MODULE_3__.jsx)("path", {
    fill: "#FFAE00",
    d: "M16 32 0 11.454l6.931-10.38L16 0l9.069 1.074L32 11.454z"
  }), (0,_emotion_react__WEBPACK_IMPORTED_MODULE_3__.jsx)("path", {
    fill: "#EC6C00",
    d: "M16 32 0 11.454h32z"
  }), (0,_emotion_react__WEBPACK_IMPORTED_MODULE_3__.jsx)("path", {
    fill: "#FFAE00",
    d: "M16 32 6.477 11.454h19.045z"
  }), (0,_emotion_react__WEBPACK_IMPORTED_MODULE_3__.jsx)("path", {
    fill: "#FFEFB4",
    d: "M16 0 6.477 11.454h19.045z"
  }), (0,_emotion_react__WEBPACK_IMPORTED_MODULE_3__.jsx)("path", {
    fill: "#FFAE00",
    d: "M6.932 1.074 3.369 6.3.001 11.454h6.542zM25.069 1.074 28.632 6.3 32 11.454h-6.542z"
  }), (0,_emotion_react__WEBPACK_IMPORTED_MODULE_3__.jsx)("path", {
    fill: "#FED305",
    d: "m6.931 1.074-.453 10.38L16 0zM25.069 1.074l.453 10.38L16 0z"
  })));
};
var icon = EuiIconLogoSketch;

/***/ })

}]);
//# sourceMappingURL=kbn-ui-shared-deps-npm.chunk.293.js.map