"use strict";
(self["webpackChunk_kbnSharedDeps_npm_"] = self["webpackChunk_kbnSharedDeps_npm_"] || []).push([[35],{

/***/ 3891:
/*!***********************************************************************************************!*\
  !*** ../../../../../node_modules/@elastic/eui/optimize/es/components/icon/assets/app_logs.js ***!
  \***********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   icon: () => (/* binding */ icon)
/* harmony export */ });
/* harmony import */ var _babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/extends */ 590);
/* harmony import */ var _babel_runtime_helpers_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @babel/runtime/helpers/objectWithoutProperties */ 1810);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ 667);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _emotion_react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @emotion/react */ 1784);


var _excluded = ["title", "titleId"];
/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */

// THIS IS A GENERATED FILE. DO NOT MODIFY MANUALLY. @see scripts/compile-icons.js



var EuiIconAppLogs = function EuiIconAppLogs(_ref) {
  var title = _ref.title,
    titleId = _ref.titleId,
    props = (0,_babel_runtime_helpers_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_1__["default"])(_ref, _excluded);
  return (0,_emotion_react__WEBPACK_IMPORTED_MODULE_3__.jsx)("svg", (0,_babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0__["default"])({
    xmlns: "http://www.w3.org/2000/svg",
    width: 32,
    height: 32,
    viewBox: "0 0 32 32",
    "aria-labelledby": titleId
  }, props), title ? (0,_emotion_react__WEBPACK_IMPORTED_MODULE_3__.jsx)("title", {
    id: titleId
  }, title) : null, (0,_emotion_react__WEBPACK_IMPORTED_MODULE_3__.jsx)("path", {
    d: "M1 8c3.983 0 7.732 1.013 11.001 2.797v2.312A20.887 20.887 0 0 0 2 10.023v11.025c4.85.462 9.27 4.183 9.955 8.691l.035.261H12v2h-1.938l-.018-1.236c-.116-4.015-4.336-7.631-8.793-7.76L0 22.986V8h1zm13-8h1c9.28 0 16.825 7.437 16.997 16.677L32 17v15h-2V17c0-7.84-6.014-14.274-13.68-14.943L16 2.033v7.681l-2-1.143V0h1-1z"
  }), (0,_emotion_react__WEBPACK_IMPORTED_MODULE_3__.jsx)("path", {
    d: "M26.997 30.636 27.009 32H14V11.305l1.483.82c6.994 3.861 11.382 10.735 11.514 18.51zm-2.048-1.04C24.505 23.556 21.205 18.2 16 14.771V30h8.974l-.025-.404z",
    className: "euiIcon__fillSecondary"
  }));
};
var icon = EuiIconAppLogs;

/***/ })

}]);
//# sourceMappingURL=kbn-ui-shared-deps-npm.chunk.35.js.map