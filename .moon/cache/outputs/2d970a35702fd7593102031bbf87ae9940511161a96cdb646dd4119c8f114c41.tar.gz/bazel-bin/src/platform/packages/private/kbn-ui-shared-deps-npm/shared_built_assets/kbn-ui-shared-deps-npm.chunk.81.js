"use strict";
(self["webpackChunk_kbnSharedDeps_npm_"] = self["webpackChunk_kbnSharedDeps_npm_"] || []).push([[81],{

/***/ 3937:
/*!******************************************************************************************!*\
  !*** ../../../../../node_modules/@elastic/eui/optimize/es/components/icon/assets/bug.js ***!
  \******************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   icon: () => (/* binding */ icon)
/* harmony export */ });
/* harmony import */ var _babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/extends */ 590);
/* harmony import */ var _babel_runtime_helpers_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @babel/runtime/helpers/objectWithoutProperties */ 1810);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ 667);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _emotion_react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @emotion/react */ 1784);


var _excluded = ["title", "titleId"];
/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */

// THIS IS A GENERATED FILE. DO NOT MODIFY MANUALLY. @see scripts/compile-icons.js



var EuiIconBug = function EuiIconBug(_ref) {
  var title = _ref.title,
    titleId = _ref.titleId,
    props = (0,_babel_runtime_helpers_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_1__["default"])(_ref, _excluded);
  return (0,_emotion_react__WEBPACK_IMPORTED_MODULE_3__.jsx)("svg", (0,_babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0__["default"])({
    xmlns: "http://www.w3.org/2000/svg",
    width: 16,
    height: 16,
    viewBox: "0 0 16 16",
    "aria-labelledby": titleId
  }, props), title ? (0,_emotion_react__WEBPACK_IMPORTED_MODULE_3__.jsx)("title", {
    id: titleId
  }, title) : null, (0,_emotion_react__WEBPACK_IMPORTED_MODULE_3__.jsx)("path", {
    d: "m10.651 5.126.922-.455.884-2.343a.5.5 0 0 1 .939.344L12.374 5.39l-1.45.717A5.3 5.3 0 0 1 11 7h1.043l2.3 2.198a.5.5 0 0 1-.692.723L11.642 8h-.737c-.09.466-.24.899-.441 1.283l.892.49 1.278 3.554a.5.5 0 0 1-.94.342l-1.15-3.2-.655-.36C9.373 10.665 8.716 11 8 11s-1.374-.335-1.89-.893l-.658.361-1.15 3.201a.5.5 0 1 1-.94-.342l1.279-3.554.895-.491A4.7 4.7 0 0 1 5.095 8h-.74l-2.01 1.92a.5.5 0 0 1-.69-.722L3.952 7H5a5.3 5.3 0 0 1 .075-.892L3.623 5.39 2.6 2.672a.5.5 0 1 1 .939-.344l.884 2.343.924.457c.17-.428.397-.81.668-1.128h.57a1.5 1.5 0 1 1 2.83 0h.568c.27.318.497.699.667 1.126ZM8 4a.5.5 0 1 0 0-1 .5.5 0 0 0 0 1Zm1.751 1.571A3.326 3.326 0 0 0 9.476 5H6.524c-.107.175-.2.367-.276.573-.11.295-.186.618-.223.957a4.354 4.354 0 0 0 .09 1.465c.071.294.172.565.295.806.168.328.38.601.616.803.295.253.631.396.974.396.342 0 .678-.142.973-.394.237-.203.448-.476.616-.803a3.62 3.62 0 0 0 .296-.807 4.263 4.263 0 0 0 .09-1.466 3.988 3.988 0 0 0-.224-.959Z"
  }));
};
var icon = EuiIconBug;

/***/ })

}]);
//# sourceMappingURL=kbn-ui-shared-deps-npm.chunk.81.js.map