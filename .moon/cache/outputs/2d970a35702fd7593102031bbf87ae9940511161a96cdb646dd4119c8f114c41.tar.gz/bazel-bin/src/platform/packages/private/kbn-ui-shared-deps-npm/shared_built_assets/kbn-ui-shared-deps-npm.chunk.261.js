"use strict";
(self["webpackChunk_kbnSharedDeps_npm_"] = self["webpackChunk_kbnSharedDeps_npm_"] || []).push([[261],{

/***/ 4117:
/*!*********************************************************************************************************!*\
  !*** ../../../../../node_modules/@elastic/eui/optimize/es/components/icon/assets/logo_elasticsearch.js ***!
  \*********************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   icon: () => (/* binding */ icon)
/* harmony export */ });
/* harmony import */ var _babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/extends */ 590);
/* harmony import */ var _babel_runtime_helpers_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @babel/runtime/helpers/objectWithoutProperties */ 1810);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ 667);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _emotion_react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @emotion/react */ 1784);


var _excluded = ["title", "titleId"];
/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */

// THIS IS A GENERATED FILE. DO NOT MODIFY MANUALLY. @see scripts/compile-icons.js



var EuiIconLogoElasticsearch = function EuiIconLogoElasticsearch(_ref) {
  var title = _ref.title,
    titleId = _ref.titleId,
    props = (0,_babel_runtime_helpers_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_1__["default"])(_ref, _excluded);
  return (0,_emotion_react__WEBPACK_IMPORTED_MODULE_3__.jsx)("svg", (0,_babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0__["default"])({
    xmlns: "http://www.w3.org/2000/svg",
    width: 32,
    height: 32,
    viewBox: "0 0 32 32",
    "aria-labelledby": titleId
  }, props), title ? (0,_emotion_react__WEBPACK_IMPORTED_MODULE_3__.jsx)("title", {
    id: titleId
  }, title) : null, (0,_emotion_react__WEBPACK_IMPORTED_MODULE_3__.jsx)("g", {
    fill: "none",
    fillRule: "evenodd"
  }, (0,_emotion_react__WEBPACK_IMPORTED_MODULE_3__.jsx)("path", {
    d: "M2 16c0 1.384.194 2.72.524 4H22a4 4 0 0 0 0-8H2.524A15.984 15.984 0 0 0 2 16",
    className: "euiIcon__fillNegative"
  }), (0,_emotion_react__WEBPACK_IMPORTED_MODULE_3__.jsx)("path", {
    fill: "#FEC514",
    d: "M28.924 7.662A15.381 15.381 0 0 0 30.48 6C27.547 2.346 23.05 0 18 0 11.679 0 6.239 3.678 3.644 9H25.51a5.039 5.039 0 0 0 3.413-1.338"
  }), (0,_emotion_react__WEBPACK_IMPORTED_MODULE_3__.jsx)("path", {
    fill: "#00BFB3",
    d: "M25.51 23H3.645C6.24 28.323 11.679 32 18 32c5.05 0 9.547-2.346 12.48-6a15.381 15.381 0 0 0-1.556-1.662A5.034 5.034 0 0 0 25.51 23"
  })));
};
var icon = EuiIconLogoElasticsearch;

/***/ })

}]);
//# sourceMappingURL=kbn-ui-shared-deps-npm.chunk.261.js.map