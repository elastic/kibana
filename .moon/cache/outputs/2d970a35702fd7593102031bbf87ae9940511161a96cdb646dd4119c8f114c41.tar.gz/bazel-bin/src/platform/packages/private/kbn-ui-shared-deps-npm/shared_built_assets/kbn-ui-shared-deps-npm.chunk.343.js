"use strict";
(self["webpackChunk_kbnSharedDeps_npm_"] = self["webpackChunk_kbnSharedDeps_npm_"] || []).push([[343],{

/***/ 4199:
/*!*************************************************************************************************!*\
  !*** ../../../../../node_modules/@elastic/eui/optimize/es/components/icon/assets/pageSelect.js ***!
  \*************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   icon: () => (/* binding */ icon)
/* harmony export */ });
/* harmony import */ var _babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/extends */ 590);
/* harmony import */ var _babel_runtime_helpers_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @babel/runtime/helpers/objectWithoutProperties */ 1810);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ 667);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _emotion_react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @emotion/react */ 1784);


var _excluded = ["title", "titleId"];
/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */

// THIS IS A GENERATED FILE. DO NOT MODIFY MANUALLY. @see scripts/compile-icons.js



var EuiIconPageSelect = function EuiIconPageSelect(_ref) {
  var title = _ref.title,
    titleId = _ref.titleId,
    props = (0,_babel_runtime_helpers_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_1__["default"])(_ref, _excluded);
  return (0,_emotion_react__WEBPACK_IMPORTED_MODULE_3__.jsx)("svg", (0,_babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0__["default"])({
    xmlns: "http://www.w3.org/2000/svg",
    width: 16,
    height: 16,
    viewBox: "0 0 16 16",
    "aria-labelledby": titleId
  }, props), title ? (0,_emotion_react__WEBPACK_IMPORTED_MODULE_3__.jsx)("title", {
    id: titleId
  }, title) : null, (0,_emotion_react__WEBPACK_IMPORTED_MODULE_3__.jsx)("path", {
    fillRule: "evenodd",
    d: "M3 1a1 1 0 0 0-1 1v12a1 1 0 0 0 1 1h5a4.995 4.995 0 0 1-.584-1H3V2h7v2a1 1 0 0 0 1 1h2v2.1c.348.07.682.177 1 .316V4a1 1 0 0 0-.293-.707l-2-2A1 1 0 0 0 11 1H3zm13 11a4 4 0 1 1-8 0 4 4 0 0 1 8 0zm-1.646-1.354a.5.5 0 0 1 0 .708l-2.5 2.5a.5.5 0 0 1-.708 0l-1-1a.5.5 0 0 1 .708-.708l.646.647 2.146-2.147a.5.5 0 0 1 .708 0z"
  }));
};
var icon = EuiIconPageSelect;

/***/ })

}]);
//# sourceMappingURL=kbn-ui-shared-deps-npm.chunk.343.js.map