"use strict";
(self["webpackChunk_kbnSharedDeps_npm_"] = self["webpackChunk_kbnSharedDeps_npm_"] || []).push([[279],{

/***/ 4135:
/*!*****************************************************************************************************!*\
  !*** ../../../../../node_modules/@elastic/eui/optimize/es/components/icon/assets/logo_memcached.js ***!
  \*****************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   icon: () => (/* binding */ icon)
/* harmony export */ });
/* harmony import */ var _babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/extends */ 590);
/* harmony import */ var _babel_runtime_helpers_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @babel/runtime/helpers/objectWithoutProperties */ 1810);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ 667);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _services__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../services */ 1622);
/* harmony import */ var _emotion_react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @emotion/react */ 1784);


var _excluded = ["title", "titleId"];
/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */

// THIS IS A GENERATED FILE. DO NOT MODIFY MANUALLY. @see scripts/compile-icons.js




var EuiIconLogoMemcached = function EuiIconLogoMemcached(_ref) {
  var title = _ref.title,
    titleId = _ref.titleId,
    props = (0,_babel_runtime_helpers_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_1__["default"])(_ref, _excluded);
  var generateId = (0,_services__WEBPACK_IMPORTED_MODULE_3__.htmlIdGenerator)('logo_memcached');
  return (0,_emotion_react__WEBPACK_IMPORTED_MODULE_4__.jsx)("svg", (0,_babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0__["default"])({
    xmlns: "http://www.w3.org/2000/svg",
    width: 32,
    height: 32,
    viewBox: "0 0 32 32",
    "aria-labelledby": titleId
  }, props), title ? (0,_emotion_react__WEBPACK_IMPORTED_MODULE_4__.jsx)("title", {
    id: titleId
  }, title) : null, (0,_emotion_react__WEBPACK_IMPORTED_MODULE_4__.jsx)("defs", null, (0,_emotion_react__WEBPACK_IMPORTED_MODULE_4__.jsx)("radialGradient", {
    id: generateId('c'),
    cx: "41.406%",
    cy: "42.708%",
    r: "0%",
    fx: "41.406%",
    fy: "42.708%"
  }, (0,_emotion_react__WEBPACK_IMPORTED_MODULE_4__.jsx)("stop", {
    offset: "0%",
    stopColor: "#DB7C7C"
  }), (0,_emotion_react__WEBPACK_IMPORTED_MODULE_4__.jsx)("stop", {
    offset: "100%",
    stopColor: "#C83737"
  })), (0,_emotion_react__WEBPACK_IMPORTED_MODULE_4__.jsx)("radialGradient", {
    id: generateId('d'),
    cx: "44.271%",
    cy: "42.708%",
    r: "0%",
    fx: "44.271%",
    fy: "42.708%"
  }, (0,_emotion_react__WEBPACK_IMPORTED_MODULE_4__.jsx)("stop", {
    offset: "0%",
    stopColor: "#DB7C7C"
  }), (0,_emotion_react__WEBPACK_IMPORTED_MODULE_4__.jsx)("stop", {
    offset: "100%",
    stopColor: "#C83737"
  })), (0,_emotion_react__WEBPACK_IMPORTED_MODULE_4__.jsx)("linearGradient", {
    id: generateId('a'),
    x1: "50%",
    x2: "50%",
    y1: "100%",
    y2: "0%"
  }, (0,_emotion_react__WEBPACK_IMPORTED_MODULE_4__.jsx)("stop", {
    offset: "0%",
    stopColor: "#574C4A"
  }), (0,_emotion_react__WEBPACK_IMPORTED_MODULE_4__.jsx)("stop", {
    offset: "100%",
    stopColor: "#80716D"
  })), (0,_emotion_react__WEBPACK_IMPORTED_MODULE_4__.jsx)("linearGradient", {
    id: generateId('b'),
    x1: "88.778%",
    x2: "30.149%",
    y1: "98.342%",
    y2: "-8.68%"
  }, (0,_emotion_react__WEBPACK_IMPORTED_MODULE_4__.jsx)("stop", {
    offset: "0%",
    stopColor: "#268D83"
  }), (0,_emotion_react__WEBPACK_IMPORTED_MODULE_4__.jsx)("stop", {
    offset: "100%",
    stopColor: "#2EA19E"
  }))), (0,_emotion_react__WEBPACK_IMPORTED_MODULE_4__.jsx)("g", {
    fill: "none"
  }, (0,_emotion_react__WEBPACK_IMPORTED_MODULE_4__.jsx)("path", {
    fill: "url(#".concat(generateId('a'), ")"),
    d: "M0 21.567V10.352C0 1.294 1.293 0 10.342 0h11.236c9.049 0 10.341 1.294 10.341 10.352v11.215c0 9.059-1.292 10.352-10.341 10.352H10.342C1.292 31.92 0 30.626 0 21.567Z"
  }), (0,_emotion_react__WEBPACK_IMPORTED_MODULE_4__.jsx)("path", {
    fill: "url(#".concat(generateId('b'), ")"),
    d: "M6.889 6.016C5.32 15.96 6.14 25.27 6.14 25.27h4.904c-.466-2.483-2.14-13.824-.748-13.861.746.118 4.156 9.621 4.156 9.621s.751-.093 1.507-.093c.755 0 1.506.093 1.506.093s3.41-9.503 4.157-9.621c1.392.037-.282 11.378-.748 13.86h4.904s.82-9.31-.748-19.253h-4.54c-.865.01-4.153 5.777-4.531 5.777-.378 0-3.666-5.767-4.53-5.777H6.889Z"
  }), (0,_emotion_react__WEBPACK_IMPORTED_MODULE_4__.jsx)("path", {
    fill: "url(#".concat(generateId('c'), ")"),
    d: "M14.993 24.109a1.16 1.16 0 1 1-2.322 0 1.16 1.16 0 0 1 2.322 0Z"
  }), (0,_emotion_react__WEBPACK_IMPORTED_MODULE_4__.jsx)("path", {
    fill: "url(#".concat(generateId('d'), ")"),
    d: "M19.249 24.109a1.16 1.16 0 1 1-2.322 0 1.16 1.16 0 0 1 2.322 0Z"
  }), (0,_emotion_react__WEBPACK_IMPORTED_MODULE_4__.jsx)("path", {
    fill: "#000",
    d: "M24.8 6.345c.707 4.79.873 9.388.86 12.813-.013 3.503-.214 5.78-.214 5.78h-4.128l-.443.332h4.904s.82-9.31-.748-19.254l-.232.329Zm-12.996-.121c1.288 1.433 3.516 5.237 3.823 5.237-.817-1.045-2.823-4.378-3.823-5.237Zm-1.84 4.852c-1.392.038.282 11.379.749 13.861H6.43l-.29.333h4.904c-.464-2.47-2.123-13.71-.769-13.861-.126-.19-.235-.32-.311-.333Zm11.326 0c-.746.119-4.156 9.622-4.156 9.622s-.751-.094-1.507-.094c-.447 0-.832.028-1.092.052l-.082.374s.751-.093 1.507-.093c.755 0 1.506.093 1.506.093s3.385-9.44 4.146-9.621c-.082-.208-.183-.33-.322-.333Z",
    opacity: 0.1
  }), (0,_emotion_react__WEBPACK_IMPORTED_MODULE_4__.jsx)("path", {
    fill: "#FFF",
    d: "M6.889 6.016C5.32 15.96 6.14 25.27 6.14 25.27l.289-.325c-.148-2.197-.543-10.14.791-18.597h4.541c.096.002.225.08.374.208-.297-.33-.544-.538-.706-.54H6.889Zm13.601 0c-.864.01-4.152 5.777-4.53 5.777.154.197.279.333.332.333.378 0 3.666-5.767 4.53-5.777h4.008l.2-.333h-4.54Zm-9.881 5.725c1.103 1.657 3.844 9.29 3.844 9.29l.08-.373c-.676-1.856-3.256-8.814-3.903-8.917h-.021Zm11.346 0c.74 1.887-.66 11.295-1.08 13.529l.444-.348c.568-3.331 1.936-13.146.636-13.18Z",
    opacity: 0.3
  })));
};
var icon = EuiIconLogoMemcached;

/***/ })

}]);
//# sourceMappingURL=kbn-ui-shared-deps-npm.chunk.279.js.map