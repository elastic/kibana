# Integration OTel Test Package

Test integration package with an OpenTelemetry collector input.
