import type { PrimitiveExample } from '@elastic/isomer-sdk';
import type { MetricNode } from '../metric';
export declare const metricSingleValue: MetricNode;
export declare const metricExamples: PrimitiveExample<MetricNode>[];
