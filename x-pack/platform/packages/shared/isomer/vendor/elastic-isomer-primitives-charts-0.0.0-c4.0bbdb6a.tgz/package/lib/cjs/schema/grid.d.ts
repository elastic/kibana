import { type PrimitiveNode, z } from '@elastic/isomer-sdk';
type ZodType<T = unknown> = z.ZodType<T>;
/** Columns across a grid, as on a Kibana dashboard. */
export declare const GRID_COLUMNS = 48;
/**
 * Below this width in pixels a grid renders as one column in reading order, as
 * Kibana's dashboard does below EUI's `m` breakpoint.
 */
export declare const GRID_SINGLE_COLUMN_BELOW = 768;
export declare const GRID_RULES: {
    readonly width: "A panel's `x + w` is at most 48.";
    readonly ids: "Panel and section ids are unique within the grid.";
};
export declare const GRID_READING_ORDER = "Reading order is the top-level panels by `y`, then `x`, followed by each section by `y` with its panels by `y`, then `x`; ties keep array order.";
/** The `grid` schema with its panel nodes unresolved, for standalone validation. */
export declare const gridSchema: z.ZodObject<{
    type: z.ZodLiteral<"grid">;
    title: z.ZodOptional<z.ZodString>;
    description: z.ZodOptional<z.ZodString>;
    panels: z.ZodArray<z.ZodObject<{
        id: z.ZodOptional<z.ZodString>;
        title: z.ZodOptional<z.ZodString>;
        description: z.ZodOptional<z.ZodString>;
        x: z.ZodInt;
        y: z.ZodInt;
        w: z.ZodInt;
        h: z.ZodInt;
        node: z.ZodObject<{
            type: z.ZodString;
        }, z.core.$loose>;
    }, z.core.$strict>>;
    sections: z.ZodOptional<z.ZodArray<z.ZodObject<{
        id: z.ZodOptional<z.ZodString>;
        title: z.ZodString;
        collapsed: z.ZodOptional<z.ZodBoolean>;
        y: z.ZodInt;
        panels: z.ZodArray<z.ZodObject<{
            id: z.ZodOptional<z.ZodString>;
            title: z.ZodOptional<z.ZodString>;
            description: z.ZodOptional<z.ZodString>;
            x: z.ZodInt;
            y: z.ZodInt;
            w: z.ZodInt;
            h: z.ZodInt;
            node: z.ZodObject<{
                type: z.ZodString;
            }, z.core.$loose>;
        }, z.core.$strict>>;
    }, z.core.$strict>>>;
}, z.core.$strip>;
/** The `grid` schema bound to a composition's body-node union. */
export declare const gridSchemaFor: (bodyNode: ZodType<unknown>) => z.ZodObject<{
    type: z.ZodLiteral<"grid">;
    title: z.ZodOptional<z.ZodString>;
    description: z.ZodOptional<z.ZodString>;
    panels: z.ZodArray<z.ZodObject<{
        id: z.ZodOptional<z.ZodString>;
        title: z.ZodOptional<z.ZodString>;
        description: z.ZodOptional<z.ZodString>;
        x: z.ZodInt;
        y: z.ZodInt;
        w: z.ZodInt;
        h: z.ZodInt;
        node: ZodType<unknown>;
    }, z.core.$strict>>;
    sections: z.ZodOptional<z.ZodArray<z.ZodObject<{
        id: z.ZodOptional<z.ZodString>;
        title: z.ZodString;
        collapsed: z.ZodOptional<z.ZodBoolean>;
        y: z.ZodInt;
        panels: z.ZodArray<z.ZodObject<{
            id: z.ZodOptional<z.ZodString>;
            title: z.ZodOptional<z.ZodString>;
            description: z.ZodOptional<z.ZodString>;
            x: z.ZodInt;
            y: z.ZodInt;
            w: z.ZodInt;
            h: z.ZodInt;
            node: ZodType<unknown>;
        }, z.core.$strict>>;
    }, z.core.$strict>>>;
}, z.core.$strip>;
export interface GridPanel<TNode = PrimitiveNode> {
    id?: string;
    title?: string;
    description?: string;
    x: number;
    y: number;
    w: number;
    h: number;
    node: TNode;
}
export interface GridSection<TNode = PrimitiveNode> {
    id?: string;
    title: string;
    collapsed?: boolean;
    y: number;
    panels: GridPanel<TNode>[];
}
/** A container's node type is hand-written: the body-node union is supplied per composition. */
export interface GridNode<TNode = PrimitiveNode> extends PrimitiveNode {
    type: 'grid';
    title?: string;
    description?: string;
    panels: GridPanel<TNode>[];
    sections?: GridSection<TNode>[];
}
export interface GridReadingEntry<TNode = PrimitiveNode> {
    panel: GridPanel<TNode>;
    /** The field path of the panel's node, such as `sections[0].panels[2].node`. */
    path: string;
    /** Absent for a top-level panel. */
    section?: GridSection<TNode>;
}
/**
 * Every panel in reading order ({@link GRID_READING_ORDER}), with the path of
 * its node. Panels in a collapsed section are included; a renderer decides
 * whether to draw them.
 */
export declare const gridReadingOrder: <TNode>(node: Pick<GridNode<TNode>, "panels" | "sections">) => GridReadingEntry<TNode>[];
export {};
