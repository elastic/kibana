import type { MetricScene, XyScene } from './types';
/** The Scene for the `metric` example "Single value", in light. */
export declare const metricSingleValueScene: MetricScene;
/** The Scene for the `xyChart` example "Time series line", in light. */
export declare const xyTimeSeriesScene: XyScene;
