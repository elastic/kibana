import type { PrimitiveExample } from '@elastic/isomer-sdk';
import type { UnsupportedNode } from '../unsupported';
export declare const unsupportedVega: UnsupportedNode;
export declare const unsupportedExamples: PrimitiveExample<UnsupportedNode>[];
