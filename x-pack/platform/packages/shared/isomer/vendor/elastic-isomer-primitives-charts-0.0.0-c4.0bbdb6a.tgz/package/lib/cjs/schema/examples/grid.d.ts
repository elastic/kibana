import type { PrimitiveExample } from '@elastic/isomer-sdk';
import type { GridNode } from '../grid';
export declare const gridExamples: PrimitiveExample<GridNode>[];
