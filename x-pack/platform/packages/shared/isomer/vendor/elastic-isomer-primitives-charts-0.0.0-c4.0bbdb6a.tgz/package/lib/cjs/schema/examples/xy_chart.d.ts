import type { PrimitiveExample } from '@elastic/isomer-sdk';
import type { XyChartNode } from '../xy_chart';
export declare const xyTimeSeries: XyChartNode;
/** Interactive: selectable marks, series and legend items, a time brush, and a static highlight. */
export declare const xyInteractive: XyChartNode;
export declare const xyChartExamples: PrimitiveExample<XyChartNode>[];
