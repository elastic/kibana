import { type PrimitiveNode, z } from '@elastic/isomer-sdk';
export declare const unsupportedSchema: z.ZodObject<{
    type: z.ZodLiteral<"unsupported">;
    title: z.ZodString;
    reason: z.ZodString;
    link: z.ZodOptional<z.ZodObject<{
        href: z.ZodString;
        label: z.ZodString;
    }, z.core.$strict>>;
    source: z.ZodOptional<z.ZodObject<{
        kind: z.ZodLiteral<"kibana">;
        kibanaVersion: z.ZodString;
        materializer: z.ZodString;
        materializerVersion: z.ZodInt;
        spaceId: z.ZodOptional<z.ZodString>;
        savedObjectType: z.ZodOptional<z.ZodString>;
        savedObjectId: z.ZodOptional<z.ZodString>;
        panelId: z.ZodOptional<z.ZodString>;
        timeRange: z.ZodOptional<z.ZodObject<{
            from: z.ZodISODateTime;
            to: z.ZodISODateTime;
        }, z.core.$strict>>;
        capturedAt: z.ZodISODateTime;
    }, z.core.$strict>>;
}, z.core.$strip>;
export type UnsupportedNode = z.infer<typeof unsupportedSchema> & PrimitiveNode;
