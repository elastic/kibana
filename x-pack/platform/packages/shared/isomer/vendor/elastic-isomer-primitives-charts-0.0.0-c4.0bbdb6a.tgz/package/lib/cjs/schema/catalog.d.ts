import type { PrimitiveCatalogEntry } from '@elastic/isomer-sdk';
export declare const metricCatalog: PrimitiveCatalogEntry;
export declare const xyChartCatalog: PrimitiveCatalogEntry;
export declare const gridCatalog: PrimitiveCatalogEntry;
export declare const unsupportedCatalog: PrimitiveCatalogEntry;
