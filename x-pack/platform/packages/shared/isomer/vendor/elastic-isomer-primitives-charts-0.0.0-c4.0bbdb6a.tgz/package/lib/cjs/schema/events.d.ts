import { type ActionEventRef, z } from '@elastic/isomer-sdk';
import { type ChartColumn, type ColumnReference } from './core';
export declare const SELECT_TARGETS: readonly ["datum", "series", "category", "legend", "cell", "tile"];
/** What a selection lands on. Each chart states which it offers. */
export type SelectTarget = (typeof SELECT_TARGETS)[number];
export declare const INTERACTION_RULES: {
    readonly brushColumn: "A `brush` column is a `date` or `number` column.";
    readonly emphasisRows: "Emphasis rows are indexes into `data.rows`.";
};
/** `interactions.select` for a chart offering `targets`. */
export declare const selectSchema: <const TTargets extends readonly [SelectTarget, ...SelectTarget[]]>(targets: TTargets) => z.ZodOptional<z.ZodArray<z.ZodEnum<{ [k_1 in TTargets[number]]: k_1; } extends infer T ? { [k in keyof T]: T[k]; } : never>>>;
export declare const brushSchema: z.ZodObject<{
    column: z.ZodString;
}, z.core.$strict>;
/** The `interactions` schema for a chart with no brush and no persisted view state. */
export declare const interactionsSchemaFor: <const TTargets extends readonly [SelectTarget, ...SelectTarget[]]>(targets: TTargets) => z.ZodObject<{
    select: z.ZodOptional<z.ZodArray<z.ZodEnum<{ [k_1 in TTargets[number]]: k_1; } extends infer T ? { [k in keyof T]: T[k]; } : never>>>;
    sync: z.ZodOptional<z.ZodObject<{
        cursor: z.ZodOptional<z.ZodBoolean>;
        tooltips: z.ZodOptional<z.ZodBoolean>;
    }, z.core.$strict>>;
    link: z.ZodOptional<z.ZodObject<{
        href: z.ZodString;
        label: z.ZodString;
    }, z.core.$strict>>;
}, z.core.$strict>;
/** The `interactions` schema for a chart that brushes and persists view state. */
export declare const brushingInteractionsSchemaFor: <const TTargets extends readonly [SelectTarget, ...SelectTarget[]], TInitial extends z.ZodRawShape>(targets: TTargets, initial: TInitial) => z.ZodObject<{
    select: z.ZodOptional<z.ZodArray<z.ZodEnum<{ [k_1 in TTargets[number]]: k_1; } extends infer T ? { [k in keyof T]: T[k]; } : never>>>;
    brush: z.ZodOptional<z.ZodObject<{
        column: z.ZodString;
    }, z.core.$strict>>;
    sync: z.ZodOptional<z.ZodObject<{
        cursor: z.ZodOptional<z.ZodBoolean>;
        tooltips: z.ZodOptional<z.ZodBoolean>;
    }, z.core.$strict>>;
    link: z.ZodOptional<z.ZodObject<{
        href: z.ZodString;
        label: z.ZodString;
    }, z.core.$strict>>;
    initial: z.ZodOptional<z.ZodObject<{ -readonly [P in keyof TInitial]: TInitial[P]; }, z.core.$strict>>;
}, z.core.$strict>;
export declare const emphasisSchema: z.ZodArray<z.ZodObject<{
    rows: z.ZodArray<z.ZodInt>;
    note: z.ZodOptional<z.ZodString>;
}, z.core.$strict>>;
export type Emphasis = z.infer<typeof emphasisSchema>;
/** The interaction fields every chart spreads into its schema beside the core. */
export declare const interactionsCoreShape: {
    emphasis: z.ZodOptional<z.ZodArray<z.ZodObject<{
        rows: z.ZodArray<z.ZodInt>;
        note: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>>>;
};
interface InteractionsInput {
    data: {
        columns: readonly ChartColumn[];
        rows: readonly unknown[];
    };
    emphasis?: Emphasis | undefined;
    interactions?: object | undefined;
}
/** Checks `emphasis` rows and a `brush` column against `data`. */
export declare const checkInteractions: (node: InteractionsInput, context: z.core.$RefinementCtx<unknown>, extra?: readonly ColumnReference[]) => void;
/** `ActionEventRef.name` for each kind of chart event. */
export declare const CHART_EVENT_NAMES: {
    readonly select: "chart.select";
    readonly brush: "chart.brush";
};
export declare const chartEventSchema: z.ZodDiscriminatedUnion<[z.ZodObject<{
    node: z.ZodString;
    description: z.ZodString;
    values: z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodUnion<readonly [z.ZodNumber, z.ZodString, z.ZodBoolean, z.ZodNull]>, z.ZodArray<z.ZodUnion<readonly [z.ZodNumber, z.ZodString, z.ZodBoolean, z.ZodNull]>>]>>;
    kind: z.ZodLiteral<"select">;
    target: z.ZodEnum<{
        datum: "datum";
        series: "series";
        category: "category";
        legend: "legend";
        cell: "cell";
        tile: "tile";
    }>;
    rows: z.ZodArray<z.ZodInt>;
    columns: z.ZodArray<z.ZodString>;
    negate: z.ZodOptional<z.ZodBoolean>;
}, z.core.$strict>, z.ZodObject<{
    node: z.ZodString;
    description: z.ZodString;
    values: z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodUnion<readonly [z.ZodNumber, z.ZodString, z.ZodBoolean, z.ZodNull]>, z.ZodArray<z.ZodUnion<readonly [z.ZodNumber, z.ZodString, z.ZodBoolean, z.ZodNull]>>]>>;
    kind: z.ZodLiteral<"brush">;
    column: z.ZodString;
    range: z.ZodTuple<[z.ZodNumber, z.ZodNumber], null>;
}, z.core.$strict>], "kind">;
export type ChartEvent = z.infer<typeof chartEventSchema>;
export type ChartSelectEvent = Extract<ChartEvent, {
    kind: 'select';
}>;
export type ChartBrushEvent = Extract<ChartEvent, {
    kind: 'brush';
}>;
/** Wraps a chart event as the `ActionEventRef` a host's `onEvent` receives. */
export declare const toActionEvent: (event: ChartEvent) => ActionEventRef;
/** The chart event an `ActionEventRef` carries, or `undefined` when it carries none. */
export declare const readChartEvent: (ref: ActionEventRef) => ChartEvent | undefined;
export {};
