import { z } from '@elastic/isomer-sdk';
type RefineParams = Exclude<Parameters<typeof z.refine>[1], string | undefined>;
/** `rule` is the sentence, word for word, that a description the authoring JSON Schema keeps states the check in. */
type StatedParams = RefineParams & {
    rule: string;
};
/** The rules a check from this module states, or `undefined` for any other check. */
export declare const rulesOf: (check: object) => readonly string[] | undefined;
/** A `.check()` rule on one field, stated in the authoring schema. */
export declare const statedRefine: <T>(check: (value: NoInfer<T>) => boolean, { rule, ...params }: StatedParams) => z.core.$ZodCheck<T>;
/** A `.check()` rule that runs even after a field fails, so one validation reports both. */
export declare const crossRefine: <T>(check: (value: NoInfer<T>) => boolean, { rule, ...params }: StatedParams) => z.core.$ZodCheck<T>;
/** {@link crossRefine} for a check that adds its own issues, one stated rule for each kind it raises. */
export declare const crossSuperRefine: <T>(refine: (value: T, context: z.core.$RefinementCtx<T>) => void, rules: readonly [string, ...string[]]) => z.core.$ZodCheck<T>;
export {};
