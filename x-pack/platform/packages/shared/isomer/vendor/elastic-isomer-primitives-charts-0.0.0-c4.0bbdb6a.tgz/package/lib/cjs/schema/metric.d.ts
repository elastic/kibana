import { type PrimitiveNode, z } from '@elastic/isomer-sdk';
export declare const METRIC_ICONS: readonly ["alert", "asterisk", "bell", "bolt", "bug", "compute", "editor_comment", "flag", "globe", "heart", "map_marker", "pin", "popout", "sort_down", "sort_up", "star_empty", "tag", "temperature"];
export declare const METRIC_RULES: {
    readonly columnType: "A bar `max` and a trend `y` are `number` columns; a trend `x` is a `date` or `number` column.";
    readonly trendColumns: "Trend column references name a column in `background.data.columns`.";
    readonly oneRow: "Without a `breakdown`, `data` holds at most one row.";
    readonly bands: "A `bands` color needs `colors.bands`.";
    readonly percentage: "Percentage bands need a `background` bar or a `breakdown`, which supply the maximum.";
    readonly trendBreakdown: "A trend `breakdown` needs a `breakdown` on the metric.";
};
export declare const metricCompareSchema: z.ZodObject<{
    to: z.ZodEnum<{
        baseline: "baseline";
        primary: "primary";
    }>;
    baseline: z.ZodOptional<z.ZodNumber>;
    showIcon: z.ZodOptional<z.ZodBoolean>;
    showValue: z.ZodOptional<z.ZodBoolean>;
    colors: z.ZodObject<{
        increase: z.ZodUnion<readonly [z.ZodObject<{
            light: z.ZodString;
            dark: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            token: z.ZodEnum<{
                text: "text";
                textSubdued: "textSubdued";
                axis: "axis";
                gridLine: "gridLine";
                background: "background";
                border: "border";
            }>;
        }, z.core.$strict>, z.ZodObject<{
            palette: z.ZodLiteral<"categorical">;
            index: z.ZodInt;
        }, z.core.$strict>]>;
        decrease: z.ZodUnion<readonly [z.ZodObject<{
            light: z.ZodString;
            dark: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            token: z.ZodEnum<{
                text: "text";
                textSubdued: "textSubdued";
                axis: "axis";
                gridLine: "gridLine";
                background: "background";
                border: "border";
            }>;
        }, z.core.$strict>, z.ZodObject<{
            palette: z.ZodLiteral<"categorical">;
            index: z.ZodInt;
        }, z.core.$strict>]>;
        neutral: z.ZodUnion<readonly [z.ZodObject<{
            light: z.ZodString;
            dark: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            token: z.ZodEnum<{
                text: "text";
                textSubdued: "textSubdued";
                axis: "axis";
                gridLine: "gridLine";
                background: "background";
                border: "border";
            }>;
        }, z.core.$strict>, z.ZodObject<{
            palette: z.ZodLiteral<"categorical">;
            index: z.ZodInt;
        }, z.core.$strict>]>;
    }, z.core.$strict>;
}, z.core.$strict>;
export declare const metricSchema: z.ZodObject<{
    interactions: z.ZodOptional<z.ZodObject<{
        select: z.ZodOptional<z.ZodArray<z.ZodEnum<{
            tile: "tile";
        }>>>;
        sync: z.ZodOptional<z.ZodObject<{
            cursor: z.ZodOptional<z.ZodBoolean>;
            tooltips: z.ZodOptional<z.ZodBoolean>;
        }, z.core.$strict>>;
        link: z.ZodOptional<z.ZodObject<{
            href: z.ZodString;
            label: z.ZodString;
        }, z.core.$strict>>;
    }, z.core.$strict>>;
    value: z.ZodObject<{
        column: z.ZodString;
        subtitle: z.ZodOptional<z.ZodString>;
        color: z.ZodOptional<z.ZodUnion<readonly [z.ZodUnion<readonly [z.ZodObject<{
            light: z.ZodString;
            dark: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            token: z.ZodEnum<{
                text: "text";
                textSubdued: "textSubdued";
                axis: "axis";
                gridLine: "gridLine";
                background: "background";
                border: "border";
            }>;
        }, z.core.$strict>, z.ZodObject<{
            palette: z.ZodLiteral<"categorical">;
            index: z.ZodInt;
        }, z.core.$strict>]>, z.ZodLiteral<"bands">]>>;
        bandsRange: z.ZodOptional<z.ZodEnum<{
            percentage: "percentage";
            absolute: "absolute";
        }>>;
        applyColorTo: z.ZodOptional<z.ZodEnum<{
            background: "background";
            value: "value";
        }>>;
    }, z.core.$strict>;
    secondary: z.ZodOptional<z.ZodObject<{
        column: z.ZodString;
        showLabel: z.ZodOptional<z.ZodBoolean>;
        labelPlacement: z.ZodOptional<z.ZodEnum<{
            before: "before";
            after: "after";
            tooltip: "tooltip";
        }>>;
        color: z.ZodOptional<z.ZodUnion<readonly [z.ZodObject<{
            light: z.ZodString;
            dark: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            token: z.ZodEnum<{
                text: "text";
                textSubdued: "textSubdued";
                axis: "axis";
                gridLine: "gridLine";
                background: "background";
                border: "border";
            }>;
        }, z.core.$strict>, z.ZodObject<{
            palette: z.ZodLiteral<"categorical">;
            index: z.ZodInt;
        }, z.core.$strict>]>>;
        compare: z.ZodOptional<z.ZodObject<{
            to: z.ZodEnum<{
                baseline: "baseline";
                primary: "primary";
            }>;
            baseline: z.ZodOptional<z.ZodNumber>;
            showIcon: z.ZodOptional<z.ZodBoolean>;
            showValue: z.ZodOptional<z.ZodBoolean>;
            colors: z.ZodObject<{
                increase: z.ZodUnion<readonly [z.ZodObject<{
                    light: z.ZodString;
                    dark: z.ZodString;
                }, z.core.$strict>, z.ZodObject<{
                    token: z.ZodEnum<{
                        text: "text";
                        textSubdued: "textSubdued";
                        axis: "axis";
                        gridLine: "gridLine";
                        background: "background";
                        border: "border";
                    }>;
                }, z.core.$strict>, z.ZodObject<{
                    palette: z.ZodLiteral<"categorical">;
                    index: z.ZodInt;
                }, z.core.$strict>]>;
                decrease: z.ZodUnion<readonly [z.ZodObject<{
                    light: z.ZodString;
                    dark: z.ZodString;
                }, z.core.$strict>, z.ZodObject<{
                    token: z.ZodEnum<{
                        text: "text";
                        textSubdued: "textSubdued";
                        axis: "axis";
                        gridLine: "gridLine";
                        background: "background";
                        border: "border";
                    }>;
                }, z.core.$strict>, z.ZodObject<{
                    palette: z.ZodLiteral<"categorical">;
                    index: z.ZodInt;
                }, z.core.$strict>]>;
                neutral: z.ZodUnion<readonly [z.ZodObject<{
                    light: z.ZodString;
                    dark: z.ZodString;
                }, z.core.$strict>, z.ZodObject<{
                    token: z.ZodEnum<{
                        text: "text";
                        textSubdued: "textSubdued";
                        axis: "axis";
                        gridLine: "gridLine";
                        background: "background";
                        border: "border";
                    }>;
                }, z.core.$strict>, z.ZodObject<{
                    palette: z.ZodLiteral<"categorical">;
                    index: z.ZodInt;
                }, z.core.$strict>]>;
            }, z.core.$strict>;
        }, z.core.$strict>>;
    }, z.core.$strict>>;
    background: z.ZodOptional<z.ZodDiscriminatedUnion<[z.ZodObject<{
        kind: z.ZodLiteral<"bar">;
        max: z.ZodString;
        orientation: z.ZodOptional<z.ZodEnum<{
            horizontal: "horizontal";
            vertical: "vertical";
        }>>;
    }, z.core.$strict>, z.ZodObject<{
        kind: z.ZodLiteral<"trend">;
        data: z.ZodObject<{
            columns: z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                label: z.ZodString;
                type: z.ZodEnum<{
                    string: "string";
                    number: "number";
                    boolean: "boolean";
                    date: "date";
                }>;
                role: z.ZodEnum<{
                    dimension: "dimension";
                    metric: "metric";
                }>;
                format: z.ZodOptional<z.ZodDiscriminatedUnion<[z.ZodObject<{
                    pattern: z.ZodString;
                    locale: z.ZodOptional<z.ZodString>;
                    alwaysShowSign: z.ZodOptional<z.ZodBoolean>;
                    suffix: z.ZodOptional<z.ZodString>;
                    kind: z.ZodLiteral<"number">;
                }, z.core.$strict>, z.ZodObject<{
                    pattern: z.ZodString;
                    locale: z.ZodOptional<z.ZodString>;
                    alwaysShowSign: z.ZodOptional<z.ZodBoolean>;
                    suffix: z.ZodOptional<z.ZodString>;
                    kind: z.ZodLiteral<"percent">;
                }, z.core.$strict>, z.ZodObject<{
                    pattern: z.ZodString;
                    locale: z.ZodOptional<z.ZodString>;
                    alwaysShowSign: z.ZodOptional<z.ZodBoolean>;
                    suffix: z.ZodOptional<z.ZodString>;
                    kind: z.ZodLiteral<"bytes">;
                }, z.core.$strict>, z.ZodObject<{
                    pattern: z.ZodString;
                    locale: z.ZodOptional<z.ZodString>;
                    alwaysShowSign: z.ZodOptional<z.ZodBoolean>;
                    suffix: z.ZodOptional<z.ZodString>;
                    kind: z.ZodLiteral<"bits">;
                }, z.core.$strict>, z.ZodObject<{
                    kind: z.ZodLiteral<"duration">;
                    input: z.ZodEnum<{
                        picoseconds: "picoseconds";
                        nanoseconds: "nanoseconds";
                        microseconds: "microseconds";
                        milliseconds: "milliseconds";
                        seconds: "seconds";
                        minutes: "minutes";
                        hours: "hours";
                        days: "days";
                        weeks: "weeks";
                        months: "months";
                        years: "years";
                    }>;
                    output: z.ZodUnion<readonly [z.ZodEnum<{
                        milliseconds: "milliseconds";
                        seconds: "seconds";
                        minutes: "minutes";
                        hours: "hours";
                        days: "days";
                        weeks: "weeks";
                        months: "months";
                        years: "years";
                    }>, z.ZodLiteral<"humanize">, z.ZodLiteral<"humanizePrecise">]>;
                    decimals: z.ZodOptional<z.ZodInt>;
                    showSuffix: z.ZodOptional<z.ZodBoolean>;
                    useShortSuffix: z.ZodOptional<z.ZodBoolean>;
                    includeSpaceWithSuffix: z.ZodOptional<z.ZodBoolean>;
                    suffix: z.ZodOptional<z.ZodString>;
                }, z.core.$strict>, z.ZodObject<{
                    kind: z.ZodLiteral<"date">;
                    pattern: z.ZodString;
                    timeZone: z.ZodString;
                }, z.core.$strict>, z.ZodObject<{
                    kind: z.ZodLiteral<"text">;
                }, z.core.$strict>], "kind">>;
                multivalue: z.ZodOptional<z.ZodLiteral<true>>;
                source: z.ZodOptional<z.ZodUnknown>;
            }, z.core.$strict>>;
            rows: z.ZodArray<z.ZodArray<z.ZodUnion<readonly [z.ZodUnion<readonly [z.ZodNumber, z.ZodString, z.ZodBoolean, z.ZodNull]>, z.ZodArray<z.ZodUnion<readonly [z.ZodNumber, z.ZodString, z.ZodBoolean, z.ZodNull]>>]>>>;
            source: z.ZodOptional<z.ZodUnknown>;
            display: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodArray<z.ZodString>>>;
        }, z.core.$strict>;
        x: z.ZodString;
        y: z.ZodString;
        breakdown: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>], "kind">>;
    breakdown: z.ZodOptional<z.ZodObject<{
        column: z.ZodString;
        maxColumns: z.ZodOptional<z.ZodInt>;
    }, z.core.$strict>>;
    layout: z.ZodOptional<z.ZodObject<{
        density: z.ZodOptional<z.ZodEnum<{
            default: "default";
            compact: "compact";
        }>>;
        icon: z.ZodOptional<z.ZodObject<{
            name: z.ZodEnum<{
                alert: "alert";
                asterisk: "asterisk";
                bell: "bell";
                bolt: "bolt";
                bug: "bug";
                compute: "compute";
                editor_comment: "editor_comment";
                flag: "flag";
                globe: "globe";
                heart: "heart";
                map_marker: "map_marker";
                pin: "pin";
                popout: "popout";
                sort_down: "sort_down";
                sort_up: "sort_up";
                star_empty: "star_empty";
                tag: "tag";
                temperature: "temperature";
            }>;
            alignment: z.ZodOptional<z.ZodEnum<{
                left: "left";
                right: "right";
            }>>;
        }, z.core.$strict>>;
        valuePosition: z.ZodOptional<z.ZodEnum<{
            top: "top";
            middle: "middle";
            bottom: "bottom";
        }>>;
        labelsAlignment: z.ZodOptional<z.ZodEnum<{
            left: "left";
            center: "center";
            right: "right";
        }>>;
        valueAlignment: z.ZodOptional<z.ZodEnum<{
            left: "left";
            center: "center";
            right: "right";
        }>>;
        valueSizing: z.ZodOptional<z.ZodEnum<{
            fill: "fill";
            auto: "auto";
        }>>;
        secondaryAlignment: z.ZodOptional<z.ZodEnum<{
            left: "left";
            center: "center";
            right: "right";
        }>>;
    }, z.core.$strict>>;
    emphasis: z.ZodOptional<z.ZodArray<z.ZodObject<{
        rows: z.ZodArray<z.ZodInt>;
        note: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>>>;
    title: z.ZodOptional<z.ZodString>;
    description: z.ZodOptional<z.ZodString>;
    data: z.ZodObject<{
        columns: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            label: z.ZodString;
            type: z.ZodEnum<{
                string: "string";
                number: "number";
                boolean: "boolean";
                date: "date";
            }>;
            role: z.ZodEnum<{
                dimension: "dimension";
                metric: "metric";
            }>;
            format: z.ZodOptional<z.ZodDiscriminatedUnion<[z.ZodObject<{
                pattern: z.ZodString;
                locale: z.ZodOptional<z.ZodString>;
                alwaysShowSign: z.ZodOptional<z.ZodBoolean>;
                suffix: z.ZodOptional<z.ZodString>;
                kind: z.ZodLiteral<"number">;
            }, z.core.$strict>, z.ZodObject<{
                pattern: z.ZodString;
                locale: z.ZodOptional<z.ZodString>;
                alwaysShowSign: z.ZodOptional<z.ZodBoolean>;
                suffix: z.ZodOptional<z.ZodString>;
                kind: z.ZodLiteral<"percent">;
            }, z.core.$strict>, z.ZodObject<{
                pattern: z.ZodString;
                locale: z.ZodOptional<z.ZodString>;
                alwaysShowSign: z.ZodOptional<z.ZodBoolean>;
                suffix: z.ZodOptional<z.ZodString>;
                kind: z.ZodLiteral<"bytes">;
            }, z.core.$strict>, z.ZodObject<{
                pattern: z.ZodString;
                locale: z.ZodOptional<z.ZodString>;
                alwaysShowSign: z.ZodOptional<z.ZodBoolean>;
                suffix: z.ZodOptional<z.ZodString>;
                kind: z.ZodLiteral<"bits">;
            }, z.core.$strict>, z.ZodObject<{
                kind: z.ZodLiteral<"duration">;
                input: z.ZodEnum<{
                    picoseconds: "picoseconds";
                    nanoseconds: "nanoseconds";
                    microseconds: "microseconds";
                    milliseconds: "milliseconds";
                    seconds: "seconds";
                    minutes: "minutes";
                    hours: "hours";
                    days: "days";
                    weeks: "weeks";
                    months: "months";
                    years: "years";
                }>;
                output: z.ZodUnion<readonly [z.ZodEnum<{
                    milliseconds: "milliseconds";
                    seconds: "seconds";
                    minutes: "minutes";
                    hours: "hours";
                    days: "days";
                    weeks: "weeks";
                    months: "months";
                    years: "years";
                }>, z.ZodLiteral<"humanize">, z.ZodLiteral<"humanizePrecise">]>;
                decimals: z.ZodOptional<z.ZodInt>;
                showSuffix: z.ZodOptional<z.ZodBoolean>;
                useShortSuffix: z.ZodOptional<z.ZodBoolean>;
                includeSpaceWithSuffix: z.ZodOptional<z.ZodBoolean>;
                suffix: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>, z.ZodObject<{
                kind: z.ZodLiteral<"date">;
                pattern: z.ZodString;
                timeZone: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                kind: z.ZodLiteral<"text">;
            }, z.core.$strict>], "kind">>;
            multivalue: z.ZodOptional<z.ZodLiteral<true>>;
            source: z.ZodOptional<z.ZodUnknown>;
        }, z.core.$strict>>;
        rows: z.ZodArray<z.ZodArray<z.ZodUnion<readonly [z.ZodUnion<readonly [z.ZodNumber, z.ZodString, z.ZodBoolean, z.ZodNull]>, z.ZodArray<z.ZodUnion<readonly [z.ZodNumber, z.ZodString, z.ZodBoolean, z.ZodNull]>>]>>>;
        source: z.ZodOptional<z.ZodUnknown>;
        display: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodArray<z.ZodString>>>;
    }, z.core.$strict>;
    colors: z.ZodOptional<z.ZodObject<{
        byKey: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodObject<{
            light: z.ZodString;
            dark: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            token: z.ZodEnum<{
                text: "text";
                textSubdued: "textSubdued";
                axis: "axis";
                gridLine: "gridLine";
                background: "background";
                border: "border";
            }>;
        }, z.core.$strict>, z.ZodObject<{
            palette: z.ZodLiteral<"categorical">;
            index: z.ZodInt;
        }, z.core.$strict>]>>>;
        bands: z.ZodOptional<z.ZodArray<z.ZodObject<{
            from: z.ZodOptional<z.ZodNumber>;
            to: z.ZodOptional<z.ZodNumber>;
            color: z.ZodUnion<readonly [z.ZodObject<{
                light: z.ZodString;
                dark: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                token: z.ZodEnum<{
                    text: "text";
                    textSubdued: "textSubdued";
                    axis: "axis";
                    gridLine: "gridLine";
                    background: "background";
                    border: "border";
                }>;
            }, z.core.$strict>, z.ZodObject<{
                palette: z.ZodLiteral<"categorical">;
                index: z.ZodInt;
            }, z.core.$strict>]>;
        }, z.core.$strict>>>;
    }, z.core.$strict>>;
    source: z.ZodOptional<z.ZodObject<{
        kind: z.ZodLiteral<"kibana">;
        kibanaVersion: z.ZodString;
        materializer: z.ZodString;
        materializerVersion: z.ZodInt;
        spaceId: z.ZodOptional<z.ZodString>;
        savedObjectType: z.ZodOptional<z.ZodString>;
        savedObjectId: z.ZodOptional<z.ZodString>;
        panelId: z.ZodOptional<z.ZodString>;
        timeRange: z.ZodOptional<z.ZodObject<{
            from: z.ZodISODateTime;
            to: z.ZodISODateTime;
        }, z.core.$strict>>;
        capturedAt: z.ZodISODateTime;
    }, z.core.$strict>>;
    losses: z.ZodOptional<z.ZodArray<z.ZodObject<{
        path: z.ZodString;
        kind: z.ZodEnum<{
            dropped: "dropped";
            approximated: "approximated";
            prerendered: "prerendered";
        }>;
        note: z.ZodString;
    }, z.core.$strict>>>;
    type: z.ZodLiteral<"metric">;
}, z.core.$strip>;
export type MetricNode = z.infer<typeof metricSchema> & PrimitiveNode;
