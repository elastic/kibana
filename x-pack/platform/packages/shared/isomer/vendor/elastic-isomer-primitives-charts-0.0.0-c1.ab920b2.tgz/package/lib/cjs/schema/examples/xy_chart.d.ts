import type { PrimitiveExample } from '@elastic/isomer-sdk';
import type { XyChartNode } from '../xy_chart';
export declare const xyTimeSeries: XyChartNode;
export declare const xyChartExamples: PrimitiveExample<XyChartNode>[];
