import { type PrimitiveNode, z } from '@elastic/isomer-sdk';
export declare const XY_MARKER_ICONS: readonly ["alert", "asterisk", "bell", "bolt", "bug", "circle", "editor_comment", "flag", "heart", "map_marker", "pin_filled", "star_empty", "star_filled", "tag", "triangle"];
export declare const XY_LEGEND_STATISTICS: readonly ["min", "max", "avg", "median", "range", "last_value", "last_non_null_value", "first_value", "first_non_null_value", "difference", "difference_percentage", "count", "total", "standard_deviation", "variance", "distinct_count", "current_and_last_value"];
export declare const XY_SERIES_KEY_RULE = "A series key, for `colors.byKey`, is the y column id without `splitBy`; with `splitBy` it is the split cell as a string (`null` as \"null\"), prefixed by the y column id and \":\" when the layer has more than one y column.";
export declare const XY_RULES: {
    readonly yType: "A `y` column is a `number` column.";
    readonly rows: "A layer's `rows` is a `[start, end)` range within `data.rows`, with `start` at most `end`.";
    readonly stack: "Only `bar` and `area` layers stack.";
    readonly dataLayer: "At least one layer is a `data` layer.";
    readonly rangeOrder: "An annotation range's `from` is not after its `to`.";
};
export declare const xyChartSchema: z.ZodObject<{
    orientation: z.ZodOptional<z.ZodEnum<{
        horizontal: "horizontal";
        vertical: "vertical";
    }>>;
    layers: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
        kind: z.ZodLiteral<"data">;
        mark: z.ZodEnum<{
            bar: "bar";
            line: "line";
            area: "area";
        }>;
        stack: z.ZodOptional<z.ZodEnum<{
            percentage: "percentage";
            stacked: "stacked";
        }>>;
        x: z.ZodOptional<z.ZodString>;
        y: z.ZodArray<z.ZodObject<{
            column: z.ZodString;
            axis: z.ZodOptional<z.ZodEnum<{
                y: "y";
                y2: "y2";
            }>>;
            color: z.ZodOptional<z.ZodUnion<readonly [z.ZodObject<{
                light: z.ZodString;
                dark: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                token: z.ZodEnum<{
                    text: "text";
                    textSubdued: "textSubdued";
                    axis: "axis";
                    gridLine: "gridLine";
                    background: "background";
                    border: "border";
                }>;
            }, z.core.$strict>, z.ZodObject<{
                palette: z.ZodLiteral<"categorical">;
                index: z.ZodInt;
            }, z.core.$strict>]>>;
        }, z.core.$strict>>;
        splitBy: z.ZodOptional<z.ZodString>;
        rows: z.ZodOptional<z.ZodTuple<[z.ZodInt, z.ZodInt], null>>;
    }, z.core.$strict>, z.ZodObject<{
        kind: z.ZodLiteral<"referenceLines">;
        lines: z.ZodArray<z.ZodObject<{
            value: z.ZodNumber;
            axis: z.ZodOptional<z.ZodEnum<{
                x: "x";
                y: "y";
                y2: "y2";
            }>>;
            label: z.ZodOptional<z.ZodString>;
            format: z.ZodOptional<z.ZodDiscriminatedUnion<[z.ZodObject<{
                pattern: z.ZodString;
                locale: z.ZodOptional<z.ZodString>;
                alwaysShowSign: z.ZodOptional<z.ZodBoolean>;
                suffix: z.ZodOptional<z.ZodString>;
                kind: z.ZodLiteral<"number">;
            }, z.core.$strict>, z.ZodObject<{
                pattern: z.ZodString;
                locale: z.ZodOptional<z.ZodString>;
                alwaysShowSign: z.ZodOptional<z.ZodBoolean>;
                suffix: z.ZodOptional<z.ZodString>;
                kind: z.ZodLiteral<"percent">;
            }, z.core.$strict>, z.ZodObject<{
                pattern: z.ZodString;
                locale: z.ZodOptional<z.ZodString>;
                alwaysShowSign: z.ZodOptional<z.ZodBoolean>;
                suffix: z.ZodOptional<z.ZodString>;
                kind: z.ZodLiteral<"bytes">;
            }, z.core.$strict>, z.ZodObject<{
                pattern: z.ZodString;
                locale: z.ZodOptional<z.ZodString>;
                alwaysShowSign: z.ZodOptional<z.ZodBoolean>;
                suffix: z.ZodOptional<z.ZodString>;
                kind: z.ZodLiteral<"bits">;
            }, z.core.$strict>, z.ZodObject<{
                kind: z.ZodLiteral<"duration">;
                input: z.ZodEnum<{
                    picoseconds: "picoseconds";
                    nanoseconds: "nanoseconds";
                    microseconds: "microseconds";
                    milliseconds: "milliseconds";
                    seconds: "seconds";
                    minutes: "minutes";
                    hours: "hours";
                    days: "days";
                    weeks: "weeks";
                    months: "months";
                    years: "years";
                }>;
                output: z.ZodUnion<readonly [z.ZodEnum<{
                    milliseconds: "milliseconds";
                    seconds: "seconds";
                    minutes: "minutes";
                    hours: "hours";
                    days: "days";
                    weeks: "weeks";
                    months: "months";
                    years: "years";
                }>, z.ZodLiteral<"humanize">, z.ZodLiteral<"humanizePrecise">]>;
                decimals: z.ZodOptional<z.ZodInt>;
                showSuffix: z.ZodOptional<z.ZodBoolean>;
                useShortSuffix: z.ZodOptional<z.ZodBoolean>;
                includeSpaceWithSuffix: z.ZodOptional<z.ZodBoolean>;
                suffix: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>, z.ZodObject<{
                kind: z.ZodLiteral<"date">;
                pattern: z.ZodString;
                timeZone: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                kind: z.ZodLiteral<"text">;
            }, z.core.$strict>], "kind">>;
            showText: z.ZodOptional<z.ZodBoolean>;
            color: z.ZodOptional<z.ZodUnion<readonly [z.ZodObject<{
                light: z.ZodString;
                dark: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                token: z.ZodEnum<{
                    text: "text";
                    textSubdued: "textSubdued";
                    axis: "axis";
                    gridLine: "gridLine";
                    background: "background";
                    border: "border";
                }>;
            }, z.core.$strict>, z.ZodObject<{
                palette: z.ZodLiteral<"categorical">;
                index: z.ZodInt;
            }, z.core.$strict>]>>;
            fill: z.ZodOptional<z.ZodEnum<{
                above: "above";
                below: "below";
            }>>;
            icon: z.ZodOptional<z.ZodEnum<{
                alert: "alert";
                asterisk: "asterisk";
                bell: "bell";
                bolt: "bolt";
                bug: "bug";
                editor_comment: "editor_comment";
                flag: "flag";
                heart: "heart";
                map_marker: "map_marker";
                star_empty: "star_empty";
                tag: "tag";
                circle: "circle";
                pin_filled: "pin_filled";
                star_filled: "star_filled";
                triangle: "triangle";
            }>>;
            strokeWidth: z.ZodOptional<z.ZodNumber>;
            strokeDash: z.ZodOptional<z.ZodEnum<{
                solid: "solid";
                dashed: "dashed";
                dotted: "dotted";
            }>>;
            textPosition: z.ZodOptional<z.ZodEnum<{
                left: "left";
                right: "right";
                auto: "auto";
            }>>;
        }, z.core.$strict>>;
    }, z.core.$strict>, z.ZodObject<{
        kind: z.ZodLiteral<"annotations">;
        events: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
            kind: z.ZodLiteral<"point">;
            at: z.ZodUnion<readonly [z.ZodNumber, z.ZodISODateTime]>;
            label: z.ZodOptional<z.ZodString>;
            text: z.ZodOptional<z.ZodString>;
            color: z.ZodOptional<z.ZodUnion<readonly [z.ZodObject<{
                light: z.ZodString;
                dark: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                token: z.ZodEnum<{
                    text: "text";
                    textSubdued: "textSubdued";
                    axis: "axis";
                    gridLine: "gridLine";
                    background: "background";
                    border: "border";
                }>;
            }, z.core.$strict>, z.ZodObject<{
                palette: z.ZodLiteral<"categorical">;
                index: z.ZodInt;
            }, z.core.$strict>]>>;
            icon: z.ZodOptional<z.ZodEnum<{
                alert: "alert";
                asterisk: "asterisk";
                bell: "bell";
                bolt: "bolt";
                bug: "bug";
                editor_comment: "editor_comment";
                flag: "flag";
                heart: "heart";
                map_marker: "map_marker";
                star_empty: "star_empty";
                tag: "tag";
                circle: "circle";
                pin_filled: "pin_filled";
                star_filled: "star_filled";
                triangle: "triangle";
            }>>;
            line: z.ZodOptional<z.ZodObject<{
                width: z.ZodNumber;
                dash: z.ZodEnum<{
                    solid: "solid";
                    dashed: "dashed";
                    dotted: "dotted";
                }>;
            }, z.core.$strict>>;
            hidden: z.ZodOptional<z.ZodBoolean>;
        }, z.core.$strict>, z.ZodObject<{
            kind: z.ZodLiteral<"range">;
            from: z.ZodUnion<readonly [z.ZodNumber, z.ZodISODateTime]>;
            to: z.ZodUnion<readonly [z.ZodNumber, z.ZodISODateTime]>;
            label: z.ZodOptional<z.ZodString>;
            color: z.ZodOptional<z.ZodUnion<readonly [z.ZodObject<{
                light: z.ZodString;
                dark: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                token: z.ZodEnum<{
                    text: "text";
                    textSubdued: "textSubdued";
                    axis: "axis";
                    gridLine: "gridLine";
                    background: "background";
                    border: "border";
                }>;
            }, z.core.$strict>, z.ZodObject<{
                palette: z.ZodLiteral<"categorical">;
                index: z.ZodInt;
            }, z.core.$strict>]>>;
            fill: z.ZodOptional<z.ZodEnum<{
                inside: "inside";
                outside: "outside";
            }>>;
            hidden: z.ZodOptional<z.ZodBoolean>;
        }, z.core.$strict>], "kind">>;
    }, z.core.$strict>], "kind">>;
    axes: z.ZodOptional<z.ZodObject<{
        x: z.ZodOptional<z.ZodObject<{
            scale: z.ZodOptional<z.ZodEnum<{
                linear: "linear";
                ordinal: "ordinal";
                temporal: "temporal";
            }>>;
            domain: z.ZodOptional<z.ZodDiscriminatedUnion<[z.ZodObject<{
                kind: z.ZodLiteral<"fit">;
            }, z.core.$strict>, z.ZodObject<{
                kind: z.ZodLiteral<"custom">;
                min: z.ZodNumber;
                max: z.ZodNumber;
            }, z.core.$strict>], "kind">>;
            rounding: z.ZodOptional<z.ZodBoolean>;
            title: z.ZodOptional<z.ZodString>;
            ticks: z.ZodOptional<z.ZodBoolean>;
            grid: z.ZodOptional<z.ZodBoolean>;
            labelOrientation: z.ZodOptional<z.ZodEnum<{
                horizontal: "horizontal";
                vertical: "vertical";
                angled: "angled";
            }>>;
        }, z.core.$strict>>;
        y: z.ZodOptional<z.ZodObject<{
            scale: z.ZodOptional<z.ZodEnum<{
                linear: "linear";
                log: "log";
                sqrt: "sqrt";
            }>>;
            domain: z.ZodOptional<z.ZodDiscriminatedUnion<[z.ZodObject<{
                kind: z.ZodLiteral<"full">;
            }, z.core.$strict>, z.ZodObject<{
                kind: z.ZodLiteral<"fit">;
            }, z.core.$strict>, z.ZodObject<{
                kind: z.ZodLiteral<"custom">;
                min: z.ZodNumber;
                max: z.ZodNumber;
            }, z.core.$strict>], "kind">>;
            rounding: z.ZodOptional<z.ZodBoolean>;
            title: z.ZodOptional<z.ZodString>;
            ticks: z.ZodOptional<z.ZodBoolean>;
            grid: z.ZodOptional<z.ZodBoolean>;
            labelOrientation: z.ZodOptional<z.ZodEnum<{
                horizontal: "horizontal";
                vertical: "vertical";
                angled: "angled";
            }>>;
        }, z.core.$strict>>;
        y2: z.ZodOptional<z.ZodObject<{
            scale: z.ZodOptional<z.ZodEnum<{
                linear: "linear";
                log: "log";
                sqrt: "sqrt";
            }>>;
            domain: z.ZodOptional<z.ZodDiscriminatedUnion<[z.ZodObject<{
                kind: z.ZodLiteral<"full">;
            }, z.core.$strict>, z.ZodObject<{
                kind: z.ZodLiteral<"fit">;
            }, z.core.$strict>, z.ZodObject<{
                kind: z.ZodLiteral<"custom">;
                min: z.ZodNumber;
                max: z.ZodNumber;
            }, z.core.$strict>], "kind">>;
            rounding: z.ZodOptional<z.ZodBoolean>;
            title: z.ZodOptional<z.ZodString>;
            ticks: z.ZodOptional<z.ZodBoolean>;
            grid: z.ZodOptional<z.ZodBoolean>;
            labelOrientation: z.ZodOptional<z.ZodEnum<{
                horizontal: "horizontal";
                vertical: "vertical";
                angled: "angled";
            }>>;
        }, z.core.$strict>>;
    }, z.core.$strict>>;
    legend: z.ZodOptional<z.ZodObject<{
        visibility: z.ZodOptional<z.ZodEnum<{
            auto: "auto";
            hidden: "hidden";
            visible: "visible";
        }>>;
        position: z.ZodOptional<z.ZodEnum<{
            left: "left";
            right: "right";
            top: "top";
            bottom: "bottom";
        }>>;
        inside: z.ZodOptional<z.ZodEnum<{
            top_left: "top_left";
            top_right: "top_right";
            bottom_left: "bottom_left";
            bottom_right: "bottom_right";
        }>>;
        layout: z.ZodOptional<z.ZodEnum<{
            grid: "grid";
            list: "list";
        }>>;
        columns: z.ZodOptional<z.ZodInt>;
        maxLines: z.ZodOptional<z.ZodInt>;
        size: z.ZodOptional<z.ZodEnum<{
            auto: "auto";
            s: "s";
            m: "m";
            l: "l";
            xl: "xl";
        }>>;
        statistics: z.ZodOptional<z.ZodArray<z.ZodEnum<{
            max: "max";
            count: "count";
            avg: "avg";
            min: "min";
            median: "median";
            range: "range";
            last_value: "last_value";
            last_non_null_value: "last_non_null_value";
            first_value: "first_value";
            first_non_null_value: "first_non_null_value";
            difference: "difference";
            difference_percentage: "difference_percentage";
            total: "total";
            standard_deviation: "standard_deviation";
            variance: "variance";
            distinct_count: "distinct_count";
            current_and_last_value: "current_and_last_value";
        }>>>;
        seriesHeader: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>>;
    style: z.ZodOptional<z.ZodObject<{
        interpolation: z.ZodOptional<z.ZodEnum<{
            linear: "linear";
            smooth: "smooth";
            stepped: "stepped";
        }>>;
        fitting: z.ZodOptional<z.ZodObject<{
            kind: z.ZodEnum<{
                linear: "linear";
                none: "none";
                zero: "zero";
                carry: "carry";
                lookahead: "lookahead";
                average: "average";
                nearest: "nearest";
            }>;
            emphasize: z.ZodOptional<z.ZodBoolean>;
            extend: z.ZodOptional<z.ZodEnum<{
                none: "none";
                zero: "zero";
                nearest: "nearest";
            }>>;
        }, z.core.$strict>>;
        points: z.ZodOptional<z.ZodEnum<{
            auto: "auto";
            hidden: "hidden";
            visible: "visible";
        }>>;
        areaOpacity: z.ZodOptional<z.ZodNumber>;
        areaFill: z.ZodOptional<z.ZodEnum<{
            solid: "solid";
            gradient: "gradient";
        }>>;
        barMinimumHeight: z.ZodOptional<z.ZodNumber>;
        barValueLabels: z.ZodOptional<z.ZodBoolean>;
        partialBuckets: z.ZodOptional<z.ZodObject<{
            from: z.ZodUnion<readonly [z.ZodNumber, z.ZodISODateTime]>;
            to: z.ZodUnion<readonly [z.ZodNumber, z.ZodISODateTime]>;
        }, z.core.$strict>>;
        currentTime: z.ZodOptional<z.ZodUnion<readonly [z.ZodNumber, z.ZodISODateTime]>>;
    }, z.core.$strict>>;
    title: z.ZodOptional<z.ZodString>;
    description: z.ZodOptional<z.ZodString>;
    data: z.ZodObject<{
        columns: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            label: z.ZodString;
            type: z.ZodEnum<{
                string: "string";
                number: "number";
                boolean: "boolean";
                date: "date";
            }>;
            role: z.ZodEnum<{
                dimension: "dimension";
                metric: "metric";
            }>;
            format: z.ZodOptional<z.ZodDiscriminatedUnion<[z.ZodObject<{
                pattern: z.ZodString;
                locale: z.ZodOptional<z.ZodString>;
                alwaysShowSign: z.ZodOptional<z.ZodBoolean>;
                suffix: z.ZodOptional<z.ZodString>;
                kind: z.ZodLiteral<"number">;
            }, z.core.$strict>, z.ZodObject<{
                pattern: z.ZodString;
                locale: z.ZodOptional<z.ZodString>;
                alwaysShowSign: z.ZodOptional<z.ZodBoolean>;
                suffix: z.ZodOptional<z.ZodString>;
                kind: z.ZodLiteral<"percent">;
            }, z.core.$strict>, z.ZodObject<{
                pattern: z.ZodString;
                locale: z.ZodOptional<z.ZodString>;
                alwaysShowSign: z.ZodOptional<z.ZodBoolean>;
                suffix: z.ZodOptional<z.ZodString>;
                kind: z.ZodLiteral<"bytes">;
            }, z.core.$strict>, z.ZodObject<{
                pattern: z.ZodString;
                locale: z.ZodOptional<z.ZodString>;
                alwaysShowSign: z.ZodOptional<z.ZodBoolean>;
                suffix: z.ZodOptional<z.ZodString>;
                kind: z.ZodLiteral<"bits">;
            }, z.core.$strict>, z.ZodObject<{
                kind: z.ZodLiteral<"duration">;
                input: z.ZodEnum<{
                    picoseconds: "picoseconds";
                    nanoseconds: "nanoseconds";
                    microseconds: "microseconds";
                    milliseconds: "milliseconds";
                    seconds: "seconds";
                    minutes: "minutes";
                    hours: "hours";
                    days: "days";
                    weeks: "weeks";
                    months: "months";
                    years: "years";
                }>;
                output: z.ZodUnion<readonly [z.ZodEnum<{
                    milliseconds: "milliseconds";
                    seconds: "seconds";
                    minutes: "minutes";
                    hours: "hours";
                    days: "days";
                    weeks: "weeks";
                    months: "months";
                    years: "years";
                }>, z.ZodLiteral<"humanize">, z.ZodLiteral<"humanizePrecise">]>;
                decimals: z.ZodOptional<z.ZodInt>;
                showSuffix: z.ZodOptional<z.ZodBoolean>;
                useShortSuffix: z.ZodOptional<z.ZodBoolean>;
                includeSpaceWithSuffix: z.ZodOptional<z.ZodBoolean>;
                suffix: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>, z.ZodObject<{
                kind: z.ZodLiteral<"date">;
                pattern: z.ZodString;
                timeZone: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                kind: z.ZodLiteral<"text">;
            }, z.core.$strict>], "kind">>;
            multivalue: z.ZodOptional<z.ZodLiteral<true>>;
            source: z.ZodOptional<z.ZodUnknown>;
        }, z.core.$strict>>;
        rows: z.ZodArray<z.ZodArray<z.ZodUnion<readonly [z.ZodUnion<readonly [z.ZodNumber, z.ZodString, z.ZodBoolean, z.ZodNull]>, z.ZodArray<z.ZodUnion<readonly [z.ZodNumber, z.ZodString, z.ZodBoolean, z.ZodNull]>>]>>>;
        source: z.ZodOptional<z.ZodUnknown>;
        display: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodArray<z.ZodString>>>;
    }, z.core.$strict>;
    colors: z.ZodOptional<z.ZodObject<{
        byKey: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodObject<{
            light: z.ZodString;
            dark: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            token: z.ZodEnum<{
                text: "text";
                textSubdued: "textSubdued";
                axis: "axis";
                gridLine: "gridLine";
                background: "background";
                border: "border";
            }>;
        }, z.core.$strict>, z.ZodObject<{
            palette: z.ZodLiteral<"categorical">;
            index: z.ZodInt;
        }, z.core.$strict>]>>>;
        bands: z.ZodOptional<z.ZodArray<z.ZodObject<{
            from: z.ZodOptional<z.ZodNumber>;
            to: z.ZodOptional<z.ZodNumber>;
            color: z.ZodUnion<readonly [z.ZodObject<{
                light: z.ZodString;
                dark: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                token: z.ZodEnum<{
                    text: "text";
                    textSubdued: "textSubdued";
                    axis: "axis";
                    gridLine: "gridLine";
                    background: "background";
                    border: "border";
                }>;
            }, z.core.$strict>, z.ZodObject<{
                palette: z.ZodLiteral<"categorical">;
                index: z.ZodInt;
            }, z.core.$strict>]>;
        }, z.core.$strict>>>;
    }, z.core.$strict>>;
    source: z.ZodOptional<z.ZodObject<{
        kind: z.ZodLiteral<"kibana">;
        kibanaVersion: z.ZodString;
        materializer: z.ZodString;
        materializerVersion: z.ZodInt;
        spaceId: z.ZodOptional<z.ZodString>;
        savedObjectType: z.ZodOptional<z.ZodString>;
        savedObjectId: z.ZodOptional<z.ZodString>;
        panelId: z.ZodOptional<z.ZodString>;
        timeRange: z.ZodOptional<z.ZodObject<{
            from: z.ZodISODateTime;
            to: z.ZodISODateTime;
        }, z.core.$strict>>;
        capturedAt: z.ZodISODateTime;
    }, z.core.$strict>>;
    losses: z.ZodOptional<z.ZodArray<z.ZodObject<{
        path: z.ZodString;
        kind: z.ZodEnum<{
            dropped: "dropped";
            approximated: "approximated";
            prerendered: "prerendered";
        }>;
        note: z.ZodString;
    }, z.core.$strict>>>;
    type: z.ZodLiteral<"xyChart">;
}, z.core.$strip>;
export type XyChartNode = z.infer<typeof xyChartSchema> & PrimitiveNode;
