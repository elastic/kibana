import type { DurationUnit } from '../schema/core';
export type DurationOutput = 'humanize' | 'humanizePrecise' | Exclude<DurationUnit, 'picoseconds' | 'nanoseconds' | 'microseconds'>;
export interface DurationFormatOptions {
    input: DurationUnit;
    output: DurationOutput;
    /** Decimals for a unit output and `humanizePrecise`. Absent means 2. */
    decimals?: number | undefined;
    showSuffix?: boolean | undefined;
    useShortSuffix?: boolean | undefined;
    /** Absent means true. */
    includeSpaceWithSuffix?: boolean | undefined;
}
/**
 * Formats a number as Kibana's duration field format does, in English.
 * `value` is in `options.input` units.
 */
export declare const formatDuration: (value: number, { input, output, decimals, showSuffix, useShortSuffix, includeSpaceWithSuffix, }: DurationFormatOptions) => string;
