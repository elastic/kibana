/** The wall-clock reading of one instant in one time zone. */
export interface WallClock {
    readonly year: number;
    /** 1–12. */
    readonly month: number;
    readonly day: number;
    readonly hour: number;
    readonly minute: number;
    readonly second: number;
    readonly millisecond: number;
    /** 0 (Sunday) – 6. */
    readonly weekday: number;
    /** Minutes east of UTC. */
    readonly offset: number;
}
/**
 * The wall-clock fields of `epoch` (milliseconds) in `timeZone`: an IANA name
 * such as `Europe/Paris`, `UTC`, or a fixed offset such as `+05:30`. Throws a
 * `RangeError` for a zone the environment cannot resolve.
 */
export declare const wallClock: (epoch: number, timeZone: string) => WallClock;
/**
 * A short name for the zone at `epoch`, for Moment's `z` token. Moment Timezone
 * prints an abbreviation such as `CET`; this prints `UTC` for UTC and the
 * offset, such as `+01:00`, for every other zone, since zone names are not
 * available on every JavaScript engine.
 */
export declare const zoneAbbreviation: (epoch: number, timeZone: string) => string;
