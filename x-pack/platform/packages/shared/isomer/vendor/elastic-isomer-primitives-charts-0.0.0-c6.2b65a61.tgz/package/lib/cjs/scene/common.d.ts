import type { Cell, ChartColumn, ChartData, PortableFormat } from '../schema/core';
import type { Emphasis, SelectTarget } from '../schema/events';
import type { ColorScheme, SceneChrome, SceneInteractions, SceneSize, SceneTable } from './types';
export interface ResolveChartOptions {
    scheme: ColorScheme;
    /** The size ticks and layout are chosen for. */
    size?: SceneSize | undefined;
    /** Absent means `en`. */
    locale?: string | undefined;
    /** IANA time zone for dates whose format names none. Absent means `UTC`. */
    timeZone?: string | undefined;
}
/** What every resolver step reads: the options, resolved, and the node's data. */
export interface Resolution {
    readonly scheme: ColorScheme;
    readonly size?: SceneSize;
    readonly locale: string;
    readonly timeZone: string;
    readonly chrome: SceneChrome;
    readonly data: ChartData;
    column(id: string): ChartColumn;
    index(id: string): number;
    cell(id: string, row: number): Cell;
    /** The column's format, or Kibana's default for its type. */
    format(id: string): PortableFormat;
    /** A cell as displayed: its `display` string, or its value formatted. */
    text(id: string, row: number): string;
    /** A value formatted as the column formats its cells. */
    valueText(id: string, value: Cell | undefined): string;
}
export declare const createResolution: (data: ChartData, { scheme, size, locale, timeZone }: ResolveChartOptions) => Resolution;
export declare const buildTable: (resolution: Resolution) => SceneTable;
interface InteractionsInput {
    interactions?: {
        select?: readonly SelectTarget[] | undefined;
        brush?: {
            column: string;
        } | undefined;
        sync?: {
            cursor?: boolean | undefined;
            tooltips?: boolean | undefined;
        } | undefined;
        link?: {
            href: string;
            label: string;
        } | undefined;
    } | undefined;
    emphasis?: Emphasis | undefined;
}
export declare const resolveInteractions: ({ interactions, emphasis, }: InteractionsInput) => SceneInteractions;
/** `label: value` pairs joined as a selection's description reads. */
export declare const describe: (parts: readonly (readonly [string, string])[]) => string;
export declare const toNumber: (cell: Cell | undefined) => number | undefined;
export declare const sceneBase: (resolution: Resolution, node: {
    title?: string | undefined;
    description?: string | undefined;
}) => {
    chrome: SceneChrome;
    table: SceneTable;
    description?: string;
    title?: string;
    locale: string;
    timeZone: string;
    size?: SceneSize;
    scheme: ColorScheme;
};
/** "Title: sentence", or the sentence alone without a title. */
export declare const titled: (title: string | undefined, sentence: string) => string;
export {};
