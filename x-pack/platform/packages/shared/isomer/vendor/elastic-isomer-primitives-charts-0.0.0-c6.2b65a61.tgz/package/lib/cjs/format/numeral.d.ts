export interface NumeralOptions {
    pattern: string;
    /** A Numeral.js locale id. Absent, or one Numeral.js does not know, means `en`. */
    locale?: string | undefined;
    alwaysShowSign?: boolean | undefined;
}
/**
 * Formats a finite number with a Numeral.js pattern, as Kibana's numeral
 * formats do: in the given locale, with `alwaysShowSign` adding `+` only when
 * the value does not round to zero under the pattern.
 */
export declare const formatNumeral: (value: number, { pattern, locale, alwaysShowSign }: NumeralOptions) => string;
