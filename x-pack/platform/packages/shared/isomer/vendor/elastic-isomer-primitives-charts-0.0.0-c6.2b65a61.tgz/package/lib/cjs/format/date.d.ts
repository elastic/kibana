/** Moment's English ordinal suffix. */
export declare const ordinal: (value: number) => string;
/**
 * Formats an instant with a Moment.js pattern in an IANA time zone, as Kibana's
 * date field format does, in English. `epoch` is milliseconds since the epoch.
 */
export declare const formatDate: (epoch: number, pattern: string, timeZone: string) => string;
/**
 * A date cell as epoch milliseconds: a number as it is, or an ISO 8601 string
 * parsed. `undefined` when it is neither.
 */
export declare const toEpoch: (value: unknown) => number | undefined;
