import type { Cell, ColumnType, PortableFormat } from '../schema/core';
/** Kibana's text for a missing value in charts and text output. */
export declare const NULL_LABEL = "(null)";
/** Kibana's text for an empty string. */
export declare const EMPTY_LABEL = "(blank)";
/** Kibana's text for a number that is not one. */
export declare const NAN_LABEL = "NaN";
/** Kibana's default patterns, from its `format:*:defaultPattern` and `dateFormat` settings. */
export declare const DEFAULT_PATTERNS: {
    readonly number: "0,0.[000]";
    readonly percent: "0,0.[000]%";
    readonly bytes: "0,0.[0]b";
    readonly date: "MMM D, YYYY @ HH:mm:ss.SSS";
};
/**
 * Formats one cell as Kibana's field format does for text: missing and empty
 * values get Kibana's labels, and a multivalue cell becomes a JSON array of
 * its formatted values. A `suffix` is appended to the whole result.
 */
export declare const formatValue: (value: Cell | undefined, format: PortableFormat) => string;
/** The format a column of `type` gets when it declares none, as Kibana's defaults. */
export declare const defaultFormatFor: (type: ColumnType, timeZone: string) => PortableFormat;
