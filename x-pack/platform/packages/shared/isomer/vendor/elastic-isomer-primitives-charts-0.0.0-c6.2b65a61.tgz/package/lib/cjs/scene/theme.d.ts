import type { ColorValue } from '../schema/core';
import type { ColorScheme, SceneChrome, SceneColor } from './types';
/** Chrome per scheme: EUI Borealis `textParagraph`, `textSubdued`, `borderBasePlain`, `borderBaseSubdued` and `backgroundBasePlain`. */
export declare const CHART_CHROME: Readonly<Record<ColorScheme, SceneChrome>>;
/** The default categorical palette, EUI Borealis `euiColorVis0`–`euiColorVis9`, the same in both schemes. */
export declare const CATEGORICAL_PALETTE: readonly SceneColor[];
/** A palette entry by index, wrapping past the end. */
export declare const categoricalColor: (index: number) => SceneColor;
/** A node color, concrete for `scheme`. */
export declare const resolveColor: (color: ColorValue, scheme: ColorScheme) => SceneColor;
/** WCAG relative luminance of a `#rgb`, `#rrggbb` or `#rrggbbaa` color. */
export declare const luminance: (hex: string) => number;
/** Text on `background`: whichever of the two schemes' text colors contrasts more. */
export declare const textOn: (background: SceneColor) => SceneColor;
