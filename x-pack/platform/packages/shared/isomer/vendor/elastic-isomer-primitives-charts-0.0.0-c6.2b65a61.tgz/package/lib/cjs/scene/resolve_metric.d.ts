import type { ColorBand } from '../schema/core';
import type { MetricNode } from '../schema/metric';
import { type ResolveChartOptions } from './common';
import type { MetricScene } from './types';
/** The band `value` falls in: `from` inclusive, `to` exclusive, the last band's `to` inclusive. */
export declare const bandFor: (bands: readonly ColorBand[], value: number) => ColorBand | undefined;
export declare const resolveMetric: (node: MetricNode, options: ResolveChartOptions) => MetricScene;
