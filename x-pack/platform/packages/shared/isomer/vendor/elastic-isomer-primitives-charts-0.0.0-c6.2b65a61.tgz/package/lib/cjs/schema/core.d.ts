import { z } from '@elastic/isomer-sdk';
/** One value in a non-multivalue cell. `null` is a missing value, never zero. */
export declare const scalarCellSchema: z.ZodUnion<readonly [z.ZodNumber, z.ZodString, z.ZodBoolean, z.ZodNull]>;
export type ScalarCell = z.infer<typeof scalarCellSchema>;
export declare const cellSchema: z.ZodUnion<readonly [z.ZodUnion<readonly [z.ZodNumber, z.ZodString, z.ZodBoolean, z.ZodNull]>, z.ZodArray<z.ZodUnion<readonly [z.ZodNumber, z.ZodString, z.ZodBoolean, z.ZodNull]>>]>;
/** A cell: one value, or an array of values in a `multivalue` column. */
export type Cell = z.infer<typeof cellSchema>;
export declare const COLUMN_TYPES: readonly ["number", "string", "date", "boolean"];
export type ColumnType = (typeof COLUMN_TYPES)[number];
export declare const COLUMN_ROLES: readonly ["dimension", "metric"];
/**
 * `dimension` columns identify a row (buckets, categories, time); `metric`
 * columns measure it. Dimensions lead text summaries and are what a selection
 * targets.
 */
export type ColumnRole = (typeof COLUMN_ROLES)[number];
export declare const hexColorSchema: z.ZodString;
export declare const CHROME_TOKENS: readonly ["text", "textSubdued", "axis", "gridLine", "background", "border"];
export type ChromeToken = (typeof CHROME_TOKENS)[number];
export declare const colorValueSchema: z.ZodUnion<readonly [z.ZodObject<{
    light: z.ZodString;
    dark: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    token: z.ZodEnum<{
        text: "text";
        textSubdued: "textSubdued";
        axis: "axis";
        gridLine: "gridLine";
        background: "background";
        border: "border";
    }>;
}, z.core.$strict>, z.ZodObject<{
    palette: z.ZodLiteral<"categorical">;
    index: z.ZodInt;
}, z.core.$strict>]>;
export type ColorValue = z.infer<typeof colorValueSchema>;
export declare const DURATION_UNITS: readonly ["picoseconds", "nanoseconds", "microseconds", "milliseconds", "seconds", "minutes", "hours", "days", "weeks", "months", "years"];
export type DurationUnit = (typeof DURATION_UNITS)[number];
export declare const DURATION_OUTPUT_UNITS: readonly ["milliseconds", "seconds", "minutes", "hours", "days", "weeks", "months", "years"];
export declare const portableFormatSchema: z.ZodDiscriminatedUnion<[z.ZodObject<{
    pattern: z.ZodString;
    locale: z.ZodOptional<z.ZodString>;
    alwaysShowSign: z.ZodOptional<z.ZodBoolean>;
    suffix: z.ZodOptional<z.ZodString>;
    kind: z.ZodLiteral<"number">;
}, z.core.$strict>, z.ZodObject<{
    fractional: z.ZodOptional<z.ZodBoolean>;
    pattern: z.ZodString;
    locale: z.ZodOptional<z.ZodString>;
    alwaysShowSign: z.ZodOptional<z.ZodBoolean>;
    suffix: z.ZodOptional<z.ZodString>;
    kind: z.ZodLiteral<"percent">;
}, z.core.$strict>, z.ZodObject<{
    pattern: z.ZodString;
    locale: z.ZodOptional<z.ZodString>;
    alwaysShowSign: z.ZodOptional<z.ZodBoolean>;
    suffix: z.ZodOptional<z.ZodString>;
    kind: z.ZodLiteral<"bytes">;
}, z.core.$strict>, z.ZodObject<{
    pattern: z.ZodString;
    locale: z.ZodOptional<z.ZodString>;
    alwaysShowSign: z.ZodOptional<z.ZodBoolean>;
    suffix: z.ZodOptional<z.ZodString>;
    kind: z.ZodLiteral<"bits">;
}, z.core.$strict>, z.ZodObject<{
    kind: z.ZodLiteral<"duration">;
    input: z.ZodEnum<{
        picoseconds: "picoseconds";
        nanoseconds: "nanoseconds";
        microseconds: "microseconds";
        milliseconds: "milliseconds";
        seconds: "seconds";
        minutes: "minutes";
        hours: "hours";
        days: "days";
        weeks: "weeks";
        months: "months";
        years: "years";
    }>;
    output: z.ZodUnion<readonly [z.ZodEnum<{
        milliseconds: "milliseconds";
        seconds: "seconds";
        minutes: "minutes";
        hours: "hours";
        days: "days";
        weeks: "weeks";
        months: "months";
        years: "years";
    }>, z.ZodLiteral<"humanize">, z.ZodLiteral<"humanizePrecise">]>;
    decimals: z.ZodOptional<z.ZodInt>;
    showSuffix: z.ZodOptional<z.ZodBoolean>;
    useShortSuffix: z.ZodOptional<z.ZodBoolean>;
    includeSpaceWithSuffix: z.ZodOptional<z.ZodBoolean>;
    suffix: z.ZodOptional<z.ZodString>;
}, z.core.$strict>, z.ZodObject<{
    kind: z.ZodLiteral<"date">;
    pattern: z.ZodString;
    timeZone: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    kind: z.ZodLiteral<"text">;
}, z.core.$strict>], "kind">;
export type PortableFormat = z.infer<typeof portableFormatSchema>;
export declare const columnSchema: z.ZodObject<{
    id: z.ZodString;
    label: z.ZodString;
    type: z.ZodEnum<{
        string: "string";
        number: "number";
        boolean: "boolean";
        date: "date";
    }>;
    role: z.ZodEnum<{
        dimension: "dimension";
        metric: "metric";
    }>;
    format: z.ZodOptional<z.ZodDiscriminatedUnion<[z.ZodObject<{
        pattern: z.ZodString;
        locale: z.ZodOptional<z.ZodString>;
        alwaysShowSign: z.ZodOptional<z.ZodBoolean>;
        suffix: z.ZodOptional<z.ZodString>;
        kind: z.ZodLiteral<"number">;
    }, z.core.$strict>, z.ZodObject<{
        fractional: z.ZodOptional<z.ZodBoolean>;
        pattern: z.ZodString;
        locale: z.ZodOptional<z.ZodString>;
        alwaysShowSign: z.ZodOptional<z.ZodBoolean>;
        suffix: z.ZodOptional<z.ZodString>;
        kind: z.ZodLiteral<"percent">;
    }, z.core.$strict>, z.ZodObject<{
        pattern: z.ZodString;
        locale: z.ZodOptional<z.ZodString>;
        alwaysShowSign: z.ZodOptional<z.ZodBoolean>;
        suffix: z.ZodOptional<z.ZodString>;
        kind: z.ZodLiteral<"bytes">;
    }, z.core.$strict>, z.ZodObject<{
        pattern: z.ZodString;
        locale: z.ZodOptional<z.ZodString>;
        alwaysShowSign: z.ZodOptional<z.ZodBoolean>;
        suffix: z.ZodOptional<z.ZodString>;
        kind: z.ZodLiteral<"bits">;
    }, z.core.$strict>, z.ZodObject<{
        kind: z.ZodLiteral<"duration">;
        input: z.ZodEnum<{
            picoseconds: "picoseconds";
            nanoseconds: "nanoseconds";
            microseconds: "microseconds";
            milliseconds: "milliseconds";
            seconds: "seconds";
            minutes: "minutes";
            hours: "hours";
            days: "days";
            weeks: "weeks";
            months: "months";
            years: "years";
        }>;
        output: z.ZodUnion<readonly [z.ZodEnum<{
            milliseconds: "milliseconds";
            seconds: "seconds";
            minutes: "minutes";
            hours: "hours";
            days: "days";
            weeks: "weeks";
            months: "months";
            years: "years";
        }>, z.ZodLiteral<"humanize">, z.ZodLiteral<"humanizePrecise">]>;
        decimals: z.ZodOptional<z.ZodInt>;
        showSuffix: z.ZodOptional<z.ZodBoolean>;
        useShortSuffix: z.ZodOptional<z.ZodBoolean>;
        includeSpaceWithSuffix: z.ZodOptional<z.ZodBoolean>;
        suffix: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>, z.ZodObject<{
        kind: z.ZodLiteral<"date">;
        pattern: z.ZodString;
        timeZone: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        kind: z.ZodLiteral<"text">;
    }, z.core.$strict>], "kind">>;
    multivalue: z.ZodOptional<z.ZodLiteral<true>>;
    source: z.ZodOptional<z.ZodUnknown>;
}, z.core.$strict>;
export type ChartColumn = z.infer<typeof columnSchema>;
export declare const DATA_RULES: {
    readonly uniqueIds: "Column ids are unique.";
    readonly rowWidth: "Every row has exactly one cell per column, in column order.";
    readonly cellType: "A cell holds its column type or null: a number in a `number` column, a string in a `string` column, a boolean in a `boolean` column, and epoch milliseconds or an ISO 8601 date-time string in a `date` column. Only a `multivalue` column holds arrays of those.";
    readonly display: "Each `display` key names a column and holds one string per row.";
};
/** Whether `cell` is legal in `column`, per {@link DATA_RULES}`.cellType`. */
export declare const cellMatchesColumn: (column: Pick<ChartColumn, "type" | "multivalue">, cell: Cell) => boolean;
export declare const chartDataSchema: z.ZodObject<{
    columns: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        label: z.ZodString;
        type: z.ZodEnum<{
            string: "string";
            number: "number";
            boolean: "boolean";
            date: "date";
        }>;
        role: z.ZodEnum<{
            dimension: "dimension";
            metric: "metric";
        }>;
        format: z.ZodOptional<z.ZodDiscriminatedUnion<[z.ZodObject<{
            pattern: z.ZodString;
            locale: z.ZodOptional<z.ZodString>;
            alwaysShowSign: z.ZodOptional<z.ZodBoolean>;
            suffix: z.ZodOptional<z.ZodString>;
            kind: z.ZodLiteral<"number">;
        }, z.core.$strict>, z.ZodObject<{
            fractional: z.ZodOptional<z.ZodBoolean>;
            pattern: z.ZodString;
            locale: z.ZodOptional<z.ZodString>;
            alwaysShowSign: z.ZodOptional<z.ZodBoolean>;
            suffix: z.ZodOptional<z.ZodString>;
            kind: z.ZodLiteral<"percent">;
        }, z.core.$strict>, z.ZodObject<{
            pattern: z.ZodString;
            locale: z.ZodOptional<z.ZodString>;
            alwaysShowSign: z.ZodOptional<z.ZodBoolean>;
            suffix: z.ZodOptional<z.ZodString>;
            kind: z.ZodLiteral<"bytes">;
        }, z.core.$strict>, z.ZodObject<{
            pattern: z.ZodString;
            locale: z.ZodOptional<z.ZodString>;
            alwaysShowSign: z.ZodOptional<z.ZodBoolean>;
            suffix: z.ZodOptional<z.ZodString>;
            kind: z.ZodLiteral<"bits">;
        }, z.core.$strict>, z.ZodObject<{
            kind: z.ZodLiteral<"duration">;
            input: z.ZodEnum<{
                picoseconds: "picoseconds";
                nanoseconds: "nanoseconds";
                microseconds: "microseconds";
                milliseconds: "milliseconds";
                seconds: "seconds";
                minutes: "minutes";
                hours: "hours";
                days: "days";
                weeks: "weeks";
                months: "months";
                years: "years";
            }>;
            output: z.ZodUnion<readonly [z.ZodEnum<{
                milliseconds: "milliseconds";
                seconds: "seconds";
                minutes: "minutes";
                hours: "hours";
                days: "days";
                weeks: "weeks";
                months: "months";
                years: "years";
            }>, z.ZodLiteral<"humanize">, z.ZodLiteral<"humanizePrecise">]>;
            decimals: z.ZodOptional<z.ZodInt>;
            showSuffix: z.ZodOptional<z.ZodBoolean>;
            useShortSuffix: z.ZodOptional<z.ZodBoolean>;
            includeSpaceWithSuffix: z.ZodOptional<z.ZodBoolean>;
            suffix: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>, z.ZodObject<{
            kind: z.ZodLiteral<"date">;
            pattern: z.ZodString;
            timeZone: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            kind: z.ZodLiteral<"text">;
        }, z.core.$strict>], "kind">>;
        multivalue: z.ZodOptional<z.ZodLiteral<true>>;
        source: z.ZodOptional<z.ZodUnknown>;
    }, z.core.$strict>>;
    rows: z.ZodArray<z.ZodArray<z.ZodUnion<readonly [z.ZodUnion<readonly [z.ZodNumber, z.ZodString, z.ZodBoolean, z.ZodNull]>, z.ZodArray<z.ZodUnion<readonly [z.ZodNumber, z.ZodString, z.ZodBoolean, z.ZodNull]>>]>>>;
    source: z.ZodOptional<z.ZodUnknown>;
    display: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodArray<z.ZodString>>>;
}, z.core.$strict>;
export type ChartData = z.infer<typeof chartDataSchema>;
export declare const BAND_RULE = "Each band with both bounds has `from` below `to`, and bands ascend without overlapping.";
export declare const colorBandSchema: z.ZodObject<{
    from: z.ZodOptional<z.ZodNumber>;
    to: z.ZodOptional<z.ZodNumber>;
    color: z.ZodUnion<readonly [z.ZodObject<{
        light: z.ZodString;
        dark: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        token: z.ZodEnum<{
            text: "text";
            textSubdued: "textSubdued";
            axis: "axis";
            gridLine: "gridLine";
            background: "background";
            border: "border";
        }>;
    }, z.core.$strict>, z.ZodObject<{
        palette: z.ZodLiteral<"categorical">;
        index: z.ZodInt;
    }, z.core.$strict>]>;
}, z.core.$strict>;
export type ColorBand = z.infer<typeof colorBandSchema>;
export declare const chartColorsSchema: z.ZodObject<{
    byKey: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodObject<{
        light: z.ZodString;
        dark: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        token: z.ZodEnum<{
            text: "text";
            textSubdued: "textSubdued";
            axis: "axis";
            gridLine: "gridLine";
            background: "background";
            border: "border";
        }>;
    }, z.core.$strict>, z.ZodObject<{
        palette: z.ZodLiteral<"categorical">;
        index: z.ZodInt;
    }, z.core.$strict>]>>>;
    bands: z.ZodOptional<z.ZodArray<z.ZodObject<{
        from: z.ZodOptional<z.ZodNumber>;
        to: z.ZodOptional<z.ZodNumber>;
        color: z.ZodUnion<readonly [z.ZodObject<{
            light: z.ZodString;
            dark: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            token: z.ZodEnum<{
                text: "text";
                textSubdued: "textSubdued";
                axis: "axis";
                gridLine: "gridLine";
                background: "background";
                border: "border";
            }>;
        }, z.core.$strict>, z.ZodObject<{
            palette: z.ZodLiteral<"categorical">;
            index: z.ZodInt;
        }, z.core.$strict>]>;
    }, z.core.$strict>>>;
}, z.core.$strict>;
export type ChartColors = z.infer<typeof chartColorsSchema>;
export declare const provenanceSchema: z.ZodObject<{
    kind: z.ZodLiteral<"kibana">;
    kibanaVersion: z.ZodString;
    materializer: z.ZodString;
    materializerVersion: z.ZodInt;
    spaceId: z.ZodOptional<z.ZodString>;
    savedObjectType: z.ZodOptional<z.ZodString>;
    savedObjectId: z.ZodOptional<z.ZodString>;
    panelId: z.ZodOptional<z.ZodString>;
    timeRange: z.ZodOptional<z.ZodObject<{
        from: z.ZodISODateTime;
        to: z.ZodISODateTime;
    }, z.core.$strict>>;
    capturedAt: z.ZodISODateTime;
}, z.core.$strict>;
export type Provenance = z.infer<typeof provenanceSchema>;
export declare const LOSS_KINDS: readonly ["dropped", "approximated", "prerendered"];
export declare const lossSchema: z.ZodObject<{
    path: z.ZodString;
    kind: z.ZodEnum<{
        dropped: "dropped";
        approximated: "approximated";
        prerendered: "prerendered";
    }>;
    note: z.ZodString;
}, z.core.$strict>;
export type Loss = z.infer<typeof lossSchema>;
/** The fields every chart primitive shares. Spread into each chart's schema. */
export declare const chartCoreShape: {
    title: z.ZodOptional<z.ZodString>;
    description: z.ZodOptional<z.ZodString>;
    data: z.ZodObject<{
        columns: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            label: z.ZodString;
            type: z.ZodEnum<{
                string: "string";
                number: "number";
                boolean: "boolean";
                date: "date";
            }>;
            role: z.ZodEnum<{
                dimension: "dimension";
                metric: "metric";
            }>;
            format: z.ZodOptional<z.ZodDiscriminatedUnion<[z.ZodObject<{
                pattern: z.ZodString;
                locale: z.ZodOptional<z.ZodString>;
                alwaysShowSign: z.ZodOptional<z.ZodBoolean>;
                suffix: z.ZodOptional<z.ZodString>;
                kind: z.ZodLiteral<"number">;
            }, z.core.$strict>, z.ZodObject<{
                fractional: z.ZodOptional<z.ZodBoolean>;
                pattern: z.ZodString;
                locale: z.ZodOptional<z.ZodString>;
                alwaysShowSign: z.ZodOptional<z.ZodBoolean>;
                suffix: z.ZodOptional<z.ZodString>;
                kind: z.ZodLiteral<"percent">;
            }, z.core.$strict>, z.ZodObject<{
                pattern: z.ZodString;
                locale: z.ZodOptional<z.ZodString>;
                alwaysShowSign: z.ZodOptional<z.ZodBoolean>;
                suffix: z.ZodOptional<z.ZodString>;
                kind: z.ZodLiteral<"bytes">;
            }, z.core.$strict>, z.ZodObject<{
                pattern: z.ZodString;
                locale: z.ZodOptional<z.ZodString>;
                alwaysShowSign: z.ZodOptional<z.ZodBoolean>;
                suffix: z.ZodOptional<z.ZodString>;
                kind: z.ZodLiteral<"bits">;
            }, z.core.$strict>, z.ZodObject<{
                kind: z.ZodLiteral<"duration">;
                input: z.ZodEnum<{
                    picoseconds: "picoseconds";
                    nanoseconds: "nanoseconds";
                    microseconds: "microseconds";
                    milliseconds: "milliseconds";
                    seconds: "seconds";
                    minutes: "minutes";
                    hours: "hours";
                    days: "days";
                    weeks: "weeks";
                    months: "months";
                    years: "years";
                }>;
                output: z.ZodUnion<readonly [z.ZodEnum<{
                    milliseconds: "milliseconds";
                    seconds: "seconds";
                    minutes: "minutes";
                    hours: "hours";
                    days: "days";
                    weeks: "weeks";
                    months: "months";
                    years: "years";
                }>, z.ZodLiteral<"humanize">, z.ZodLiteral<"humanizePrecise">]>;
                decimals: z.ZodOptional<z.ZodInt>;
                showSuffix: z.ZodOptional<z.ZodBoolean>;
                useShortSuffix: z.ZodOptional<z.ZodBoolean>;
                includeSpaceWithSuffix: z.ZodOptional<z.ZodBoolean>;
                suffix: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>, z.ZodObject<{
                kind: z.ZodLiteral<"date">;
                pattern: z.ZodString;
                timeZone: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                kind: z.ZodLiteral<"text">;
            }, z.core.$strict>], "kind">>;
            multivalue: z.ZodOptional<z.ZodLiteral<true>>;
            source: z.ZodOptional<z.ZodUnknown>;
        }, z.core.$strict>>;
        rows: z.ZodArray<z.ZodArray<z.ZodUnion<readonly [z.ZodUnion<readonly [z.ZodNumber, z.ZodString, z.ZodBoolean, z.ZodNull]>, z.ZodArray<z.ZodUnion<readonly [z.ZodNumber, z.ZodString, z.ZodBoolean, z.ZodNull]>>]>>>;
        source: z.ZodOptional<z.ZodUnknown>;
        display: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodArray<z.ZodString>>>;
    }, z.core.$strict>;
    colors: z.ZodOptional<z.ZodObject<{
        byKey: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodObject<{
            light: z.ZodString;
            dark: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            token: z.ZodEnum<{
                text: "text";
                textSubdued: "textSubdued";
                axis: "axis";
                gridLine: "gridLine";
                background: "background";
                border: "border";
            }>;
        }, z.core.$strict>, z.ZodObject<{
            palette: z.ZodLiteral<"categorical">;
            index: z.ZodInt;
        }, z.core.$strict>]>>>;
        bands: z.ZodOptional<z.ZodArray<z.ZodObject<{
            from: z.ZodOptional<z.ZodNumber>;
            to: z.ZodOptional<z.ZodNumber>;
            color: z.ZodUnion<readonly [z.ZodObject<{
                light: z.ZodString;
                dark: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                token: z.ZodEnum<{
                    text: "text";
                    textSubdued: "textSubdued";
                    axis: "axis";
                    gridLine: "gridLine";
                    background: "background";
                    border: "border";
                }>;
            }, z.core.$strict>, z.ZodObject<{
                palette: z.ZodLiteral<"categorical">;
                index: z.ZodInt;
            }, z.core.$strict>]>;
        }, z.core.$strict>>>;
    }, z.core.$strict>>;
    source: z.ZodOptional<z.ZodObject<{
        kind: z.ZodLiteral<"kibana">;
        kibanaVersion: z.ZodString;
        materializer: z.ZodString;
        materializerVersion: z.ZodInt;
        spaceId: z.ZodOptional<z.ZodString>;
        savedObjectType: z.ZodOptional<z.ZodString>;
        savedObjectId: z.ZodOptional<z.ZodString>;
        panelId: z.ZodOptional<z.ZodString>;
        timeRange: z.ZodOptional<z.ZodObject<{
            from: z.ZodISODateTime;
            to: z.ZodISODateTime;
        }, z.core.$strict>>;
        capturedAt: z.ZodISODateTime;
    }, z.core.$strict>>;
    losses: z.ZodOptional<z.ZodArray<z.ZodObject<{
        path: z.ZodString;
        kind: z.ZodEnum<{
            dropped: "dropped";
            approximated: "approximated";
            prerendered: "prerendered";
        }>;
        note: z.ZodString;
    }, z.core.$strict>>>;
};
export declare const COLUMN_REF_RULE = "Every column reference names a column in `data.columns`.";
/** A reference to a column by id, checked against `data.columns` by the chart that holds it. */
export declare const columnRefSchema: z.ZodString;
export interface ColumnReference {
    path: (string | number)[];
    id: string;
    /** Types the reference accepts. Absent means any. */
    types?: readonly ColumnType[];
}
/** Adds an issue for each reference that names no column, or a column of a type it does not accept. */
export declare const checkColumnReferences: (data: {
    columns: readonly ChartColumn[];
} | undefined, references: readonly ColumnReference[], context: z.core.$RefinementCtx<unknown>, typeRule: string) => void;
