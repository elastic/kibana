import type { MetricNode } from '../schema/metric';
import type { XyChartNode } from '../schema/xy_chart';
import type { ResolveChartOptions } from './common';
import type { MetricScene, Scene, XyScene } from './types';
/** A chart node the resolver draws. */
export type ChartNode = MetricNode | XyChartNode;
/**
 * Resolves a chart node to the Scene every renderer draws: colors for
 * `options.scheme`, every string formatted, ticks for `options.size`, and the
 * rows and columns each selectable part stands for. Pure and synchronous; the
 * result is plain JSON data.
 */
export declare function resolveChart(node: MetricNode, options: ResolveChartOptions): MetricScene;
export declare function resolveChart(node: XyChartNode, options: ResolveChartOptions): XyScene;
export declare function resolveChart(node: ChartNode, options: ResolveChartOptions): Scene;
