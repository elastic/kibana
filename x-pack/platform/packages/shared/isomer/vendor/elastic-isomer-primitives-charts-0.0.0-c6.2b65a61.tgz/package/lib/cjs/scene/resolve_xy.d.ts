import type { XyChartNode } from '../schema/xy_chart';
import { type ResolveChartOptions } from './common';
import type { XyScene } from './types';
export declare const resolveXy: (node: XyChartNode, options: ResolveChartOptions) => XyScene;
