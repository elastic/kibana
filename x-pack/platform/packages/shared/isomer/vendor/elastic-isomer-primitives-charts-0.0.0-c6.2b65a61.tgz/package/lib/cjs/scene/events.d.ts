import type { ChartBrushEvent, ChartSelectEvent } from '../schema/events';
import type { SceneSelection, XyScene } from './types';
/** The `select` event for a part of the Scene the reader selected. */
export declare const selectEvent: (node: string, { target, rows, columns, values, description }: SceneSelection, negate?: boolean) => ChartSelectEvent;
/**
 * The `brush` event for a range along the Scene's brush column, or `undefined`
 * when the node offers no brush. The description names each end by the x
 * position nearest it, as the x axis formats it.
 */
export declare const brushEvent: (scene: XyScene, node: string, range: readonly [number, number]) => ChartBrushEvent | undefined;
