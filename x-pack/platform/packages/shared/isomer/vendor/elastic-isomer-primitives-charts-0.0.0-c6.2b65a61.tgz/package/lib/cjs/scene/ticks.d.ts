/** d3's tick step for `count` ticks across `[start, stop]`. */
export declare const tickStep: (start: number, stop: number, count: number) => number;
/** `[min, max]` widened to multiples of the tick step, as d3's `nice`. */
export declare const niceDomain: (min: number, max: number, count: number) => [number, number];
/** Linear ticks inside `[min, max]`. */
export declare const linearTicks: (min: number, max: number, count: number) => number[];
/** Powers of ten inside `[min, max]`, for a log axis. */
export declare const logTicks: (min: number, max: number) => number[];
/**
 * Time ticks inside `[min, max]` at the smallest calendar-sized step that gives
 * at most `count`, on round wall-clock times in `timeZone`.
 */
export declare const timeTicks: (min: number, max: number, count: number, timeZone: string) => number[];
/** Tick count for an axis `length` pixels long, one tick per `spacing` pixels. */
export declare const tickCount: (length: number | undefined, spacing: number, fallback: number) => number;
