import { type PrimitiveNode, z } from '@elastic/isomer-sdk/schema';
/** The cross-field rules `xyChartSchema` states in its description, one sentence each. */
export declare const XY_RULES: {
    readonly yType: "A `y` column is a `number` column.";
    readonly sharedX: "Every data layer uses the same x column; absent means every row draws at one x position.";
    readonly xCoordinate: "On a continuous x scale, stated or inferred from the x column type, each non-missing x cell is a finite number for `linear`, or epoch milliseconds or an ISO 8601 date-time with a UTC offset for `temporal`.";
    readonly singleValued: "The `x`, `y` and `splitBy` columns are not `multivalue`.";
    readonly dateEncoding: "A `date` column holds one encoding: every non-missing value is epoch milliseconds, or every one is an ISO 8601 date-time.";
    readonly rows: "A layer's `rows` is a `[start, end)` range within `data.rows`, with `start` at most `end`.";
    readonly stack: "Only `bar` and `area` layers stack.";
    readonly dataLayer: "At least one layer is a `data` layer.";
    readonly rangeOrder: "An annotation range's `from` is not after its `to`.";
    readonly customDomain: "A `custom` axis domain has `min` below `max`, and on a `log` y axis `min` above zero.";
};
/** An x/y chart: line, area and bar layers over typed data, with reference lines and annotations. */
export declare const xyChartSchema: z.ZodObject<{
    interactions: z.ZodOptional<z.ZodObject<{
        select: z.ZodOptional<z.ZodArray<z.ZodEnum<{
            datum: "datum";
            series: "series";
            category: "category";
            legend: "legend";
        }>>>;
        brush: z.ZodOptional<z.ZodObject<{
            column: z.ZodString;
        }, z.core.$strict>>;
        sync: z.ZodOptional<z.ZodObject<{
            cursor: z.ZodOptional<z.ZodBoolean>;
            tooltips: z.ZodOptional<z.ZodBoolean>;
        }, z.core.$strict>>;
        link: z.ZodOptional<z.ZodObject<{
            href: z.ZodString;
            label: z.ZodString;
        }, z.core.$strict>>;
        initial: z.ZodOptional<z.ZodObject<{
            hiddenSeries: z.ZodOptional<z.ZodArray<z.ZodString>>;
        }, z.core.$strict>>;
    }, z.core.$strict>>;
    orientation: z.ZodOptional<z.ZodEnum<{
        horizontal: "horizontal";
        vertical: "vertical";
    }>>;
    layers: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
        kind: z.ZodLiteral<"data">;
        mark: z.ZodEnum<{
            line: "line";
            area: "area";
            bar: "bar";
        }>;
        stack: z.ZodOptional<z.ZodEnum<{
            stacked: "stacked";
            percentage: "percentage";
        }>>;
        x: z.ZodOptional<z.ZodString>;
        y: z.ZodArray<z.ZodObject<{
            column: z.ZodString;
            axis: z.ZodOptional<z.ZodEnum<{
                y: "y";
                y2: "y2";
            }>>;
            color: z.ZodOptional<z.ZodUnion<readonly [z.ZodObject<{
                light: z.ZodString;
                dark: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                token: z.ZodEnum<{
                    text: "text";
                    textSubdued: "textSubdued";
                    axis: "axis";
                    gridLine: "gridLine";
                    background: "background";
                    border: "border";
                }>;
            }, z.core.$strict>, z.ZodObject<{
                palette: z.ZodLiteral<"categorical">;
                index: z.ZodInt;
            }, z.core.$strict>]>>;
        }, z.core.$strict>>;
        splitBy: z.ZodOptional<z.ZodString>;
        rows: z.ZodOptional<z.ZodTuple<[z.ZodInt, z.ZodInt], null>>;
    }, z.core.$strict>, z.ZodObject<{
        kind: z.ZodLiteral<"referenceLines">;
        lines: z.ZodArray<z.ZodObject<{
            value: z.ZodNumber;
            axis: z.ZodOptional<z.ZodEnum<{
                y: "y";
                x: "x";
                y2: "y2";
            }>>;
            label: z.ZodOptional<z.ZodString>;
            format: z.ZodOptional<z.ZodDiscriminatedUnion<[z.ZodObject<{
                notation: z.ZodOptional<z.ZodEnum<{
                    standard: "standard";
                    compact: "compact";
                }>>;
                minimumFractionDigits: z.ZodOptional<z.ZodInt>;
                maximumFractionDigits: z.ZodOptional<z.ZodInt>;
                signDisplay: z.ZodOptional<z.ZodEnum<{
                    auto: "auto";
                    always: "always";
                    exceptZero: "exceptZero";
                    never: "never";
                }>>;
                useGrouping: z.ZodOptional<z.ZodBoolean>;
                suffix: z.ZodOptional<z.ZodString>;
                kind: z.ZodLiteral<"number">;
            }, z.core.$strict>, z.ZodObject<{
                fractional: z.ZodOptional<z.ZodBoolean>;
                minimumFractionDigits: z.ZodOptional<z.ZodInt>;
                maximumFractionDigits: z.ZodOptional<z.ZodInt>;
                signDisplay: z.ZodOptional<z.ZodEnum<{
                    auto: "auto";
                    always: "always";
                    exceptZero: "exceptZero";
                    never: "never";
                }>>;
                useGrouping: z.ZodOptional<z.ZodBoolean>;
                suffix: z.ZodOptional<z.ZodString>;
                kind: z.ZodLiteral<"percent">;
            }, z.core.$strict>, z.ZodObject<{
                base: z.ZodOptional<z.ZodUnion<readonly [z.ZodLiteral<1000>, z.ZodLiteral<1024>]>>;
                unitDisplay: z.ZodOptional<z.ZodEnum<{
                    long: "long";
                    short: "short";
                    narrow: "narrow";
                }>>;
                minimumFractionDigits: z.ZodOptional<z.ZodInt>;
                maximumFractionDigits: z.ZodOptional<z.ZodInt>;
                signDisplay: z.ZodOptional<z.ZodEnum<{
                    auto: "auto";
                    always: "always";
                    exceptZero: "exceptZero";
                    never: "never";
                }>>;
                useGrouping: z.ZodOptional<z.ZodBoolean>;
                suffix: z.ZodOptional<z.ZodString>;
                kind: z.ZodLiteral<"bytes">;
            }, z.core.$strict>, z.ZodObject<{
                base: z.ZodOptional<z.ZodUnion<readonly [z.ZodLiteral<1000>, z.ZodLiteral<1024>]>>;
                unitDisplay: z.ZodOptional<z.ZodEnum<{
                    long: "long";
                    short: "short";
                    narrow: "narrow";
                }>>;
                minimumFractionDigits: z.ZodOptional<z.ZodInt>;
                maximumFractionDigits: z.ZodOptional<z.ZodInt>;
                signDisplay: z.ZodOptional<z.ZodEnum<{
                    auto: "auto";
                    always: "always";
                    exceptZero: "exceptZero";
                    never: "never";
                }>>;
                useGrouping: z.ZodOptional<z.ZodBoolean>;
                suffix: z.ZodOptional<z.ZodString>;
                kind: z.ZodLiteral<"bits">;
            }, z.core.$strict>, z.ZodObject<{
                unitDisplay: z.ZodOptional<z.ZodEnum<{
                    long: "long";
                    short: "short";
                    narrow: "narrow";
                }>>;
                minimumFractionDigits: z.ZodOptional<z.ZodInt>;
                maximumFractionDigits: z.ZodOptional<z.ZodInt>;
                signDisplay: z.ZodOptional<z.ZodEnum<{
                    auto: "auto";
                    always: "always";
                    exceptZero: "exceptZero";
                    never: "never";
                }>>;
                useGrouping: z.ZodOptional<z.ZodBoolean>;
                suffix: z.ZodOptional<z.ZodString>;
                kind: z.ZodLiteral<"duration">;
                input: z.ZodEnum<{
                    picoseconds: "picoseconds";
                    nanoseconds: "nanoseconds";
                    microseconds: "microseconds";
                    milliseconds: "milliseconds";
                    seconds: "seconds";
                    minutes: "minutes";
                    hours: "hours";
                    days: "days";
                    weeks: "weeks";
                    months: "months";
                    years: "years";
                }>;
                output: z.ZodOptional<z.ZodUnion<readonly [z.ZodEnum<{
                    nanoseconds: "nanoseconds";
                    microseconds: "microseconds";
                    milliseconds: "milliseconds";
                    seconds: "seconds";
                    minutes: "minutes";
                    hours: "hours";
                    days: "days";
                    weeks: "weeks";
                    months: "months";
                    years: "years";
                }>, z.ZodLiteral<"auto">]>>;
            }, z.core.$strict>, z.ZodObject<{
                kind: z.ZodLiteral<"date">;
                timeZone: z.ZodOptional<z.ZodString>;
                dateStyle: z.ZodOptional<z.ZodEnum<{
                    long: "long";
                    short: "short";
                    full: "full";
                    medium: "medium";
                }>>;
                timeStyle: z.ZodOptional<z.ZodEnum<{
                    long: "long";
                    short: "short";
                    full: "full";
                    medium: "medium";
                }>>;
                weekday: z.ZodOptional<z.ZodEnum<{
                    long: "long";
                    short: "short";
                    narrow: "narrow";
                }>>;
                year: z.ZodOptional<z.ZodEnum<{
                    numeric: "numeric";
                    "2-digit": "2-digit";
                }>>;
                month: z.ZodOptional<z.ZodEnum<{
                    long: "long";
                    short: "short";
                    narrow: "narrow";
                    numeric: "numeric";
                    "2-digit": "2-digit";
                }>>;
                day: z.ZodOptional<z.ZodEnum<{
                    numeric: "numeric";
                    "2-digit": "2-digit";
                }>>;
                hour: z.ZodOptional<z.ZodEnum<{
                    numeric: "numeric";
                    "2-digit": "2-digit";
                }>>;
                minute: z.ZodOptional<z.ZodEnum<{
                    numeric: "numeric";
                    "2-digit": "2-digit";
                }>>;
                second: z.ZodOptional<z.ZodEnum<{
                    numeric: "numeric";
                    "2-digit": "2-digit";
                }>>;
                fractionalSecondDigits: z.ZodOptional<z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>, z.ZodLiteral<3>]>>;
                hour12: z.ZodOptional<z.ZodBoolean>;
                timeZoneName: z.ZodOptional<z.ZodEnum<{
                    long: "long";
                    short: "short";
                    shortOffset: "shortOffset";
                    longOffset: "longOffset";
                }>>;
            }, z.core.$strict>, z.ZodObject<{
                kind: z.ZodLiteral<"text">;
            }, z.core.$strict>], "kind">>;
            showText: z.ZodOptional<z.ZodBoolean>;
            color: z.ZodOptional<z.ZodUnion<readonly [z.ZodObject<{
                light: z.ZodString;
                dark: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                token: z.ZodEnum<{
                    text: "text";
                    textSubdued: "textSubdued";
                    axis: "axis";
                    gridLine: "gridLine";
                    background: "background";
                    border: "border";
                }>;
            }, z.core.$strict>, z.ZodObject<{
                palette: z.ZodLiteral<"categorical">;
                index: z.ZodInt;
            }, z.core.$strict>]>>;
            fill: z.ZodOptional<z.ZodEnum<{
                above: "above";
                below: "below";
            }>>;
            icon: z.ZodOptional<z.ZodEnum<{
                alert: "alert";
                asterisk: "asterisk";
                bell: "bell";
                bolt: "bolt";
                bug: "bug";
                circle: "circle";
                comment: "comment";
                external: "external";
                flag: "flag";
                globe: "globe";
                heart: "heart";
                marker: "marker";
                pin: "pin";
                pinFilled: "pinFilled";
                processor: "processor";
                sortDown: "sortDown";
                sortUp: "sortUp";
                star: "star";
                starFilled: "starFilled";
                tag: "tag";
                temperature: "temperature";
                triangle: "triangle";
            }>>;
            strokeWidth: z.ZodOptional<z.ZodNumber>;
            strokeDash: z.ZodOptional<z.ZodEnum<{
                solid: "solid";
                dashed: "dashed";
                dotted: "dotted";
            }>>;
            textPosition: z.ZodOptional<z.ZodEnum<{
                auto: "auto";
                left: "left";
                right: "right";
            }>>;
        }, z.core.$strict>>;
    }, z.core.$strict>, z.ZodObject<{
        kind: z.ZodLiteral<"annotations">;
        events: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
            kind: z.ZodLiteral<"point">;
            at: z.ZodUnion<readonly [z.ZodNumber, z.ZodISODateTime]>;
            label: z.ZodOptional<z.ZodString>;
            text: z.ZodOptional<z.ZodString>;
            color: z.ZodOptional<z.ZodUnion<readonly [z.ZodObject<{
                light: z.ZodString;
                dark: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                token: z.ZodEnum<{
                    text: "text";
                    textSubdued: "textSubdued";
                    axis: "axis";
                    gridLine: "gridLine";
                    background: "background";
                    border: "border";
                }>;
            }, z.core.$strict>, z.ZodObject<{
                palette: z.ZodLiteral<"categorical">;
                index: z.ZodInt;
            }, z.core.$strict>]>>;
            icon: z.ZodOptional<z.ZodEnum<{
                alert: "alert";
                asterisk: "asterisk";
                bell: "bell";
                bolt: "bolt";
                bug: "bug";
                circle: "circle";
                comment: "comment";
                external: "external";
                flag: "flag";
                globe: "globe";
                heart: "heart";
                marker: "marker";
                pin: "pin";
                pinFilled: "pinFilled";
                processor: "processor";
                sortDown: "sortDown";
                sortUp: "sortUp";
                star: "star";
                starFilled: "starFilled";
                tag: "tag";
                temperature: "temperature";
                triangle: "triangle";
            }>>;
            line: z.ZodOptional<z.ZodObject<{
                width: z.ZodNumber;
                dash: z.ZodEnum<{
                    solid: "solid";
                    dashed: "dashed";
                    dotted: "dotted";
                }>;
            }, z.core.$strict>>;
            hidden: z.ZodOptional<z.ZodBoolean>;
        }, z.core.$strict>, z.ZodObject<{
            kind: z.ZodLiteral<"range">;
            from: z.ZodUnion<readonly [z.ZodNumber, z.ZodISODateTime]>;
            to: z.ZodUnion<readonly [z.ZodNumber, z.ZodISODateTime]>;
            label: z.ZodOptional<z.ZodString>;
            color: z.ZodOptional<z.ZodUnion<readonly [z.ZodObject<{
                light: z.ZodString;
                dark: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                token: z.ZodEnum<{
                    text: "text";
                    textSubdued: "textSubdued";
                    axis: "axis";
                    gridLine: "gridLine";
                    background: "background";
                    border: "border";
                }>;
            }, z.core.$strict>, z.ZodObject<{
                palette: z.ZodLiteral<"categorical">;
                index: z.ZodInt;
            }, z.core.$strict>]>>;
            fill: z.ZodOptional<z.ZodEnum<{
                inside: "inside";
                outside: "outside";
            }>>;
            hidden: z.ZodOptional<z.ZodBoolean>;
        }, z.core.$strict>], "kind">>;
    }, z.core.$strict>], "kind">>;
    axes: z.ZodOptional<z.ZodObject<{
        x: z.ZodOptional<z.ZodObject<{
            scale: z.ZodOptional<z.ZodEnum<{
                linear: "linear";
                temporal: "temporal";
                ordinal: "ordinal";
            }>>;
            domain: z.ZodOptional<z.ZodDiscriminatedUnion<[z.ZodObject<{
                kind: z.ZodLiteral<"fit">;
            }, z.core.$strict>, z.ZodObject<{
                kind: z.ZodLiteral<"custom">;
                min: z.ZodNumber;
                max: z.ZodNumber;
            }, z.core.$strict>], "kind">>;
            rounding: z.ZodOptional<z.ZodBoolean>;
            interval: z.ZodOptional<z.ZodNumber>;
            title: z.ZodOptional<z.ZodString>;
            ticks: z.ZodOptional<z.ZodBoolean>;
            grid: z.ZodOptional<z.ZodBoolean>;
            labelOrientation: z.ZodOptional<z.ZodEnum<{
                horizontal: "horizontal";
                vertical: "vertical";
                angled: "angled";
            }>>;
        }, z.core.$strict>>;
        y: z.ZodOptional<z.ZodObject<{
            scale: z.ZodOptional<z.ZodEnum<{
                linear: "linear";
                log: "log";
                sqrt: "sqrt";
            }>>;
            domain: z.ZodOptional<z.ZodDiscriminatedUnion<[z.ZodObject<{
                kind: z.ZodLiteral<"full">;
            }, z.core.$strict>, z.ZodObject<{
                kind: z.ZodLiteral<"fit">;
            }, z.core.$strict>, z.ZodObject<{
                kind: z.ZodLiteral<"custom">;
                min: z.ZodNumber;
                max: z.ZodNumber;
            }, z.core.$strict>], "kind">>;
            rounding: z.ZodOptional<z.ZodBoolean>;
            title: z.ZodOptional<z.ZodString>;
            ticks: z.ZodOptional<z.ZodBoolean>;
            grid: z.ZodOptional<z.ZodBoolean>;
            labelOrientation: z.ZodOptional<z.ZodEnum<{
                horizontal: "horizontal";
                vertical: "vertical";
                angled: "angled";
            }>>;
        }, z.core.$strict>>;
        y2: z.ZodOptional<z.ZodObject<{
            scale: z.ZodOptional<z.ZodEnum<{
                linear: "linear";
                log: "log";
                sqrt: "sqrt";
            }>>;
            domain: z.ZodOptional<z.ZodDiscriminatedUnion<[z.ZodObject<{
                kind: z.ZodLiteral<"full">;
            }, z.core.$strict>, z.ZodObject<{
                kind: z.ZodLiteral<"fit">;
            }, z.core.$strict>, z.ZodObject<{
                kind: z.ZodLiteral<"custom">;
                min: z.ZodNumber;
                max: z.ZodNumber;
            }, z.core.$strict>], "kind">>;
            rounding: z.ZodOptional<z.ZodBoolean>;
            title: z.ZodOptional<z.ZodString>;
            ticks: z.ZodOptional<z.ZodBoolean>;
            grid: z.ZodOptional<z.ZodBoolean>;
            labelOrientation: z.ZodOptional<z.ZodEnum<{
                horizontal: "horizontal";
                vertical: "vertical";
                angled: "angled";
            }>>;
        }, z.core.$strict>>;
    }, z.core.$strict>>;
    legend: z.ZodOptional<z.ZodObject<{
        visibility: z.ZodOptional<z.ZodEnum<{
            auto: "auto";
            visible: "visible";
            hidden: "hidden";
        }>>;
        position: z.ZodOptional<z.ZodEnum<{
            left: "left";
            right: "right";
            top: "top";
            bottom: "bottom";
        }>>;
        inside: z.ZodOptional<z.ZodEnum<{
            top_left: "top_left";
            top_right: "top_right";
            bottom_left: "bottom_left";
            bottom_right: "bottom_right";
        }>>;
        layout: z.ZodOptional<z.ZodEnum<{
            grid: "grid";
            list: "list";
        }>>;
        columns: z.ZodOptional<z.ZodInt>;
        maxLines: z.ZodOptional<z.ZodInt>;
        size: z.ZodOptional<z.ZodEnum<{
            auto: "auto";
            s: "s";
            m: "m";
            l: "l";
            xl: "xl";
        }>>;
        statistics: z.ZodOptional<z.ZodArray<z.ZodEnum<{
            range: "range";
            avg: "avg";
            count: "count";
            min: "min";
            max: "max";
            median: "median";
            last_value: "last_value";
            last_non_null_value: "last_non_null_value";
            first_value: "first_value";
            first_non_null_value: "first_non_null_value";
            difference: "difference";
            difference_percentage: "difference_percentage";
            total: "total";
            standard_deviation: "standard_deviation";
            variance: "variance";
            distinct_count: "distinct_count";
            current_and_last_value: "current_and_last_value";
        }>>>;
        seriesHeader: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>>;
    style: z.ZodOptional<z.ZodObject<{
        interpolation: z.ZodOptional<z.ZodEnum<{
            linear: "linear";
            smooth: "smooth";
            stepped: "stepped";
        }>>;
        fitting: z.ZodOptional<z.ZodObject<{
            kind: z.ZodEnum<{
                linear: "linear";
                none: "none";
                zero: "zero";
                carry: "carry";
                lookahead: "lookahead";
                average: "average";
                nearest: "nearest";
            }>;
            emphasize: z.ZodOptional<z.ZodBoolean>;
            extend: z.ZodOptional<z.ZodEnum<{
                none: "none";
                zero: "zero";
                nearest: "nearest";
            }>>;
        }, z.core.$strict>>;
        points: z.ZodOptional<z.ZodEnum<{
            auto: "auto";
            visible: "visible";
            hidden: "hidden";
        }>>;
        areaOpacity: z.ZodOptional<z.ZodNumber>;
        areaFill: z.ZodOptional<z.ZodEnum<{
            solid: "solid";
            gradient: "gradient";
        }>>;
        barMinimumHeight: z.ZodOptional<z.ZodNumber>;
        barValueLabels: z.ZodOptional<z.ZodBoolean>;
        partialBuckets: z.ZodOptional<z.ZodObject<{
            from: z.ZodUnion<readonly [z.ZodNumber, z.ZodISODateTime]>;
            to: z.ZodUnion<readonly [z.ZodNumber, z.ZodISODateTime]>;
        }, z.core.$strict>>;
        currentTime: z.ZodOptional<z.ZodUnion<readonly [z.ZodNumber, z.ZodISODateTime]>>;
    }, z.core.$strict>>;
    emphasis: z.ZodOptional<z.ZodArray<z.ZodObject<{
        rows: z.ZodArray<z.ZodInt>;
        note: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>>>;
    title: z.ZodOptional<z.ZodString>;
    description: z.ZodOptional<z.ZodString>;
    data: z.ZodObject<{
        columns: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            label: z.ZodString;
            type: z.ZodEnum<{
                string: "string";
                number: "number";
                boolean: "boolean";
                date: "date";
            }>;
            role: z.ZodEnum<{
                dimension: "dimension";
                metric: "metric";
            }>;
            format: z.ZodOptional<z.ZodDiscriminatedUnion<[z.ZodObject<{
                notation: z.ZodOptional<z.ZodEnum<{
                    standard: "standard";
                    compact: "compact";
                }>>;
                minimumFractionDigits: z.ZodOptional<z.ZodInt>;
                maximumFractionDigits: z.ZodOptional<z.ZodInt>;
                signDisplay: z.ZodOptional<z.ZodEnum<{
                    auto: "auto";
                    always: "always";
                    exceptZero: "exceptZero";
                    never: "never";
                }>>;
                useGrouping: z.ZodOptional<z.ZodBoolean>;
                suffix: z.ZodOptional<z.ZodString>;
                kind: z.ZodLiteral<"number">;
            }, z.core.$strict>, z.ZodObject<{
                fractional: z.ZodOptional<z.ZodBoolean>;
                minimumFractionDigits: z.ZodOptional<z.ZodInt>;
                maximumFractionDigits: z.ZodOptional<z.ZodInt>;
                signDisplay: z.ZodOptional<z.ZodEnum<{
                    auto: "auto";
                    always: "always";
                    exceptZero: "exceptZero";
                    never: "never";
                }>>;
                useGrouping: z.ZodOptional<z.ZodBoolean>;
                suffix: z.ZodOptional<z.ZodString>;
                kind: z.ZodLiteral<"percent">;
            }, z.core.$strict>, z.ZodObject<{
                base: z.ZodOptional<z.ZodUnion<readonly [z.ZodLiteral<1000>, z.ZodLiteral<1024>]>>;
                unitDisplay: z.ZodOptional<z.ZodEnum<{
                    long: "long";
                    short: "short";
                    narrow: "narrow";
                }>>;
                minimumFractionDigits: z.ZodOptional<z.ZodInt>;
                maximumFractionDigits: z.ZodOptional<z.ZodInt>;
                signDisplay: z.ZodOptional<z.ZodEnum<{
                    auto: "auto";
                    always: "always";
                    exceptZero: "exceptZero";
                    never: "never";
                }>>;
                useGrouping: z.ZodOptional<z.ZodBoolean>;
                suffix: z.ZodOptional<z.ZodString>;
                kind: z.ZodLiteral<"bytes">;
            }, z.core.$strict>, z.ZodObject<{
                base: z.ZodOptional<z.ZodUnion<readonly [z.ZodLiteral<1000>, z.ZodLiteral<1024>]>>;
                unitDisplay: z.ZodOptional<z.ZodEnum<{
                    long: "long";
                    short: "short";
                    narrow: "narrow";
                }>>;
                minimumFractionDigits: z.ZodOptional<z.ZodInt>;
                maximumFractionDigits: z.ZodOptional<z.ZodInt>;
                signDisplay: z.ZodOptional<z.ZodEnum<{
                    auto: "auto";
                    always: "always";
                    exceptZero: "exceptZero";
                    never: "never";
                }>>;
                useGrouping: z.ZodOptional<z.ZodBoolean>;
                suffix: z.ZodOptional<z.ZodString>;
                kind: z.ZodLiteral<"bits">;
            }, z.core.$strict>, z.ZodObject<{
                unitDisplay: z.ZodOptional<z.ZodEnum<{
                    long: "long";
                    short: "short";
                    narrow: "narrow";
                }>>;
                minimumFractionDigits: z.ZodOptional<z.ZodInt>;
                maximumFractionDigits: z.ZodOptional<z.ZodInt>;
                signDisplay: z.ZodOptional<z.ZodEnum<{
                    auto: "auto";
                    always: "always";
                    exceptZero: "exceptZero";
                    never: "never";
                }>>;
                useGrouping: z.ZodOptional<z.ZodBoolean>;
                suffix: z.ZodOptional<z.ZodString>;
                kind: z.ZodLiteral<"duration">;
                input: z.ZodEnum<{
                    picoseconds: "picoseconds";
                    nanoseconds: "nanoseconds";
                    microseconds: "microseconds";
                    milliseconds: "milliseconds";
                    seconds: "seconds";
                    minutes: "minutes";
                    hours: "hours";
                    days: "days";
                    weeks: "weeks";
                    months: "months";
                    years: "years";
                }>;
                output: z.ZodOptional<z.ZodUnion<readonly [z.ZodEnum<{
                    nanoseconds: "nanoseconds";
                    microseconds: "microseconds";
                    milliseconds: "milliseconds";
                    seconds: "seconds";
                    minutes: "minutes";
                    hours: "hours";
                    days: "days";
                    weeks: "weeks";
                    months: "months";
                    years: "years";
                }>, z.ZodLiteral<"auto">]>>;
            }, z.core.$strict>, z.ZodObject<{
                kind: z.ZodLiteral<"date">;
                timeZone: z.ZodOptional<z.ZodString>;
                dateStyle: z.ZodOptional<z.ZodEnum<{
                    long: "long";
                    short: "short";
                    full: "full";
                    medium: "medium";
                }>>;
                timeStyle: z.ZodOptional<z.ZodEnum<{
                    long: "long";
                    short: "short";
                    full: "full";
                    medium: "medium";
                }>>;
                weekday: z.ZodOptional<z.ZodEnum<{
                    long: "long";
                    short: "short";
                    narrow: "narrow";
                }>>;
                year: z.ZodOptional<z.ZodEnum<{
                    numeric: "numeric";
                    "2-digit": "2-digit";
                }>>;
                month: z.ZodOptional<z.ZodEnum<{
                    long: "long";
                    short: "short";
                    narrow: "narrow";
                    numeric: "numeric";
                    "2-digit": "2-digit";
                }>>;
                day: z.ZodOptional<z.ZodEnum<{
                    numeric: "numeric";
                    "2-digit": "2-digit";
                }>>;
                hour: z.ZodOptional<z.ZodEnum<{
                    numeric: "numeric";
                    "2-digit": "2-digit";
                }>>;
                minute: z.ZodOptional<z.ZodEnum<{
                    numeric: "numeric";
                    "2-digit": "2-digit";
                }>>;
                second: z.ZodOptional<z.ZodEnum<{
                    numeric: "numeric";
                    "2-digit": "2-digit";
                }>>;
                fractionalSecondDigits: z.ZodOptional<z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>, z.ZodLiteral<3>]>>;
                hour12: z.ZodOptional<z.ZodBoolean>;
                timeZoneName: z.ZodOptional<z.ZodEnum<{
                    long: "long";
                    short: "short";
                    shortOffset: "shortOffset";
                    longOffset: "longOffset";
                }>>;
            }, z.core.$strict>, z.ZodObject<{
                kind: z.ZodLiteral<"text">;
            }, z.core.$strict>], "kind">>;
            multivalue: z.ZodOptional<z.ZodLiteral<true>>;
            source: z.ZodOptional<z.ZodUnknown>;
        }, z.core.$strict>>;
        rows: z.ZodArray<z.ZodArray<z.ZodUnion<readonly [z.ZodUnion<readonly [z.ZodNumber, z.ZodString, z.ZodBoolean, z.ZodNull]>, z.ZodArray<z.ZodUnion<readonly [z.ZodNumber, z.ZodString, z.ZodBoolean, z.ZodNull]>>]>>>;
        source: z.ZodOptional<z.ZodUnknown>;
        missing: z.ZodOptional<z.ZodObject<{
            null: z.ZodOptional<z.ZodString>;
            empty: z.ZodOptional<z.ZodString>;
            nan: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>;
        display: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodArray<z.ZodString>>>;
    }, z.core.$strict>;
    colors: z.ZodOptional<z.ZodObject<{
        byKey: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodObject<{
            light: z.ZodString;
            dark: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            token: z.ZodEnum<{
                text: "text";
                textSubdued: "textSubdued";
                axis: "axis";
                gridLine: "gridLine";
                background: "background";
                border: "border";
            }>;
        }, z.core.$strict>, z.ZodObject<{
            palette: z.ZodLiteral<"categorical">;
            index: z.ZodInt;
        }, z.core.$strict>]>>>;
        bands: z.ZodOptional<z.ZodArray<z.ZodObject<{
            from: z.ZodOptional<z.ZodNumber>;
            to: z.ZodOptional<z.ZodNumber>;
            color: z.ZodUnion<readonly [z.ZodObject<{
                light: z.ZodString;
                dark: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                token: z.ZodEnum<{
                    text: "text";
                    textSubdued: "textSubdued";
                    axis: "axis";
                    gridLine: "gridLine";
                    background: "background";
                    border: "border";
                }>;
            }, z.core.$strict>, z.ZodObject<{
                palette: z.ZodLiteral<"categorical">;
                index: z.ZodInt;
            }, z.core.$strict>]>;
        }, z.core.$strict>>>;
    }, z.core.$strict>>;
    source: z.ZodOptional<z.ZodObject<{
        host: z.ZodString;
        hostVersion: z.ZodOptional<z.ZodString>;
        capturedAt: z.ZodISODateTime;
        timeRange: z.ZodOptional<z.ZodObject<{
            from: z.ZodISODateTime;
            to: z.ZodISODateTime;
        }, z.core.$strict>>;
        meta: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnknown>>;
    }, z.core.$strict>>;
    losses: z.ZodOptional<z.ZodArray<z.ZodObject<{
        path: z.ZodString;
        kind: z.ZodEnum<{
            dropped: "dropped";
            approximated: "approximated";
            prerendered: "prerendered";
        }>;
        note: z.ZodString;
    }, z.core.$strict>>>;
    type: z.ZodLiteral<"xyChart">;
}, z.core.$strip>;
/** A validated `xyChart` node. */
export type XyChartNode = z.infer<typeof xyChartSchema> & PrimitiveNode;
