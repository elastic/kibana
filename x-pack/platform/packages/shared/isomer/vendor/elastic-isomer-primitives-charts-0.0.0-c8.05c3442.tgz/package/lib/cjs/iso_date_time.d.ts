/**
 * The instant an ISO 8601 date-time with a UTC offset names, in epoch
 * milliseconds, computed without `Date.parse`. `undefined` for any other
 * string, including a calendar-invalid one such as February 30.
 */
export declare const isoDateTimeEpoch: (value: string) => number | undefined;
