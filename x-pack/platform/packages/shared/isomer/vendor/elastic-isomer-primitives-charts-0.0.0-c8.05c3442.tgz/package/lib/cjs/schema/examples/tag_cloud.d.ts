import type { PrimitiveExample } from '@elastic/isomer-sdk/schema';
import type { TagCloudNode } from '../tag_cloud';
/** The smallest `tagCloud`: services by log volume. The catalog's example. */
export declare const tagCloudServices: TagCloudNode;
/** Named `tagCloud` examples covering the corpus edge cases, each valid in a composition. */
export declare const tagCloudExamples: PrimitiveExample<TagCloudNode>[];
