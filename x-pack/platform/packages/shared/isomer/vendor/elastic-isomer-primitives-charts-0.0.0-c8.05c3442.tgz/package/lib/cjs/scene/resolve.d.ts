import type { DataTableNode } from '../schema/data_table';
import type { GaugeNode } from '../schema/gauge';
import type { HeatmapNode } from '../schema/heatmap';
import type { LegacyMetricNode } from '../schema/legacy_metric';
import type { MetricNode } from '../schema/metric';
import type { PartitionChartNode } from '../schema/partition_chart';
import type { TagCloudNode } from '../schema/tag_cloud';
import type { XyChartNode } from '../schema/xy_chart';
import type { ResolveChartOptions } from './common';
import type { GaugeScene, HeatmapScene, LegacyMetricScene, MetricScene, PartitionScene, Scene, TableScene, TagCloudScene, XyScene } from './types';
/** A chart node the resolver draws. */
export type ChartNode = MetricNode | XyChartNode | DataTableNode | PartitionChartNode | HeatmapNode | GaugeNode | TagCloudNode | LegacyMetricNode;
/**
 * Resolves a chart node to the Scene every renderer draws: colors for
 * `options.scheme`, every string formatted, axis and series intent, and the
 * rows and columns each selectable part stands for. Pure and synchronous; the
 * result is plain JSON data.
 */
export declare function resolveChart(node: MetricNode, options: ResolveChartOptions): MetricScene;
/** Resolves an `xyChart` node to an {@link XyScene}. */
export declare function resolveChart(node: XyChartNode, options: ResolveChartOptions): XyScene;
/** Resolves a `dataTable` node to a {@link TableScene}. */
export declare function resolveChart(node: DataTableNode, options: ResolveChartOptions): TableScene;
/** Resolves a `partitionChart` node to a {@link PartitionScene}. */
export declare function resolveChart(node: PartitionChartNode, options: ResolveChartOptions): PartitionScene;
/** Resolves a `heatmap` node to a {@link HeatmapScene}. */
export declare function resolveChart(node: HeatmapNode, options: ResolveChartOptions): HeatmapScene;
/** Resolves a `gauge` node to a {@link GaugeScene}. */
export declare function resolveChart(node: GaugeNode, options: ResolveChartOptions): GaugeScene;
/** Resolves a `tagCloud` node to a {@link TagCloudScene}. */
export declare function resolveChart(node: TagCloudNode, options: ResolveChartOptions): TagCloudScene;
/** Resolves a `legacyMetric` node to a {@link LegacyMetricScene}. */
export declare function resolveChart(node: LegacyMetricNode, options: ResolveChartOptions): LegacyMetricScene;
/** Resolves any chart node to its {@link Scene}. */
export declare function resolveChart(node: ChartNode, options: ResolveChartOptions): Scene;
