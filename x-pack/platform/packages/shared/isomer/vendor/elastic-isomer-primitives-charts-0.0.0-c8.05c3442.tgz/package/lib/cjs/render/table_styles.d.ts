/**
 * The table's handles, and the vars a Scene's colors and sizes reach them
 * through. Each handle that reads a var declares its default, so the vars are
 * set on the element that reads them.
 */
export declare const tableModule: {
    handles: {
        root: import("@elastic/distillate").StyleHandle;
        column: import("@elastic/distillate").StyleHandle;
        ruled: import("@elastic/distillate").StyleHandle;
        shaded: import("@elastic/distillate").StyleHandle;
        ink: import("@elastic/distillate").StyleHandle;
        filled: import("@elastic/distillate").StyleHandle;
        font: {
            default: import("@elastic/distillate").StyleHandle;
            compact: import("@elastic/distillate").StyleHandle;
            expanded: import("@elastic/distillate").StyleHandle;
        };
        title: import("@elastic/distillate").StyleHandle;
        line: import("@elastic/distillate").StyleHandle;
        table: import("@elastic/distillate").StyleHandle;
        cell: import("@elastic/distillate").StyleHandle;
        row: {
            default: import("@elastic/distillate").StyleHandle;
            compact: import("@elastic/distillate").StyleHandle;
            expanded: import("@elastic/distillate").StyleHandle;
        };
        align: {
            left: import("@elastic/distillate").StyleHandle;
            center: import("@elastic/distillate").StyleHandle;
            right: import("@elastic/distillate").StyleHandle;
        };
        heading: import("@elastic/distillate").StyleHandle;
        rowHeading: import("@elastic/distillate").StyleHandle;
        barCell: import("@elastic/distillate").StyleHandle;
        barValue: import("@elastic/distillate").StyleHandle;
        bar: import("@elastic/distillate").StyleHandle;
        barFill: import("@elastic/distillate").StyleHandle;
        barShape: {
            default: import("@elastic/distillate").StyleHandle;
            compact: import("@elastic/distillate").StyleHandle;
            expanded: import("@elastic/distillate").StyleHandle;
        };
        badge: import("@elastic/distillate").StyleHandle;
        pager: import("@elastic/distillate").StyleHandle;
        pages: import("@elastic/distillate").StyleHandle;
        page: import("@elastic/distillate").StyleHandle;
    };
    vars: {
        box: import("@elastic/distillate").LocalVarGroup<"fill" | "width" | "height" | "ink">;
        column: import("@elastic/distillate").LocalVarGroup<"width">;
        rule: import("@elastic/distillate").LocalVarGroup<"color">;
        shade: import("@elastic/distillate").LocalVarGroup<"fill">;
        ink: import("@elastic/distillate").LocalVarGroup<"color">;
        cell: import("@elastic/distillate").LocalVarGroup<"fill">;
        bar: import("@elastic/distillate").LocalVarGroup<"fill" | "from" | "track" | "span">;
        badge: import("@elastic/distillate").LocalVarGroup<"fill">;
        gutter: import("@elastic/distillate").LocalVarGroup<"basis">;
    };
    stylesheet: () => string;
};
