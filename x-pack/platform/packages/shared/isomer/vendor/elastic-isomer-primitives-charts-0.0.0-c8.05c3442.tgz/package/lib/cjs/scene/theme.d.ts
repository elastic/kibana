import type { ColorValue } from '../schema/colors';
import type { ColorScheme, SceneChrome, SceneColor } from './types';
/** Chrome per scheme: EUI Borealis `textParagraph`, `textSubdued`, `borderBasePlain`, `borderBaseSubdued` and `backgroundBasePlain`. */
export declare const CHART_CHROME: Readonly<Record<ColorScheme, SceneChrome>>;
/** The default categorical palette, EUI Borealis `euiColorVis0`–`euiColorVis9`, the same in both schemes. */
export declare const CATEGORICAL_PALETTE: readonly SceneColor[];
/** A palette entry by index, wrapping past the end. */
export declare const categoricalColor: (index: number) => SceneColor;
/** A node color, concrete for `scheme`. */
export declare const resolveColor: (color: ColorValue, scheme: ColorScheme) => SceneColor;
/** Text on `background`: whichever of the two schemes' text colors contrasts more. */
export declare const textOn: (background: SceneColor, canvas: SceneColor) => SceneColor;
/**
 * Table colors per scheme, EUI Borealis: `darkShade` for empty values,
 * `lightShade` for a bar's track, `lightestShade` for the header and footer,
 * `backgroundBasePrimary` for emphasized rows, and `textInk` and `textGhost`
 * for text on a colored cell.
 */
export declare const TABLE_CHROME: Readonly<Record<ColorScheme, {
    readonly emptyValue: SceneColor;
    readonly barTrack: SceneColor;
    readonly header: SceneColor;
    readonly emphasis: SceneColor;
    readonly inkText: SceneColor;
    readonly ghostText: SceneColor;
}>>;
/** A table bar's fill when its column sets none: Lens's `DEFAULT_PROGRESS_BAR_COLOR`, `euiColorVis2`. */
export declare const DEFAULT_TABLE_BAR_COLOR: SceneColor;
/**
 * Text on a colored table cell, as Lens's `getContrastColor`: `textGhost` on a
 * dark color (EUI `isColorDark`, relative luminance at most 0.179), else
 * `textInk`. A translucent color is judged as drawn over `canvas`.
 */
export declare const contrastText: (background: SceneColor, canvas: SceneColor, scheme: ColorScheme) => SceneColor;
/**
 * `color` mixed toward `toward` by `amount` (0 to 1) in LCH, as chroma-js's
 * `mix(color, toward, amount, 'lch')`: the shorter way round the hue circle,
 * and a gray takes the other color's hue. Alpha mixes linearly, and an
 * opaque result is `#rrggbb`.
 */
export declare const mixLch: (color: SceneColor, toward: SceneColor, amount: number) => SceneColor;
/** The fill of a mosaic's outer layer, which its inner slices cover: Lens's transparent white. */
export declare const TRANSPARENT: SceneColor;
/**
 * A heat map's colors when its node states no bands, lowest first: Lens's
 * default `temperature` palette at its default five steps, EUI's
 * `euiPaletteForTemperature(5)`, the same in both schemes.
 */
export declare const HEATMAP_PALETTE: readonly SceneColor[];
