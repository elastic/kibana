import type { PrimitiveExample } from '@elastic/isomer-sdk/schema';
import type { HeatmapNode } from '../heatmap';
/** The smallest `heatmap`: requests by hour and host. The catalog's example. */
export declare const heatmapHourly: HeatmapNode;
/** Named `heatmap` examples covering the corpus edge cases, each valid in a composition. */
export declare const heatmapExamples: PrimitiveExample<HeatmapNode>[];
