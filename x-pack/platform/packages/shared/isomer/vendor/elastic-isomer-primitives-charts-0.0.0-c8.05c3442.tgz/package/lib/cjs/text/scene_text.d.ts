import { type MarkdownContent } from '@elastic/isomer-sdk/markdown';
import type { Scene } from '../scene/types';
/** The authored description, when the node has one. */
export declare const described: ({ description }: Scene) => string[];
/** The Scene's emphasis notes, in order. */
export declare const sceneNotes: ({ interactions }: Scene) => string[];
/**
 * The summary, description and each emphasis note on its own line, then the
 * table and its footer with cells separated by ` | `, then the link, each as
 * its own paragraph.
 */
export declare const sceneToText: (scene: Scene) => string;
/** The summary, description, each emphasis note, the table and its footer as a GFM table, and the link. */
export declare const sceneToMarkdown: (scene: Scene) => MarkdownContent;
