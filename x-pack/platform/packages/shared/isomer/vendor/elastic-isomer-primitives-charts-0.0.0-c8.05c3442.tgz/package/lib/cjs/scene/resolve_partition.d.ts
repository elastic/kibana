import type { PartitionChartNode } from '../schema/partition_chart';
import { type ResolveChartOptions } from './common';
import type { PartitionScene } from './types';
/** The Scene of a `partitionChart` node. */
export declare const resolvePartition: (node: PartitionChartNode, options: ResolveChartOptions) => PartitionScene;
