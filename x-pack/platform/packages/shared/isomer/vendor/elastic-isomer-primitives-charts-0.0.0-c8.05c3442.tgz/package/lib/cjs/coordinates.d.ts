import type { Cell } from './schema/data';
/** The largest absolute epoch, in milliseconds, a JavaScript `Date` represents. */
export declare const MAX_EPOCH = 8640000000000000;
/** A cell's scalar value: a multivalue cell's first non-null entry. */
export declare const scalarOf: (cell: Cell | undefined) => Cell | undefined;
/** The continuous scale a column type implies, if any. */
export declare const continuousScaleOf: (type: string) => "linear" | "temporal" | undefined;
/** A cell's position on a continuous scale, or `undefined` when it has none. */
export declare const coordinateOf: (cell: Cell | undefined, scale: "linear" | "temporal") => number | undefined;
