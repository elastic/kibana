import { type PrimitivePack } from '@elastic/isomer-sdk';
import type { ReactSceneRenderer, SceneResolver } from './render/context';
/** What {@link createChartsPack} builds the pack with. Every field is optional. */
export interface ChartsPackOptions {
    /** Turns a chart node into its Scene. Absent: `resolveChart`. */
    readonly resolveScene?: SceneResolver;
    /**
     * The pack's own renderer preferences, tried after a render's
     * `context.sceneRenderers` and before the pack's fallback. The `snapshot`
     * surface takes no host context, so this is where its preference goes.
     */
    readonly sceneRenderers?: readonly ReactSceneRenderer[];
}
/**
 * The input budget the charts pack declares. Chart nodes carry their data
 * inline, so a dashboard of them passes the SDK's default of 20,000 values
 * long before it is large. Room for about forty panels at a thousand rows of
 * a few columns each.
 */
export declare const CHARTS_INPUT_BUDGET: {
    readonly values: 250000;
    readonly characters: 10000000;
};
/** The charts pack, drawing every chart through `SceneRenderer`s. */
export declare const createChartsPack: ({ resolveScene, sceneRenderers, }?: ChartsPackOptions) => PrimitivePack;
/**
 * The charts pack with its defaults: `resolveChart`, then the summary
 * fallback. A host registers an engine through {@link createChartsPack} or the
 * render context's `sceneRenderers`.
 */
export declare const chartsPack: PrimitivePack;
/** Every rule the pack draws with, for a host that draws the `react` surface and ships the CSS itself. */
export declare const chartsStylesheet: () => string;
