/**
 * The one authoring source for every length the pack's own containers draw.
 * Colors are not here: chart colors come from the Scene, and container chrome
 * inherits the page's text color.
 */
export declare const CHARTS_THEME: {
    readonly frame: {
        /** The page width of `chartsFrame`, in pixels. */
        readonly width: 960;
        readonly padding: 16;
        readonly gap: 16;
        /** The page title size, in pixels. */
        readonly title: 20;
        /** The page subtitle size, in pixels. */
        readonly subtitle: 14;
    };
    /**
     * How a chart sizes itself outside a sized container, as Lens's chart size
     * specs do. A grid panel or a host `size` overrides it.
     */
    readonly chart: {
        /** The width a chart lays out for on Node, where there is no container to fill, in pixels. */
        readonly width: 480;
        readonly xy: {
            /** Width to height. Lens uses it for a vertical time chart and fills a container otherwise. */
            readonly aspectRatio: {
                readonly x: 16;
                readonly y: 9;
            };
            /** The least height of a vertical time chart, in pixels. */
            readonly timeMinHeight: 300;
        };
        readonly gauge: {
            /**
             * Lens's gauge size specs by shape (`useGaugeSizeByType`): width to
             * height, and the greatest width. A bullet takes the box of its largest
             * size, which Lens fills.
             */
            readonly horizontalBullet: {
                readonly aspectRatio: {
                    readonly x: 3;
                    readonly y: 1;
                };
                readonly maxWidth: 600;
            };
            readonly verticalBullet: {
                readonly aspectRatio: {
                    readonly x: 2;
                    readonly y: 3;
                };
                readonly maxWidth: 400;
            };
            readonly semiCircle: {
                readonly aspectRatio: {
                    readonly x: 2;
                    readonly y: 1.25;
                };
                readonly maxWidth: 600;
            };
            readonly arc: {
                readonly aspectRatio: {
                    readonly x: 1.1;
                    readonly y: 1;
                };
                readonly maxWidth: 600;
            };
            readonly circle: {
                readonly aspectRatio: {
                    readonly x: 1;
                    readonly y: 1;
                };
                readonly maxWidth: 600;
            };
        };
        readonly tagCloud: {
            /**
             * Width to height. Lens gives a tag cloud no size spec and fills its
             * container, so outside one it takes the xy chart's shape.
             */
            readonly aspectRatio: {
                readonly x: 16;
                readonly y: 9;
            };
        };
        readonly legacyMetric: {
            /**
             * Width to height. Lens gives a legacy metric no size spec and fills its
             * container, so outside one it takes the xy chart's shape, growing
             * taller when its tiles wrap to more rows than fit.
             */
            readonly aspectRatio: {
                readonly x: 16;
                readonly y: 9;
            };
        };
        readonly heatmap: {
            /**
             * Width to height. Lens gives a heat map no size spec and fills its
             * container, so outside one it takes the xy chart's shape.
             */
            readonly aspectRatio: {
                readonly x: 16;
                readonly y: 9;
            };
        };
        readonly partition: {
            /**
             * Width to height. Lens gives a partition chart no size spec and fills
             * its container, so outside one it takes the xy chart's shape.
             */
            readonly aspectRatio: {
                readonly x: 16;
                readonly y: 9;
            };
        };
        readonly metric: {
            /** The largest box of a metric with one tile, in pixels. */
            readonly single: {
                readonly width: 300;
                readonly height: 160;
            };
            /** The largest side of each tile when there are several, in pixels. */
            readonly tileSide: 200;
        };
        /** Height of the line a chart's link draws on below the chart, in pixels. */
        readonly linkHeight: 18;
    };
    readonly grid: {
        /** Height of one grid row unit, in pixels. */
        readonly rowHeight: 20;
        /** Space between panels, in pixels. */
        readonly gap: 8;
        /** Space between a section title and its panels, in pixels. */
        readonly sectionGap: 16;
        /**
         * The width a grid lays out for when the host gives none, in pixels:
         * `chartsFrame`'s content, so a grid on `snapshot` fits its page.
         */
        readonly nominalWidth: number;
        /** Height of a panel header with a title, in pixels. */
        readonly headerHeight: 24;
        /** Height of a grid or panel description line, in pixels. */
        readonly descriptionHeight: 18;
    };
    readonly type: {
        /** Panel and section title size, in pixels. */
        readonly title: 14;
        /** Description, reason and link size, in pixels. */
        readonly body: 12;
    };
    /** A `dataTable`, laid out as EUI's data grid. */
    readonly table: {
        /** Type size, cell padding and row height per density, in pixels. */
        readonly density: {
            readonly compact: {
                readonly font: 12;
                readonly padding: 4;
                readonly rowHeight: 24;
            };
            readonly default: {
                readonly font: 14;
                readonly padding: 6;
                readonly rowHeight: 32;
            };
            readonly expanded: {
                readonly font: 16;
                readonly padding: 8;
                readonly rowHeight: 40;
            };
        };
        readonly lineWidth: 1;
        readonly headerWeight: 700;
        /** A bar's thickness as a share of the row height. */
        readonly barThickness: 0.3;
        readonly barGap: 6;
        /** The least width a bar's value takes, in `ch`. */
        readonly barLabelMinChars: 3;
        readonly badgePadding: 4;
        readonly badgeRadius: 3;
        readonly pageGap: 12;
        /** Height of the title line, in pixels. */
        readonly titleHeight: 24;
        /** Height of a description, note or link line, in pixels. */
        readonly lineHeight: 18;
    };
    readonly unsupported: {
        readonly padding: 12;
        readonly borderWidth: 1;
        /** Height a `snapshot` frame reserves for an unsupported node, in pixels. */
        readonly height: 96;
    };
};
