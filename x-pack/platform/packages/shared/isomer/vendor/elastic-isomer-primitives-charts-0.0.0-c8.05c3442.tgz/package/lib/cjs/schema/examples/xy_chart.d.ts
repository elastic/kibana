import type { PrimitiveExample } from '@elastic/isomer-sdk/schema';
import type { XyChartNode } from '../xy_chart';
/** One line over a time axis. The catalog's example. */
export declare const xyTimeSeries: XyChartNode;
/** Interactive: selectable marks, series and legend items, a time brush, and a static highlight. */
export declare const xyInteractive: XyChartNode;
/** Named `xyChart` examples covering the corpus edge cases, each valid in a composition. */
export declare const xyChartExamples: PrimitiveExample<XyChartNode>[];
