import { z } from '@elastic/isomer-sdk/schema';
declare const scalarCellSchema: z.ZodUnion<readonly [z.ZodNumber, z.ZodString, z.ZodBoolean, z.ZodNull]>;
/** One value in a non-multivalue cell. `null` is a missing value, never zero. */
export type ScalarCell = z.infer<typeof scalarCellSchema>;
/** A cell: one scalar, or an array of scalars for a multivalue column. */
export declare const cellSchema: z.ZodUnion<readonly [z.ZodUnion<readonly [z.ZodNumber, z.ZodString, z.ZodBoolean, z.ZodNull]>, z.ZodArray<z.ZodUnion<readonly [z.ZodNumber, z.ZodString, z.ZodBoolean, z.ZodNull]>>]>;
/** A cell: one value, or an array of values in a `multivalue` column. */
export type Cell = z.infer<typeof cellSchema>;
declare const COLUMN_TYPES: readonly ["number", "string", "date", "boolean"];
/** The kind of value a column's cells hold. */
export type ColumnType = (typeof COLUMN_TYPES)[number];
declare const COLUMN_ROLES: readonly ["dimension", "metric"];
/**
 * `dimension` columns identify a row (buckets, categories, time); `metric`
 * columns measure it. Dimensions lead text summaries and are what a selection
 * targets.
 */
export type ColumnRole = (typeof COLUMN_ROLES)[number];
declare const columnSchema: z.ZodObject<{
    id: z.ZodString;
    label: z.ZodString;
    type: z.ZodEnum<{
        string: "string";
        number: "number";
        boolean: "boolean";
        date: "date";
    }>;
    role: z.ZodEnum<{
        dimension: "dimension";
        metric: "metric";
    }>;
    format: z.ZodOptional<z.ZodDiscriminatedUnion<[z.ZodObject<{
        notation: z.ZodOptional<z.ZodEnum<{
            standard: "standard";
            compact: "compact";
        }>>;
        minimumFractionDigits: z.ZodOptional<z.ZodInt>;
        maximumFractionDigits: z.ZodOptional<z.ZodInt>;
        signDisplay: z.ZodOptional<z.ZodEnum<{
            auto: "auto";
            always: "always";
            exceptZero: "exceptZero";
            never: "never";
        }>>;
        useGrouping: z.ZodOptional<z.ZodBoolean>;
        suffix: z.ZodOptional<z.ZodString>;
        kind: z.ZodLiteral<"number">;
    }, z.core.$strict>, z.ZodObject<{
        fractional: z.ZodOptional<z.ZodBoolean>;
        minimumFractionDigits: z.ZodOptional<z.ZodInt>;
        maximumFractionDigits: z.ZodOptional<z.ZodInt>;
        signDisplay: z.ZodOptional<z.ZodEnum<{
            auto: "auto";
            always: "always";
            exceptZero: "exceptZero";
            never: "never";
        }>>;
        useGrouping: z.ZodOptional<z.ZodBoolean>;
        suffix: z.ZodOptional<z.ZodString>;
        kind: z.ZodLiteral<"percent">;
    }, z.core.$strict>, z.ZodObject<{
        base: z.ZodOptional<z.ZodUnion<readonly [z.ZodLiteral<1000>, z.ZodLiteral<1024>]>>;
        unitDisplay: z.ZodOptional<z.ZodEnum<{
            long: "long";
            short: "short";
            narrow: "narrow";
        }>>;
        minimumFractionDigits: z.ZodOptional<z.ZodInt>;
        maximumFractionDigits: z.ZodOptional<z.ZodInt>;
        signDisplay: z.ZodOptional<z.ZodEnum<{
            auto: "auto";
            always: "always";
            exceptZero: "exceptZero";
            never: "never";
        }>>;
        useGrouping: z.ZodOptional<z.ZodBoolean>;
        suffix: z.ZodOptional<z.ZodString>;
        kind: z.ZodLiteral<"bytes">;
    }, z.core.$strict>, z.ZodObject<{
        base: z.ZodOptional<z.ZodUnion<readonly [z.ZodLiteral<1000>, z.ZodLiteral<1024>]>>;
        unitDisplay: z.ZodOptional<z.ZodEnum<{
            long: "long";
            short: "short";
            narrow: "narrow";
        }>>;
        minimumFractionDigits: z.ZodOptional<z.ZodInt>;
        maximumFractionDigits: z.ZodOptional<z.ZodInt>;
        signDisplay: z.ZodOptional<z.ZodEnum<{
            auto: "auto";
            always: "always";
            exceptZero: "exceptZero";
            never: "never";
        }>>;
        useGrouping: z.ZodOptional<z.ZodBoolean>;
        suffix: z.ZodOptional<z.ZodString>;
        kind: z.ZodLiteral<"bits">;
    }, z.core.$strict>, z.ZodObject<{
        unitDisplay: z.ZodOptional<z.ZodEnum<{
            long: "long";
            short: "short";
            narrow: "narrow";
        }>>;
        minimumFractionDigits: z.ZodOptional<z.ZodInt>;
        maximumFractionDigits: z.ZodOptional<z.ZodInt>;
        signDisplay: z.ZodOptional<z.ZodEnum<{
            auto: "auto";
            always: "always";
            exceptZero: "exceptZero";
            never: "never";
        }>>;
        useGrouping: z.ZodOptional<z.ZodBoolean>;
        suffix: z.ZodOptional<z.ZodString>;
        kind: z.ZodLiteral<"duration">;
        input: z.ZodEnum<{
            picoseconds: "picoseconds";
            nanoseconds: "nanoseconds";
            microseconds: "microseconds";
            milliseconds: "milliseconds";
            seconds: "seconds";
            minutes: "minutes";
            hours: "hours";
            days: "days";
            weeks: "weeks";
            months: "months";
            years: "years";
        }>;
        output: z.ZodOptional<z.ZodUnion<readonly [z.ZodEnum<{
            nanoseconds: "nanoseconds";
            microseconds: "microseconds";
            milliseconds: "milliseconds";
            seconds: "seconds";
            minutes: "minutes";
            hours: "hours";
            days: "days";
            weeks: "weeks";
            months: "months";
            years: "years";
        }>, z.ZodLiteral<"auto">]>>;
    }, z.core.$strict>, z.ZodObject<{
        kind: z.ZodLiteral<"date">;
        timeZone: z.ZodOptional<z.ZodString>;
        dateStyle: z.ZodOptional<z.ZodEnum<{
            long: "long";
            short: "short";
            full: "full";
            medium: "medium";
        }>>;
        timeStyle: z.ZodOptional<z.ZodEnum<{
            long: "long";
            short: "short";
            full: "full";
            medium: "medium";
        }>>;
        weekday: z.ZodOptional<z.ZodEnum<{
            long: "long";
            short: "short";
            narrow: "narrow";
        }>>;
        year: z.ZodOptional<z.ZodEnum<{
            numeric: "numeric";
            "2-digit": "2-digit";
        }>>;
        month: z.ZodOptional<z.ZodEnum<{
            long: "long";
            short: "short";
            narrow: "narrow";
            numeric: "numeric";
            "2-digit": "2-digit";
        }>>;
        day: z.ZodOptional<z.ZodEnum<{
            numeric: "numeric";
            "2-digit": "2-digit";
        }>>;
        hour: z.ZodOptional<z.ZodEnum<{
            numeric: "numeric";
            "2-digit": "2-digit";
        }>>;
        minute: z.ZodOptional<z.ZodEnum<{
            numeric: "numeric";
            "2-digit": "2-digit";
        }>>;
        second: z.ZodOptional<z.ZodEnum<{
            numeric: "numeric";
            "2-digit": "2-digit";
        }>>;
        fractionalSecondDigits: z.ZodOptional<z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>, z.ZodLiteral<3>]>>;
        hour12: z.ZodOptional<z.ZodBoolean>;
        timeZoneName: z.ZodOptional<z.ZodEnum<{
            long: "long";
            short: "short";
            shortOffset: "shortOffset";
            longOffset: "longOffset";
        }>>;
    }, z.core.$strict>, z.ZodObject<{
        kind: z.ZodLiteral<"text">;
    }, z.core.$strict>], "kind">>;
    multivalue: z.ZodOptional<z.ZodLiteral<true>>;
    source: z.ZodOptional<z.ZodUnknown>;
}, z.core.$strict>;
/** A column of `data`: its identity, type, role and format. */
export type ChartColumn = z.infer<typeof columnSchema>;
/** The rules `chartDataSchema` states, one sentence each. */
export declare const DATA_RULES: {
    readonly uniqueIds: "Column ids are unique.";
    readonly rowWidth: "Every row has exactly one cell per column, in column order.";
    readonly cellType: "A cell holds its column type or null: a number in a `number` column, a string in a `string` column, a boolean in a `boolean` column, and epoch milliseconds or an ISO 8601 date-time string with a UTC offset (`Z` or `+hh:mm`) in a `date` column. Only a `multivalue` column holds arrays of those.";
    readonly display: "Each `display` key names a column and holds one string per row.";
};
/** Typed columnar data, shared by every chart, with the rules in {@link DATA_RULES}. */
export declare const chartDataSchema: z.ZodObject<{
    columns: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        label: z.ZodString;
        type: z.ZodEnum<{
            string: "string";
            number: "number";
            boolean: "boolean";
            date: "date";
        }>;
        role: z.ZodEnum<{
            dimension: "dimension";
            metric: "metric";
        }>;
        format: z.ZodOptional<z.ZodDiscriminatedUnion<[z.ZodObject<{
            notation: z.ZodOptional<z.ZodEnum<{
                standard: "standard";
                compact: "compact";
            }>>;
            minimumFractionDigits: z.ZodOptional<z.ZodInt>;
            maximumFractionDigits: z.ZodOptional<z.ZodInt>;
            signDisplay: z.ZodOptional<z.ZodEnum<{
                auto: "auto";
                always: "always";
                exceptZero: "exceptZero";
                never: "never";
            }>>;
            useGrouping: z.ZodOptional<z.ZodBoolean>;
            suffix: z.ZodOptional<z.ZodString>;
            kind: z.ZodLiteral<"number">;
        }, z.core.$strict>, z.ZodObject<{
            fractional: z.ZodOptional<z.ZodBoolean>;
            minimumFractionDigits: z.ZodOptional<z.ZodInt>;
            maximumFractionDigits: z.ZodOptional<z.ZodInt>;
            signDisplay: z.ZodOptional<z.ZodEnum<{
                auto: "auto";
                always: "always";
                exceptZero: "exceptZero";
                never: "never";
            }>>;
            useGrouping: z.ZodOptional<z.ZodBoolean>;
            suffix: z.ZodOptional<z.ZodString>;
            kind: z.ZodLiteral<"percent">;
        }, z.core.$strict>, z.ZodObject<{
            base: z.ZodOptional<z.ZodUnion<readonly [z.ZodLiteral<1000>, z.ZodLiteral<1024>]>>;
            unitDisplay: z.ZodOptional<z.ZodEnum<{
                long: "long";
                short: "short";
                narrow: "narrow";
            }>>;
            minimumFractionDigits: z.ZodOptional<z.ZodInt>;
            maximumFractionDigits: z.ZodOptional<z.ZodInt>;
            signDisplay: z.ZodOptional<z.ZodEnum<{
                auto: "auto";
                always: "always";
                exceptZero: "exceptZero";
                never: "never";
            }>>;
            useGrouping: z.ZodOptional<z.ZodBoolean>;
            suffix: z.ZodOptional<z.ZodString>;
            kind: z.ZodLiteral<"bytes">;
        }, z.core.$strict>, z.ZodObject<{
            base: z.ZodOptional<z.ZodUnion<readonly [z.ZodLiteral<1000>, z.ZodLiteral<1024>]>>;
            unitDisplay: z.ZodOptional<z.ZodEnum<{
                long: "long";
                short: "short";
                narrow: "narrow";
            }>>;
            minimumFractionDigits: z.ZodOptional<z.ZodInt>;
            maximumFractionDigits: z.ZodOptional<z.ZodInt>;
            signDisplay: z.ZodOptional<z.ZodEnum<{
                auto: "auto";
                always: "always";
                exceptZero: "exceptZero";
                never: "never";
            }>>;
            useGrouping: z.ZodOptional<z.ZodBoolean>;
            suffix: z.ZodOptional<z.ZodString>;
            kind: z.ZodLiteral<"bits">;
        }, z.core.$strict>, z.ZodObject<{
            unitDisplay: z.ZodOptional<z.ZodEnum<{
                long: "long";
                short: "short";
                narrow: "narrow";
            }>>;
            minimumFractionDigits: z.ZodOptional<z.ZodInt>;
            maximumFractionDigits: z.ZodOptional<z.ZodInt>;
            signDisplay: z.ZodOptional<z.ZodEnum<{
                auto: "auto";
                always: "always";
                exceptZero: "exceptZero";
                never: "never";
            }>>;
            useGrouping: z.ZodOptional<z.ZodBoolean>;
            suffix: z.ZodOptional<z.ZodString>;
            kind: z.ZodLiteral<"duration">;
            input: z.ZodEnum<{
                picoseconds: "picoseconds";
                nanoseconds: "nanoseconds";
                microseconds: "microseconds";
                milliseconds: "milliseconds";
                seconds: "seconds";
                minutes: "minutes";
                hours: "hours";
                days: "days";
                weeks: "weeks";
                months: "months";
                years: "years";
            }>;
            output: z.ZodOptional<z.ZodUnion<readonly [z.ZodEnum<{
                nanoseconds: "nanoseconds";
                microseconds: "microseconds";
                milliseconds: "milliseconds";
                seconds: "seconds";
                minutes: "minutes";
                hours: "hours";
                days: "days";
                weeks: "weeks";
                months: "months";
                years: "years";
            }>, z.ZodLiteral<"auto">]>>;
        }, z.core.$strict>, z.ZodObject<{
            kind: z.ZodLiteral<"date">;
            timeZone: z.ZodOptional<z.ZodString>;
            dateStyle: z.ZodOptional<z.ZodEnum<{
                long: "long";
                short: "short";
                full: "full";
                medium: "medium";
            }>>;
            timeStyle: z.ZodOptional<z.ZodEnum<{
                long: "long";
                short: "short";
                full: "full";
                medium: "medium";
            }>>;
            weekday: z.ZodOptional<z.ZodEnum<{
                long: "long";
                short: "short";
                narrow: "narrow";
            }>>;
            year: z.ZodOptional<z.ZodEnum<{
                numeric: "numeric";
                "2-digit": "2-digit";
            }>>;
            month: z.ZodOptional<z.ZodEnum<{
                long: "long";
                short: "short";
                narrow: "narrow";
                numeric: "numeric";
                "2-digit": "2-digit";
            }>>;
            day: z.ZodOptional<z.ZodEnum<{
                numeric: "numeric";
                "2-digit": "2-digit";
            }>>;
            hour: z.ZodOptional<z.ZodEnum<{
                numeric: "numeric";
                "2-digit": "2-digit";
            }>>;
            minute: z.ZodOptional<z.ZodEnum<{
                numeric: "numeric";
                "2-digit": "2-digit";
            }>>;
            second: z.ZodOptional<z.ZodEnum<{
                numeric: "numeric";
                "2-digit": "2-digit";
            }>>;
            fractionalSecondDigits: z.ZodOptional<z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>, z.ZodLiteral<3>]>>;
            hour12: z.ZodOptional<z.ZodBoolean>;
            timeZoneName: z.ZodOptional<z.ZodEnum<{
                long: "long";
                short: "short";
                shortOffset: "shortOffset";
                longOffset: "longOffset";
            }>>;
        }, z.core.$strict>, z.ZodObject<{
            kind: z.ZodLiteral<"text">;
        }, z.core.$strict>], "kind">>;
        multivalue: z.ZodOptional<z.ZodLiteral<true>>;
        source: z.ZodOptional<z.ZodUnknown>;
    }, z.core.$strict>>;
    rows: z.ZodArray<z.ZodArray<z.ZodUnion<readonly [z.ZodUnion<readonly [z.ZodNumber, z.ZodString, z.ZodBoolean, z.ZodNull]>, z.ZodArray<z.ZodUnion<readonly [z.ZodNumber, z.ZodString, z.ZodBoolean, z.ZodNull]>>]>>>;
    source: z.ZodOptional<z.ZodUnknown>;
    missing: z.ZodOptional<z.ZodObject<{
        null: z.ZodOptional<z.ZodString>;
        empty: z.ZodOptional<z.ZodString>;
        nan: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>>;
    display: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodArray<z.ZodString>>>;
}, z.core.$strict>;
/** The table a chart draws: columns, rows, and optional pre-rendered strings. */
export type ChartData = z.infer<typeof chartDataSchema>;
export {};
