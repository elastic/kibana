import type { HeatmapNode } from '../schema/heatmap';
import { type ResolveChartOptions } from './common';
import type { HeatmapScene } from './types';
/** The least double above `value`, so a band's inclusive top is an exclusive `end`. */
export declare const nextUp: (value: number) => number;
/** The Scene of a `heatmap` node. */
export declare const resolveHeatmap: (node: HeatmapNode, options: ResolveChartOptions) => HeatmapScene;
