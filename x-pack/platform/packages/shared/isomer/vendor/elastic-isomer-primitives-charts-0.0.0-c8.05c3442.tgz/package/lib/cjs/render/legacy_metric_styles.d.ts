/**
 * The legacy metric's handles, laid out as Kibana's `legacyMtrVis` container
 * and `legacyMtrVis__container` tiles, and the vars a Scene's colors and sizes
 * reach them through.
 */
export declare const legacyMetricModule: {
    handles: {
        root: import("@elastic/distillate").StyleHandle;
        tile: import("@elastic/distillate").StyleHandle;
        selectable: import("@elastic/distillate").StyleHandle;
        align: {
            left: import("@elastic/distillate").StyleHandle;
            center: import("@elastic/distillate").StyleHandle;
            right: import("@elastic/distillate").StyleHandle;
        };
        text: import("@elastic/distillate").StyleHandle;
        label: {
            top: import("@elastic/distillate").StyleHandle;
            bottom: import("@elastic/distillate").StyleHandle;
        };
        empty: import("@elastic/distillate").StyleHandle;
    };
    vars: {
        box: import("@elastic/distillate").LocalVarGroup<"fill" | "width" | "height" | "ink">;
        tile: import("@elastic/distillate").LocalVarGroup<"fill" | "padding">;
        text: import("@elastic/distillate").LocalVarGroup<"color" | "size" | "lineHeight" | "weight">;
    };
    stylesheet: () => string;
};
