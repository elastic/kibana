import type { ReactSceneRenderer } from './context';
/**
 * The pack's own renderer for legacy metric Scenes. Kibana draws a legacy
 * metric with no chart engine, so the pack does, the same in the browser and
 * on Node, at the Scene's size.
 */
export declare const legacyMetricSceneRenderer: ReactSceneRenderer;
