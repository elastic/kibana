import type { PrimitiveExample } from '@elastic/isomer-sdk/schema';
import type { DataTableNode } from '../data_table';
/** A `dataTable` of the top hosts. The catalog's example. */
export declare const dataTableTopHosts: DataTableNode;
/** Named `dataTable` examples covering the corpus edge cases, each valid in a composition. */
export declare const dataTableExamples: PrimitiveExample<DataTableNode>[];
