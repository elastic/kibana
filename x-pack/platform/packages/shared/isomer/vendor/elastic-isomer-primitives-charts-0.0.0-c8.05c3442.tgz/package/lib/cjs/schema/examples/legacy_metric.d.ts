import type { PrimitiveExample } from '@elastic/isomer-sdk/schema';
import type { LegacyMetricNode } from '../legacy_metric';
/** The smallest `legacyMetric`: one value from one row. The catalog's example. */
export declare const legacyMetricSingleValue: LegacyMetricNode;
/** Named `legacyMetric` examples covering the corpus edge cases, each valid in a composition. */
export declare const legacyMetricExamples: PrimitiveExample<LegacyMetricNode>[];
