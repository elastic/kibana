/** The shared URL validation check for navigation links in this pack. */
export declare const navigationHrefSchema: import("zod").ZodString;
