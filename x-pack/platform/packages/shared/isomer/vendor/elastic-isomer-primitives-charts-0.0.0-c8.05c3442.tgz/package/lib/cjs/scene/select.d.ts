import type { SceneEnvironment, SceneKind, SceneRenderer } from './types';
/**
 * The renderer that draws a Scene: the first in `preferences` that runs in
 * `environment` and supports `kind`. `undefined` when none does.
 */
export declare const selectSceneRenderer: <TOutput>(preferences: readonly SceneRenderer<TOutput>[], kind: SceneKind, environment: SceneEnvironment) => SceneRenderer<TOutput> | undefined;
