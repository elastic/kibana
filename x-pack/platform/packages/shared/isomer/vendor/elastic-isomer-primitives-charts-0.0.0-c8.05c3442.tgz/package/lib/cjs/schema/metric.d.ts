import { type PrimitiveNode, z } from '@elastic/isomer-sdk/schema';
/** The cross-field rules `metricSchema` states in its description, one sentence each. */
export declare const METRIC_RULES: {
    readonly columnType: "A bar `max` and a trend `y` are `number` columns; a trend `x` is a `date` or `number` column.";
    readonly operands: "A `compare` secondary column is a single-valued `number` column, as is the headline `value` column when `background` is a bar or `color` is `bands`.";
    readonly trendColumns: "Trend column references name a column in `background.data.columns`.";
    readonly oneRow: "Without a `breakdown`, `data` holds at most one row.";
    readonly bands: "A `bands` color needs `colors.bands`.";
    readonly trendBreakdown: "A trend `breakdown` needs a `breakdown` on the metric.";
};
/** A metric: one headline value per tile, with optional secondary value, progress bar or trend. */
export declare const metricSchema: z.ZodObject<{
    interactions: z.ZodOptional<z.ZodObject<{
        select: z.ZodOptional<z.ZodArray<z.ZodEnum<{
            tile: "tile";
        }>>>;
        sync: z.ZodOptional<z.ZodObject<{
            cursor: z.ZodOptional<z.ZodBoolean>;
            tooltips: z.ZodOptional<z.ZodBoolean>;
        }, z.core.$strict>>;
        link: z.ZodOptional<z.ZodObject<{
            href: z.ZodString;
            label: z.ZodString;
        }, z.core.$strict>>;
    }, z.core.$strict>>;
    value: z.ZodObject<{
        column: z.ZodString;
        subtitle: z.ZodOptional<z.ZodString>;
        color: z.ZodOptional<z.ZodUnion<readonly [z.ZodUnion<readonly [z.ZodObject<{
            light: z.ZodString;
            dark: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            token: z.ZodEnum<{
                text: "text";
                textSubdued: "textSubdued";
                axis: "axis";
                gridLine: "gridLine";
                background: "background";
                border: "border";
            }>;
        }, z.core.$strict>, z.ZodObject<{
            palette: z.ZodLiteral<"categorical">;
            index: z.ZodInt;
        }, z.core.$strict>]>, z.ZodLiteral<"bands">]>>;
        bandsRange: z.ZodOptional<z.ZodEnum<{
            percentage: "percentage";
            absolute: "absolute";
        }>>;
        applyColorTo: z.ZodOptional<z.ZodEnum<{
            value: "value";
            background: "background";
        }>>;
    }, z.core.$strict>;
    secondary: z.ZodOptional<z.ZodObject<{
        column: z.ZodString;
        showLabel: z.ZodOptional<z.ZodBoolean>;
        labelPlacement: z.ZodOptional<z.ZodEnum<{
            before: "before";
            after: "after";
            tooltip: "tooltip";
        }>>;
        color: z.ZodOptional<z.ZodUnion<readonly [z.ZodObject<{
            light: z.ZodString;
            dark: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            token: z.ZodEnum<{
                text: "text";
                textSubdued: "textSubdued";
                axis: "axis";
                gridLine: "gridLine";
                background: "background";
                border: "border";
            }>;
        }, z.core.$strict>, z.ZodObject<{
            palette: z.ZodLiteral<"categorical">;
            index: z.ZodInt;
        }, z.core.$strict>]>>;
        compare: z.ZodOptional<z.ZodObject<{
            to: z.ZodEnum<{
                baseline: "baseline";
                primary: "primary";
            }>;
            baseline: z.ZodOptional<z.ZodNumber>;
            showIcon: z.ZodOptional<z.ZodBoolean>;
            showValue: z.ZodOptional<z.ZodBoolean>;
            colors: z.ZodObject<{
                increase: z.ZodUnion<readonly [z.ZodObject<{
                    light: z.ZodString;
                    dark: z.ZodString;
                }, z.core.$strict>, z.ZodObject<{
                    token: z.ZodEnum<{
                        text: "text";
                        textSubdued: "textSubdued";
                        axis: "axis";
                        gridLine: "gridLine";
                        background: "background";
                        border: "border";
                    }>;
                }, z.core.$strict>, z.ZodObject<{
                    palette: z.ZodLiteral<"categorical">;
                    index: z.ZodInt;
                }, z.core.$strict>]>;
                decrease: z.ZodUnion<readonly [z.ZodObject<{
                    light: z.ZodString;
                    dark: z.ZodString;
                }, z.core.$strict>, z.ZodObject<{
                    token: z.ZodEnum<{
                        text: "text";
                        textSubdued: "textSubdued";
                        axis: "axis";
                        gridLine: "gridLine";
                        background: "background";
                        border: "border";
                    }>;
                }, z.core.$strict>, z.ZodObject<{
                    palette: z.ZodLiteral<"categorical">;
                    index: z.ZodInt;
                }, z.core.$strict>]>;
                neutral: z.ZodUnion<readonly [z.ZodObject<{
                    light: z.ZodString;
                    dark: z.ZodString;
                }, z.core.$strict>, z.ZodObject<{
                    token: z.ZodEnum<{
                        text: "text";
                        textSubdued: "textSubdued";
                        axis: "axis";
                        gridLine: "gridLine";
                        background: "background";
                        border: "border";
                    }>;
                }, z.core.$strict>, z.ZodObject<{
                    palette: z.ZodLiteral<"categorical">;
                    index: z.ZodInt;
                }, z.core.$strict>]>;
            }, z.core.$strict>;
        }, z.core.$strict>>;
    }, z.core.$strict>>;
    background: z.ZodOptional<z.ZodDiscriminatedUnion<[z.ZodObject<{
        kind: z.ZodLiteral<"bar">;
        max: z.ZodString;
        orientation: z.ZodOptional<z.ZodEnum<{
            horizontal: "horizontal";
            vertical: "vertical";
        }>>;
    }, z.core.$strict>, z.ZodObject<{
        kind: z.ZodLiteral<"trend">;
        data: z.ZodObject<{
            columns: z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                label: z.ZodString;
                type: z.ZodEnum<{
                    string: "string";
                    number: "number";
                    boolean: "boolean";
                    date: "date";
                }>;
                role: z.ZodEnum<{
                    dimension: "dimension";
                    metric: "metric";
                }>;
                format: z.ZodOptional<z.ZodDiscriminatedUnion<[z.ZodObject<{
                    notation: z.ZodOptional<z.ZodEnum<{
                        standard: "standard";
                        compact: "compact";
                    }>>;
                    minimumFractionDigits: z.ZodOptional<z.ZodInt>;
                    maximumFractionDigits: z.ZodOptional<z.ZodInt>;
                    signDisplay: z.ZodOptional<z.ZodEnum<{
                        auto: "auto";
                        always: "always";
                        exceptZero: "exceptZero";
                        never: "never";
                    }>>;
                    useGrouping: z.ZodOptional<z.ZodBoolean>;
                    suffix: z.ZodOptional<z.ZodString>;
                    kind: z.ZodLiteral<"number">;
                }, z.core.$strict>, z.ZodObject<{
                    fractional: z.ZodOptional<z.ZodBoolean>;
                    minimumFractionDigits: z.ZodOptional<z.ZodInt>;
                    maximumFractionDigits: z.ZodOptional<z.ZodInt>;
                    signDisplay: z.ZodOptional<z.ZodEnum<{
                        auto: "auto";
                        always: "always";
                        exceptZero: "exceptZero";
                        never: "never";
                    }>>;
                    useGrouping: z.ZodOptional<z.ZodBoolean>;
                    suffix: z.ZodOptional<z.ZodString>;
                    kind: z.ZodLiteral<"percent">;
                }, z.core.$strict>, z.ZodObject<{
                    base: z.ZodOptional<z.ZodUnion<readonly [z.ZodLiteral<1000>, z.ZodLiteral<1024>]>>;
                    unitDisplay: z.ZodOptional<z.ZodEnum<{
                        long: "long";
                        short: "short";
                        narrow: "narrow";
                    }>>;
                    minimumFractionDigits: z.ZodOptional<z.ZodInt>;
                    maximumFractionDigits: z.ZodOptional<z.ZodInt>;
                    signDisplay: z.ZodOptional<z.ZodEnum<{
                        auto: "auto";
                        always: "always";
                        exceptZero: "exceptZero";
                        never: "never";
                    }>>;
                    useGrouping: z.ZodOptional<z.ZodBoolean>;
                    suffix: z.ZodOptional<z.ZodString>;
                    kind: z.ZodLiteral<"bytes">;
                }, z.core.$strict>, z.ZodObject<{
                    base: z.ZodOptional<z.ZodUnion<readonly [z.ZodLiteral<1000>, z.ZodLiteral<1024>]>>;
                    unitDisplay: z.ZodOptional<z.ZodEnum<{
                        long: "long";
                        short: "short";
                        narrow: "narrow";
                    }>>;
                    minimumFractionDigits: z.ZodOptional<z.ZodInt>;
                    maximumFractionDigits: z.ZodOptional<z.ZodInt>;
                    signDisplay: z.ZodOptional<z.ZodEnum<{
                        auto: "auto";
                        always: "always";
                        exceptZero: "exceptZero";
                        never: "never";
                    }>>;
                    useGrouping: z.ZodOptional<z.ZodBoolean>;
                    suffix: z.ZodOptional<z.ZodString>;
                    kind: z.ZodLiteral<"bits">;
                }, z.core.$strict>, z.ZodObject<{
                    unitDisplay: z.ZodOptional<z.ZodEnum<{
                        long: "long";
                        short: "short";
                        narrow: "narrow";
                    }>>;
                    minimumFractionDigits: z.ZodOptional<z.ZodInt>;
                    maximumFractionDigits: z.ZodOptional<z.ZodInt>;
                    signDisplay: z.ZodOptional<z.ZodEnum<{
                        auto: "auto";
                        always: "always";
                        exceptZero: "exceptZero";
                        never: "never";
                    }>>;
                    useGrouping: z.ZodOptional<z.ZodBoolean>;
                    suffix: z.ZodOptional<z.ZodString>;
                    kind: z.ZodLiteral<"duration">;
                    input: z.ZodEnum<{
                        picoseconds: "picoseconds";
                        nanoseconds: "nanoseconds";
                        microseconds: "microseconds";
                        milliseconds: "milliseconds";
                        seconds: "seconds";
                        minutes: "minutes";
                        hours: "hours";
                        days: "days";
                        weeks: "weeks";
                        months: "months";
                        years: "years";
                    }>;
                    output: z.ZodOptional<z.ZodUnion<readonly [z.ZodEnum<{
                        nanoseconds: "nanoseconds";
                        microseconds: "microseconds";
                        milliseconds: "milliseconds";
                        seconds: "seconds";
                        minutes: "minutes";
                        hours: "hours";
                        days: "days";
                        weeks: "weeks";
                        months: "months";
                        years: "years";
                    }>, z.ZodLiteral<"auto">]>>;
                }, z.core.$strict>, z.ZodObject<{
                    kind: z.ZodLiteral<"date">;
                    timeZone: z.ZodOptional<z.ZodString>;
                    dateStyle: z.ZodOptional<z.ZodEnum<{
                        long: "long";
                        short: "short";
                        full: "full";
                        medium: "medium";
                    }>>;
                    timeStyle: z.ZodOptional<z.ZodEnum<{
                        long: "long";
                        short: "short";
                        full: "full";
                        medium: "medium";
                    }>>;
                    weekday: z.ZodOptional<z.ZodEnum<{
                        long: "long";
                        short: "short";
                        narrow: "narrow";
                    }>>;
                    year: z.ZodOptional<z.ZodEnum<{
                        numeric: "numeric";
                        "2-digit": "2-digit";
                    }>>;
                    month: z.ZodOptional<z.ZodEnum<{
                        long: "long";
                        short: "short";
                        narrow: "narrow";
                        numeric: "numeric";
                        "2-digit": "2-digit";
                    }>>;
                    day: z.ZodOptional<z.ZodEnum<{
                        numeric: "numeric";
                        "2-digit": "2-digit";
                    }>>;
                    hour: z.ZodOptional<z.ZodEnum<{
                        numeric: "numeric";
                        "2-digit": "2-digit";
                    }>>;
                    minute: z.ZodOptional<z.ZodEnum<{
                        numeric: "numeric";
                        "2-digit": "2-digit";
                    }>>;
                    second: z.ZodOptional<z.ZodEnum<{
                        numeric: "numeric";
                        "2-digit": "2-digit";
                    }>>;
                    fractionalSecondDigits: z.ZodOptional<z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>, z.ZodLiteral<3>]>>;
                    hour12: z.ZodOptional<z.ZodBoolean>;
                    timeZoneName: z.ZodOptional<z.ZodEnum<{
                        long: "long";
                        short: "short";
                        shortOffset: "shortOffset";
                        longOffset: "longOffset";
                    }>>;
                }, z.core.$strict>, z.ZodObject<{
                    kind: z.ZodLiteral<"text">;
                }, z.core.$strict>], "kind">>;
                multivalue: z.ZodOptional<z.ZodLiteral<true>>;
                source: z.ZodOptional<z.ZodUnknown>;
            }, z.core.$strict>>;
            rows: z.ZodArray<z.ZodArray<z.ZodUnion<readonly [z.ZodUnion<readonly [z.ZodNumber, z.ZodString, z.ZodBoolean, z.ZodNull]>, z.ZodArray<z.ZodUnion<readonly [z.ZodNumber, z.ZodString, z.ZodBoolean, z.ZodNull]>>]>>>;
            source: z.ZodOptional<z.ZodUnknown>;
            missing: z.ZodOptional<z.ZodObject<{
                null: z.ZodOptional<z.ZodString>;
                empty: z.ZodOptional<z.ZodString>;
                nan: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>>;
            display: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodArray<z.ZodString>>>;
        }, z.core.$strict>;
        x: z.ZodString;
        y: z.ZodString;
        breakdown: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>], "kind">>;
    breakdown: z.ZodOptional<z.ZodObject<{
        column: z.ZodString;
        maxColumns: z.ZodOptional<z.ZodInt>;
    }, z.core.$strict>>;
    layout: z.ZodOptional<z.ZodObject<{
        density: z.ZodOptional<z.ZodEnum<{
            default: "default";
            compact: "compact";
        }>>;
        icon: z.ZodOptional<z.ZodObject<{
            name: z.ZodEnum<{
                alert: "alert";
                asterisk: "asterisk";
                bell: "bell";
                bolt: "bolt";
                bug: "bug";
                circle: "circle";
                comment: "comment";
                external: "external";
                flag: "flag";
                globe: "globe";
                heart: "heart";
                marker: "marker";
                pin: "pin";
                pinFilled: "pinFilled";
                processor: "processor";
                sortDown: "sortDown";
                sortUp: "sortUp";
                star: "star";
                starFilled: "starFilled";
                tag: "tag";
                temperature: "temperature";
                triangle: "triangle";
            }>;
            alignment: z.ZodOptional<z.ZodEnum<{
                left: "left";
                right: "right";
            }>>;
        }, z.core.$strict>>;
        valuePosition: z.ZodOptional<z.ZodEnum<{
            top: "top";
            middle: "middle";
            bottom: "bottom";
        }>>;
        labelsAlignment: z.ZodOptional<z.ZodEnum<{
            left: "left";
            center: "center";
            right: "right";
        }>>;
        valueAlignment: z.ZodOptional<z.ZodEnum<{
            left: "left";
            center: "center";
            right: "right";
        }>>;
        valueSizing: z.ZodOptional<z.ZodEnum<{
            fill: "fill";
            auto: "auto";
        }>>;
        secondaryAlignment: z.ZodOptional<z.ZodEnum<{
            left: "left";
            center: "center";
            right: "right";
        }>>;
    }, z.core.$strict>>;
    emphasis: z.ZodOptional<z.ZodArray<z.ZodObject<{
        rows: z.ZodArray<z.ZodInt>;
        note: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>>>;
    title: z.ZodOptional<z.ZodString>;
    description: z.ZodOptional<z.ZodString>;
    data: z.ZodObject<{
        columns: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            label: z.ZodString;
            type: z.ZodEnum<{
                string: "string";
                number: "number";
                boolean: "boolean";
                date: "date";
            }>;
            role: z.ZodEnum<{
                dimension: "dimension";
                metric: "metric";
            }>;
            format: z.ZodOptional<z.ZodDiscriminatedUnion<[z.ZodObject<{
                notation: z.ZodOptional<z.ZodEnum<{
                    standard: "standard";
                    compact: "compact";
                }>>;
                minimumFractionDigits: z.ZodOptional<z.ZodInt>;
                maximumFractionDigits: z.ZodOptional<z.ZodInt>;
                signDisplay: z.ZodOptional<z.ZodEnum<{
                    auto: "auto";
                    always: "always";
                    exceptZero: "exceptZero";
                    never: "never";
                }>>;
                useGrouping: z.ZodOptional<z.ZodBoolean>;
                suffix: z.ZodOptional<z.ZodString>;
                kind: z.ZodLiteral<"number">;
            }, z.core.$strict>, z.ZodObject<{
                fractional: z.ZodOptional<z.ZodBoolean>;
                minimumFractionDigits: z.ZodOptional<z.ZodInt>;
                maximumFractionDigits: z.ZodOptional<z.ZodInt>;
                signDisplay: z.ZodOptional<z.ZodEnum<{
                    auto: "auto";
                    always: "always";
                    exceptZero: "exceptZero";
                    never: "never";
                }>>;
                useGrouping: z.ZodOptional<z.ZodBoolean>;
                suffix: z.ZodOptional<z.ZodString>;
                kind: z.ZodLiteral<"percent">;
            }, z.core.$strict>, z.ZodObject<{
                base: z.ZodOptional<z.ZodUnion<readonly [z.ZodLiteral<1000>, z.ZodLiteral<1024>]>>;
                unitDisplay: z.ZodOptional<z.ZodEnum<{
                    long: "long";
                    short: "short";
                    narrow: "narrow";
                }>>;
                minimumFractionDigits: z.ZodOptional<z.ZodInt>;
                maximumFractionDigits: z.ZodOptional<z.ZodInt>;
                signDisplay: z.ZodOptional<z.ZodEnum<{
                    auto: "auto";
                    always: "always";
                    exceptZero: "exceptZero";
                    never: "never";
                }>>;
                useGrouping: z.ZodOptional<z.ZodBoolean>;
                suffix: z.ZodOptional<z.ZodString>;
                kind: z.ZodLiteral<"bytes">;
            }, z.core.$strict>, z.ZodObject<{
                base: z.ZodOptional<z.ZodUnion<readonly [z.ZodLiteral<1000>, z.ZodLiteral<1024>]>>;
                unitDisplay: z.ZodOptional<z.ZodEnum<{
                    long: "long";
                    short: "short";
                    narrow: "narrow";
                }>>;
                minimumFractionDigits: z.ZodOptional<z.ZodInt>;
                maximumFractionDigits: z.ZodOptional<z.ZodInt>;
                signDisplay: z.ZodOptional<z.ZodEnum<{
                    auto: "auto";
                    always: "always";
                    exceptZero: "exceptZero";
                    never: "never";
                }>>;
                useGrouping: z.ZodOptional<z.ZodBoolean>;
                suffix: z.ZodOptional<z.ZodString>;
                kind: z.ZodLiteral<"bits">;
            }, z.core.$strict>, z.ZodObject<{
                unitDisplay: z.ZodOptional<z.ZodEnum<{
                    long: "long";
                    short: "short";
                    narrow: "narrow";
                }>>;
                minimumFractionDigits: z.ZodOptional<z.ZodInt>;
                maximumFractionDigits: z.ZodOptional<z.ZodInt>;
                signDisplay: z.ZodOptional<z.ZodEnum<{
                    auto: "auto";
                    always: "always";
                    exceptZero: "exceptZero";
                    never: "never";
                }>>;
                useGrouping: z.ZodOptional<z.ZodBoolean>;
                suffix: z.ZodOptional<z.ZodString>;
                kind: z.ZodLiteral<"duration">;
                input: z.ZodEnum<{
                    picoseconds: "picoseconds";
                    nanoseconds: "nanoseconds";
                    microseconds: "microseconds";
                    milliseconds: "milliseconds";
                    seconds: "seconds";
                    minutes: "minutes";
                    hours: "hours";
                    days: "days";
                    weeks: "weeks";
                    months: "months";
                    years: "years";
                }>;
                output: z.ZodOptional<z.ZodUnion<readonly [z.ZodEnum<{
                    nanoseconds: "nanoseconds";
                    microseconds: "microseconds";
                    milliseconds: "milliseconds";
                    seconds: "seconds";
                    minutes: "minutes";
                    hours: "hours";
                    days: "days";
                    weeks: "weeks";
                    months: "months";
                    years: "years";
                }>, z.ZodLiteral<"auto">]>>;
            }, z.core.$strict>, z.ZodObject<{
                kind: z.ZodLiteral<"date">;
                timeZone: z.ZodOptional<z.ZodString>;
                dateStyle: z.ZodOptional<z.ZodEnum<{
                    long: "long";
                    short: "short";
                    full: "full";
                    medium: "medium";
                }>>;
                timeStyle: z.ZodOptional<z.ZodEnum<{
                    long: "long";
                    short: "short";
                    full: "full";
                    medium: "medium";
                }>>;
                weekday: z.ZodOptional<z.ZodEnum<{
                    long: "long";
                    short: "short";
                    narrow: "narrow";
                }>>;
                year: z.ZodOptional<z.ZodEnum<{
                    numeric: "numeric";
                    "2-digit": "2-digit";
                }>>;
                month: z.ZodOptional<z.ZodEnum<{
                    long: "long";
                    short: "short";
                    narrow: "narrow";
                    numeric: "numeric";
                    "2-digit": "2-digit";
                }>>;
                day: z.ZodOptional<z.ZodEnum<{
                    numeric: "numeric";
                    "2-digit": "2-digit";
                }>>;
                hour: z.ZodOptional<z.ZodEnum<{
                    numeric: "numeric";
                    "2-digit": "2-digit";
                }>>;
                minute: z.ZodOptional<z.ZodEnum<{
                    numeric: "numeric";
                    "2-digit": "2-digit";
                }>>;
                second: z.ZodOptional<z.ZodEnum<{
                    numeric: "numeric";
                    "2-digit": "2-digit";
                }>>;
                fractionalSecondDigits: z.ZodOptional<z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>, z.ZodLiteral<3>]>>;
                hour12: z.ZodOptional<z.ZodBoolean>;
                timeZoneName: z.ZodOptional<z.ZodEnum<{
                    long: "long";
                    short: "short";
                    shortOffset: "shortOffset";
                    longOffset: "longOffset";
                }>>;
            }, z.core.$strict>, z.ZodObject<{
                kind: z.ZodLiteral<"text">;
            }, z.core.$strict>], "kind">>;
            multivalue: z.ZodOptional<z.ZodLiteral<true>>;
            source: z.ZodOptional<z.ZodUnknown>;
        }, z.core.$strict>>;
        rows: z.ZodArray<z.ZodArray<z.ZodUnion<readonly [z.ZodUnion<readonly [z.ZodNumber, z.ZodString, z.ZodBoolean, z.ZodNull]>, z.ZodArray<z.ZodUnion<readonly [z.ZodNumber, z.ZodString, z.ZodBoolean, z.ZodNull]>>]>>>;
        source: z.ZodOptional<z.ZodUnknown>;
        missing: z.ZodOptional<z.ZodObject<{
            null: z.ZodOptional<z.ZodString>;
            empty: z.ZodOptional<z.ZodString>;
            nan: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>;
        display: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodArray<z.ZodString>>>;
    }, z.core.$strict>;
    colors: z.ZodOptional<z.ZodObject<{
        byKey: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodObject<{
            light: z.ZodString;
            dark: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            token: z.ZodEnum<{
                text: "text";
                textSubdued: "textSubdued";
                axis: "axis";
                gridLine: "gridLine";
                background: "background";
                border: "border";
            }>;
        }, z.core.$strict>, z.ZodObject<{
            palette: z.ZodLiteral<"categorical">;
            index: z.ZodInt;
        }, z.core.$strict>]>>>;
        bands: z.ZodOptional<z.ZodArray<z.ZodObject<{
            from: z.ZodOptional<z.ZodNumber>;
            to: z.ZodOptional<z.ZodNumber>;
            color: z.ZodUnion<readonly [z.ZodObject<{
                light: z.ZodString;
                dark: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                token: z.ZodEnum<{
                    text: "text";
                    textSubdued: "textSubdued";
                    axis: "axis";
                    gridLine: "gridLine";
                    background: "background";
                    border: "border";
                }>;
            }, z.core.$strict>, z.ZodObject<{
                palette: z.ZodLiteral<"categorical">;
                index: z.ZodInt;
            }, z.core.$strict>]>;
        }, z.core.$strict>>>;
    }, z.core.$strict>>;
    source: z.ZodOptional<z.ZodObject<{
        host: z.ZodString;
        hostVersion: z.ZodOptional<z.ZodString>;
        capturedAt: z.ZodISODateTime;
        timeRange: z.ZodOptional<z.ZodObject<{
            from: z.ZodISODateTime;
            to: z.ZodISODateTime;
        }, z.core.$strict>>;
        meta: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnknown>>;
    }, z.core.$strict>>;
    losses: z.ZodOptional<z.ZodArray<z.ZodObject<{
        path: z.ZodString;
        kind: z.ZodEnum<{
            dropped: "dropped";
            approximated: "approximated";
            prerendered: "prerendered";
        }>;
        note: z.ZodString;
    }, z.core.$strict>>>;
    type: z.ZodLiteral<"metric">;
}, z.core.$strip>;
/** A validated `metric` node. */
export type MetricNode = z.infer<typeof metricSchema> & PrimitiveNode;
