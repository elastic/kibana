import { type SlackBlock } from '@elastic/isomer-sdk/slack';
import type { TableScene } from '../scene/types';
/** A table Scene as Slack blocks: its summary, description and notes as paragraphs, then a native `table` block of its strings in starting order, without empty columns and within Slack's caps, then its link. */
export declare const tableSceneToSlack: (scene: TableScene, baseUrl?: string) => SlackBlock[];
