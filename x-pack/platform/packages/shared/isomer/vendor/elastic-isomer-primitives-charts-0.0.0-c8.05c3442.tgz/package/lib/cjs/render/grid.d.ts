import { type PrimitiveNode, type z } from '@elastic/isomer-sdk';
import { type GridNode } from '../schema/grid';
/** The `snapshot` height of a grid laid out at full width. */
export declare const gridSnapshotHeight: (node: GridNode) => number;
/** Panels on a 48-column grid; one column, in reading order, below the threshold width. */
export declare const gridPrimitive: import("@elastic/isomer-sdk").PrimitiveDefinition<GridNode<PrimitiveNode>, import("./context").ChartsPackTypes, z.ZodObject<z.core.$ZodLooseShape & {
    id: ReturnType<() => z.ZodOptional<z.ZodString>>;
    surfaces: ReturnType<() => z.ZodOptional<z.ZodArray<z.ZodEnum<{
        react: "react";
        snapshot: "snapshot";
        text: "text";
        markdown: "markdown";
        slack: "slack";
    }>>>>;
}, z.core.$strip>>;
