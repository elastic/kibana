import { z } from '@elastic/isomer-sdk/schema';
/** The rules a check from this module states, or `undefined` for any other check. */
export declare const rulesOf: (check: object) => readonly string[] | undefined;
/**
 * A `.check()` that adds its own issues and runs even after a field fails, so
 * one validation reports every problem. `rules` are the sentences, word for
 * word, that a description in the authoring JSON Schema states, one for each
 * kind of issue the check raises.
 *
 * ```ts
 * schema.check(
 *   crossSuperRefine<Node>(
 *     ({ rows }, context) => {
 *       if (rows.length > 1) {
 *         context.addIssue({ code: 'custom', path: ['rows'], message: RULES.oneRow });
 *       }
 *     },
 *     [RULES.oneRow]
 *   )
 * );
 * ```
 */
export declare const crossSuperRefine: <T>(refine: (value: T, context: z.core.$RefinementCtx<T>) => void, rules: readonly [string, ...string[]]) => z.core.$ZodCheck<T>;
