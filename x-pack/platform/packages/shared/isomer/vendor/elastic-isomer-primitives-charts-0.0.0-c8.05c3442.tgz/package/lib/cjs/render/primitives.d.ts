import { type DataTableNode } from '../schema/data_table';
import type { ChartNode } from './context';
import { type SceneShimConfig } from './scene_node';
/** The chart primitives, each drawing through `config`. */
export declare const defineChartPrimitives: (config: SceneShimConfig) => readonly [import("@elastic/isomer-sdk").PrimitiveDefinition<ChartNode, import("./context").ChartsPackTypes, import("zod").ZodObject<{
    interactions: import("zod").ZodOptional<import("zod").ZodObject<{
        select: import("zod").ZodOptional<import("zod").ZodArray<import("zod").ZodEnum<{
            tile: "tile";
        }>>>;
        sync: import("zod").ZodOptional<import("zod").ZodObject<{
            cursor: import("zod").ZodOptional<import("zod").ZodBoolean>;
            tooltips: import("zod").ZodOptional<import("zod").ZodBoolean>;
        }, import("zod/v4/core").$strict>>;
        link: import("zod").ZodOptional<import("zod").ZodObject<{
            href: import("zod").ZodString;
            label: import("zod").ZodString;
        }, import("zod/v4/core").$strict>>;
    }, import("zod/v4/core").$strict>>;
    value: import("zod").ZodObject<{
        column: import("zod").ZodString;
        subtitle: import("zod").ZodOptional<import("zod").ZodString>;
        color: import("zod").ZodOptional<import("zod").ZodUnion<readonly [import("zod").ZodUnion<readonly [import("zod").ZodObject<{
            light: import("zod").ZodString;
            dark: import("zod").ZodString;
        }, import("zod/v4/core").$strict>, import("zod").ZodObject<{
            token: import("zod").ZodEnum<{
                text: "text";
                textSubdued: "textSubdued";
                axis: "axis";
                gridLine: "gridLine";
                background: "background";
                border: "border";
            }>;
        }, import("zod/v4/core").$strict>, import("zod").ZodObject<{
            palette: import("zod").ZodLiteral<"categorical">;
            index: import("zod").ZodInt;
        }, import("zod/v4/core").$strict>]>, import("zod").ZodLiteral<"bands">]>>;
        bandsRange: import("zod").ZodOptional<import("zod").ZodEnum<{
            percentage: "percentage";
            absolute: "absolute";
        }>>;
        applyColorTo: import("zod").ZodOptional<import("zod").ZodEnum<{
            value: "value";
            background: "background";
        }>>;
    }, import("zod/v4/core").$strict>;
    secondary: import("zod").ZodOptional<import("zod").ZodObject<{
        column: import("zod").ZodString;
        showLabel: import("zod").ZodOptional<import("zod").ZodBoolean>;
        labelPlacement: import("zod").ZodOptional<import("zod").ZodEnum<{
            before: "before";
            after: "after";
            tooltip: "tooltip";
        }>>;
        color: import("zod").ZodOptional<import("zod").ZodUnion<readonly [import("zod").ZodObject<{
            light: import("zod").ZodString;
            dark: import("zod").ZodString;
        }, import("zod/v4/core").$strict>, import("zod").ZodObject<{
            token: import("zod").ZodEnum<{
                text: "text";
                textSubdued: "textSubdued";
                axis: "axis";
                gridLine: "gridLine";
                background: "background";
                border: "border";
            }>;
        }, import("zod/v4/core").$strict>, import("zod").ZodObject<{
            palette: import("zod").ZodLiteral<"categorical">;
            index: import("zod").ZodInt;
        }, import("zod/v4/core").$strict>]>>;
        compare: import("zod").ZodOptional<import("zod").ZodObject<{
            to: import("zod").ZodEnum<{
                baseline: "baseline";
                primary: "primary";
            }>;
            baseline: import("zod").ZodOptional<import("zod").ZodNumber>;
            showIcon: import("zod").ZodOptional<import("zod").ZodBoolean>;
            showValue: import("zod").ZodOptional<import("zod").ZodBoolean>;
            colors: import("zod").ZodObject<{
                increase: import("zod").ZodUnion<readonly [import("zod").ZodObject<{
                    light: import("zod").ZodString;
                    dark: import("zod").ZodString;
                }, import("zod/v4/core").$strict>, import("zod").ZodObject<{
                    token: import("zod").ZodEnum<{
                        text: "text";
                        textSubdued: "textSubdued";
                        axis: "axis";
                        gridLine: "gridLine";
                        background: "background";
                        border: "border";
                    }>;
                }, import("zod/v4/core").$strict>, import("zod").ZodObject<{
                    palette: import("zod").ZodLiteral<"categorical">;
                    index: import("zod").ZodInt;
                }, import("zod/v4/core").$strict>]>;
                decrease: import("zod").ZodUnion<readonly [import("zod").ZodObject<{
                    light: import("zod").ZodString;
                    dark: import("zod").ZodString;
                }, import("zod/v4/core").$strict>, import("zod").ZodObject<{
                    token: import("zod").ZodEnum<{
                        text: "text";
                        textSubdued: "textSubdued";
                        axis: "axis";
                        gridLine: "gridLine";
                        background: "background";
                        border: "border";
                    }>;
                }, import("zod/v4/core").$strict>, import("zod").ZodObject<{
                    palette: import("zod").ZodLiteral<"categorical">;
                    index: import("zod").ZodInt;
                }, import("zod/v4/core").$strict>]>;
                neutral: import("zod").ZodUnion<readonly [import("zod").ZodObject<{
                    light: import("zod").ZodString;
                    dark: import("zod").ZodString;
                }, import("zod/v4/core").$strict>, import("zod").ZodObject<{
                    token: import("zod").ZodEnum<{
                        text: "text";
                        textSubdued: "textSubdued";
                        axis: "axis";
                        gridLine: "gridLine";
                        background: "background";
                        border: "border";
                    }>;
                }, import("zod/v4/core").$strict>, import("zod").ZodObject<{
                    palette: import("zod").ZodLiteral<"categorical">;
                    index: import("zod").ZodInt;
                }, import("zod/v4/core").$strict>]>;
            }, import("zod/v4/core").$strict>;
        }, import("zod/v4/core").$strict>>;
    }, import("zod/v4/core").$strict>>;
    background: import("zod").ZodOptional<import("zod").ZodDiscriminatedUnion<[import("zod").ZodObject<{
        kind: import("zod").ZodLiteral<"bar">;
        max: import("zod").ZodString;
        orientation: import("zod").ZodOptional<import("zod").ZodEnum<{
            horizontal: "horizontal";
            vertical: "vertical";
        }>>;
    }, import("zod/v4/core").$strict>, import("zod").ZodObject<{
        kind: import("zod").ZodLiteral<"trend">;
        data: import("zod").ZodObject<{
            columns: import("zod").ZodArray<import("zod").ZodObject<{
                id: import("zod").ZodString;
                label: import("zod").ZodString;
                type: import("zod").ZodEnum<{
                    string: "string";
                    number: "number";
                    boolean: "boolean";
                    date: "date";
                }>;
                role: import("zod").ZodEnum<{
                    dimension: "dimension";
                    metric: "metric";
                }>;
                format: import("zod").ZodOptional<import("zod").ZodDiscriminatedUnion<[import("zod").ZodObject<{
                    notation: import("zod").ZodOptional<import("zod").ZodEnum<{
                        standard: "standard";
                        compact: "compact";
                    }>>;
                    minimumFractionDigits: import("zod").ZodOptional<import("zod").ZodInt>;
                    maximumFractionDigits: import("zod").ZodOptional<import("zod").ZodInt>;
                    signDisplay: import("zod").ZodOptional<import("zod").ZodEnum<{
                        auto: "auto";
                        always: "always";
                        exceptZero: "exceptZero";
                        never: "never";
                    }>>;
                    useGrouping: import("zod").ZodOptional<import("zod").ZodBoolean>;
                    suffix: import("zod").ZodOptional<import("zod").ZodString>;
                    kind: import("zod").ZodLiteral<"number">;
                }, import("zod/v4/core").$strict>, import("zod").ZodObject<{
                    fractional: import("zod").ZodOptional<import("zod").ZodBoolean>;
                    minimumFractionDigits: import("zod").ZodOptional<import("zod").ZodInt>;
                    maximumFractionDigits: import("zod").ZodOptional<import("zod").ZodInt>;
                    signDisplay: import("zod").ZodOptional<import("zod").ZodEnum<{
                        auto: "auto";
                        always: "always";
                        exceptZero: "exceptZero";
                        never: "never";
                    }>>;
                    useGrouping: import("zod").ZodOptional<import("zod").ZodBoolean>;
                    suffix: import("zod").ZodOptional<import("zod").ZodString>;
                    kind: import("zod").ZodLiteral<"percent">;
                }, import("zod/v4/core").$strict>, import("zod").ZodObject<{
                    base: import("zod").ZodOptional<import("zod").ZodUnion<readonly [import("zod").ZodLiteral<1000>, import("zod").ZodLiteral<1024>]>>;
                    unitDisplay: import("zod").ZodOptional<import("zod").ZodEnum<{
                        long: "long";
                        short: "short";
                        narrow: "narrow";
                    }>>;
                    minimumFractionDigits: import("zod").ZodOptional<import("zod").ZodInt>;
                    maximumFractionDigits: import("zod").ZodOptional<import("zod").ZodInt>;
                    signDisplay: import("zod").ZodOptional<import("zod").ZodEnum<{
                        auto: "auto";
                        always: "always";
                        exceptZero: "exceptZero";
                        never: "never";
                    }>>;
                    useGrouping: import("zod").ZodOptional<import("zod").ZodBoolean>;
                    suffix: import("zod").ZodOptional<import("zod").ZodString>;
                    kind: import("zod").ZodLiteral<"bytes">;
                }, import("zod/v4/core").$strict>, import("zod").ZodObject<{
                    base: import("zod").ZodOptional<import("zod").ZodUnion<readonly [import("zod").ZodLiteral<1000>, import("zod").ZodLiteral<1024>]>>;
                    unitDisplay: import("zod").ZodOptional<import("zod").ZodEnum<{
                        long: "long";
                        short: "short";
                        narrow: "narrow";
                    }>>;
                    minimumFractionDigits: import("zod").ZodOptional<import("zod").ZodInt>;
                    maximumFractionDigits: import("zod").ZodOptional<import("zod").ZodInt>;
                    signDisplay: import("zod").ZodOptional<import("zod").ZodEnum<{
                        auto: "auto";
                        always: "always";
                        exceptZero: "exceptZero";
                        never: "never";
                    }>>;
                    useGrouping: import("zod").ZodOptional<import("zod").ZodBoolean>;
                    suffix: import("zod").ZodOptional<import("zod").ZodString>;
                    kind: import("zod").ZodLiteral<"bits">;
                }, import("zod/v4/core").$strict>, import("zod").ZodObject<{
                    unitDisplay: import("zod").ZodOptional<import("zod").ZodEnum<{
                        long: "long";
                        short: "short";
                        narrow: "narrow";
                    }>>;
                    minimumFractionDigits: import("zod").ZodOptional<import("zod").ZodInt>;
                    maximumFractionDigits: import("zod").ZodOptional<import("zod").ZodInt>;
                    signDisplay: import("zod").ZodOptional<import("zod").ZodEnum<{
                        auto: "auto";
                        always: "always";
                        exceptZero: "exceptZero";
                        never: "never";
                    }>>;
                    useGrouping: import("zod").ZodOptional<import("zod").ZodBoolean>;
                    suffix: import("zod").ZodOptional<import("zod").ZodString>;
                    kind: import("zod").ZodLiteral<"duration">;
                    input: import("zod").ZodEnum<{
                        picoseconds: "picoseconds";
                        nanoseconds: "nanoseconds";
                        microseconds: "microseconds";
                        milliseconds: "milliseconds";
                        seconds: "seconds";
                        minutes: "minutes";
                        hours: "hours";
                        days: "days";
                        weeks: "weeks";
                        months: "months";
                        years: "years";
                    }>;
                    output: import("zod").ZodOptional<import("zod").ZodUnion<readonly [import("zod").ZodEnum<{
                        nanoseconds: "nanoseconds";
                        microseconds: "microseconds";
                        milliseconds: "milliseconds";
                        seconds: "seconds";
                        minutes: "minutes";
                        hours: "hours";
                        days: "days";
                        weeks: "weeks";
                        months: "months";
                        years: "years";
                    }>, import("zod").ZodLiteral<"auto">]>>;
                }, import("zod/v4/core").$strict>, import("zod").ZodObject<{
                    kind: import("zod").ZodLiteral<"date">;
                    timeZone: import("zod").ZodOptional<import("zod").ZodString>;
                    dateStyle: import("zod").ZodOptional<import("zod").ZodEnum<{
                        long: "long";
                        short: "short";
                        full: "full";
                        medium: "medium";
                    }>>;
                    timeStyle: import("zod").ZodOptional<import("zod").ZodEnum<{
                        long: "long";
                        short: "short";
                        full: "full";
                        medium: "medium";
                    }>>;
                    weekday: import("zod").ZodOptional<import("zod").ZodEnum<{
                        long: "long";
                        short: "short";
                        narrow: "narrow";
                    }>>;
                    year: import("zod").ZodOptional<import("zod").ZodEnum<{
                        numeric: "numeric";
                        "2-digit": "2-digit";
                    }>>;
                    month: import("zod").ZodOptional<import("zod").ZodEnum<{
                        long: "long";
                        short: "short";
                        narrow: "narrow";
                        numeric: "numeric";
                        "2-digit": "2-digit";
                    }>>;
                    day: import("zod").ZodOptional<import("zod").ZodEnum<{
                        numeric: "numeric";
                        "2-digit": "2-digit";
                    }>>;
                    hour: import("zod").ZodOptional<import("zod").ZodEnum<{
                        numeric: "numeric";
                        "2-digit": "2-digit";
                    }>>;
                    minute: import("zod").ZodOptional<import("zod").ZodEnum<{
                        numeric: "numeric";
                        "2-digit": "2-digit";
                    }>>;
                    second: import("zod").ZodOptional<import("zod").ZodEnum<{
                        numeric: "numeric";
                        "2-digit": "2-digit";
                    }>>;
                    fractionalSecondDigits: import("zod").ZodOptional<import("zod").ZodUnion<readonly [import("zod").ZodLiteral<1>, import("zod").ZodLiteral<2>, import("zod").ZodLiteral<3>]>>;
                    hour12: import("zod").ZodOptional<import("zod").ZodBoolean>;
                    timeZoneName: import("zod").ZodOptional<import("zod").ZodEnum<{
                        long: "long";
                        short: "short";
                        shortOffset: "shortOffset";
                        longOffset: "longOffset";
                    }>>;
                }, import("zod/v4/core").$strict>, import("zod").ZodObject<{
                    kind: import("zod").ZodLiteral<"text">;
                }, import("zod/v4/core").$strict>], "kind">>;
                multivalue: import("zod").ZodOptional<import("zod").ZodLiteral<true>>;
                source: import("zod").ZodOptional<import("zod").ZodUnknown>;
            }, import("zod/v4/core").$strict>>;
            rows: import("zod").ZodArray<import("zod").ZodArray<import("zod").ZodUnion<readonly [import("zod").ZodUnion<readonly [import("zod").ZodNumber, import("zod").ZodString, import("zod").ZodBoolean, import("zod").ZodNull]>, import("zod").ZodArray<import("zod").ZodUnion<readonly [import("zod").ZodNumber, import("zod").ZodString, import("zod").ZodBoolean, import("zod").ZodNull]>>]>>>;
            source: import("zod").ZodOptional<import("zod").ZodUnknown>;
            missing: import("zod").ZodOptional<import("zod").ZodObject<{
                null: import("zod").ZodOptional<import("zod").ZodString>;
                empty: import("zod").ZodOptional<import("zod").ZodString>;
                nan: import("zod").ZodOptional<import("zod").ZodString>;
            }, import("zod/v4/core").$strict>>;
            display: import("zod").ZodOptional<import("zod").ZodRecord<import("zod").ZodString, import("zod").ZodArray<import("zod").ZodString>>>;
        }, import("zod/v4/core").$strict>;
        x: import("zod").ZodString;
        y: import("zod").ZodString;
        breakdown: import("zod").ZodOptional<import("zod").ZodString>;
    }, import("zod/v4/core").$strict>], "kind">>;
    breakdown: import("zod").ZodOptional<import("zod").ZodObject<{
        column: import("zod").ZodString;
        maxColumns: import("zod").ZodOptional<import("zod").ZodInt>;
    }, import("zod/v4/core").$strict>>;
    layout: import("zod").ZodOptional<import("zod").ZodObject<{
        density: import("zod").ZodOptional<import("zod").ZodEnum<{
            default: "default";
            compact: "compact";
        }>>;
        icon: import("zod").ZodOptional<import("zod").ZodObject<{
            name: import("zod").ZodEnum<{
                alert: "alert";
                asterisk: "asterisk";
                bell: "bell";
                bolt: "bolt";
                bug: "bug";
                circle: "circle";
                comment: "comment";
                external: "external";
                flag: "flag";
                globe: "globe";
                heart: "heart";
                marker: "marker";
                pin: "pin";
                pinFilled: "pinFilled";
                processor: "processor";
                sortDown: "sortDown";
                sortUp: "sortUp";
                star: "star";
                starFilled: "starFilled";
                tag: "tag";
                temperature: "temperature";
                triangle: "triangle";
            }>;
            alignment: import("zod").ZodOptional<import("zod").ZodEnum<{
                left: "left";
                right: "right";
            }>>;
        }, import("zod/v4/core").$strict>>;
        valuePosition: import("zod").ZodOptional<import("zod").ZodEnum<{
            top: "top";
            middle: "middle";
            bottom: "bottom";
        }>>;
        labelsAlignment: import("zod").ZodOptional<import("zod").ZodEnum<{
            left: "left";
            center: "center";
            right: "right";
        }>>;
        valueAlignment: import("zod").ZodOptional<import("zod").ZodEnum<{
            left: "left";
            center: "center";
            right: "right";
        }>>;
        valueSizing: import("zod").ZodOptional<import("zod").ZodEnum<{
            fill: "fill";
            auto: "auto";
        }>>;
        secondaryAlignment: import("zod").ZodOptional<import("zod").ZodEnum<{
            left: "left";
            center: "center";
            right: "right";
        }>>;
    }, import("zod/v4/core").$strict>>;
    emphasis: import("zod").ZodOptional<import("zod").ZodArray<import("zod").ZodObject<{
        rows: import("zod").ZodArray<import("zod").ZodInt>;
        note: import("zod").ZodOptional<import("zod").ZodString>;
    }, import("zod/v4/core").$strict>>>;
    title: import("zod").ZodOptional<import("zod").ZodString>;
    description: import("zod").ZodOptional<import("zod").ZodString>;
    data: import("zod").ZodObject<{
        columns: import("zod").ZodArray<import("zod").ZodObject<{
            id: import("zod").ZodString;
            label: import("zod").ZodString;
            type: import("zod").ZodEnum<{
                string: "string";
                number: "number";
                boolean: "boolean";
                date: "date";
            }>;
            role: import("zod").ZodEnum<{
                dimension: "dimension";
                metric: "metric";
            }>;
            format: import("zod").ZodOptional<import("zod").ZodDiscriminatedUnion<[import("zod").ZodObject<{
                notation: import("zod").ZodOptional<import("zod").ZodEnum<{
                    standard: "standard";
                    compact: "compact";
                }>>;
                minimumFractionDigits: import("zod").ZodOptional<import("zod").ZodInt>;
                maximumFractionDigits: import("zod").ZodOptional<import("zod").ZodInt>;
                signDisplay: import("zod").ZodOptional<import("zod").ZodEnum<{
                    auto: "auto";
                    always: "always";
                    exceptZero: "exceptZero";
                    never: "never";
                }>>;
                useGrouping: import("zod").ZodOptional<import("zod").ZodBoolean>;
                suffix: import("zod").ZodOptional<import("zod").ZodString>;
                kind: import("zod").ZodLiteral<"number">;
            }, import("zod/v4/core").$strict>, import("zod").ZodObject<{
                fractional: import("zod").ZodOptional<import("zod").ZodBoolean>;
                minimumFractionDigits: import("zod").ZodOptional<import("zod").ZodInt>;
                maximumFractionDigits: import("zod").ZodOptional<import("zod").ZodInt>;
                signDisplay: import("zod").ZodOptional<import("zod").ZodEnum<{
                    auto: "auto";
                    always: "always";
                    exceptZero: "exceptZero";
                    never: "never";
                }>>;
                useGrouping: import("zod").ZodOptional<import("zod").ZodBoolean>;
                suffix: import("zod").ZodOptional<import("zod").ZodString>;
                kind: import("zod").ZodLiteral<"percent">;
            }, import("zod/v4/core").$strict>, import("zod").ZodObject<{
                base: import("zod").ZodOptional<import("zod").ZodUnion<readonly [import("zod").ZodLiteral<1000>, import("zod").ZodLiteral<1024>]>>;
                unitDisplay: import("zod").ZodOptional<import("zod").ZodEnum<{
                    long: "long";
                    short: "short";
                    narrow: "narrow";
                }>>;
                minimumFractionDigits: import("zod").ZodOptional<import("zod").ZodInt>;
                maximumFractionDigits: import("zod").ZodOptional<import("zod").ZodInt>;
                signDisplay: import("zod").ZodOptional<import("zod").ZodEnum<{
                    auto: "auto";
                    always: "always";
                    exceptZero: "exceptZero";
                    never: "never";
                }>>;
                useGrouping: import("zod").ZodOptional<import("zod").ZodBoolean>;
                suffix: import("zod").ZodOptional<import("zod").ZodString>;
                kind: import("zod").ZodLiteral<"bytes">;
            }, import("zod/v4/core").$strict>, import("zod").ZodObject<{
                base: import("zod").ZodOptional<import("zod").ZodUnion<readonly [import("zod").ZodLiteral<1000>, import("zod").ZodLiteral<1024>]>>;
                unitDisplay: import("zod").ZodOptional<import("zod").ZodEnum<{
                    long: "long";
                    short: "short";
                    narrow: "narrow";
                }>>;
                minimumFractionDigits: import("zod").ZodOptional<import("zod").ZodInt>;
                maximumFractionDigits: import("zod").ZodOptional<import("zod").ZodInt>;
                signDisplay: import("zod").ZodOptional<import("zod").ZodEnum<{
                    auto: "auto";
                    always: "always";
                    exceptZero: "exceptZero";
                    never: "never";
                }>>;
                useGrouping: import("zod").ZodOptional<import("zod").ZodBoolean>;
                suffix: import("zod").ZodOptional<import("zod").ZodString>;
                kind: import("zod").ZodLiteral<"bits">;
            }, import("zod/v4/core").$strict>, import("zod").ZodObject<{
                unitDisplay: import("zod").ZodOptional<import("zod").ZodEnum<{
                    long: "long";
                    short: "short";
                    narrow: "narrow";
                }>>;
                minimumFractionDigits: import("zod").ZodOptional<import("zod").ZodInt>;
                maximumFractionDigits: import("zod").ZodOptional<import("zod").ZodInt>;
                signDisplay: import("zod").ZodOptional<import("zod").ZodEnum<{
                    auto: "auto";
                    always: "always";
                    exceptZero: "exceptZero";
                    never: "never";
                }>>;
                useGrouping: import("zod").ZodOptional<import("zod").ZodBoolean>;
                suffix: import("zod").ZodOptional<import("zod").ZodString>;
                kind: import("zod").ZodLiteral<"duration">;
                input: import("zod").ZodEnum<{
                    picoseconds: "picoseconds";
                    nanoseconds: "nanoseconds";
                    microseconds: "microseconds";
                    milliseconds: "milliseconds";
                    seconds: "seconds";
                    minutes: "minutes";
                    hours: "hours";
                    days: "days";
                    weeks: "weeks";
                    months: "months";
                    years: "years";
                }>;
                output: import("zod").ZodOptional<import("zod").ZodUnion<readonly [import("zod").ZodEnum<{
                    nanoseconds: "nanoseconds";
                    microseconds: "microseconds";
                    milliseconds: "milliseconds";
                    seconds: "seconds";
                    minutes: "minutes";
                    hours: "hours";
                    days: "days";
                    weeks: "weeks";
                    months: "months";
                    years: "years";
                }>, import("zod").ZodLiteral<"auto">]>>;
            }, import("zod/v4/core").$strict>, import("zod").ZodObject<{
                kind: import("zod").ZodLiteral<"date">;
                timeZone: import("zod").ZodOptional<import("zod").ZodString>;
                dateStyle: import("zod").ZodOptional<import("zod").ZodEnum<{
                    long: "long";
                    short: "short";
                    full: "full";
                    medium: "medium";
                }>>;
                timeStyle: import("zod").ZodOptional<import("zod").ZodEnum<{
                    long: "long";
                    short: "short";
                    full: "full";
                    medium: "medium";
                }>>;
                weekday: import("zod").ZodOptional<import("zod").ZodEnum<{
                    long: "long";
                    short: "short";
                    narrow: "narrow";
                }>>;
                year: import("zod").ZodOptional<import("zod").ZodEnum<{
                    numeric: "numeric";
                    "2-digit": "2-digit";
                }>>;
                month: import("zod").ZodOptional<import("zod").ZodEnum<{
                    long: "long";
                    short: "short";
                    narrow: "narrow";
                    numeric: "numeric";
                    "2-digit": "2-digit";
                }>>;
                day: import("zod").ZodOptional<import("zod").ZodEnum<{
                    numeric: "numeric";
                    "2-digit": "2-digit";
                }>>;
                hour: import("zod").ZodOptional<import("zod").ZodEnum<{
                    numeric: "numeric";
                    "2-digit": "2-digit";
                }>>;
                minute: import("zod").ZodOptional<import("zod").ZodEnum<{
                    numeric: "numeric";
                    "2-digit": "2-digit";
                }>>;
                second: import("zod").ZodOptional<import("zod").ZodEnum<{
                    numeric: "numeric";
                    "2-digit": "2-digit";
                }>>;
                fractionalSecondDigits: import("zod").ZodOptional<import("zod").ZodUnion<readonly [import("zod").ZodLiteral<1>, import("zod").ZodLiteral<2>, import("zod").ZodLiteral<3>]>>;
                hour12: import("zod").ZodOptional<import("zod").ZodBoolean>;
                timeZoneName: import("zod").ZodOptional<import("zod").ZodEnum<{
                    long: "long";
                    short: "short";
                    shortOffset: "shortOffset";
                    longOffset: "longOffset";
                }>>;
            }, import("zod/v4/core").$strict>, import("zod").ZodObject<{
                kind: import("zod").ZodLiteral<"text">;
            }, import("zod/v4/core").$strict>], "kind">>;
            multivalue: import("zod").ZodOptional<import("zod").ZodLiteral<true>>;
            source: import("zod").ZodOptional<import("zod").ZodUnknown>;
        }, import("zod/v4/core").$strict>>;
        rows: import("zod").ZodArray<import("zod").ZodArray<import("zod").ZodUnion<readonly [import("zod").ZodUnion<readonly [import("zod").ZodNumber, import("zod").ZodString, import("zod").ZodBoolean, import("zod").ZodNull]>, import("zod").ZodArray<import("zod").ZodUnion<readonly [import("zod").ZodNumber, import("zod").ZodString, import("zod").ZodBoolean, import("zod").ZodNull]>>]>>>;
        source: import("zod").ZodOptional<import("zod").ZodUnknown>;
        missing: import("zod").ZodOptional<import("zod").ZodObject<{
            null: import("zod").ZodOptional<import("zod").ZodString>;
            empty: import("zod").ZodOptional<import("zod").ZodString>;
            nan: import("zod").ZodOptional<import("zod").ZodString>;
        }, import("zod/v4/core").$strict>>;
        display: import("zod").ZodOptional<import("zod").ZodRecord<import("zod").ZodString, import("zod").ZodArray<import("zod").ZodString>>>;
    }, import("zod/v4/core").$strict>;
    colors: import("zod").ZodOptional<import("zod").ZodObject<{
        byKey: import("zod").ZodOptional<import("zod").ZodRecord<import("zod").ZodString, import("zod").ZodUnion<readonly [import("zod").ZodObject<{
            light: import("zod").ZodString;
            dark: import("zod").ZodString;
        }, import("zod/v4/core").$strict>, import("zod").ZodObject<{
            token: import("zod").ZodEnum<{
                text: "text";
                textSubdued: "textSubdued";
                axis: "axis";
                gridLine: "gridLine";
                background: "background";
                border: "border";
            }>;
        }, import("zod/v4/core").$strict>, import("zod").ZodObject<{
            palette: import("zod").ZodLiteral<"categorical">;
            index: import("zod").ZodInt;
        }, import("zod/v4/core").$strict>]>>>;
        bands: import("zod").ZodOptional<import("zod").ZodArray<import("zod").ZodObject<{
            from: import("zod").ZodOptional<import("zod").ZodNumber>;
            to: import("zod").ZodOptional<import("zod").ZodNumber>;
            color: import("zod").ZodUnion<readonly [import("zod").ZodObject<{
                light: import("zod").ZodString;
                dark: import("zod").ZodString;
            }, import("zod/v4/core").$strict>, import("zod").ZodObject<{
                token: import("zod").ZodEnum<{
                    text: "text";
                    textSubdued: "textSubdued";
                    axis: "axis";
                    gridLine: "gridLine";
                    background: "background";
                    border: "border";
                }>;
            }, import("zod/v4/core").$strict>, import("zod").ZodObject<{
                palette: import("zod").ZodLiteral<"categorical">;
                index: import("zod").ZodInt;
            }, import("zod/v4/core").$strict>]>;
        }, import("zod/v4/core").$strict>>>;
    }, import("zod/v4/core").$strict>>;
    source: import("zod").ZodOptional<import("zod").ZodObject<{
        host: import("zod").ZodString;
        hostVersion: import("zod").ZodOptional<import("zod").ZodString>;
        capturedAt: import("zod").ZodISODateTime;
        timeRange: import("zod").ZodOptional<import("zod").ZodObject<{
            from: import("zod").ZodISODateTime;
            to: import("zod").ZodISODateTime;
        }, import("zod/v4/core").$strict>>;
        meta: import("zod").ZodOptional<import("zod").ZodRecord<import("zod").ZodString, import("zod").ZodUnknown>>;
    }, import("zod/v4/core").$strict>>;
    losses: import("zod").ZodOptional<import("zod").ZodArray<import("zod").ZodObject<{
        path: import("zod").ZodString;
        kind: import("zod").ZodEnum<{
            dropped: "dropped";
            approximated: "approximated";
            prerendered: "prerendered";
        }>;
        note: import("zod").ZodString;
    }, import("zod/v4/core").$strict>>>;
    type: import("zod").ZodLiteral<"metric">;
} & {
    id: ReturnType<() => import("zod").ZodOptional<import("zod").ZodString>>;
    surfaces: ReturnType<() => import("zod").ZodOptional<import("zod").ZodArray<import("zod").ZodEnum<{
        react: "react";
        snapshot: "snapshot";
        text: "text";
        markdown: "markdown";
        slack: "slack";
    }>>>>;
}, import("zod/v4/core").$strip>>, import("@elastic/isomer-sdk").PrimitiveDefinition<ChartNode, import("./context").ChartsPackTypes, import("zod").ZodObject<{
    interactions: import("zod").ZodOptional<import("zod").ZodObject<{
        select: import("zod").ZodOptional<import("zod").ZodArray<import("zod").ZodEnum<{
            tile: "tile";
        }>>>;
        sync: import("zod").ZodOptional<import("zod").ZodObject<{
            cursor: import("zod").ZodOptional<import("zod").ZodBoolean>;
            tooltips: import("zod").ZodOptional<import("zod").ZodBoolean>;
        }, import("zod/v4/core").$strict>>;
        link: import("zod").ZodOptional<import("zod").ZodObject<{
            href: import("zod").ZodString;
            label: import("zod").ZodString;
        }, import("zod/v4/core").$strict>>;
    }, import("zod/v4/core").$strict>>;
    metrics: import("zod").ZodArray<import("zod").ZodObject<{
        column: import("zod").ZodString;
    }, import("zod/v4/core").$strict>>;
    breakdown: import("zod").ZodOptional<import("zod").ZodObject<{
        column: import("zod").ZodString;
    }, import("zod/v4/core").$strict>>;
    size: import("zod").ZodOptional<import("zod").ZodEnum<{
        s: "s";
        m: "m";
        l: "l";
        xl: "xl";
        xs: "xs";
        xxl: "xxl";
    }>>;
    labelPosition: import("zod").ZodOptional<import("zod").ZodEnum<{
        top: "top";
        bottom: "bottom";
    }>>;
    textAlign: import("zod").ZodOptional<import("zod").ZodEnum<{
        left: "left";
        center: "center";
        right: "right";
    }>>;
    showLabels: import("zod").ZodOptional<import("zod").ZodBoolean>;
    applyColorTo: import("zod").ZodOptional<import("zod").ZodEnum<{
        value: "value";
        background: "background";
    }>>;
    bandsRange: import("zod").ZodOptional<import("zod").ZodEnum<{
        percentage: "percentage";
        absolute: "absolute";
    }>>;
    emphasis: import("zod").ZodOptional<import("zod").ZodArray<import("zod").ZodObject<{
        rows: import("zod").ZodArray<import("zod").ZodInt>;
        note: import("zod").ZodOptional<import("zod").ZodString>;
    }, import("zod/v4/core").$strict>>>;
    title: import("zod").ZodOptional<import("zod").ZodString>;
    description: import("zod").ZodOptional<import("zod").ZodString>;
    data: import("zod").ZodObject<{
        columns: import("zod").ZodArray<import("zod").ZodObject<{
            id: import("zod").ZodString;
            label: import("zod").ZodString;
            type: import("zod").ZodEnum<{
                string: "string";
                number: "number";
                boolean: "boolean";
                date: "date";
            }>;
            role: import("zod").ZodEnum<{
                dimension: "dimension";
                metric: "metric";
            }>;
            format: import("zod").ZodOptional<import("zod").ZodDiscriminatedUnion<[import("zod").ZodObject<{
                notation: import("zod").ZodOptional<import("zod").ZodEnum<{
                    standard: "standard";
                    compact: "compact";
                }>>;
                minimumFractionDigits: import("zod").ZodOptional<import("zod").ZodInt>;
                maximumFractionDigits: import("zod").ZodOptional<import("zod").ZodInt>;
                signDisplay: import("zod").ZodOptional<import("zod").ZodEnum<{
                    auto: "auto";
                    always: "always";
                    exceptZero: "exceptZero";
                    never: "never";
                }>>;
                useGrouping: import("zod").ZodOptional<import("zod").ZodBoolean>;
                suffix: import("zod").ZodOptional<import("zod").ZodString>;
                kind: import("zod").ZodLiteral<"number">;
            }, import("zod/v4/core").$strict>, import("zod").ZodObject<{
                fractional: import("zod").ZodOptional<import("zod").ZodBoolean>;
                minimumFractionDigits: import("zod").ZodOptional<import("zod").ZodInt>;
                maximumFractionDigits: import("zod").ZodOptional<import("zod").ZodInt>;
                signDisplay: import("zod").ZodOptional<import("zod").ZodEnum<{
                    auto: "auto";
                    always: "always";
                    exceptZero: "exceptZero";
                    never: "never";
                }>>;
                useGrouping: import("zod").ZodOptional<import("zod").ZodBoolean>;
                suffix: import("zod").ZodOptional<import("zod").ZodString>;
                kind: import("zod").ZodLiteral<"percent">;
            }, import("zod/v4/core").$strict>, import("zod").ZodObject<{
                base: import("zod").ZodOptional<import("zod").ZodUnion<readonly [import("zod").ZodLiteral<1000>, import("zod").ZodLiteral<1024>]>>;
                unitDisplay: import("zod").ZodOptional<import("zod").ZodEnum<{
                    long: "long";
                    short: "short";
                    narrow: "narrow";
                }>>;
                minimumFractionDigits: import("zod").ZodOptional<import("zod").ZodInt>;
                maximumFractionDigits: import("zod").ZodOptional<import("zod").ZodInt>;
                signDisplay: import("zod").ZodOptional<import("zod").ZodEnum<{
                    auto: "auto";
                    always: "always";
                    exceptZero: "exceptZero";
                    never: "never";
                }>>;
                useGrouping: import("zod").ZodOptional<import("zod").ZodBoolean>;
                suffix: import("zod").ZodOptional<import("zod").ZodString>;
                kind: import("zod").ZodLiteral<"bytes">;
            }, import("zod/v4/core").$strict>, import("zod").ZodObject<{
                base: import("zod").ZodOptional<import("zod").ZodUnion<readonly [import("zod").ZodLiteral<1000>, import("zod").ZodLiteral<1024>]>>;
                unitDisplay: import("zod").ZodOptional<import("zod").ZodEnum<{
                    long: "long";
                    short: "short";
                    narrow: "narrow";
                }>>;
                minimumFractionDigits: import("zod").ZodOptional<import("zod").ZodInt>;
                maximumFractionDigits: import("zod").ZodOptional<import("zod").ZodInt>;
                signDisplay: import("zod").ZodOptional<import("zod").ZodEnum<{
                    auto: "auto";
                    always: "always";
                    exceptZero: "exceptZero";
                    never: "never";
                }>>;
                useGrouping: import("zod").ZodOptional<import("zod").ZodBoolean>;
                suffix: import("zod").ZodOptional<import("zod").ZodString>;
                kind: import("zod").ZodLiteral<"bits">;
            }, import("zod/v4/core").$strict>, import("zod").ZodObject<{
                unitDisplay: import("zod").ZodOptional<import("zod").ZodEnum<{
                    long: "long";
                    short: "short";
                    narrow: "narrow";
                }>>;
                minimumFractionDigits: import("zod").ZodOptional<import("zod").ZodInt>;
                maximumFractionDigits: import("zod").ZodOptional<import("zod").ZodInt>;
                signDisplay: import("zod").ZodOptional<import("zod").ZodEnum<{
                    auto: "auto";
                    always: "always";
                    exceptZero: "exceptZero";
                    never: "never";
                }>>;
                useGrouping: import("zod").ZodOptional<import("zod").ZodBoolean>;
                suffix: import("zod").ZodOptional<import("zod").ZodString>;
                kind: import("zod").ZodLiteral<"duration">;
                input: import("zod").ZodEnum<{
                    picoseconds: "picoseconds";
                    nanoseconds: "nanoseconds";
                    microseconds: "microseconds";
                    milliseconds: "milliseconds";
                    seconds: "seconds";
                    minutes: "minutes";
                    hours: "hours";
                    days: "days";
                    weeks: "weeks";
                    months: "months";
                    years: "years";
                }>;
                output: import("zod").ZodOptional<import("zod").ZodUnion<readonly [import("zod").ZodEnum<{
                    nanoseconds: "nanoseconds";
                    microseconds: "microseconds";
                    milliseconds: "milliseconds";
                    seconds: "seconds";
                    minutes: "minutes";
                    hours: "hours";
                    days: "days";
                    weeks: "weeks";
                    months: "months";
                    years: "years";
                }>, import("zod").ZodLiteral<"auto">]>>;
            }, import("zod/v4/core").$strict>, import("zod").ZodObject<{
                kind: import("zod").ZodLiteral<"date">;
                timeZone: import("zod").ZodOptional<import("zod").ZodString>;
                dateStyle: import("zod").ZodOptional<import("zod").ZodEnum<{
                    long: "long";
                    short: "short";
                    full: "full";
                    medium: "medium";
                }>>;
                timeStyle: import("zod").ZodOptional<import("zod").ZodEnum<{
                    long: "long";
                    short: "short";
                    full: "full";
                    medium: "medium";
                }>>;
                weekday: import("zod").ZodOptional<import("zod").ZodEnum<{
                    long: "long";
                    short: "short";
                    narrow: "narrow";
                }>>;
                year: import("zod").ZodOptional<import("zod").ZodEnum<{
                    numeric: "numeric";
                    "2-digit": "2-digit";
                }>>;
                month: import("zod").ZodOptional<import("zod").ZodEnum<{
                    long: "long";
                    short: "short";
                    narrow: "narrow";
                    numeric: "numeric";
                    "2-digit": "2-digit";
                }>>;
                day: import("zod").ZodOptional<import("zod").ZodEnum<{
                    numeric: "numeric";
                    "2-digit": "2-digit";
                }>>;
                hour: import("zod").ZodOptional<import("zod").ZodEnum<{
                    numeric: "numeric";
                    "2-digit": "2-digit";
                }>>;
                minute: import("zod").ZodOptional<import("zod").ZodEnum<{
                    numeric: "numeric";
                    "2-digit": "2-digit";
                }>>;
                second: import("zod").ZodOptional<import("zod").ZodEnum<{
                    numeric: "numeric";
                    "2-digit": "2-digit";
                }>>;
                fractionalSecondDigits: import("zod").ZodOptional<import("zod").ZodUnion<readonly [import("zod").ZodLiteral<1>, import("zod").ZodLiteral<2>, import("zod").ZodLiteral<3>]>>;
                hour12: import("zod").ZodOptional<import("zod").ZodBoolean>;
                timeZoneName: import("zod").ZodOptional<import("zod").ZodEnum<{
                    long: "long";
                    short: "short";
                    shortOffset: "shortOffset";
                    longOffset: "longOffset";
                }>>;
            }, import("zod/v4/core").$strict>, import("zod").ZodObject<{
                kind: import("zod").ZodLiteral<"text">;
            }, import("zod/v4/core").$strict>], "kind">>;
            multivalue: import("zod").ZodOptional<import("zod").ZodLiteral<true>>;
            source: import("zod").ZodOptional<import("zod").ZodUnknown>;
        }, import("zod/v4/core").$strict>>;
        rows: import("zod").ZodArray<import("zod").ZodArray<import("zod").ZodUnion<readonly [import("zod").ZodUnion<readonly [import("zod").ZodNumber, import("zod").ZodString, import("zod").ZodBoolean, import("zod").ZodNull]>, import("zod").ZodArray<import("zod").ZodUnion<readonly [import("zod").ZodNumber, import("zod").ZodString, import("zod").ZodBoolean, import("zod").ZodNull]>>]>>>;
        source: import("zod").ZodOptional<import("zod").ZodUnknown>;
        missing: import("zod").ZodOptional<import("zod").ZodObject<{
            null: import("zod").ZodOptional<import("zod").ZodString>;
            empty: import("zod").ZodOptional<import("zod").ZodString>;
            nan: import("zod").ZodOptional<import("zod").ZodString>;
        }, import("zod/v4/core").$strict>>;
        display: import("zod").ZodOptional<import("zod").ZodRecord<import("zod").ZodString, import("zod").ZodArray<import("zod").ZodString>>>;
    }, import("zod/v4/core").$strict>;
    colors: import("zod").ZodOptional<import("zod").ZodObject<{
        byKey: import("zod").ZodOptional<import("zod").ZodRecord<import("zod").ZodString, import("zod").ZodUnion<readonly [import("zod").ZodObject<{
            light: import("zod").ZodString;
            dark: import("zod").ZodString;
        }, import("zod/v4/core").$strict>, import("zod").ZodObject<{
            token: import("zod").ZodEnum<{
                text: "text";
                textSubdued: "textSubdued";
                axis: "axis";
                gridLine: "gridLine";
                background: "background";
                border: "border";
            }>;
        }, import("zod/v4/core").$strict>, import("zod").ZodObject<{
            palette: import("zod").ZodLiteral<"categorical">;
            index: import("zod").ZodInt;
        }, import("zod/v4/core").$strict>]>>>;
        bands: import("zod").ZodOptional<import("zod").ZodArray<import("zod").ZodObject<{
            from: import("zod").ZodOptional<import("zod").ZodNumber>;
            to: import("zod").ZodOptional<import("zod").ZodNumber>;
            color: import("zod").ZodUnion<readonly [import("zod").ZodObject<{
                light: import("zod").ZodString;
                dark: import("zod").ZodString;
            }, import("zod/v4/core").$strict>, import("zod").ZodObject<{
                token: import("zod").ZodEnum<{
                    text: "text";
                    textSubdued: "textSubdued";
                    axis: "axis";
                    gridLine: "gridLine";
                    background: "background";
                    border: "border";
                }>;
            }, import("zod/v4/core").$strict>, import("zod").ZodObject<{
                palette: import("zod").ZodLiteral<"categorical">;
                index: import("zod").ZodInt;
            }, import("zod/v4/core").$strict>]>;
        }, import("zod/v4/core").$strict>>>;
    }, import("zod/v4/core").$strict>>;
    source: import("zod").ZodOptional<import("zod").ZodObject<{
        host: import("zod").ZodString;
        hostVersion: import("zod").ZodOptional<import("zod").ZodString>;
        capturedAt: import("zod").ZodISODateTime;
        timeRange: import("zod").ZodOptional<import("zod").ZodObject<{
            from: import("zod").ZodISODateTime;
            to: import("zod").ZodISODateTime;
        }, import("zod/v4/core").$strict>>;
        meta: import("zod").ZodOptional<import("zod").ZodRecord<import("zod").ZodString, import("zod").ZodUnknown>>;
    }, import("zod/v4/core").$strict>>;
    losses: import("zod").ZodOptional<import("zod").ZodArray<import("zod").ZodObject<{
        path: import("zod").ZodString;
        kind: import("zod").ZodEnum<{
            dropped: "dropped";
            approximated: "approximated";
            prerendered: "prerendered";
        }>;
        note: import("zod").ZodString;
    }, import("zod/v4/core").$strict>>>;
    type: import("zod").ZodLiteral<"legacyMetric">;
} & {
    id: ReturnType<() => import("zod").ZodOptional<import("zod").ZodString>>;
    surfaces: ReturnType<() => import("zod").ZodOptional<import("zod").ZodArray<import("zod").ZodEnum<{
        react: "react";
        snapshot: "snapshot";
        text: "text";
        markdown: "markdown";
        slack: "slack";
    }>>>>;
}, import("zod/v4/core").$strip>>, import("@elastic/isomer-sdk").PrimitiveDefinition<DataTableNode, import("./context").ChartsPackTypes, import("zod").ZodObject<{
    interactions: import("zod").ZodOptional<import("zod").ZodObject<{
        select: import("zod").ZodOptional<import("zod").ZodArray<import("zod").ZodEnum<{
            cell: "cell";
        }>>>;
        sync: import("zod").ZodOptional<import("zod").ZodObject<{
            cursor: import("zod").ZodOptional<import("zod").ZodBoolean>;
            tooltips: import("zod").ZodOptional<import("zod").ZodBoolean>;
        }, import("zod/v4/core").$strict>>;
        link: import("zod").ZodOptional<import("zod").ZodObject<{
            href: import("zod").ZodString;
            label: import("zod").ZodString;
        }, import("zod/v4/core").$strict>>;
        initial: import("zod").ZodOptional<import("zod").ZodObject<{
            sort: import("zod").ZodOptional<import("zod").ZodObject<{
                column: import("zod").ZodString;
                direction: import("zod").ZodEnum<{
                    asc: "asc";
                    desc: "desc";
                }>;
            }, import("zod/v4/core").$strict>>;
        }, import("zod/v4/core").$strict>>;
    }, import("zod/v4/core").$strict>>;
    columns: import("zod").ZodOptional<import("zod").ZodArray<import("zod").ZodObject<{
        column: import("zod").ZodString;
        alignment: import("zod").ZodOptional<import("zod").ZodEnum<{
            left: "left";
            center: "center";
            right: "right";
        }>>;
        width: import("zod").ZodOptional<import("zod").ZodNumber>;
        decoration: import("zod").ZodOptional<import("zod").ZodDiscriminatedUnion<[import("zod").ZodObject<{
            kind: import("zod").ZodEnum<{
                text: "text";
                background: "background";
                badge: "badge";
            }>;
            colors: import("zod").ZodObject<{
                byKey: import("zod").ZodOptional<import("zod").ZodRecord<import("zod").ZodString, import("zod").ZodUnion<readonly [import("zod").ZodObject<{
                    light: import("zod").ZodString;
                    dark: import("zod").ZodString;
                }, import("zod/v4/core").$strict>, import("zod").ZodObject<{
                    token: import("zod").ZodEnum<{
                        text: "text";
                        textSubdued: "textSubdued";
                        axis: "axis";
                        gridLine: "gridLine";
                        background: "background";
                        border: "border";
                    }>;
                }, import("zod/v4/core").$strict>, import("zod").ZodObject<{
                    palette: import("zod").ZodLiteral<"categorical">;
                    index: import("zod").ZodInt;
                }, import("zod/v4/core").$strict>]>>>;
                bands: import("zod").ZodOptional<import("zod").ZodArray<import("zod").ZodObject<{
                    from: import("zod").ZodOptional<import("zod").ZodNumber>;
                    to: import("zod").ZodOptional<import("zod").ZodNumber>;
                    color: import("zod").ZodUnion<readonly [import("zod").ZodObject<{
                        light: import("zod").ZodString;
                        dark: import("zod").ZodString;
                    }, import("zod/v4/core").$strict>, import("zod").ZodObject<{
                        token: import("zod").ZodEnum<{
                            text: "text";
                            textSubdued: "textSubdued";
                            axis: "axis";
                            gridLine: "gridLine";
                            background: "background";
                            border: "border";
                        }>;
                    }, import("zod/v4/core").$strict>, import("zod").ZodObject<{
                        palette: import("zod").ZodLiteral<"categorical">;
                        index: import("zod").ZodInt;
                    }, import("zod/v4/core").$strict>]>;
                }, import("zod/v4/core").$strict>>>;
            }, import("zod/v4/core").$strict>;
        }, import("zod/v4/core").$strict>, import("zod").ZodObject<{
            kind: import("zod").ZodLiteral<"bar">;
            color: import("zod").ZodOptional<import("zod").ZodUnion<readonly [import("zod").ZodObject<{
                light: import("zod").ZodString;
                dark: import("zod").ZodString;
            }, import("zod/v4/core").$strict>, import("zod").ZodObject<{
                token: import("zod").ZodEnum<{
                    text: "text";
                    textSubdued: "textSubdued";
                    axis: "axis";
                    gridLine: "gridLine";
                    background: "background";
                    border: "border";
                }>;
            }, import("zod/v4/core").$strict>, import("zod").ZodObject<{
                palette: import("zod").ZodLiteral<"categorical">;
                index: import("zod").ZodInt;
            }, import("zod/v4/core").$strict>]>>;
            colors: import("zod").ZodOptional<import("zod").ZodObject<{
                byKey: import("zod").ZodOptional<import("zod").ZodRecord<import("zod").ZodString, import("zod").ZodUnion<readonly [import("zod").ZodObject<{
                    light: import("zod").ZodString;
                    dark: import("zod").ZodString;
                }, import("zod/v4/core").$strict>, import("zod").ZodObject<{
                    token: import("zod").ZodEnum<{
                        text: "text";
                        textSubdued: "textSubdued";
                        axis: "axis";
                        gridLine: "gridLine";
                        background: "background";
                        border: "border";
                    }>;
                }, import("zod/v4/core").$strict>, import("zod").ZodObject<{
                    palette: import("zod").ZodLiteral<"categorical">;
                    index: import("zod").ZodInt;
                }, import("zod/v4/core").$strict>]>>>;
                bands: import("zod").ZodOptional<import("zod").ZodArray<import("zod").ZodObject<{
                    from: import("zod").ZodOptional<import("zod").ZodNumber>;
                    to: import("zod").ZodOptional<import("zod").ZodNumber>;
                    color: import("zod").ZodUnion<readonly [import("zod").ZodObject<{
                        light: import("zod").ZodString;
                        dark: import("zod").ZodString;
                    }, import("zod/v4/core").$strict>, import("zod").ZodObject<{
                        token: import("zod").ZodEnum<{
                            text: "text";
                            textSubdued: "textSubdued";
                            axis: "axis";
                            gridLine: "gridLine";
                            background: "background";
                            border: "border";
                        }>;
                    }, import("zod/v4/core").$strict>, import("zod").ZodObject<{
                        palette: import("zod").ZodLiteral<"categorical">;
                        index: import("zod").ZodInt;
                    }, import("zod/v4/core").$strict>]>;
                }, import("zod/v4/core").$strict>>>;
            }, import("zod/v4/core").$strict>>;
            min: import("zod").ZodOptional<import("zod").ZodNumber>;
            max: import("zod").ZodOptional<import("zod").ZodNumber>;
            baseline: import("zod").ZodOptional<import("zod").ZodNumber>;
        }, import("zod/v4/core").$strict>], "kind">>;
        summary: import("zod").ZodOptional<import("zod").ZodObject<{
            kind: import("zod").ZodEnum<{
                sum: "sum";
                avg: "avg";
                count: "count";
                min: "min";
                max: "max";
            }>;
            label: import("zod").ZodOptional<import("zod").ZodString>;
        }, import("zod/v4/core").$strict>>;
    }, import("zod/v4/core").$strict>>>;
    pageSize: import("zod").ZodOptional<import("zod").ZodInt>;
    density: import("zod").ZodOptional<import("zod").ZodEnum<{
        default: "default";
        compact: "compact";
        expanded: "expanded";
    }>>;
    emphasis: import("zod").ZodOptional<import("zod").ZodArray<import("zod").ZodObject<{
        rows: import("zod").ZodArray<import("zod").ZodInt>;
        note: import("zod").ZodOptional<import("zod").ZodString>;
    }, import("zod/v4/core").$strict>>>;
    title: import("zod").ZodOptional<import("zod").ZodString>;
    description: import("zod").ZodOptional<import("zod").ZodString>;
    data: import("zod").ZodObject<{
        columns: import("zod").ZodArray<import("zod").ZodObject<{
            id: import("zod").ZodString;
            label: import("zod").ZodString;
            type: import("zod").ZodEnum<{
                string: "string";
                number: "number";
                boolean: "boolean";
                date: "date";
            }>;
            role: import("zod").ZodEnum<{
                dimension: "dimension";
                metric: "metric";
            }>;
            format: import("zod").ZodOptional<import("zod").ZodDiscriminatedUnion<[import("zod").ZodObject<{
                notation: import("zod").ZodOptional<import("zod").ZodEnum<{
                    standard: "standard";
                    compact: "compact";
                }>>;
                minimumFractionDigits: import("zod").ZodOptional<import("zod").ZodInt>;
                maximumFractionDigits: import("zod").ZodOptional<import("zod").ZodInt>;
                signDisplay: import("zod").ZodOptional<import("zod").ZodEnum<{
                    auto: "auto";
                    always: "always";
                    exceptZero: "exceptZero";
                    never: "never";
                }>>;
                useGrouping: import("zod").ZodOptional<import("zod").ZodBoolean>;
                suffix: import("zod").ZodOptional<import("zod").ZodString>;
                kind: import("zod").ZodLiteral<"number">;
            }, import("zod/v4/core").$strict>, import("zod").ZodObject<{
                fractional: import("zod").ZodOptional<import("zod").ZodBoolean>;
                minimumFractionDigits: import("zod").ZodOptional<import("zod").ZodInt>;
                maximumFractionDigits: import("zod").ZodOptional<import("zod").ZodInt>;
                signDisplay: import("zod").ZodOptional<import("zod").ZodEnum<{
                    auto: "auto";
                    always: "always";
                    exceptZero: "exceptZero";
                    never: "never";
                }>>;
                useGrouping: import("zod").ZodOptional<import("zod").ZodBoolean>;
                suffix: import("zod").ZodOptional<import("zod").ZodString>;
                kind: import("zod").ZodLiteral<"percent">;
            }, import("zod/v4/core").$strict>, import("zod").ZodObject<{
                base: import("zod").ZodOptional<import("zod").ZodUnion<readonly [import("zod").ZodLiteral<1000>, import("zod").ZodLiteral<1024>]>>;
                unitDisplay: import("zod").ZodOptional<import("zod").ZodEnum<{
                    long: "long";
                    short: "short";
                    narrow: "narrow";
                }>>;
                minimumFractionDigits: import("zod").ZodOptional<import("zod").ZodInt>;
                maximumFractionDigits: import("zod").ZodOptional<import("zod").ZodInt>;
                signDisplay: import("zod").ZodOptional<import("zod").ZodEnum<{
                    auto: "auto";
                    always: "always";
                    exceptZero: "exceptZero";
                    never: "never";
                }>>;
                useGrouping: import("zod").ZodOptional<import("zod").ZodBoolean>;
                suffix: import("zod").ZodOptional<import("zod").ZodString>;
                kind: import("zod").ZodLiteral<"bytes">;
            }, import("zod/v4/core").$strict>, import("zod").ZodObject<{
                base: import("zod").ZodOptional<import("zod").ZodUnion<readonly [import("zod").ZodLiteral<1000>, import("zod").ZodLiteral<1024>]>>;
                unitDisplay: import("zod").ZodOptional<import("zod").ZodEnum<{
                    long: "long";
                    short: "short";
                    narrow: "narrow";
                }>>;
                minimumFractionDigits: import("zod").ZodOptional<import("zod").ZodInt>;
                maximumFractionDigits: import("zod").ZodOptional<import("zod").ZodInt>;
                signDisplay: import("zod").ZodOptional<import("zod").ZodEnum<{
                    auto: "auto";
                    always: "always";
                    exceptZero: "exceptZero";
                    never: "never";
                }>>;
                useGrouping: import("zod").ZodOptional<import("zod").ZodBoolean>;
                suffix: import("zod").ZodOptional<import("zod").ZodString>;
                kind: import("zod").ZodLiteral<"bits">;
            }, import("zod/v4/core").$strict>, import("zod").ZodObject<{
                unitDisplay: import("zod").ZodOptional<import("zod").ZodEnum<{
                    long: "long";
                    short: "short";
                    narrow: "narrow";
                }>>;
                minimumFractionDigits: import("zod").ZodOptional<import("zod").ZodInt>;
                maximumFractionDigits: import("zod").ZodOptional<import("zod").ZodInt>;
                signDisplay: import("zod").ZodOptional<import("zod").ZodEnum<{
                    auto: "auto";
                    always: "always";
                    exceptZero: "exceptZero";
                    never: "never";
                }>>;
                useGrouping: import("zod").ZodOptional<import("zod").ZodBoolean>;
                suffix: import("zod").ZodOptional<import("zod").ZodString>;
                kind: import("zod").ZodLiteral<"duration">;
                input: import("zod").ZodEnum<{
                    picoseconds: "picoseconds";
                    nanoseconds: "nanoseconds";
                    microseconds: "microseconds";
                    milliseconds: "milliseconds";
                    seconds: "seconds";
                    minutes: "minutes";
                    hours: "hours";
                    days: "days";
                    weeks: "weeks";
                    months: "months";
                    years: "years";
                }>;
                output: import("zod").ZodOptional<import("zod").ZodUnion<readonly [import("zod").ZodEnum<{
                    nanoseconds: "nanoseconds";
                    microseconds: "microseconds";
                    milliseconds: "milliseconds";
                    seconds: "seconds";
                    minutes: "minutes";
                    hours: "hours";
                    days: "days";
                    weeks: "weeks";
                    months: "months";
                    years: "years";
                }>, import("zod").ZodLiteral<"auto">]>>;
            }, import("zod/v4/core").$strict>, import("zod").ZodObject<{
                kind: import("zod").ZodLiteral<"date">;
                timeZone: import("zod").ZodOptional<import("zod").ZodString>;
                dateStyle: import("zod").ZodOptional<import("zod").ZodEnum<{
                    long: "long";
                    short: "short";
                    full: "full";
                    medium: "medium";
                }>>;
                timeStyle: import("zod").ZodOptional<import("zod").ZodEnum<{
                    long: "long";
                    short: "short";
                    full: "full";
                    medium: "medium";
                }>>;
                weekday: import("zod").ZodOptional<import("zod").ZodEnum<{
                    long: "long";
                    short: "short";
                    narrow: "narrow";
                }>>;
                year: import("zod").ZodOptional<import("zod").ZodEnum<{
                    numeric: "numeric";
                    "2-digit": "2-digit";
                }>>;
                month: import("zod").ZodOptional<import("zod").ZodEnum<{
                    long: "long";
                    short: "short";
                    narrow: "narrow";
                    numeric: "numeric";
                    "2-digit": "2-digit";
                }>>;
                day: import("zod").ZodOptional<import("zod").ZodEnum<{
                    numeric: "numeric";
                    "2-digit": "2-digit";
                }>>;
                hour: import("zod").ZodOptional<import("zod").ZodEnum<{
                    numeric: "numeric";
                    "2-digit": "2-digit";
                }>>;
                minute: import("zod").ZodOptional<import("zod").ZodEnum<{
                    numeric: "numeric";
                    "2-digit": "2-digit";
                }>>;
                second: import("zod").ZodOptional<import("zod").ZodEnum<{
                    numeric: "numeric";
                    "2-digit": "2-digit";
                }>>;
                fractionalSecondDigits: import("zod").ZodOptional<import("zod").ZodUnion<readonly [import("zod").ZodLiteral<1>, import("zod").ZodLiteral<2>, import("zod").ZodLiteral<3>]>>;
                hour12: import("zod").ZodOptional<import("zod").ZodBoolean>;
                timeZoneName: import("zod").ZodOptional<import("zod").ZodEnum<{
                    long: "long";
                    short: "short";
                    shortOffset: "shortOffset";
                    longOffset: "longOffset";
                }>>;
            }, import("zod/v4/core").$strict>, import("zod").ZodObject<{
                kind: import("zod").ZodLiteral<"text">;
            }, import("zod/v4/core").$strict>], "kind">>;
            multivalue: import("zod").ZodOptional<import("zod").ZodLiteral<true>>;
            source: import("zod").ZodOptional<import("zod").ZodUnknown>;
        }, import("zod/v4/core").$strict>>;
        rows: import("zod").ZodArray<import("zod").ZodArray<import("zod").ZodUnion<readonly [import("zod").ZodUnion<readonly [import("zod").ZodNumber, import("zod").ZodString, import("zod").ZodBoolean, import("zod").ZodNull]>, import("zod").ZodArray<import("zod").ZodUnion<readonly [import("zod").ZodNumber, import("zod").ZodString, import("zod").ZodBoolean, import("zod").ZodNull]>>]>>>;
        source: import("zod").ZodOptional<import("zod").ZodUnknown>;
        missing: import("zod").ZodOptional<import("zod").ZodObject<{
            null: import("zod").ZodOptional<import("zod").ZodString>;
            empty: import("zod").ZodOptional<import("zod").ZodString>;
            nan: import("zod").ZodOptional<import("zod").ZodString>;
        }, import("zod/v4/core").$strict>>;
        display: import("zod").ZodOptional<import("zod").ZodRecord<import("zod").ZodString, import("zod").ZodArray<import("zod").ZodString>>>;
    }, import("zod/v4/core").$strict>;
    colors: import("zod").ZodOptional<import("zod").ZodObject<{
        byKey: import("zod").ZodOptional<import("zod").ZodRecord<import("zod").ZodString, import("zod").ZodUnion<readonly [import("zod").ZodObject<{
            light: import("zod").ZodString;
            dark: import("zod").ZodString;
        }, import("zod/v4/core").$strict>, import("zod").ZodObject<{
            token: import("zod").ZodEnum<{
                text: "text";
                textSubdued: "textSubdued";
                axis: "axis";
                gridLine: "gridLine";
                background: "background";
                border: "border";
            }>;
        }, import("zod/v4/core").$strict>, import("zod").ZodObject<{
            palette: import("zod").ZodLiteral<"categorical">;
            index: import("zod").ZodInt;
        }, import("zod/v4/core").$strict>]>>>;
        bands: import("zod").ZodOptional<import("zod").ZodArray<import("zod").ZodObject<{
            from: import("zod").ZodOptional<import("zod").ZodNumber>;
            to: import("zod").ZodOptional<import("zod").ZodNumber>;
            color: import("zod").ZodUnion<readonly [import("zod").ZodObject<{
                light: import("zod").ZodString;
                dark: import("zod").ZodString;
            }, import("zod/v4/core").$strict>, import("zod").ZodObject<{
                token: import("zod").ZodEnum<{
                    text: "text";
                    textSubdued: "textSubdued";
                    axis: "axis";
                    gridLine: "gridLine";
                    background: "background";
                    border: "border";
                }>;
            }, import("zod/v4/core").$strict>, import("zod").ZodObject<{
                palette: import("zod").ZodLiteral<"categorical">;
                index: import("zod").ZodInt;
            }, import("zod/v4/core").$strict>]>;
        }, import("zod/v4/core").$strict>>>;
    }, import("zod/v4/core").$strict>>;
    source: import("zod").ZodOptional<import("zod").ZodObject<{
        host: import("zod").ZodString;
        hostVersion: import("zod").ZodOptional<import("zod").ZodString>;
        capturedAt: import("zod").ZodISODateTime;
        timeRange: import("zod").ZodOptional<import("zod").ZodObject<{
            from: import("zod").ZodISODateTime;
            to: import("zod").ZodISODateTime;
        }, import("zod/v4/core").$strict>>;
        meta: import("zod").ZodOptional<import("zod").ZodRecord<import("zod").ZodString, import("zod").ZodUnknown>>;
    }, import("zod/v4/core").$strict>>;
    losses: import("zod").ZodOptional<import("zod").ZodArray<import("zod").ZodObject<{
        path: import("zod").ZodString;
        kind: import("zod").ZodEnum<{
            dropped: "dropped";
            approximated: "approximated";
            prerendered: "prerendered";
        }>;
        note: import("zod").ZodString;
    }, import("zod/v4/core").$strict>>>;
    type: import("zod").ZodLiteral<"dataTable">;
} & {
    id: ReturnType<() => import("zod").ZodOptional<import("zod").ZodString>>;
    surfaces: ReturnType<() => import("zod").ZodOptional<import("zod").ZodArray<import("zod").ZodEnum<{
        react: "react";
        snapshot: "snapshot";
        text: "text";
        markdown: "markdown";
        slack: "slack";
    }>>>>;
}, import("zod/v4/core").$strip>>, import("@elastic/isomer-sdk").PrimitiveDefinition<ChartNode, import("./context").ChartsPackTypes, import("zod").ZodObject<{
    interactions: import("zod").ZodOptional<import("zod").ZodObject<{
        select: import("zod").ZodOptional<import("zod").ZodArray<import("zod").ZodEnum<{
            datum: "datum";
            series: "series";
            category: "category";
            legend: "legend";
        }>>>;
        brush: import("zod").ZodOptional<import("zod").ZodObject<{
            column: import("zod").ZodString;
        }, import("zod/v4/core").$strict>>;
        sync: import("zod").ZodOptional<import("zod").ZodObject<{
            cursor: import("zod").ZodOptional<import("zod").ZodBoolean>;
            tooltips: import("zod").ZodOptional<import("zod").ZodBoolean>;
        }, import("zod/v4/core").$strict>>;
        link: import("zod").ZodOptional<import("zod").ZodObject<{
            href: import("zod").ZodString;
            label: import("zod").ZodString;
        }, import("zod/v4/core").$strict>>;
        initial: import("zod").ZodOptional<import("zod").ZodObject<{
            hiddenSeries: import("zod").ZodOptional<import("zod").ZodArray<import("zod").ZodString>>;
        }, import("zod/v4/core").$strict>>;
    }, import("zod/v4/core").$strict>>;
    orientation: import("zod").ZodOptional<import("zod").ZodEnum<{
        horizontal: "horizontal";
        vertical: "vertical";
    }>>;
    layers: import("zod").ZodArray<import("zod").ZodDiscriminatedUnion<[import("zod").ZodObject<{
        kind: import("zod").ZodLiteral<"data">;
        mark: import("zod").ZodEnum<{
            line: "line";
            area: "area";
            bar: "bar";
        }>;
        stack: import("zod").ZodOptional<import("zod").ZodEnum<{
            stacked: "stacked";
            percentage: "percentage";
        }>>;
        x: import("zod").ZodOptional<import("zod").ZodString>;
        y: import("zod").ZodArray<import("zod").ZodObject<{
            column: import("zod").ZodString;
            axis: import("zod").ZodOptional<import("zod").ZodEnum<{
                y: "y";
                y2: "y2";
            }>>;
            color: import("zod").ZodOptional<import("zod").ZodUnion<readonly [import("zod").ZodObject<{
                light: import("zod").ZodString;
                dark: import("zod").ZodString;
            }, import("zod/v4/core").$strict>, import("zod").ZodObject<{
                token: import("zod").ZodEnum<{
                    text: "text";
                    textSubdued: "textSubdued";
                    axis: "axis";
                    gridLine: "gridLine";
                    background: "background";
                    border: "border";
                }>;
            }, import("zod/v4/core").$strict>, import("zod").ZodObject<{
                palette: import("zod").ZodLiteral<"categorical">;
                index: import("zod").ZodInt;
            }, import("zod/v4/core").$strict>]>>;
        }, import("zod/v4/core").$strict>>;
        splitBy: import("zod").ZodOptional<import("zod").ZodString>;
        rows: import("zod").ZodOptional<import("zod").ZodTuple<[import("zod").ZodInt, import("zod").ZodInt], null>>;
    }, import("zod/v4/core").$strict>, import("zod").ZodObject<{
        kind: import("zod").ZodLiteral<"referenceLines">;
        lines: import("zod").ZodArray<import("zod").ZodObject<{
            value: import("zod").ZodNumber;
            axis: import("zod").ZodOptional<import("zod").ZodEnum<{
                y: "y";
                x: "x";
                y2: "y2";
            }>>;
            label: import("zod").ZodOptional<import("zod").ZodString>;
            format: import("zod").ZodOptional<import("zod").ZodDiscriminatedUnion<[import("zod").ZodObject<{
                notation: import("zod").ZodOptional<import("zod").ZodEnum<{
                    standard: "standard";
                    compact: "compact";
                }>>;
                minimumFractionDigits: import("zod").ZodOptional<import("zod").ZodInt>;
                maximumFractionDigits: import("zod").ZodOptional<import("zod").ZodInt>;
                signDisplay: import("zod").ZodOptional<import("zod").ZodEnum<{
                    auto: "auto";
                    always: "always";
                    exceptZero: "exceptZero";
                    never: "never";
                }>>;
                useGrouping: import("zod").ZodOptional<import("zod").ZodBoolean>;
                suffix: import("zod").ZodOptional<import("zod").ZodString>;
                kind: import("zod").ZodLiteral<"number">;
            }, import("zod/v4/core").$strict>, import("zod").ZodObject<{
                fractional: import("zod").ZodOptional<import("zod").ZodBoolean>;
                minimumFractionDigits: import("zod").ZodOptional<import("zod").ZodInt>;
                maximumFractionDigits: import("zod").ZodOptional<import("zod").ZodInt>;
                signDisplay: import("zod").ZodOptional<import("zod").ZodEnum<{
                    auto: "auto";
                    always: "always";
                    exceptZero: "exceptZero";
                    never: "never";
                }>>;
                useGrouping: import("zod").ZodOptional<import("zod").ZodBoolean>;
                suffix: import("zod").ZodOptional<import("zod").ZodString>;
                kind: import("zod").ZodLiteral<"percent">;
            }, import("zod/v4/core").$strict>, import("zod").ZodObject<{
                base: import("zod").ZodOptional<import("zod").ZodUnion<readonly [import("zod").ZodLiteral<1000>, import("zod").ZodLiteral<1024>]>>;
                unitDisplay: import("zod").ZodOptional<import("zod").ZodEnum<{
                    long: "long";
                    short: "short";
                    narrow: "narrow";
                }>>;
                minimumFractionDigits: import("zod").ZodOptional<import("zod").ZodInt>;
                maximumFractionDigits: import("zod").ZodOptional<import("zod").ZodInt>;
                signDisplay: import("zod").ZodOptional<import("zod").ZodEnum<{
                    auto: "auto";
                    always: "always";
                    exceptZero: "exceptZero";
                    never: "never";
                }>>;
                useGrouping: import("zod").ZodOptional<import("zod").ZodBoolean>;
                suffix: import("zod").ZodOptional<import("zod").ZodString>;
                kind: import("zod").ZodLiteral<"bytes">;
            }, import("zod/v4/core").$strict>, import("zod").ZodObject<{
                base: import("zod").ZodOptional<import("zod").ZodUnion<readonly [import("zod").ZodLiteral<1000>, import("zod").ZodLiteral<1024>]>>;
                unitDisplay: import("zod").ZodOptional<import("zod").ZodEnum<{
                    long: "long";
                    short: "short";
                    narrow: "narrow";
                }>>;
                minimumFractionDigits: import("zod").ZodOptional<import("zod").ZodInt>;
                maximumFractionDigits: import("zod").ZodOptional<import("zod").ZodInt>;
                signDisplay: import("zod").ZodOptional<import("zod").ZodEnum<{
                    auto: "auto";
                    always: "always";
                    exceptZero: "exceptZero";
                    never: "never";
                }>>;
                useGrouping: import("zod").ZodOptional<import("zod").ZodBoolean>;
                suffix: import("zod").ZodOptional<import("zod").ZodString>;
                kind: import("zod").ZodLiteral<"bits">;
            }, import("zod/v4/core").$strict>, import("zod").ZodObject<{
                unitDisplay: import("zod").ZodOptional<import("zod").ZodEnum<{
                    long: "long";
                    short: "short";
                    narrow: "narrow";
                }>>;
                minimumFractionDigits: import("zod").ZodOptional<import("zod").ZodInt>;
                maximumFractionDigits: import("zod").ZodOptional<import("zod").ZodInt>;
                signDisplay: import("zod").ZodOptional<import("zod").ZodEnum<{
                    auto: "auto";
                    always: "always";
                    exceptZero: "exceptZero";
                    never: "never";
                }>>;
                useGrouping: import("zod").ZodOptional<import("zod").ZodBoolean>;
                suffix: import("zod").ZodOptional<import("zod").ZodString>;
                kind: import("zod").ZodLiteral<"duration">;
                input: import("zod").ZodEnum<{
                    picoseconds: "picoseconds";
                    nanoseconds: "nanoseconds";
                    microseconds: "microseconds";
                    milliseconds: "milliseconds";
                    seconds: "seconds";
                    minutes: "minutes";
                    hours: "hours";
                    days: "days";
                    weeks: "weeks";
                    months: "months";
                    years: "years";
                }>;
                output: import("zod").ZodOptional<import("zod").ZodUnion<readonly [import("zod").ZodEnum<{
                    nanoseconds: "nanoseconds";
                    microseconds: "microseconds";
                    milliseconds: "milliseconds";
                    seconds: "seconds";
                    minutes: "minutes";
                    hours: "hours";
                    days: "days";
                    weeks: "weeks";
                    months: "months";
                    years: "years";
                }>, import("zod").ZodLiteral<"auto">]>>;
            }, import("zod/v4/core").$strict>, import("zod").ZodObject<{
                kind: import("zod").ZodLiteral<"date">;
                timeZone: import("zod").ZodOptional<import("zod").ZodString>;
                dateStyle: import("zod").ZodOptional<import("zod").ZodEnum<{
                    long: "long";
                    short: "short";
                    full: "full";
                    medium: "medium";
                }>>;
                timeStyle: import("zod").ZodOptional<import("zod").ZodEnum<{
                    long: "long";
                    short: "short";
                    full: "full";
                    medium: "medium";
                }>>;
                weekday: import("zod").ZodOptional<import("zod").ZodEnum<{
                    long: "long";
                    short: "short";
                    narrow: "narrow";
                }>>;
                year: import("zod").ZodOptional<import("zod").ZodEnum<{
                    numeric: "numeric";
                    "2-digit": "2-digit";
                }>>;
                month: import("zod").ZodOptional<import("zod").ZodEnum<{
                    long: "long";
                    short: "short";
                    narrow: "narrow";
                    numeric: "numeric";
                    "2-digit": "2-digit";
                }>>;
                day: import("zod").ZodOptional<import("zod").ZodEnum<{
                    numeric: "numeric";
                    "2-digit": "2-digit";
                }>>;
                hour: import("zod").ZodOptional<import("zod").ZodEnum<{
                    numeric: "numeric";
                    "2-digit": "2-digit";
                }>>;
                minute: import("zod").ZodOptional<import("zod").ZodEnum<{
                    numeric: "numeric";
                    "2-digit": "2-digit";
                }>>;
                second: import("zod").ZodOptional<import("zod").ZodEnum<{
                    numeric: "numeric";
                    "2-digit": "2-digit";
                }>>;
                fractionalSecondDigits: import("zod").ZodOptional<import("zod").ZodUnion<readonly [import("zod").ZodLiteral<1>, import("zod").ZodLiteral<2>, import("zod").ZodLiteral<3>]>>;
                hour12: import("zod").ZodOptional<import("zod").ZodBoolean>;
                timeZoneName: import("zod").ZodOptional<import("zod").ZodEnum<{
                    long: "long";
                    short: "short";
                    shortOffset: "shortOffset";
                    longOffset: "longOffset";
                }>>;
            }, import("zod/v4/core").$strict>, import("zod").ZodObject<{
                kind: import("zod").ZodLiteral<"text">;
            }, import("zod/v4/core").$strict>], "kind">>;
            showText: import("zod").ZodOptional<import("zod").ZodBoolean>;
            color: import("zod").ZodOptional<import("zod").ZodUnion<readonly [import("zod").ZodObject<{
                light: import("zod").ZodString;
                dark: import("zod").ZodString;
            }, import("zod/v4/core").$strict>, import("zod").ZodObject<{
                token: import("zod").ZodEnum<{
                    text: "text";
                    textSubdued: "textSubdued";
                    axis: "axis";
                    gridLine: "gridLine";
                    background: "background";
                    border: "border";
                }>;
            }, import("zod/v4/core").$strict>, import("zod").ZodObject<{
                palette: import("zod").ZodLiteral<"categorical">;
                index: import("zod").ZodInt;
            }, import("zod/v4/core").$strict>]>>;
            fill: import("zod").ZodOptional<import("zod").ZodEnum<{
                above: "above";
                below: "below";
            }>>;
            icon: import("zod").ZodOptional<import("zod").ZodEnum<{
                alert: "alert";
                asterisk: "asterisk";
                bell: "bell";
                bolt: "bolt";
                bug: "bug";
                circle: "circle";
                comment: "comment";
                external: "external";
                flag: "flag";
                globe: "globe";
                heart: "heart";
                marker: "marker";
                pin: "pin";
                pinFilled: "pinFilled";
                processor: "processor";
                sortDown: "sortDown";
                sortUp: "sortUp";
                star: "star";
                starFilled: "starFilled";
                tag: "tag";
                temperature: "temperature";
                triangle: "triangle";
            }>>;
            strokeWidth: import("zod").ZodOptional<import("zod").ZodNumber>;
            strokeDash: import("zod").ZodOptional<import("zod").ZodEnum<{
                solid: "solid";
                dashed: "dashed";
                dotted: "dotted";
            }>>;
            textPosition: import("zod").ZodOptional<import("zod").ZodEnum<{
                auto: "auto";
                left: "left";
                right: "right";
            }>>;
        }, import("zod/v4/core").$strict>>;
    }, import("zod/v4/core").$strict>, import("zod").ZodObject<{
        kind: import("zod").ZodLiteral<"annotations">;
        events: import("zod").ZodArray<import("zod").ZodDiscriminatedUnion<[import("zod").ZodObject<{
            kind: import("zod").ZodLiteral<"point">;
            at: import("zod").ZodUnion<readonly [import("zod").ZodNumber, import("zod").ZodISODateTime]>;
            label: import("zod").ZodOptional<import("zod").ZodString>;
            text: import("zod").ZodOptional<import("zod").ZodString>;
            color: import("zod").ZodOptional<import("zod").ZodUnion<readonly [import("zod").ZodObject<{
                light: import("zod").ZodString;
                dark: import("zod").ZodString;
            }, import("zod/v4/core").$strict>, import("zod").ZodObject<{
                token: import("zod").ZodEnum<{
                    text: "text";
                    textSubdued: "textSubdued";
                    axis: "axis";
                    gridLine: "gridLine";
                    background: "background";
                    border: "border";
                }>;
            }, import("zod/v4/core").$strict>, import("zod").ZodObject<{
                palette: import("zod").ZodLiteral<"categorical">;
                index: import("zod").ZodInt;
            }, import("zod/v4/core").$strict>]>>;
            icon: import("zod").ZodOptional<import("zod").ZodEnum<{
                alert: "alert";
                asterisk: "asterisk";
                bell: "bell";
                bolt: "bolt";
                bug: "bug";
                circle: "circle";
                comment: "comment";
                external: "external";
                flag: "flag";
                globe: "globe";
                heart: "heart";
                marker: "marker";
                pin: "pin";
                pinFilled: "pinFilled";
                processor: "processor";
                sortDown: "sortDown";
                sortUp: "sortUp";
                star: "star";
                starFilled: "starFilled";
                tag: "tag";
                temperature: "temperature";
                triangle: "triangle";
            }>>;
            line: import("zod").ZodOptional<import("zod").ZodObject<{
                width: import("zod").ZodNumber;
                dash: import("zod").ZodEnum<{
                    solid: "solid";
                    dashed: "dashed";
                    dotted: "dotted";
                }>;
            }, import("zod/v4/core").$strict>>;
            hidden: import("zod").ZodOptional<import("zod").ZodBoolean>;
        }, import("zod/v4/core").$strict>, import("zod").ZodObject<{
            kind: import("zod").ZodLiteral<"range">;
            from: import("zod").ZodUnion<readonly [import("zod").ZodNumber, import("zod").ZodISODateTime]>;
            to: import("zod").ZodUnion<readonly [import("zod").ZodNumber, import("zod").ZodISODateTime]>;
            label: import("zod").ZodOptional<import("zod").ZodString>;
            color: import("zod").ZodOptional<import("zod").ZodUnion<readonly [import("zod").ZodObject<{
                light: import("zod").ZodString;
                dark: import("zod").ZodString;
            }, import("zod/v4/core").$strict>, import("zod").ZodObject<{
                token: import("zod").ZodEnum<{
                    text: "text";
                    textSubdued: "textSubdued";
                    axis: "axis";
                    gridLine: "gridLine";
                    background: "background";
                    border: "border";
                }>;
            }, import("zod/v4/core").$strict>, import("zod").ZodObject<{
                palette: import("zod").ZodLiteral<"categorical">;
                index: import("zod").ZodInt;
            }, import("zod/v4/core").$strict>]>>;
            fill: import("zod").ZodOptional<import("zod").ZodEnum<{
                inside: "inside";
                outside: "outside";
            }>>;
            hidden: import("zod").ZodOptional<import("zod").ZodBoolean>;
        }, import("zod/v4/core").$strict>], "kind">>;
    }, import("zod/v4/core").$strict>], "kind">>;
    axes: import("zod").ZodOptional<import("zod").ZodObject<{
        x: import("zod").ZodOptional<import("zod").ZodObject<{
            scale: import("zod").ZodOptional<import("zod").ZodEnum<{
                linear: "linear";
                temporal: "temporal";
                ordinal: "ordinal";
            }>>;
            domain: import("zod").ZodOptional<import("zod").ZodDiscriminatedUnion<[import("zod").ZodObject<{
                kind: import("zod").ZodLiteral<"fit">;
            }, import("zod/v4/core").$strict>, import("zod").ZodObject<{
                kind: import("zod").ZodLiteral<"custom">;
                min: import("zod").ZodNumber;
                max: import("zod").ZodNumber;
            }, import("zod/v4/core").$strict>], "kind">>;
            rounding: import("zod").ZodOptional<import("zod").ZodBoolean>;
            interval: import("zod").ZodOptional<import("zod").ZodNumber>;
            title: import("zod").ZodOptional<import("zod").ZodString>;
            ticks: import("zod").ZodOptional<import("zod").ZodBoolean>;
            grid: import("zod").ZodOptional<import("zod").ZodBoolean>;
            labelOrientation: import("zod").ZodOptional<import("zod").ZodEnum<{
                horizontal: "horizontal";
                vertical: "vertical";
                angled: "angled";
            }>>;
        }, import("zod/v4/core").$strict>>;
        y: import("zod").ZodOptional<import("zod").ZodObject<{
            scale: import("zod").ZodOptional<import("zod").ZodEnum<{
                linear: "linear";
                log: "log";
                sqrt: "sqrt";
            }>>;
            domain: import("zod").ZodOptional<import("zod").ZodDiscriminatedUnion<[import("zod").ZodObject<{
                kind: import("zod").ZodLiteral<"full">;
            }, import("zod/v4/core").$strict>, import("zod").ZodObject<{
                kind: import("zod").ZodLiteral<"fit">;
            }, import("zod/v4/core").$strict>, import("zod").ZodObject<{
                kind: import("zod").ZodLiteral<"custom">;
                min: import("zod").ZodNumber;
                max: import("zod").ZodNumber;
            }, import("zod/v4/core").$strict>], "kind">>;
            rounding: import("zod").ZodOptional<import("zod").ZodBoolean>;
            title: import("zod").ZodOptional<import("zod").ZodString>;
            ticks: import("zod").ZodOptional<import("zod").ZodBoolean>;
            grid: import("zod").ZodOptional<import("zod").ZodBoolean>;
            labelOrientation: import("zod").ZodOptional<import("zod").ZodEnum<{
                horizontal: "horizontal";
                vertical: "vertical";
                angled: "angled";
            }>>;
        }, import("zod/v4/core").$strict>>;
        y2: import("zod").ZodOptional<import("zod").ZodObject<{
            scale: import("zod").ZodOptional<import("zod").ZodEnum<{
                linear: "linear";
                log: "log";
                sqrt: "sqrt";
            }>>;
            domain: import("zod").ZodOptional<import("zod").ZodDiscriminatedUnion<[import("zod").ZodObject<{
                kind: import("zod").ZodLiteral<"full">;
            }, import("zod/v4/core").$strict>, import("zod").ZodObject<{
                kind: import("zod").ZodLiteral<"fit">;
            }, import("zod/v4/core").$strict>, import("zod").ZodObject<{
                kind: import("zod").ZodLiteral<"custom">;
                min: import("zod").ZodNumber;
                max: import("zod").ZodNumber;
            }, import("zod/v4/core").$strict>], "kind">>;
            rounding: import("zod").ZodOptional<import("zod").ZodBoolean>;
            title: import("zod").ZodOptional<import("zod").ZodString>;
            ticks: import("zod").ZodOptional<import("zod").ZodBoolean>;
            grid: import("zod").ZodOptional<import("zod").ZodBoolean>;
            labelOrientation: import("zod").ZodOptional<import("zod").ZodEnum<{
                horizontal: "horizontal";
                vertical: "vertical";
                angled: "angled";
            }>>;
        }, import("zod/v4/core").$strict>>;
    }, import("zod/v4/core").$strict>>;
    legend: import("zod").ZodOptional<import("zod").ZodObject<{
        visibility: import("zod").ZodOptional<import("zod").ZodEnum<{
            auto: "auto";
            visible: "visible";
            hidden: "hidden";
        }>>;
        position: import("zod").ZodOptional<import("zod").ZodEnum<{
            left: "left";
            right: "right";
            top: "top";
            bottom: "bottom";
        }>>;
        inside: import("zod").ZodOptional<import("zod").ZodEnum<{
            top_left: "top_left";
            top_right: "top_right";
            bottom_left: "bottom_left";
            bottom_right: "bottom_right";
        }>>;
        layout: import("zod").ZodOptional<import("zod").ZodEnum<{
            grid: "grid";
            list: "list";
        }>>;
        columns: import("zod").ZodOptional<import("zod").ZodInt>;
        maxLines: import("zod").ZodOptional<import("zod").ZodInt>;
        size: import("zod").ZodOptional<import("zod").ZodEnum<{
            auto: "auto";
            s: "s";
            m: "m";
            l: "l";
            xl: "xl";
        }>>;
        statistics: import("zod").ZodOptional<import("zod").ZodArray<import("zod").ZodEnum<{
            range: "range";
            avg: "avg";
            count: "count";
            min: "min";
            max: "max";
            median: "median";
            last_value: "last_value";
            last_non_null_value: "last_non_null_value";
            first_value: "first_value";
            first_non_null_value: "first_non_null_value";
            difference: "difference";
            difference_percentage: "difference_percentage";
            total: "total";
            standard_deviation: "standard_deviation";
            variance: "variance";
            distinct_count: "distinct_count";
            current_and_last_value: "current_and_last_value";
        }>>>;
        seriesHeader: import("zod").ZodOptional<import("zod").ZodString>;
    }, import("zod/v4/core").$strict>>;
    style: import("zod").ZodOptional<import("zod").ZodObject<{
        interpolation: import("zod").ZodOptional<import("zod").ZodEnum<{
            linear: "linear";
            smooth: "smooth";
            stepped: "stepped";
        }>>;
        fitting: import("zod").ZodOptional<import("zod").ZodObject<{
            kind: import("zod").ZodEnum<{
                linear: "linear";
                none: "none";
                zero: "zero";
                carry: "carry";
                lookahead: "lookahead";
                average: "average";
                nearest: "nearest";
            }>;
            emphasize: import("zod").ZodOptional<import("zod").ZodBoolean>;
            extend: import("zod").ZodOptional<import("zod").ZodEnum<{
                none: "none";
                zero: "zero";
                nearest: "nearest";
            }>>;
        }, import("zod/v4/core").$strict>>;
        points: import("zod").ZodOptional<import("zod").ZodEnum<{
            auto: "auto";
            visible: "visible";
            hidden: "hidden";
        }>>;
        areaOpacity: import("zod").ZodOptional<import("zod").ZodNumber>;
        areaFill: import("zod").ZodOptional<import("zod").ZodEnum<{
            solid: "solid";
            gradient: "gradient";
        }>>;
        barMinimumHeight: import("zod").ZodOptional<import("zod").ZodNumber>;
        barValueLabels: import("zod").ZodOptional<import("zod").ZodBoolean>;
        partialBuckets: import("zod").ZodOptional<import("zod").ZodObject<{
            from: import("zod").ZodUnion<readonly [import("zod").ZodNumber, import("zod").ZodISODateTime]>;
            to: import("zod").ZodUnion<readonly [import("zod").ZodNumber, import("zod").ZodISODateTime]>;
        }, import("zod/v4/core").$strict>>;
        currentTime: import("zod").ZodOptional<import("zod").ZodUnion<readonly [import("zod").ZodNumber, import("zod").ZodISODateTime]>>;
    }, import("zod/v4/core").$strict>>;
    emphasis: import("zod").ZodOptional<import("zod").ZodArray<import("zod").ZodObject<{
        rows: import("zod").ZodArray<import("zod").ZodInt>;
        note: import("zod").ZodOptional<import("zod").ZodString>;
    }, import("zod/v4/core").$strict>>>;
    title: import("zod").ZodOptional<import("zod").ZodString>;
    description: import("zod").ZodOptional<import("zod").ZodString>;
    data: import("zod").ZodObject<{
        columns: import("zod").ZodArray<import("zod").ZodObject<{
            id: import("zod").ZodString;
            label: import("zod").ZodString;
            type: import("zod").ZodEnum<{
                string: "string";
                number: "number";
                boolean: "boolean";
                date: "date";
            }>;
            role: import("zod").ZodEnum<{
                dimension: "dimension";
                metric: "metric";
            }>;
            format: import("zod").ZodOptional<import("zod").ZodDiscriminatedUnion<[import("zod").ZodObject<{
                notation: import("zod").ZodOptional<import("zod").ZodEnum<{
                    standard: "standard";
                    compact: "compact";
                }>>;
                minimumFractionDigits: import("zod").ZodOptional<import("zod").ZodInt>;
                maximumFractionDigits: import("zod").ZodOptional<import("zod").ZodInt>;
                signDisplay: import("zod").ZodOptional<import("zod").ZodEnum<{
                    auto: "auto";
                    always: "always";
                    exceptZero: "exceptZero";
                    never: "never";
                }>>;
                useGrouping: import("zod").ZodOptional<import("zod").ZodBoolean>;
                suffix: import("zod").ZodOptional<import("zod").ZodString>;
                kind: import("zod").ZodLiteral<"number">;
            }, import("zod/v4/core").$strict>, import("zod").ZodObject<{
                fractional: import("zod").ZodOptional<import("zod").ZodBoolean>;
                minimumFractionDigits: import("zod").ZodOptional<import("zod").ZodInt>;
                maximumFractionDigits: import("zod").ZodOptional<import("zod").ZodInt>;
                signDisplay: import("zod").ZodOptional<import("zod").ZodEnum<{
                    auto: "auto";
                    always: "always";
                    exceptZero: "exceptZero";
                    never: "never";
                }>>;
                useGrouping: import("zod").ZodOptional<import("zod").ZodBoolean>;
                suffix: import("zod").ZodOptional<import("zod").ZodString>;
                kind: import("zod").ZodLiteral<"percent">;
            }, import("zod/v4/core").$strict>, import("zod").ZodObject<{
                base: import("zod").ZodOptional<import("zod").ZodUnion<readonly [import("zod").ZodLiteral<1000>, import("zod").ZodLiteral<1024>]>>;
                unitDisplay: import("zod").ZodOptional<import("zod").ZodEnum<{
                    long: "long";
                    short: "short";
                    narrow: "narrow";
                }>>;
                minimumFractionDigits: import("zod").ZodOptional<import("zod").ZodInt>;
                maximumFractionDigits: import("zod").ZodOptional<import("zod").ZodInt>;
                signDisplay: import("zod").ZodOptional<import("zod").ZodEnum<{
                    auto: "auto";
                    always: "always";
                    exceptZero: "exceptZero";
                    never: "never";
                }>>;
                useGrouping: import("zod").ZodOptional<import("zod").ZodBoolean>;
                suffix: import("zod").ZodOptional<import("zod").ZodString>;
                kind: import("zod").ZodLiteral<"bytes">;
            }, import("zod/v4/core").$strict>, import("zod").ZodObject<{
                base: import("zod").ZodOptional<import("zod").ZodUnion<readonly [import("zod").ZodLiteral<1000>, import("zod").ZodLiteral<1024>]>>;
                unitDisplay: import("zod").ZodOptional<import("zod").ZodEnum<{
                    long: "long";
                    short: "short";
                    narrow: "narrow";
                }>>;
                minimumFractionDigits: import("zod").ZodOptional<import("zod").ZodInt>;
                maximumFractionDigits: import("zod").ZodOptional<import("zod").ZodInt>;
                signDisplay: import("zod").ZodOptional<import("zod").ZodEnum<{
                    auto: "auto";
                    always: "always";
                    exceptZero: "exceptZero";
                    never: "never";
                }>>;
                useGrouping: import("zod").ZodOptional<import("zod").ZodBoolean>;
                suffix: import("zod").ZodOptional<import("zod").ZodString>;
                kind: import("zod").ZodLiteral<"bits">;
            }, import("zod/v4/core").$strict>, import("zod").ZodObject<{
                unitDisplay: import("zod").ZodOptional<import("zod").ZodEnum<{
                    long: "long";
                    short: "short";
                    narrow: "narrow";
                }>>;
                minimumFractionDigits: import("zod").ZodOptional<import("zod").ZodInt>;
                maximumFractionDigits: import("zod").ZodOptional<import("zod").ZodInt>;
                signDisplay: import("zod").ZodOptional<import("zod").ZodEnum<{
                    auto: "auto";
                    always: "always";
                    exceptZero: "exceptZero";
                    never: "never";
                }>>;
                useGrouping: import("zod").ZodOptional<import("zod").ZodBoolean>;
                suffix: import("zod").ZodOptional<import("zod").ZodString>;
                kind: import("zod").ZodLiteral<"duration">;
                input: import("zod").ZodEnum<{
                    picoseconds: "picoseconds";
                    nanoseconds: "nanoseconds";
                    microseconds: "microseconds";
                    milliseconds: "milliseconds";
                    seconds: "seconds";
                    minutes: "minutes";
                    hours: "hours";
                    days: "days";
                    weeks: "weeks";
                    months: "months";
                    years: "years";
                }>;
                output: import("zod").ZodOptional<import("zod").ZodUnion<readonly [import("zod").ZodEnum<{
                    nanoseconds: "nanoseconds";
                    microseconds: "microseconds";
                    milliseconds: "milliseconds";
                    seconds: "seconds";
                    minutes: "minutes";
                    hours: "hours";
                    days: "days";
                    weeks: "weeks";
                    months: "months";
                    years: "years";
                }>, import("zod").ZodLiteral<"auto">]>>;
            }, import("zod/v4/core").$strict>, import("zod").ZodObject<{
                kind: import("zod").ZodLiteral<"date">;
                timeZone: import("zod").ZodOptional<import("zod").ZodString>;
                dateStyle: import("zod").ZodOptional<import("zod").ZodEnum<{
                    long: "long";
                    short: "short";
                    full: "full";
                    medium: "medium";
                }>>;
                timeStyle: import("zod").ZodOptional<import("zod").ZodEnum<{
                    long: "long";
                    short: "short";
                    full: "full";
                    medium: "medium";
                }>>;
                weekday: import("zod").ZodOptional<import("zod").ZodEnum<{
                    long: "long";
                    short: "short";
                    narrow: "narrow";
                }>>;
                year: import("zod").ZodOptional<import("zod").ZodEnum<{
                    numeric: "numeric";
                    "2-digit": "2-digit";
                }>>;
                month: import("zod").ZodOptional<import("zod").ZodEnum<{
                    long: "long";
                    short: "short";
                    narrow: "narrow";
                    numeric: "numeric";
                    "2-digit": "2-digit";
                }>>;
                day: import("zod").ZodOptional<import("zod").ZodEnum<{
                    numeric: "numeric";
                    "2-digit": "2-digit";
                }>>;
                hour: import("zod").ZodOptional<import("zod").ZodEnum<{
                    numeric: "numeric";
                    "2-digit": "2-digit";
                }>>;
                minute: import("zod").ZodOptional<import("zod").ZodEnum<{
                    numeric: "numeric";
                    "2-digit": "2-digit";
                }>>;
                second: import("zod").ZodOptional<import("zod").ZodEnum<{
                    numeric: "numeric";
                    "2-digit": "2-digit";
                }>>;
                fractionalSecondDigits: import("zod").ZodOptional<import("zod").ZodUnion<readonly [import("zod").ZodLiteral<1>, import("zod").ZodLiteral<2>, import("zod").ZodLiteral<3>]>>;
                hour12: import("zod").ZodOptional<import("zod").ZodBoolean>;
                timeZoneName: import("zod").ZodOptional<import("zod").ZodEnum<{
                    long: "long";
                    short: "short";
                    shortOffset: "shortOffset";
                    longOffset: "longOffset";
                }>>;
            }, import("zod/v4/core").$strict>, import("zod").ZodObject<{
                kind: import("zod").ZodLiteral<"text">;
            }, import("zod/v4/core").$strict>], "kind">>;
            multivalue: import("zod").ZodOptional<import("zod").ZodLiteral<true>>;
            source: import("zod").ZodOptional<import("zod").ZodUnknown>;
        }, import("zod/v4/core").$strict>>;
        rows: import("zod").ZodArray<import("zod").ZodArray<import("zod").ZodUnion<readonly [import("zod").ZodUnion<readonly [import("zod").ZodNumber, import("zod").ZodString, import("zod").ZodBoolean, import("zod").ZodNull]>, import("zod").ZodArray<import("zod").ZodUnion<readonly [import("zod").ZodNumber, import("zod").ZodString, import("zod").ZodBoolean, import("zod").ZodNull]>>]>>>;
        source: import("zod").ZodOptional<import("zod").ZodUnknown>;
        missing: import("zod").ZodOptional<import("zod").ZodObject<{
            null: import("zod").ZodOptional<import("zod").ZodString>;
            empty: import("zod").ZodOptional<import("zod").ZodString>;
            nan: import("zod").ZodOptional<import("zod").ZodString>;
        }, import("zod/v4/core").$strict>>;
        display: import("zod").ZodOptional<import("zod").ZodRecord<import("zod").ZodString, import("zod").ZodArray<import("zod").ZodString>>>;
    }, import("zod/v4/core").$strict>;
    colors: import("zod").ZodOptional<import("zod").ZodObject<{
        byKey: import("zod").ZodOptional<import("zod").ZodRecord<import("zod").ZodString, import("zod").ZodUnion<readonly [import("zod").ZodObject<{
            light: import("zod").ZodString;
            dark: import("zod").ZodString;
        }, import("zod/v4/core").$strict>, import("zod").ZodObject<{
            token: import("zod").ZodEnum<{
                text: "text";
                textSubdued: "textSubdued";
                axis: "axis";
                gridLine: "gridLine";
                background: "background";
                border: "border";
            }>;
        }, import("zod/v4/core").$strict>, import("zod").ZodObject<{
            palette: import("zod").ZodLiteral<"categorical">;
            index: import("zod").ZodInt;
        }, import("zod/v4/core").$strict>]>>>;
        bands: import("zod").ZodOptional<import("zod").ZodArray<import("zod").ZodObject<{
            from: import("zod").ZodOptional<import("zod").ZodNumber>;
            to: import("zod").ZodOptional<import("zod").ZodNumber>;
            color: import("zod").ZodUnion<readonly [import("zod").ZodObject<{
                light: import("zod").ZodString;
                dark: import("zod").ZodString;
            }, import("zod/v4/core").$strict>, import("zod").ZodObject<{
                token: import("zod").ZodEnum<{
                    text: "text";
                    textSubdued: "textSubdued";
                    axis: "axis";
                    gridLine: "gridLine";
                    background: "background";
                    border: "border";
                }>;
            }, import("zod/v4/core").$strict>, import("zod").ZodObject<{
                palette: import("zod").ZodLiteral<"categorical">;
                index: import("zod").ZodInt;
            }, import("zod/v4/core").$strict>]>;
        }, import("zod/v4/core").$strict>>>;
    }, import("zod/v4/core").$strict>>;
    source: import("zod").ZodOptional<import("zod").ZodObject<{
        host: import("zod").ZodString;
        hostVersion: import("zod").ZodOptional<import("zod").ZodString>;
        capturedAt: import("zod").ZodISODateTime;
        timeRange: import("zod").ZodOptional<import("zod").ZodObject<{
            from: import("zod").ZodISODateTime;
            to: import("zod").ZodISODateTime;
        }, import("zod/v4/core").$strict>>;
        meta: import("zod").ZodOptional<import("zod").ZodRecord<import("zod").ZodString, import("zod").ZodUnknown>>;
    }, import("zod/v4/core").$strict>>;
    losses: import("zod").ZodOptional<import("zod").ZodArray<import("zod").ZodObject<{
        path: import("zod").ZodString;
        kind: import("zod").ZodEnum<{
            dropped: "dropped";
            approximated: "approximated";
            prerendered: "prerendered";
        }>;
        note: import("zod").ZodString;
    }, import("zod/v4/core").$strict>>>;
    type: import("zod").ZodLiteral<"xyChart">;
} & {
    id: ReturnType<() => import("zod").ZodOptional<import("zod").ZodString>>;
    surfaces: ReturnType<() => import("zod").ZodOptional<import("zod").ZodArray<import("zod").ZodEnum<{
        react: "react";
        snapshot: "snapshot";
        text: "text";
        markdown: "markdown";
        slack: "slack";
    }>>>>;
}, import("zod/v4/core").$strip>>, import("@elastic/isomer-sdk").PrimitiveDefinition<ChartNode, import("./context").ChartsPackTypes, import("zod").ZodObject<{
    interactions: import("zod").ZodOptional<import("zod").ZodObject<{
        select: import("zod").ZodOptional<import("zod").ZodArray<import("zod").ZodEnum<{
            slice: "slice";
        }>>>;
        sync: import("zod").ZodOptional<import("zod").ZodObject<{
            cursor: import("zod").ZodOptional<import("zod").ZodBoolean>;
            tooltips: import("zod").ZodOptional<import("zod").ZodBoolean>;
        }, import("zod/v4/core").$strict>>;
        link: import("zod").ZodOptional<import("zod").ZodObject<{
            href: import("zod").ZodString;
            label: import("zod").ZodString;
        }, import("zod/v4/core").$strict>>;
    }, import("zod/v4/core").$strict>>;
    shape: import("zod").ZodEnum<{
        pie: "pie";
        donut: "donut";
        treemap: "treemap";
        mosaic: "mosaic";
        waffle: "waffle";
    }>;
    metrics: import("zod").ZodArray<import("zod").ZodObject<{
        column: import("zod").ZodString;
    }, import("zod/v4/core").$strict>>;
    groups: import("zod").ZodOptional<import("zod").ZodArray<import("zod").ZodObject<{
        column: import("zod").ZodString;
    }, import("zod/v4/core").$strict>>>;
    labels: import("zod").ZodOptional<import("zod").ZodObject<{
        categories: import("zod").ZodOptional<import("zod").ZodEnum<{
            auto: "auto";
            hidden: "hidden";
            inside: "inside";
        }>>;
        values: import("zod").ZodOptional<import("zod").ZodEnum<{
            value: "value";
            percent: "percent";
            hidden: "hidden";
        }>>;
        percentDecimals: import("zod").ZodOptional<import("zod").ZodInt>;
    }, import("zod/v4/core").$strict>>;
    donutHole: import("zod").ZodOptional<import("zod").ZodNumber>;
    legend: import("zod").ZodOptional<import("zod").ZodObject<{
        visibility: import("zod").ZodOptional<import("zod").ZodEnum<{
            auto: "auto";
            visible: "visible";
            hidden: "hidden";
        }>>;
        position: import("zod").ZodOptional<import("zod").ZodEnum<{
            left: "left";
            right: "right";
            top: "top";
            bottom: "bottom";
        }>>;
        nested: import("zod").ZodOptional<import("zod").ZodBoolean>;
        maxLines: import("zod").ZodOptional<import("zod").ZodInt>;
        size: import("zod").ZodOptional<import("zod").ZodEnum<{
            auto: "auto";
            s: "s";
            m: "m";
            l: "l";
            xl: "xl";
        }>>;
        values: import("zod").ZodOptional<import("zod").ZodBoolean>;
    }, import("zod/v4/core").$strict>>;
    emphasis: import("zod").ZodOptional<import("zod").ZodArray<import("zod").ZodObject<{
        rows: import("zod").ZodArray<import("zod").ZodInt>;
        note: import("zod").ZodOptional<import("zod").ZodString>;
    }, import("zod/v4/core").$strict>>>;
    title: import("zod").ZodOptional<import("zod").ZodString>;
    description: import("zod").ZodOptional<import("zod").ZodString>;
    data: import("zod").ZodObject<{
        columns: import("zod").ZodArray<import("zod").ZodObject<{
            id: import("zod").ZodString;
            label: import("zod").ZodString;
            type: import("zod").ZodEnum<{
                string: "string";
                number: "number";
                boolean: "boolean";
                date: "date";
            }>;
            role: import("zod").ZodEnum<{
                dimension: "dimension";
                metric: "metric";
            }>;
            format: import("zod").ZodOptional<import("zod").ZodDiscriminatedUnion<[import("zod").ZodObject<{
                notation: import("zod").ZodOptional<import("zod").ZodEnum<{
                    standard: "standard";
                    compact: "compact";
                }>>;
                minimumFractionDigits: import("zod").ZodOptional<import("zod").ZodInt>;
                maximumFractionDigits: import("zod").ZodOptional<import("zod").ZodInt>;
                signDisplay: import("zod").ZodOptional<import("zod").ZodEnum<{
                    auto: "auto";
                    always: "always";
                    exceptZero: "exceptZero";
                    never: "never";
                }>>;
                useGrouping: import("zod").ZodOptional<import("zod").ZodBoolean>;
                suffix: import("zod").ZodOptional<import("zod").ZodString>;
                kind: import("zod").ZodLiteral<"number">;
            }, import("zod/v4/core").$strict>, import("zod").ZodObject<{
                fractional: import("zod").ZodOptional<import("zod").ZodBoolean>;
                minimumFractionDigits: import("zod").ZodOptional<import("zod").ZodInt>;
                maximumFractionDigits: import("zod").ZodOptional<import("zod").ZodInt>;
                signDisplay: import("zod").ZodOptional<import("zod").ZodEnum<{
                    auto: "auto";
                    always: "always";
                    exceptZero: "exceptZero";
                    never: "never";
                }>>;
                useGrouping: import("zod").ZodOptional<import("zod").ZodBoolean>;
                suffix: import("zod").ZodOptional<import("zod").ZodString>;
                kind: import("zod").ZodLiteral<"percent">;
            }, import("zod/v4/core").$strict>, import("zod").ZodObject<{
                base: import("zod").ZodOptional<import("zod").ZodUnion<readonly [import("zod").ZodLiteral<1000>, import("zod").ZodLiteral<1024>]>>;
                unitDisplay: import("zod").ZodOptional<import("zod").ZodEnum<{
                    long: "long";
                    short: "short";
                    narrow: "narrow";
                }>>;
                minimumFractionDigits: import("zod").ZodOptional<import("zod").ZodInt>;
                maximumFractionDigits: import("zod").ZodOptional<import("zod").ZodInt>;
                signDisplay: import("zod").ZodOptional<import("zod").ZodEnum<{
                    auto: "auto";
                    always: "always";
                    exceptZero: "exceptZero";
                    never: "never";
                }>>;
                useGrouping: import("zod").ZodOptional<import("zod").ZodBoolean>;
                suffix: import("zod").ZodOptional<import("zod").ZodString>;
                kind: import("zod").ZodLiteral<"bytes">;
            }, import("zod/v4/core").$strict>, import("zod").ZodObject<{
                base: import("zod").ZodOptional<import("zod").ZodUnion<readonly [import("zod").ZodLiteral<1000>, import("zod").ZodLiteral<1024>]>>;
                unitDisplay: import("zod").ZodOptional<import("zod").ZodEnum<{
                    long: "long";
                    short: "short";
                    narrow: "narrow";
                }>>;
                minimumFractionDigits: import("zod").ZodOptional<import("zod").ZodInt>;
                maximumFractionDigits: import("zod").ZodOptional<import("zod").ZodInt>;
                signDisplay: import("zod").ZodOptional<import("zod").ZodEnum<{
                    auto: "auto";
                    always: "always";
                    exceptZero: "exceptZero";
                    never: "never";
                }>>;
                useGrouping: import("zod").ZodOptional<import("zod").ZodBoolean>;
                suffix: import("zod").ZodOptional<import("zod").ZodString>;
                kind: import("zod").ZodLiteral<"bits">;
            }, import("zod/v4/core").$strict>, import("zod").ZodObject<{
                unitDisplay: import("zod").ZodOptional<import("zod").ZodEnum<{
                    long: "long";
                    short: "short";
                    narrow: "narrow";
                }>>;
                minimumFractionDigits: import("zod").ZodOptional<import("zod").ZodInt>;
                maximumFractionDigits: import("zod").ZodOptional<import("zod").ZodInt>;
                signDisplay: import("zod").ZodOptional<import("zod").ZodEnum<{
                    auto: "auto";
                    always: "always";
                    exceptZero: "exceptZero";
                    never: "never";
                }>>;
                useGrouping: import("zod").ZodOptional<import("zod").ZodBoolean>;
                suffix: import("zod").ZodOptional<import("zod").ZodString>;
                kind: import("zod").ZodLiteral<"duration">;
                input: import("zod").ZodEnum<{
                    picoseconds: "picoseconds";
                    nanoseconds: "nanoseconds";
                    microseconds: "microseconds";
                    milliseconds: "milliseconds";
                    seconds: "seconds";
                    minutes: "minutes";
                    hours: "hours";
                    days: "days";
                    weeks: "weeks";
                    months: "months";
                    years: "years";
                }>;
                output: import("zod").ZodOptional<import("zod").ZodUnion<readonly [import("zod").ZodEnum<{
                    nanoseconds: "nanoseconds";
                    microseconds: "microseconds";
                    milliseconds: "milliseconds";
                    seconds: "seconds";
                    minutes: "minutes";
                    hours: "hours";
                    days: "days";
                    weeks: "weeks";
                    months: "months";
                    years: "years";
                }>, import("zod").ZodLiteral<"auto">]>>;
            }, import("zod/v4/core").$strict>, import("zod").ZodObject<{
                kind: import("zod").ZodLiteral<"date">;
                timeZone: import("zod").ZodOptional<import("zod").ZodString>;
                dateStyle: import("zod").ZodOptional<import("zod").ZodEnum<{
                    long: "long";
                    short: "short";
                    full: "full";
                    medium: "medium";
                }>>;
                timeStyle: import("zod").ZodOptional<import("zod").ZodEnum<{
                    long: "long";
                    short: "short";
                    full: "full";
                    medium: "medium";
                }>>;
                weekday: import("zod").ZodOptional<import("zod").ZodEnum<{
                    long: "long";
                    short: "short";
                    narrow: "narrow";
                }>>;
                year: import("zod").ZodOptional<import("zod").ZodEnum<{
                    numeric: "numeric";
                    "2-digit": "2-digit";
                }>>;
                month: import("zod").ZodOptional<import("zod").ZodEnum<{
                    long: "long";
                    short: "short";
                    narrow: "narrow";
                    numeric: "numeric";
                    "2-digit": "2-digit";
                }>>;
                day: import("zod").ZodOptional<import("zod").ZodEnum<{
                    numeric: "numeric";
                    "2-digit": "2-digit";
                }>>;
                hour: import("zod").ZodOptional<import("zod").ZodEnum<{
                    numeric: "numeric";
                    "2-digit": "2-digit";
                }>>;
                minute: import("zod").ZodOptional<import("zod").ZodEnum<{
                    numeric: "numeric";
                    "2-digit": "2-digit";
                }>>;
                second: import("zod").ZodOptional<import("zod").ZodEnum<{
                    numeric: "numeric";
                    "2-digit": "2-digit";
                }>>;
                fractionalSecondDigits: import("zod").ZodOptional<import("zod").ZodUnion<readonly [import("zod").ZodLiteral<1>, import("zod").ZodLiteral<2>, import("zod").ZodLiteral<3>]>>;
                hour12: import("zod").ZodOptional<import("zod").ZodBoolean>;
                timeZoneName: import("zod").ZodOptional<import("zod").ZodEnum<{
                    long: "long";
                    short: "short";
                    shortOffset: "shortOffset";
                    longOffset: "longOffset";
                }>>;
            }, import("zod/v4/core").$strict>, import("zod").ZodObject<{
                kind: import("zod").ZodLiteral<"text">;
            }, import("zod/v4/core").$strict>], "kind">>;
            multivalue: import("zod").ZodOptional<import("zod").ZodLiteral<true>>;
            source: import("zod").ZodOptional<import("zod").ZodUnknown>;
        }, import("zod/v4/core").$strict>>;
        rows: import("zod").ZodArray<import("zod").ZodArray<import("zod").ZodUnion<readonly [import("zod").ZodUnion<readonly [import("zod").ZodNumber, import("zod").ZodString, import("zod").ZodBoolean, import("zod").ZodNull]>, import("zod").ZodArray<import("zod").ZodUnion<readonly [import("zod").ZodNumber, import("zod").ZodString, import("zod").ZodBoolean, import("zod").ZodNull]>>]>>>;
        source: import("zod").ZodOptional<import("zod").ZodUnknown>;
        missing: import("zod").ZodOptional<import("zod").ZodObject<{
            null: import("zod").ZodOptional<import("zod").ZodString>;
            empty: import("zod").ZodOptional<import("zod").ZodString>;
            nan: import("zod").ZodOptional<import("zod").ZodString>;
        }, import("zod/v4/core").$strict>>;
        display: import("zod").ZodOptional<import("zod").ZodRecord<import("zod").ZodString, import("zod").ZodArray<import("zod").ZodString>>>;
    }, import("zod/v4/core").$strict>;
    colors: import("zod").ZodOptional<import("zod").ZodObject<{
        byKey: import("zod").ZodOptional<import("zod").ZodRecord<import("zod").ZodString, import("zod").ZodUnion<readonly [import("zod").ZodObject<{
            light: import("zod").ZodString;
            dark: import("zod").ZodString;
        }, import("zod/v4/core").$strict>, import("zod").ZodObject<{
            token: import("zod").ZodEnum<{
                text: "text";
                textSubdued: "textSubdued";
                axis: "axis";
                gridLine: "gridLine";
                background: "background";
                border: "border";
            }>;
        }, import("zod/v4/core").$strict>, import("zod").ZodObject<{
            palette: import("zod").ZodLiteral<"categorical">;
            index: import("zod").ZodInt;
        }, import("zod/v4/core").$strict>]>>>;
        bands: import("zod").ZodOptional<import("zod").ZodArray<import("zod").ZodObject<{
            from: import("zod").ZodOptional<import("zod").ZodNumber>;
            to: import("zod").ZodOptional<import("zod").ZodNumber>;
            color: import("zod").ZodUnion<readonly [import("zod").ZodObject<{
                light: import("zod").ZodString;
                dark: import("zod").ZodString;
            }, import("zod/v4/core").$strict>, import("zod").ZodObject<{
                token: import("zod").ZodEnum<{
                    text: "text";
                    textSubdued: "textSubdued";
                    axis: "axis";
                    gridLine: "gridLine";
                    background: "background";
                    border: "border";
                }>;
            }, import("zod/v4/core").$strict>, import("zod").ZodObject<{
                palette: import("zod").ZodLiteral<"categorical">;
                index: import("zod").ZodInt;
            }, import("zod/v4/core").$strict>]>;
        }, import("zod/v4/core").$strict>>>;
    }, import("zod/v4/core").$strict>>;
    source: import("zod").ZodOptional<import("zod").ZodObject<{
        host: import("zod").ZodString;
        hostVersion: import("zod").ZodOptional<import("zod").ZodString>;
        capturedAt: import("zod").ZodISODateTime;
        timeRange: import("zod").ZodOptional<import("zod").ZodObject<{
            from: import("zod").ZodISODateTime;
            to: import("zod").ZodISODateTime;
        }, import("zod/v4/core").$strict>>;
        meta: import("zod").ZodOptional<import("zod").ZodRecord<import("zod").ZodString, import("zod").ZodUnknown>>;
    }, import("zod/v4/core").$strict>>;
    losses: import("zod").ZodOptional<import("zod").ZodArray<import("zod").ZodObject<{
        path: import("zod").ZodString;
        kind: import("zod").ZodEnum<{
            dropped: "dropped";
            approximated: "approximated";
            prerendered: "prerendered";
        }>;
        note: import("zod").ZodString;
    }, import("zod/v4/core").$strict>>>;
    type: import("zod").ZodLiteral<"partitionChart">;
} & {
    id: ReturnType<() => import("zod").ZodOptional<import("zod").ZodString>>;
    surfaces: ReturnType<() => import("zod").ZodOptional<import("zod").ZodArray<import("zod").ZodEnum<{
        react: "react";
        snapshot: "snapshot";
        text: "text";
        markdown: "markdown";
        slack: "slack";
    }>>>>;
}, import("zod/v4/core").$strip>>, import("@elastic/isomer-sdk").PrimitiveDefinition<ChartNode, import("./context").ChartsPackTypes, import("zod").ZodObject<{
    interactions: import("zod").ZodOptional<import("zod").ZodObject<{
        select: import("zod").ZodOptional<import("zod").ZodArray<import("zod").ZodEnum<{
            cell: "cell";
        }>>>;
        brush: import("zod").ZodOptional<import("zod").ZodObject<{
            column: import("zod").ZodString;
        }, import("zod/v4/core").$strict>>;
        sync: import("zod").ZodOptional<import("zod").ZodObject<{
            cursor: import("zod").ZodOptional<import("zod").ZodBoolean>;
            tooltips: import("zod").ZodOptional<import("zod").ZodBoolean>;
        }, import("zod/v4/core").$strict>>;
        link: import("zod").ZodOptional<import("zod").ZodObject<{
            href: import("zod").ZodString;
            label: import("zod").ZodString;
        }, import("zod/v4/core").$strict>>;
    }, import("zod/v4/core").$strict>>;
    x: import("zod").ZodObject<{
        column: import("zod").ZodString;
        sort: import("zod").ZodOptional<import("zod").ZodEnum<{
            asc: "asc";
            desc: "desc";
        }>>;
        interval: import("zod").ZodOptional<import("zod").ZodNumber>;
    }, import("zod/v4/core").$strict>;
    y: import("zod").ZodOptional<import("zod").ZodObject<{
        column: import("zod").ZodString;
        sort: import("zod").ZodOptional<import("zod").ZodEnum<{
            asc: "asc";
            desc: "desc";
        }>>;
    }, import("zod/v4/core").$strict>>;
    value: import("zod").ZodObject<{
        column: import("zod").ZodString;
    }, import("zod/v4/core").$strict>;
    bandsRange: import("zod").ZodOptional<import("zod").ZodEnum<{
        percentage: "percentage";
        absolute: "absolute";
    }>>;
    cellLabels: import("zod").ZodOptional<import("zod").ZodBoolean>;
    axes: import("zod").ZodOptional<import("zod").ZodObject<{
        x: import("zod").ZodOptional<import("zod").ZodObject<{
            labelOrientation: import("zod").ZodOptional<import("zod").ZodEnum<{
                horizontal: "horizontal";
                vertical: "vertical";
                angled: "angled";
            }>>;
            title: import("zod").ZodOptional<import("zod").ZodString>;
            labels: import("zod").ZodOptional<import("zod").ZodBoolean>;
        }, import("zod/v4/core").$strict>>;
        y: import("zod").ZodOptional<import("zod").ZodObject<{
            title: import("zod").ZodOptional<import("zod").ZodString>;
            labels: import("zod").ZodOptional<import("zod").ZodBoolean>;
        }, import("zod/v4/core").$strict>>;
    }, import("zod/v4/core").$strict>>;
    gridLines: import("zod").ZodOptional<import("zod").ZodObject<{
        width: import("zod").ZodOptional<import("zod").ZodNumber>;
        color: import("zod").ZodOptional<import("zod").ZodUnion<readonly [import("zod").ZodObject<{
            light: import("zod").ZodString;
            dark: import("zod").ZodString;
        }, import("zod/v4/core").$strict>, import("zod").ZodObject<{
            token: import("zod").ZodEnum<{
                text: "text";
                textSubdued: "textSubdued";
                axis: "axis";
                gridLine: "gridLine";
                background: "background";
                border: "border";
            }>;
        }, import("zod/v4/core").$strict>, import("zod").ZodObject<{
            palette: import("zod").ZodLiteral<"categorical">;
            index: import("zod").ZodInt;
        }, import("zod/v4/core").$strict>]>>;
    }, import("zod/v4/core").$strict>>;
    legend: import("zod").ZodOptional<import("zod").ZodObject<{
        visibility: import("zod").ZodOptional<import("zod").ZodEnum<{
            visible: "visible";
            hidden: "hidden";
        }>>;
        position: import("zod").ZodOptional<import("zod").ZodEnum<{
            left: "left";
            right: "right";
            top: "top";
            bottom: "bottom";
        }>>;
        maxLines: import("zod").ZodOptional<import("zod").ZodInt>;
        size: import("zod").ZodOptional<import("zod").ZodEnum<{
            auto: "auto";
            s: "s";
            m: "m";
            l: "l";
            xl: "xl";
        }>>;
    }, import("zod/v4/core").$strict>>;
    emphasis: import("zod").ZodOptional<import("zod").ZodArray<import("zod").ZodObject<{
        rows: import("zod").ZodArray<import("zod").ZodInt>;
        note: import("zod").ZodOptional<import("zod").ZodString>;
    }, import("zod/v4/core").$strict>>>;
    title: import("zod").ZodOptional<import("zod").ZodString>;
    description: import("zod").ZodOptional<import("zod").ZodString>;
    data: import("zod").ZodObject<{
        columns: import("zod").ZodArray<import("zod").ZodObject<{
            id: import("zod").ZodString;
            label: import("zod").ZodString;
            type: import("zod").ZodEnum<{
                string: "string";
                number: "number";
                boolean: "boolean";
                date: "date";
            }>;
            role: import("zod").ZodEnum<{
                dimension: "dimension";
                metric: "metric";
            }>;
            format: import("zod").ZodOptional<import("zod").ZodDiscriminatedUnion<[import("zod").ZodObject<{
                notation: import("zod").ZodOptional<import("zod").ZodEnum<{
                    standard: "standard";
                    compact: "compact";
                }>>;
                minimumFractionDigits: import("zod").ZodOptional<import("zod").ZodInt>;
                maximumFractionDigits: import("zod").ZodOptional<import("zod").ZodInt>;
                signDisplay: import("zod").ZodOptional<import("zod").ZodEnum<{
                    auto: "auto";
                    always: "always";
                    exceptZero: "exceptZero";
                    never: "never";
                }>>;
                useGrouping: import("zod").ZodOptional<import("zod").ZodBoolean>;
                suffix: import("zod").ZodOptional<import("zod").ZodString>;
                kind: import("zod").ZodLiteral<"number">;
            }, import("zod/v4/core").$strict>, import("zod").ZodObject<{
                fractional: import("zod").ZodOptional<import("zod").ZodBoolean>;
                minimumFractionDigits: import("zod").ZodOptional<import("zod").ZodInt>;
                maximumFractionDigits: import("zod").ZodOptional<import("zod").ZodInt>;
                signDisplay: import("zod").ZodOptional<import("zod").ZodEnum<{
                    auto: "auto";
                    always: "always";
                    exceptZero: "exceptZero";
                    never: "never";
                }>>;
                useGrouping: import("zod").ZodOptional<import("zod").ZodBoolean>;
                suffix: import("zod").ZodOptional<import("zod").ZodString>;
                kind: import("zod").ZodLiteral<"percent">;
            }, import("zod/v4/core").$strict>, import("zod").ZodObject<{
                base: import("zod").ZodOptional<import("zod").ZodUnion<readonly [import("zod").ZodLiteral<1000>, import("zod").ZodLiteral<1024>]>>;
                unitDisplay: import("zod").ZodOptional<import("zod").ZodEnum<{
                    long: "long";
                    short: "short";
                    narrow: "narrow";
                }>>;
                minimumFractionDigits: import("zod").ZodOptional<import("zod").ZodInt>;
                maximumFractionDigits: import("zod").ZodOptional<import("zod").ZodInt>;
                signDisplay: import("zod").ZodOptional<import("zod").ZodEnum<{
                    auto: "auto";
                    always: "always";
                    exceptZero: "exceptZero";
                    never: "never";
                }>>;
                useGrouping: import("zod").ZodOptional<import("zod").ZodBoolean>;
                suffix: import("zod").ZodOptional<import("zod").ZodString>;
                kind: import("zod").ZodLiteral<"bytes">;
            }, import("zod/v4/core").$strict>, import("zod").ZodObject<{
                base: import("zod").ZodOptional<import("zod").ZodUnion<readonly [import("zod").ZodLiteral<1000>, import("zod").ZodLiteral<1024>]>>;
                unitDisplay: import("zod").ZodOptional<import("zod").ZodEnum<{
                    long: "long";
                    short: "short";
                    narrow: "narrow";
                }>>;
                minimumFractionDigits: import("zod").ZodOptional<import("zod").ZodInt>;
                maximumFractionDigits: import("zod").ZodOptional<import("zod").ZodInt>;
                signDisplay: import("zod").ZodOptional<import("zod").ZodEnum<{
                    auto: "auto";
                    always: "always";
                    exceptZero: "exceptZero";
                    never: "never";
                }>>;
                useGrouping: import("zod").ZodOptional<import("zod").ZodBoolean>;
                suffix: import("zod").ZodOptional<import("zod").ZodString>;
                kind: import("zod").ZodLiteral<"bits">;
            }, import("zod/v4/core").$strict>, import("zod").ZodObject<{
                unitDisplay: import("zod").ZodOptional<import("zod").ZodEnum<{
                    long: "long";
                    short: "short";
                    narrow: "narrow";
                }>>;
                minimumFractionDigits: import("zod").ZodOptional<import("zod").ZodInt>;
                maximumFractionDigits: import("zod").ZodOptional<import("zod").ZodInt>;
                signDisplay: import("zod").ZodOptional<import("zod").ZodEnum<{
                    auto: "auto";
                    always: "always";
                    exceptZero: "exceptZero";
                    never: "never";
                }>>;
                useGrouping: import("zod").ZodOptional<import("zod").ZodBoolean>;
                suffix: import("zod").ZodOptional<import("zod").ZodString>;
                kind: import("zod").ZodLiteral<"duration">;
                input: import("zod").ZodEnum<{
                    picoseconds: "picoseconds";
                    nanoseconds: "nanoseconds";
                    microseconds: "microseconds";
                    milliseconds: "milliseconds";
                    seconds: "seconds";
                    minutes: "minutes";
                    hours: "hours";
                    days: "days";
                    weeks: "weeks";
                    months: "months";
                    years: "years";
                }>;
                output: import("zod").ZodOptional<import("zod").ZodUnion<readonly [import("zod").ZodEnum<{
                    nanoseconds: "nanoseconds";
                    microseconds: "microseconds";
                    milliseconds: "milliseconds";
                    seconds: "seconds";
                    minutes: "minutes";
                    hours: "hours";
                    days: "days";
                    weeks: "weeks";
                    months: "months";
                    years: "years";
                }>, import("zod").ZodLiteral<"auto">]>>;
            }, import("zod/v4/core").$strict>, import("zod").ZodObject<{
                kind: import("zod").ZodLiteral<"date">;
                timeZone: import("zod").ZodOptional<import("zod").ZodString>;
                dateStyle: import("zod").ZodOptional<import("zod").ZodEnum<{
                    long: "long";
                    short: "short";
                    full: "full";
                    medium: "medium";
                }>>;
                timeStyle: import("zod").ZodOptional<import("zod").ZodEnum<{
                    long: "long";
                    short: "short";
                    full: "full";
                    medium: "medium";
                }>>;
                weekday: import("zod").ZodOptional<import("zod").ZodEnum<{
                    long: "long";
                    short: "short";
                    narrow: "narrow";
                }>>;
                year: import("zod").ZodOptional<import("zod").ZodEnum<{
                    numeric: "numeric";
                    "2-digit": "2-digit";
                }>>;
                month: import("zod").ZodOptional<import("zod").ZodEnum<{
                    long: "long";
                    short: "short";
                    narrow: "narrow";
                    numeric: "numeric";
                    "2-digit": "2-digit";
                }>>;
                day: import("zod").ZodOptional<import("zod").ZodEnum<{
                    numeric: "numeric";
                    "2-digit": "2-digit";
                }>>;
                hour: import("zod").ZodOptional<import("zod").ZodEnum<{
                    numeric: "numeric";
                    "2-digit": "2-digit";
                }>>;
                minute: import("zod").ZodOptional<import("zod").ZodEnum<{
                    numeric: "numeric";
                    "2-digit": "2-digit";
                }>>;
                second: import("zod").ZodOptional<import("zod").ZodEnum<{
                    numeric: "numeric";
                    "2-digit": "2-digit";
                }>>;
                fractionalSecondDigits: import("zod").ZodOptional<import("zod").ZodUnion<readonly [import("zod").ZodLiteral<1>, import("zod").ZodLiteral<2>, import("zod").ZodLiteral<3>]>>;
                hour12: import("zod").ZodOptional<import("zod").ZodBoolean>;
                timeZoneName: import("zod").ZodOptional<import("zod").ZodEnum<{
                    long: "long";
                    short: "short";
                    shortOffset: "shortOffset";
                    longOffset: "longOffset";
                }>>;
            }, import("zod/v4/core").$strict>, import("zod").ZodObject<{
                kind: import("zod").ZodLiteral<"text">;
            }, import("zod/v4/core").$strict>], "kind">>;
            multivalue: import("zod").ZodOptional<import("zod").ZodLiteral<true>>;
            source: import("zod").ZodOptional<import("zod").ZodUnknown>;
        }, import("zod/v4/core").$strict>>;
        rows: import("zod").ZodArray<import("zod").ZodArray<import("zod").ZodUnion<readonly [import("zod").ZodUnion<readonly [import("zod").ZodNumber, import("zod").ZodString, import("zod").ZodBoolean, import("zod").ZodNull]>, import("zod").ZodArray<import("zod").ZodUnion<readonly [import("zod").ZodNumber, import("zod").ZodString, import("zod").ZodBoolean, import("zod").ZodNull]>>]>>>;
        source: import("zod").ZodOptional<import("zod").ZodUnknown>;
        missing: import("zod").ZodOptional<import("zod").ZodObject<{
            null: import("zod").ZodOptional<import("zod").ZodString>;
            empty: import("zod").ZodOptional<import("zod").ZodString>;
            nan: import("zod").ZodOptional<import("zod").ZodString>;
        }, import("zod/v4/core").$strict>>;
        display: import("zod").ZodOptional<import("zod").ZodRecord<import("zod").ZodString, import("zod").ZodArray<import("zod").ZodString>>>;
    }, import("zod/v4/core").$strict>;
    colors: import("zod").ZodOptional<import("zod").ZodObject<{
        byKey: import("zod").ZodOptional<import("zod").ZodRecord<import("zod").ZodString, import("zod").ZodUnion<readonly [import("zod").ZodObject<{
            light: import("zod").ZodString;
            dark: import("zod").ZodString;
        }, import("zod/v4/core").$strict>, import("zod").ZodObject<{
            token: import("zod").ZodEnum<{
                text: "text";
                textSubdued: "textSubdued";
                axis: "axis";
                gridLine: "gridLine";
                background: "background";
                border: "border";
            }>;
        }, import("zod/v4/core").$strict>, import("zod").ZodObject<{
            palette: import("zod").ZodLiteral<"categorical">;
            index: import("zod").ZodInt;
        }, import("zod/v4/core").$strict>]>>>;
        bands: import("zod").ZodOptional<import("zod").ZodArray<import("zod").ZodObject<{
            from: import("zod").ZodOptional<import("zod").ZodNumber>;
            to: import("zod").ZodOptional<import("zod").ZodNumber>;
            color: import("zod").ZodUnion<readonly [import("zod").ZodObject<{
                light: import("zod").ZodString;
                dark: import("zod").ZodString;
            }, import("zod/v4/core").$strict>, import("zod").ZodObject<{
                token: import("zod").ZodEnum<{
                    text: "text";
                    textSubdued: "textSubdued";
                    axis: "axis";
                    gridLine: "gridLine";
                    background: "background";
                    border: "border";
                }>;
            }, import("zod/v4/core").$strict>, import("zod").ZodObject<{
                palette: import("zod").ZodLiteral<"categorical">;
                index: import("zod").ZodInt;
            }, import("zod/v4/core").$strict>]>;
        }, import("zod/v4/core").$strict>>>;
    }, import("zod/v4/core").$strict>>;
    source: import("zod").ZodOptional<import("zod").ZodObject<{
        host: import("zod").ZodString;
        hostVersion: import("zod").ZodOptional<import("zod").ZodString>;
        capturedAt: import("zod").ZodISODateTime;
        timeRange: import("zod").ZodOptional<import("zod").ZodObject<{
            from: import("zod").ZodISODateTime;
            to: import("zod").ZodISODateTime;
        }, import("zod/v4/core").$strict>>;
        meta: import("zod").ZodOptional<import("zod").ZodRecord<import("zod").ZodString, import("zod").ZodUnknown>>;
    }, import("zod/v4/core").$strict>>;
    losses: import("zod").ZodOptional<import("zod").ZodArray<import("zod").ZodObject<{
        path: import("zod").ZodString;
        kind: import("zod").ZodEnum<{
            dropped: "dropped";
            approximated: "approximated";
            prerendered: "prerendered";
        }>;
        note: import("zod").ZodString;
    }, import("zod/v4/core").$strict>>>;
    type: import("zod").ZodLiteral<"heatmap">;
} & {
    id: ReturnType<() => import("zod").ZodOptional<import("zod").ZodString>>;
    surfaces: ReturnType<() => import("zod").ZodOptional<import("zod").ZodArray<import("zod").ZodEnum<{
        react: "react";
        snapshot: "snapshot";
        text: "text";
        markdown: "markdown";
        slack: "slack";
    }>>>>;
}, import("zod/v4/core").$strip>>, import("@elastic/isomer-sdk").PrimitiveDefinition<ChartNode, import("./context").ChartsPackTypes, import("zod").ZodObject<{
    interactions: import("zod").ZodOptional<import("zod").ZodObject<{
        link: import("zod").ZodOptional<import("zod").ZodObject<{
            href: import("zod").ZodString;
            label: import("zod").ZodString;
        }, import("zod/v4/core").$strict>>;
    }, import("zod/v4/core").$strict>>;
    shape: import("zod").ZodEnum<{
        circle: "circle";
        horizontalBullet: "horizontalBullet";
        verticalBullet: "verticalBullet";
        semiCircle: "semiCircle";
        arc: "arc";
    }>;
    value: import("zod").ZodObject<{
        column: import("zod").ZodString;
    }, import("zod/v4/core").$strict>;
    min: import("zod").ZodOptional<import("zod").ZodObject<{
        column: import("zod").ZodString;
    }, import("zod/v4/core").$strict>>;
    max: import("zod").ZodOptional<import("zod").ZodObject<{
        column: import("zod").ZodString;
    }, import("zod/v4/core").$strict>>;
    goal: import("zod").ZodOptional<import("zod").ZodObject<{
        column: import("zod").ZodString;
    }, import("zod/v4/core").$strict>>;
    bandsRange: import("zod").ZodOptional<import("zod").ZodEnum<{
        percentage: "percentage";
        absolute: "absolute";
    }>>;
    ticks: import("zod").ZodOptional<import("zod").ZodEnum<{
        auto: "auto";
        bands: "bands";
        hidden: "hidden";
    }>>;
    labels: import("zod").ZodOptional<import("zod").ZodObject<{
        major: import("zod").ZodOptional<import("zod").ZodUnion<readonly [import("zod").ZodString, import("zod").ZodLiteral<false>]>>;
        minor: import("zod").ZodOptional<import("zod").ZodString>;
    }, import("zod/v4/core").$strict>>;
    title: import("zod").ZodOptional<import("zod").ZodString>;
    description: import("zod").ZodOptional<import("zod").ZodString>;
    data: import("zod").ZodObject<{
        columns: import("zod").ZodArray<import("zod").ZodObject<{
            id: import("zod").ZodString;
            label: import("zod").ZodString;
            type: import("zod").ZodEnum<{
                string: "string";
                number: "number";
                boolean: "boolean";
                date: "date";
            }>;
            role: import("zod").ZodEnum<{
                dimension: "dimension";
                metric: "metric";
            }>;
            format: import("zod").ZodOptional<import("zod").ZodDiscriminatedUnion<[import("zod").ZodObject<{
                notation: import("zod").ZodOptional<import("zod").ZodEnum<{
                    standard: "standard";
                    compact: "compact";
                }>>;
                minimumFractionDigits: import("zod").ZodOptional<import("zod").ZodInt>;
                maximumFractionDigits: import("zod").ZodOptional<import("zod").ZodInt>;
                signDisplay: import("zod").ZodOptional<import("zod").ZodEnum<{
                    auto: "auto";
                    always: "always";
                    exceptZero: "exceptZero";
                    never: "never";
                }>>;
                useGrouping: import("zod").ZodOptional<import("zod").ZodBoolean>;
                suffix: import("zod").ZodOptional<import("zod").ZodString>;
                kind: import("zod").ZodLiteral<"number">;
            }, import("zod/v4/core").$strict>, import("zod").ZodObject<{
                fractional: import("zod").ZodOptional<import("zod").ZodBoolean>;
                minimumFractionDigits: import("zod").ZodOptional<import("zod").ZodInt>;
                maximumFractionDigits: import("zod").ZodOptional<import("zod").ZodInt>;
                signDisplay: import("zod").ZodOptional<import("zod").ZodEnum<{
                    auto: "auto";
                    always: "always";
                    exceptZero: "exceptZero";
                    never: "never";
                }>>;
                useGrouping: import("zod").ZodOptional<import("zod").ZodBoolean>;
                suffix: import("zod").ZodOptional<import("zod").ZodString>;
                kind: import("zod").ZodLiteral<"percent">;
            }, import("zod/v4/core").$strict>, import("zod").ZodObject<{
                base: import("zod").ZodOptional<import("zod").ZodUnion<readonly [import("zod").ZodLiteral<1000>, import("zod").ZodLiteral<1024>]>>;
                unitDisplay: import("zod").ZodOptional<import("zod").ZodEnum<{
                    long: "long";
                    short: "short";
                    narrow: "narrow";
                }>>;
                minimumFractionDigits: import("zod").ZodOptional<import("zod").ZodInt>;
                maximumFractionDigits: import("zod").ZodOptional<import("zod").ZodInt>;
                signDisplay: import("zod").ZodOptional<import("zod").ZodEnum<{
                    auto: "auto";
                    always: "always";
                    exceptZero: "exceptZero";
                    never: "never";
                }>>;
                useGrouping: import("zod").ZodOptional<import("zod").ZodBoolean>;
                suffix: import("zod").ZodOptional<import("zod").ZodString>;
                kind: import("zod").ZodLiteral<"bytes">;
            }, import("zod/v4/core").$strict>, import("zod").ZodObject<{
                base: import("zod").ZodOptional<import("zod").ZodUnion<readonly [import("zod").ZodLiteral<1000>, import("zod").ZodLiteral<1024>]>>;
                unitDisplay: import("zod").ZodOptional<import("zod").ZodEnum<{
                    long: "long";
                    short: "short";
                    narrow: "narrow";
                }>>;
                minimumFractionDigits: import("zod").ZodOptional<import("zod").ZodInt>;
                maximumFractionDigits: import("zod").ZodOptional<import("zod").ZodInt>;
                signDisplay: import("zod").ZodOptional<import("zod").ZodEnum<{
                    auto: "auto";
                    always: "always";
                    exceptZero: "exceptZero";
                    never: "never";
                }>>;
                useGrouping: import("zod").ZodOptional<import("zod").ZodBoolean>;
                suffix: import("zod").ZodOptional<import("zod").ZodString>;
                kind: import("zod").ZodLiteral<"bits">;
            }, import("zod/v4/core").$strict>, import("zod").ZodObject<{
                unitDisplay: import("zod").ZodOptional<import("zod").ZodEnum<{
                    long: "long";
                    short: "short";
                    narrow: "narrow";
                }>>;
                minimumFractionDigits: import("zod").ZodOptional<import("zod").ZodInt>;
                maximumFractionDigits: import("zod").ZodOptional<import("zod").ZodInt>;
                signDisplay: import("zod").ZodOptional<import("zod").ZodEnum<{
                    auto: "auto";
                    always: "always";
                    exceptZero: "exceptZero";
                    never: "never";
                }>>;
                useGrouping: import("zod").ZodOptional<import("zod").ZodBoolean>;
                suffix: import("zod").ZodOptional<import("zod").ZodString>;
                kind: import("zod").ZodLiteral<"duration">;
                input: import("zod").ZodEnum<{
                    picoseconds: "picoseconds";
                    nanoseconds: "nanoseconds";
                    microseconds: "microseconds";
                    milliseconds: "milliseconds";
                    seconds: "seconds";
                    minutes: "minutes";
                    hours: "hours";
                    days: "days";
                    weeks: "weeks";
                    months: "months";
                    years: "years";
                }>;
                output: import("zod").ZodOptional<import("zod").ZodUnion<readonly [import("zod").ZodEnum<{
                    nanoseconds: "nanoseconds";
                    microseconds: "microseconds";
                    milliseconds: "milliseconds";
                    seconds: "seconds";
                    minutes: "minutes";
                    hours: "hours";
                    days: "days";
                    weeks: "weeks";
                    months: "months";
                    years: "years";
                }>, import("zod").ZodLiteral<"auto">]>>;
            }, import("zod/v4/core").$strict>, import("zod").ZodObject<{
                kind: import("zod").ZodLiteral<"date">;
                timeZone: import("zod").ZodOptional<import("zod").ZodString>;
                dateStyle: import("zod").ZodOptional<import("zod").ZodEnum<{
                    long: "long";
                    short: "short";
                    full: "full";
                    medium: "medium";
                }>>;
                timeStyle: import("zod").ZodOptional<import("zod").ZodEnum<{
                    long: "long";
                    short: "short";
                    full: "full";
                    medium: "medium";
                }>>;
                weekday: import("zod").ZodOptional<import("zod").ZodEnum<{
                    long: "long";
                    short: "short";
                    narrow: "narrow";
                }>>;
                year: import("zod").ZodOptional<import("zod").ZodEnum<{
                    numeric: "numeric";
                    "2-digit": "2-digit";
                }>>;
                month: import("zod").ZodOptional<import("zod").ZodEnum<{
                    long: "long";
                    short: "short";
                    narrow: "narrow";
                    numeric: "numeric";
                    "2-digit": "2-digit";
                }>>;
                day: import("zod").ZodOptional<import("zod").ZodEnum<{
                    numeric: "numeric";
                    "2-digit": "2-digit";
                }>>;
                hour: import("zod").ZodOptional<import("zod").ZodEnum<{
                    numeric: "numeric";
                    "2-digit": "2-digit";
                }>>;
                minute: import("zod").ZodOptional<import("zod").ZodEnum<{
                    numeric: "numeric";
                    "2-digit": "2-digit";
                }>>;
                second: import("zod").ZodOptional<import("zod").ZodEnum<{
                    numeric: "numeric";
                    "2-digit": "2-digit";
                }>>;
                fractionalSecondDigits: import("zod").ZodOptional<import("zod").ZodUnion<readonly [import("zod").ZodLiteral<1>, import("zod").ZodLiteral<2>, import("zod").ZodLiteral<3>]>>;
                hour12: import("zod").ZodOptional<import("zod").ZodBoolean>;
                timeZoneName: import("zod").ZodOptional<import("zod").ZodEnum<{
                    long: "long";
                    short: "short";
                    shortOffset: "shortOffset";
                    longOffset: "longOffset";
                }>>;
            }, import("zod/v4/core").$strict>, import("zod").ZodObject<{
                kind: import("zod").ZodLiteral<"text">;
            }, import("zod/v4/core").$strict>], "kind">>;
            multivalue: import("zod").ZodOptional<import("zod").ZodLiteral<true>>;
            source: import("zod").ZodOptional<import("zod").ZodUnknown>;
        }, import("zod/v4/core").$strict>>;
        rows: import("zod").ZodArray<import("zod").ZodArray<import("zod").ZodUnion<readonly [import("zod").ZodUnion<readonly [import("zod").ZodNumber, import("zod").ZodString, import("zod").ZodBoolean, import("zod").ZodNull]>, import("zod").ZodArray<import("zod").ZodUnion<readonly [import("zod").ZodNumber, import("zod").ZodString, import("zod").ZodBoolean, import("zod").ZodNull]>>]>>>;
        source: import("zod").ZodOptional<import("zod").ZodUnknown>;
        missing: import("zod").ZodOptional<import("zod").ZodObject<{
            null: import("zod").ZodOptional<import("zod").ZodString>;
            empty: import("zod").ZodOptional<import("zod").ZodString>;
            nan: import("zod").ZodOptional<import("zod").ZodString>;
        }, import("zod/v4/core").$strict>>;
        display: import("zod").ZodOptional<import("zod").ZodRecord<import("zod").ZodString, import("zod").ZodArray<import("zod").ZodString>>>;
    }, import("zod/v4/core").$strict>;
    colors: import("zod").ZodOptional<import("zod").ZodObject<{
        byKey: import("zod").ZodOptional<import("zod").ZodRecord<import("zod").ZodString, import("zod").ZodUnion<readonly [import("zod").ZodObject<{
            light: import("zod").ZodString;
            dark: import("zod").ZodString;
        }, import("zod/v4/core").$strict>, import("zod").ZodObject<{
            token: import("zod").ZodEnum<{
                text: "text";
                textSubdued: "textSubdued";
                axis: "axis";
                gridLine: "gridLine";
                background: "background";
                border: "border";
            }>;
        }, import("zod/v4/core").$strict>, import("zod").ZodObject<{
            palette: import("zod").ZodLiteral<"categorical">;
            index: import("zod").ZodInt;
        }, import("zod/v4/core").$strict>]>>>;
        bands: import("zod").ZodOptional<import("zod").ZodArray<import("zod").ZodObject<{
            from: import("zod").ZodOptional<import("zod").ZodNumber>;
            to: import("zod").ZodOptional<import("zod").ZodNumber>;
            color: import("zod").ZodUnion<readonly [import("zod").ZodObject<{
                light: import("zod").ZodString;
                dark: import("zod").ZodString;
            }, import("zod/v4/core").$strict>, import("zod").ZodObject<{
                token: import("zod").ZodEnum<{
                    text: "text";
                    textSubdued: "textSubdued";
                    axis: "axis";
                    gridLine: "gridLine";
                    background: "background";
                    border: "border";
                }>;
            }, import("zod/v4/core").$strict>, import("zod").ZodObject<{
                palette: import("zod").ZodLiteral<"categorical">;
                index: import("zod").ZodInt;
            }, import("zod/v4/core").$strict>]>;
        }, import("zod/v4/core").$strict>>>;
    }, import("zod/v4/core").$strict>>;
    source: import("zod").ZodOptional<import("zod").ZodObject<{
        host: import("zod").ZodString;
        hostVersion: import("zod").ZodOptional<import("zod").ZodString>;
        capturedAt: import("zod").ZodISODateTime;
        timeRange: import("zod").ZodOptional<import("zod").ZodObject<{
            from: import("zod").ZodISODateTime;
            to: import("zod").ZodISODateTime;
        }, import("zod/v4/core").$strict>>;
        meta: import("zod").ZodOptional<import("zod").ZodRecord<import("zod").ZodString, import("zod").ZodUnknown>>;
    }, import("zod/v4/core").$strict>>;
    losses: import("zod").ZodOptional<import("zod").ZodArray<import("zod").ZodObject<{
        path: import("zod").ZodString;
        kind: import("zod").ZodEnum<{
            dropped: "dropped";
            approximated: "approximated";
            prerendered: "prerendered";
        }>;
        note: import("zod").ZodString;
    }, import("zod/v4/core").$strict>>>;
    type: import("zod").ZodLiteral<"gauge">;
} & {
    id: ReturnType<() => import("zod").ZodOptional<import("zod").ZodString>>;
    surfaces: ReturnType<() => import("zod").ZodOptional<import("zod").ZodArray<import("zod").ZodEnum<{
        react: "react";
        snapshot: "snapshot";
        text: "text";
        markdown: "markdown";
        slack: "slack";
    }>>>>;
}, import("zod/v4/core").$strip>>, import("@elastic/isomer-sdk").PrimitiveDefinition<ChartNode, import("./context").ChartsPackTypes, import("zod").ZodObject<{
    interactions: import("zod").ZodOptional<import("zod").ZodObject<{
        select: import("zod").ZodOptional<import("zod").ZodArray<import("zod").ZodEnum<{
            tag: "tag";
        }>>>;
        sync: import("zod").ZodOptional<import("zod").ZodObject<{
            cursor: import("zod").ZodOptional<import("zod").ZodBoolean>;
            tooltips: import("zod").ZodOptional<import("zod").ZodBoolean>;
        }, import("zod/v4/core").$strict>>;
        link: import("zod").ZodOptional<import("zod").ZodObject<{
            href: import("zod").ZodString;
            label: import("zod").ZodString;
        }, import("zod/v4/core").$strict>>;
    }, import("zod/v4/core").$strict>>;
    tags: import("zod").ZodObject<{
        column: import("zod").ZodString;
    }, import("zod/v4/core").$strict>;
    metric: import("zod").ZodObject<{
        column: import("zod").ZodString;
    }, import("zod/v4/core").$strict>;
    scale: import("zod").ZodOptional<import("zod").ZodEnum<{
        linear: "linear";
        log: "log";
        squareRoot: "squareRoot";
    }>>;
    orientation: import("zod").ZodOptional<import("zod").ZodEnum<{
        single: "single";
        rightAngled: "rightAngled";
        multiple: "multiple";
    }>>;
    fontSize: import("zod").ZodOptional<import("zod").ZodObject<{
        min: import("zod").ZodOptional<import("zod").ZodNumber>;
        max: import("zod").ZodOptional<import("zod").ZodNumber>;
    }, import("zod/v4/core").$strict>>;
    showLabel: import("zod").ZodOptional<import("zod").ZodBoolean>;
    emphasis: import("zod").ZodOptional<import("zod").ZodArray<import("zod").ZodObject<{
        rows: import("zod").ZodArray<import("zod").ZodInt>;
        note: import("zod").ZodOptional<import("zod").ZodString>;
    }, import("zod/v4/core").$strict>>>;
    title: import("zod").ZodOptional<import("zod").ZodString>;
    description: import("zod").ZodOptional<import("zod").ZodString>;
    data: import("zod").ZodObject<{
        columns: import("zod").ZodArray<import("zod").ZodObject<{
            id: import("zod").ZodString;
            label: import("zod").ZodString;
            type: import("zod").ZodEnum<{
                string: "string";
                number: "number";
                boolean: "boolean";
                date: "date";
            }>;
            role: import("zod").ZodEnum<{
                dimension: "dimension";
                metric: "metric";
            }>;
            format: import("zod").ZodOptional<import("zod").ZodDiscriminatedUnion<[import("zod").ZodObject<{
                notation: import("zod").ZodOptional<import("zod").ZodEnum<{
                    standard: "standard";
                    compact: "compact";
                }>>;
                minimumFractionDigits: import("zod").ZodOptional<import("zod").ZodInt>;
                maximumFractionDigits: import("zod").ZodOptional<import("zod").ZodInt>;
                signDisplay: import("zod").ZodOptional<import("zod").ZodEnum<{
                    auto: "auto";
                    always: "always";
                    exceptZero: "exceptZero";
                    never: "never";
                }>>;
                useGrouping: import("zod").ZodOptional<import("zod").ZodBoolean>;
                suffix: import("zod").ZodOptional<import("zod").ZodString>;
                kind: import("zod").ZodLiteral<"number">;
            }, import("zod/v4/core").$strict>, import("zod").ZodObject<{
                fractional: import("zod").ZodOptional<import("zod").ZodBoolean>;
                minimumFractionDigits: import("zod").ZodOptional<import("zod").ZodInt>;
                maximumFractionDigits: import("zod").ZodOptional<import("zod").ZodInt>;
                signDisplay: import("zod").ZodOptional<import("zod").ZodEnum<{
                    auto: "auto";
                    always: "always";
                    exceptZero: "exceptZero";
                    never: "never";
                }>>;
                useGrouping: import("zod").ZodOptional<import("zod").ZodBoolean>;
                suffix: import("zod").ZodOptional<import("zod").ZodString>;
                kind: import("zod").ZodLiteral<"percent">;
            }, import("zod/v4/core").$strict>, import("zod").ZodObject<{
                base: import("zod").ZodOptional<import("zod").ZodUnion<readonly [import("zod").ZodLiteral<1000>, import("zod").ZodLiteral<1024>]>>;
                unitDisplay: import("zod").ZodOptional<import("zod").ZodEnum<{
                    long: "long";
                    short: "short";
                    narrow: "narrow";
                }>>;
                minimumFractionDigits: import("zod").ZodOptional<import("zod").ZodInt>;
                maximumFractionDigits: import("zod").ZodOptional<import("zod").ZodInt>;
                signDisplay: import("zod").ZodOptional<import("zod").ZodEnum<{
                    auto: "auto";
                    always: "always";
                    exceptZero: "exceptZero";
                    never: "never";
                }>>;
                useGrouping: import("zod").ZodOptional<import("zod").ZodBoolean>;
                suffix: import("zod").ZodOptional<import("zod").ZodString>;
                kind: import("zod").ZodLiteral<"bytes">;
            }, import("zod/v4/core").$strict>, import("zod").ZodObject<{
                base: import("zod").ZodOptional<import("zod").ZodUnion<readonly [import("zod").ZodLiteral<1000>, import("zod").ZodLiteral<1024>]>>;
                unitDisplay: import("zod").ZodOptional<import("zod").ZodEnum<{
                    long: "long";
                    short: "short";
                    narrow: "narrow";
                }>>;
                minimumFractionDigits: import("zod").ZodOptional<import("zod").ZodInt>;
                maximumFractionDigits: import("zod").ZodOptional<import("zod").ZodInt>;
                signDisplay: import("zod").ZodOptional<import("zod").ZodEnum<{
                    auto: "auto";
                    always: "always";
                    exceptZero: "exceptZero";
                    never: "never";
                }>>;
                useGrouping: import("zod").ZodOptional<import("zod").ZodBoolean>;
                suffix: import("zod").ZodOptional<import("zod").ZodString>;
                kind: import("zod").ZodLiteral<"bits">;
            }, import("zod/v4/core").$strict>, import("zod").ZodObject<{
                unitDisplay: import("zod").ZodOptional<import("zod").ZodEnum<{
                    long: "long";
                    short: "short";
                    narrow: "narrow";
                }>>;
                minimumFractionDigits: import("zod").ZodOptional<import("zod").ZodInt>;
                maximumFractionDigits: import("zod").ZodOptional<import("zod").ZodInt>;
                signDisplay: import("zod").ZodOptional<import("zod").ZodEnum<{
                    auto: "auto";
                    always: "always";
                    exceptZero: "exceptZero";
                    never: "never";
                }>>;
                useGrouping: import("zod").ZodOptional<import("zod").ZodBoolean>;
                suffix: import("zod").ZodOptional<import("zod").ZodString>;
                kind: import("zod").ZodLiteral<"duration">;
                input: import("zod").ZodEnum<{
                    picoseconds: "picoseconds";
                    nanoseconds: "nanoseconds";
                    microseconds: "microseconds";
                    milliseconds: "milliseconds";
                    seconds: "seconds";
                    minutes: "minutes";
                    hours: "hours";
                    days: "days";
                    weeks: "weeks";
                    months: "months";
                    years: "years";
                }>;
                output: import("zod").ZodOptional<import("zod").ZodUnion<readonly [import("zod").ZodEnum<{
                    nanoseconds: "nanoseconds";
                    microseconds: "microseconds";
                    milliseconds: "milliseconds";
                    seconds: "seconds";
                    minutes: "minutes";
                    hours: "hours";
                    days: "days";
                    weeks: "weeks";
                    months: "months";
                    years: "years";
                }>, import("zod").ZodLiteral<"auto">]>>;
            }, import("zod/v4/core").$strict>, import("zod").ZodObject<{
                kind: import("zod").ZodLiteral<"date">;
                timeZone: import("zod").ZodOptional<import("zod").ZodString>;
                dateStyle: import("zod").ZodOptional<import("zod").ZodEnum<{
                    long: "long";
                    short: "short";
                    full: "full";
                    medium: "medium";
                }>>;
                timeStyle: import("zod").ZodOptional<import("zod").ZodEnum<{
                    long: "long";
                    short: "short";
                    full: "full";
                    medium: "medium";
                }>>;
                weekday: import("zod").ZodOptional<import("zod").ZodEnum<{
                    long: "long";
                    short: "short";
                    narrow: "narrow";
                }>>;
                year: import("zod").ZodOptional<import("zod").ZodEnum<{
                    numeric: "numeric";
                    "2-digit": "2-digit";
                }>>;
                month: import("zod").ZodOptional<import("zod").ZodEnum<{
                    long: "long";
                    short: "short";
                    narrow: "narrow";
                    numeric: "numeric";
                    "2-digit": "2-digit";
                }>>;
                day: import("zod").ZodOptional<import("zod").ZodEnum<{
                    numeric: "numeric";
                    "2-digit": "2-digit";
                }>>;
                hour: import("zod").ZodOptional<import("zod").ZodEnum<{
                    numeric: "numeric";
                    "2-digit": "2-digit";
                }>>;
                minute: import("zod").ZodOptional<import("zod").ZodEnum<{
                    numeric: "numeric";
                    "2-digit": "2-digit";
                }>>;
                second: import("zod").ZodOptional<import("zod").ZodEnum<{
                    numeric: "numeric";
                    "2-digit": "2-digit";
                }>>;
                fractionalSecondDigits: import("zod").ZodOptional<import("zod").ZodUnion<readonly [import("zod").ZodLiteral<1>, import("zod").ZodLiteral<2>, import("zod").ZodLiteral<3>]>>;
                hour12: import("zod").ZodOptional<import("zod").ZodBoolean>;
                timeZoneName: import("zod").ZodOptional<import("zod").ZodEnum<{
                    long: "long";
                    short: "short";
                    shortOffset: "shortOffset";
                    longOffset: "longOffset";
                }>>;
            }, import("zod/v4/core").$strict>, import("zod").ZodObject<{
                kind: import("zod").ZodLiteral<"text">;
            }, import("zod/v4/core").$strict>], "kind">>;
            multivalue: import("zod").ZodOptional<import("zod").ZodLiteral<true>>;
            source: import("zod").ZodOptional<import("zod").ZodUnknown>;
        }, import("zod/v4/core").$strict>>;
        rows: import("zod").ZodArray<import("zod").ZodArray<import("zod").ZodUnion<readonly [import("zod").ZodUnion<readonly [import("zod").ZodNumber, import("zod").ZodString, import("zod").ZodBoolean, import("zod").ZodNull]>, import("zod").ZodArray<import("zod").ZodUnion<readonly [import("zod").ZodNumber, import("zod").ZodString, import("zod").ZodBoolean, import("zod").ZodNull]>>]>>>;
        source: import("zod").ZodOptional<import("zod").ZodUnknown>;
        missing: import("zod").ZodOptional<import("zod").ZodObject<{
            null: import("zod").ZodOptional<import("zod").ZodString>;
            empty: import("zod").ZodOptional<import("zod").ZodString>;
            nan: import("zod").ZodOptional<import("zod").ZodString>;
        }, import("zod/v4/core").$strict>>;
        display: import("zod").ZodOptional<import("zod").ZodRecord<import("zod").ZodString, import("zod").ZodArray<import("zod").ZodString>>>;
    }, import("zod/v4/core").$strict>;
    colors: import("zod").ZodOptional<import("zod").ZodObject<{
        byKey: import("zod").ZodOptional<import("zod").ZodRecord<import("zod").ZodString, import("zod").ZodUnion<readonly [import("zod").ZodObject<{
            light: import("zod").ZodString;
            dark: import("zod").ZodString;
        }, import("zod/v4/core").$strict>, import("zod").ZodObject<{
            token: import("zod").ZodEnum<{
                text: "text";
                textSubdued: "textSubdued";
                axis: "axis";
                gridLine: "gridLine";
                background: "background";
                border: "border";
            }>;
        }, import("zod/v4/core").$strict>, import("zod").ZodObject<{
            palette: import("zod").ZodLiteral<"categorical">;
            index: import("zod").ZodInt;
        }, import("zod/v4/core").$strict>]>>>;
        bands: import("zod").ZodOptional<import("zod").ZodArray<import("zod").ZodObject<{
            from: import("zod").ZodOptional<import("zod").ZodNumber>;
            to: import("zod").ZodOptional<import("zod").ZodNumber>;
            color: import("zod").ZodUnion<readonly [import("zod").ZodObject<{
                light: import("zod").ZodString;
                dark: import("zod").ZodString;
            }, import("zod/v4/core").$strict>, import("zod").ZodObject<{
                token: import("zod").ZodEnum<{
                    text: "text";
                    textSubdued: "textSubdued";
                    axis: "axis";
                    gridLine: "gridLine";
                    background: "background";
                    border: "border";
                }>;
            }, import("zod/v4/core").$strict>, import("zod").ZodObject<{
                palette: import("zod").ZodLiteral<"categorical">;
                index: import("zod").ZodInt;
            }, import("zod/v4/core").$strict>]>;
        }, import("zod/v4/core").$strict>>>;
    }, import("zod/v4/core").$strict>>;
    source: import("zod").ZodOptional<import("zod").ZodObject<{
        host: import("zod").ZodString;
        hostVersion: import("zod").ZodOptional<import("zod").ZodString>;
        capturedAt: import("zod").ZodISODateTime;
        timeRange: import("zod").ZodOptional<import("zod").ZodObject<{
            from: import("zod").ZodISODateTime;
            to: import("zod").ZodISODateTime;
        }, import("zod/v4/core").$strict>>;
        meta: import("zod").ZodOptional<import("zod").ZodRecord<import("zod").ZodString, import("zod").ZodUnknown>>;
    }, import("zod/v4/core").$strict>>;
    losses: import("zod").ZodOptional<import("zod").ZodArray<import("zod").ZodObject<{
        path: import("zod").ZodString;
        kind: import("zod").ZodEnum<{
            dropped: "dropped";
            approximated: "approximated";
            prerendered: "prerendered";
        }>;
        note: import("zod").ZodString;
    }, import("zod/v4/core").$strict>>>;
    type: import("zod").ZodLiteral<"tagCloud">;
} & {
    id: ReturnType<() => import("zod").ZodOptional<import("zod").ZodString>>;
    surfaces: ReturnType<() => import("zod").ZodOptional<import("zod").ZodArray<import("zod").ZodEnum<{
        react: "react";
        snapshot: "snapshot";
        text: "text";
        markdown: "markdown";
        slack: "slack";
    }>>>>;
}, import("zod/v4/core").$strip>>];
