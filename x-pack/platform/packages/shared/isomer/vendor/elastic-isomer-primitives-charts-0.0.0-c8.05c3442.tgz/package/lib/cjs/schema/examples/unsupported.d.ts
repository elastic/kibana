import type { PrimitiveExample } from '@elastic/isomer-sdk/schema';
import type { UnsupportedNode } from '../unsupported';
/** An `unsupported` node for a Vega chart. The catalog's example. */
export declare const unsupportedVega: UnsupportedNode;
/** Named `unsupported` examples, each valid in a composition. */
export declare const unsupportedExamples: PrimitiveExample<UnsupportedNode>[];
