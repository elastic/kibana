import type { ReactSceneRenderer } from './context';
/** Draws a Scene's summary sentence, description and emphasis notes. The pack's last resort for every kind. */
export declare const summarySceneRenderer: ReactSceneRenderer;
