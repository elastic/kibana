import type { PrimitiveCatalogEntry } from '@elastic/isomer-sdk/schema';
/** What an agent reads to choose `metric`: purpose, when to use it, and an example. */
export declare const metricCatalog: PrimitiveCatalogEntry;
/** What an agent reads to choose `legacyMetric`: purpose, when to use it, and an example. */
export declare const legacyMetricCatalog: PrimitiveCatalogEntry;
/** What an agent reads to choose `xyChart`: purpose, when to use it, and an example. */
export declare const xyChartCatalog: PrimitiveCatalogEntry;
/** What an agent reads to choose `grid`: purpose, when to use it, and an example. */
export declare const gridCatalog: PrimitiveCatalogEntry;
/** What an agent reads to choose `unsupported`: purpose, when to use it, and an example. */
export declare const unsupportedCatalog: PrimitiveCatalogEntry;
/** What an agent reads to choose `dataTable`: purpose, when to use it, and an example. */
export declare const dataTableCatalog: PrimitiveCatalogEntry;
/** What an agent reads to choose `partitionChart`: purpose, when to use it, and an example. */
export declare const partitionChartCatalog: PrimitiveCatalogEntry;
/** What an agent reads to choose `heatmap`: purpose, when to use it, and an example. */
export declare const heatmapCatalog: PrimitiveCatalogEntry;
/** What an agent reads to choose `gauge`: purpose, when to use it, and an example. */
export declare const gaugeCatalog: PrimitiveCatalogEntry;
/** What an agent reads to choose `tagCloud`: purpose, when to use it, and an example. */
export declare const tagCloudCatalog: PrimitiveCatalogEntry;
