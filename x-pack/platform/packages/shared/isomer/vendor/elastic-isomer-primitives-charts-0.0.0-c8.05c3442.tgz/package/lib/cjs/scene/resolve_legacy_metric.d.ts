import type { LegacyMetricNode } from '../schema/legacy_metric';
import { type ResolveChartOptions } from './common';
import type { LegacyMetricScene } from './types';
/** The estimated width of `text` at `size` pixels and `weight`. */
export declare const estimateTextWidth: (text: string, size: number, weight?: number) => number;
/** The Scene of a `legacyMetric` node. */
export declare const resolveLegacyMetric: (node: LegacyMetricNode, options: ResolveChartOptions) => LegacyMetricScene;
