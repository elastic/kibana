import type { Cell, ColumnType } from '../schema/data';
import type { PortableFormat } from '../schema/format';
/** The text for values a format cannot show. */
interface MissingText {
    /** A missing (`null` or absent) value. */
    readonly null: string;
    /** An empty string. */
    readonly empty: string;
    /** A value that is not a number in a numeric format. */
    readonly nan: string;
}
/** What a missing value prints as. */
export declare const NULL_LABEL: string;
/** What an empty string prints as. */
export declare const EMPTY_LABEL: string;
interface FormatOptions {
    /** Absent means `en`. */
    readonly locale?: string | undefined;
    /** Absent means `UTC`. */
    readonly timeZone?: string | undefined;
    /** The node's `data.missing`; absent texts keep their defaults. */
    readonly missing?: {
        readonly [Key in keyof MissingText]?: string | undefined;
    } | undefined;
}
/** The format a value gets when its column and the chart state none. */
export declare const DEFAULT_FORMATS: {
    readonly number: {
        readonly kind: "number";
        readonly maximumFractionDigits: 3;
    };
    readonly percent: {
        readonly kind: "percent";
        readonly maximumFractionDigits: 3;
    };
    readonly date: {
        readonly kind: "date";
    };
    readonly text: {
        readonly kind: "text";
    };
};
/**
 * Formats one cell with `Intl`: missing and empty values get their text,
 * and a multivalue cell becomes a JSON array of its formatted values. A
 * `suffix` is appended to the whole result, except to a missing or empty
 * value's text.
 */
export declare const formatValue: (value: Cell | undefined, format: PortableFormat, { locale, timeZone, missing }?: FormatOptions) => string;
/** The format a column of `type` gets when it declares none. */
export declare const defaultFormatFor: (type: ColumnType) => PortableFormat;
export {};
