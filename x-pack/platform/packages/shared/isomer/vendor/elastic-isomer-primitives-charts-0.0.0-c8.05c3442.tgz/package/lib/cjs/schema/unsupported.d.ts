import { type PrimitiveNode, z } from '@elastic/isomer-sdk/schema';
/** A visible placeholder for content that could not be materialized or rendered. */
export declare const unsupportedSchema: z.ZodObject<{
    type: z.ZodLiteral<"unsupported">;
    title: z.ZodString;
    reason: z.ZodString;
    link: z.ZodOptional<z.ZodObject<{
        href: z.ZodString;
        label: z.ZodString;
    }, z.core.$strict>>;
    source: z.ZodOptional<z.ZodObject<{
        host: z.ZodString;
        hostVersion: z.ZodOptional<z.ZodString>;
        capturedAt: z.ZodISODateTime;
        timeRange: z.ZodOptional<z.ZodObject<{
            from: z.ZodISODateTime;
            to: z.ZodISODateTime;
        }, z.core.$strict>>;
        meta: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnknown>>;
    }, z.core.$strict>>;
}, z.core.$strip>;
/** A validated `unsupported` node. */
export type UnsupportedNode = z.infer<typeof unsupportedSchema> & PrimitiveNode;
