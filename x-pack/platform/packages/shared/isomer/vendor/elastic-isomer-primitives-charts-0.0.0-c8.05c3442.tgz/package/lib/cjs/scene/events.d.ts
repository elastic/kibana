import type { ChartBrushEvent, ChartSelectEvent } from '../schema/events';
import type { HeatmapScene, SceneSelection, XyScene } from './types';
/** The `select` event for a part of the Scene the reader selected. */
export declare const selectEvent: (node: string, selection: SceneSelection, negate?: boolean) => ChartSelectEvent;
/**
 * The `brush` event for a range along the Scene's brush column, or `undefined`
 * when the node offers no brush. The description names each end by the x
 * position nearest it, as the x axis formats it: an xy Scene's `categories`,
 * or a heat map's `x.categories`.
 */
export declare const brushEvent: (scene: XyScene | HeatmapScene, node: string, range: readonly [number, number]) => ChartBrushEvent | undefined;
