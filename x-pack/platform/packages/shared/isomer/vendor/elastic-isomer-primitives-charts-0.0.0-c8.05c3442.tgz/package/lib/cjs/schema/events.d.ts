import { type ActionEventRef, z } from '@elastic/isomer-sdk/schema';
import { type ChartColumn } from './data';
/** Every part of a chart a reader can select. */
export declare const SELECT_TARGETS: readonly ["datum", "series", "category", "legend", "cell", "tile", "slice", "tag"];
/** What a selection lands on. Each chart states which it offers. */
export type SelectTarget = (typeof SELECT_TARGETS)[number];
/** The cross-field rules the interaction schemas state in their descriptions, one sentence each. */
export declare const INTERACTION_RULES: {
    readonly brushColumn: "A `brush` column is a `date` or `number` column used as `x` by at least one `data` layer.";
    readonly emphasisRows: "Emphasis rows are indexes into `data.rows`.";
};
/** A static link a chart draws on every surface. */
export declare const linkSchema: z.ZodObject<{
    href: z.ZodString;
    label: z.ZodString;
}, z.core.$strict>;
/** `interactions.select` for a chart offering `targets`. */
export declare const selectSchema: <const TTargets extends readonly [SelectTarget, ...SelectTarget[]]>(targets: TTargets) => z.ZodOptional<z.ZodArray<z.ZodEnum<{ [k_1 in TTargets[number]]: k_1; } extends infer T ? { [k in keyof T]: T[k]; } : never>>>;
/** A brush along one continuous x column. */
export declare const brushSchema: z.ZodObject<{
    column: z.ZodString;
}, z.core.$strict>;
/** The `interactions` schema for a chart with no brush and no persisted view state. */
export declare const interactionsSchemaFor: <const TTargets extends readonly [SelectTarget, ...SelectTarget[]]>(targets: TTargets) => z.ZodObject<{
    select: z.ZodOptional<z.ZodArray<z.ZodEnum<{ [k_1 in TTargets[number]]: k_1; } extends infer T ? { [k in keyof T]: T[k]; } : never>>>;
    sync: z.ZodOptional<z.ZodObject<{
        cursor: z.ZodOptional<z.ZodBoolean>;
        tooltips: z.ZodOptional<z.ZodBoolean>;
    }, z.core.$strict>>;
    link: z.ZodOptional<z.ZodObject<{
        href: z.ZodString;
        label: z.ZodString;
    }, z.core.$strict>>;
}, z.core.$strict>;
/** The `interactions` schema for a chart that brushes along `brush`, with no persisted view state. */
export declare const brushInteractionsSchemaFor: <const TTargets extends readonly [SelectTarget, ...SelectTarget[]], TBrush extends z.ZodType>(targets: TTargets, brush: TBrush) => z.ZodObject<{
    select: z.ZodOptional<z.ZodArray<z.ZodEnum<{ [k_1 in TTargets[number]]: k_1; } extends infer T ? { [k in keyof T]: T[k]; } : never>>>;
    brush: z.ZodOptional<TBrush>;
    sync: z.ZodOptional<z.ZodObject<{
        cursor: z.ZodOptional<z.ZodBoolean>;
        tooltips: z.ZodOptional<z.ZodBoolean>;
    }, z.core.$strict>>;
    link: z.ZodOptional<z.ZodObject<{
        href: z.ZodString;
        label: z.ZodString;
    }, z.core.$strict>>;
}, z.core.$strict>;
/** The `interactions` schema for a chart that brushes and persists view state. */
export declare const brushingInteractionsSchemaFor: <const TTargets extends readonly [SelectTarget, ...SelectTarget[]], TInitial extends z.ZodRawShape>(targets: TTargets, initial: TInitial) => z.ZodObject<{
    select: z.ZodOptional<z.ZodArray<z.ZodEnum<{ [k_1 in TTargets[number]]: k_1; } extends infer T ? { [k in keyof T]: T[k]; } : never>>>;
    brush: z.ZodOptional<z.ZodObject<{
        column: z.ZodString;
    }, z.core.$strict>>;
    sync: z.ZodOptional<z.ZodObject<{
        cursor: z.ZodOptional<z.ZodBoolean>;
        tooltips: z.ZodOptional<z.ZodBoolean>;
    }, z.core.$strict>>;
    link: z.ZodOptional<z.ZodObject<{
        href: z.ZodString;
        label: z.ZodString;
    }, z.core.$strict>>;
    initial: z.ZodOptional<z.ZodObject<{ -readonly [P in keyof TInitial]: TInitial[P]; }, z.core.$strict>>;
}, z.core.$strict>;
/** Rows drawn with emphasis, each with an optional note. */
export declare const emphasisSchema: z.ZodArray<z.ZodObject<{
    rows: z.ZodArray<z.ZodInt>;
    note: z.ZodOptional<z.ZodString>;
}, z.core.$strict>>;
/** A chart's parsed `emphasis`. */
export type Emphasis = z.infer<typeof emphasisSchema>;
/** The interaction fields every chart spreads into its schema beside the core. */
export declare const interactionsCoreShape: {
    emphasis: z.ZodOptional<z.ZodArray<z.ZodObject<{
        rows: z.ZodArray<z.ZodInt>;
        note: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>>>;
};
interface InteractionsInput {
    data: {
        columns: readonly ChartColumn[];
        rows: readonly unknown[];
    };
    emphasis?: Emphasis | undefined;
    interactions?: object | undefined;
}
interface InteractionCheckOptions {
    brushColumns?: readonly string[];
    /** Reported for a brush on any other column, in place of `INTERACTION_RULES.brushColumn`. */
    brushRule?: string;
    /** The types a brush column takes. Absent means `date` and `number`. */
    brushTypes?: readonly ('date' | 'number')[];
}
/** Checks emphasis rows and an `xyChart` brush against `data` and its x columns. */
export declare const checkInteractions: (node: InteractionsInput, context: z.core.$RefinementCtx<unknown>, options?: InteractionCheckOptions) => void;
/** `ActionEventRef.name` for each kind of chart event. */
export declare const CHART_EVENT_NAMES: {
    readonly select: "chart.select";
    readonly brush: "chart.brush";
};
/** An event a chart raises: a selection or a brush. */
export declare const chartEventSchema: z.ZodDiscriminatedUnion<[z.ZodDiscriminatedUnion<[z.ZodObject<{
    target: z.ZodEnum<{
        datum: "datum";
        series: "series";
        legend: "legend";
    }>;
    seriesKey: z.ZodString;
    series: z.ZodObject<{
        layer: z.ZodInt;
        y: z.ZodInt;
    }, z.core.$strict>;
    node: z.ZodString;
    description: z.ZodString;
    values: z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodUnion<readonly [z.ZodNumber, z.ZodString, z.ZodBoolean, z.ZodNull]>, z.ZodArray<z.ZodUnion<readonly [z.ZodNumber, z.ZodString, z.ZodBoolean, z.ZodNull]>>]>>;
    kind: z.ZodLiteral<"select">;
    rows: z.ZodArray<z.ZodInt>;
    columns: z.ZodArray<z.ZodString>;
    negate: z.ZodOptional<z.ZodBoolean>;
}, z.core.$strict>, z.ZodObject<{
    target: z.ZodEnum<{
        slice: "slice";
        tag: "tag";
        category: "category";
        cell: "cell";
        tile: "tile";
    }>;
    node: z.ZodString;
    description: z.ZodString;
    values: z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodUnion<readonly [z.ZodNumber, z.ZodString, z.ZodBoolean, z.ZodNull]>, z.ZodArray<z.ZodUnion<readonly [z.ZodNumber, z.ZodString, z.ZodBoolean, z.ZodNull]>>]>>;
    kind: z.ZodLiteral<"select">;
    rows: z.ZodArray<z.ZodInt>;
    columns: z.ZodArray<z.ZodString>;
    negate: z.ZodOptional<z.ZodBoolean>;
}, z.core.$strict>], "target">, z.ZodObject<{
    node: z.ZodString;
    description: z.ZodString;
    values: z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodUnion<readonly [z.ZodNumber, z.ZodString, z.ZodBoolean, z.ZodNull]>, z.ZodArray<z.ZodUnion<readonly [z.ZodNumber, z.ZodString, z.ZodBoolean, z.ZodNull]>>]>>;
    kind: z.ZodLiteral<"brush">;
    column: z.ZodString;
    range: z.ZodTuple<[z.ZodNumber, z.ZodNumber], null>;
}, z.core.$strict>], "kind">;
/** A `select` or `brush` gesture on a chart, in terms of the node's `data`. */
export type ChartEvent = z.infer<typeof chartEventSchema>;
/** The `select` member of {@link ChartEvent}. */
export type ChartSelectEvent = Extract<ChartEvent, {
    kind: 'select';
}>;
/** The `brush` member of {@link ChartEvent}. */
export type ChartBrushEvent = Extract<ChartEvent, {
    kind: 'brush';
}>;
/** Wraps a chart event as the `ActionEventRef` a host's `onEvent` receives. */
export declare const toActionEvent: (event: ChartEvent) => ActionEventRef;
/** The chart event an `ActionEventRef` carries, or `undefined` when it carries none. */
export declare const readChartEvent: (ref: ActionEventRef) => ChartEvent | undefined;
export {};
