import type { PrimitiveIcon } from '@elastic/isomer-sdk';
/** A label above a large value, and a trend under it. */
export declare const metricIcon: PrimitiveIcon;
/** A large value, centered, over its label. */
export declare const legacyMetricIcon: PrimitiveIcon;
/** Axes and a rising line through its points. */
export declare const xyChartIcon: PrimitiveIcon;
/** A pie with one slice pulled out. */
export declare const partitionChartIcon: PrimitiveIcon;
/** A dial with a needle. */
export declare const gaugeIcon: PrimitiveIcon;
/** Words of three sizes. */
export declare const tagCloudIcon: PrimitiveIcon;
/** A grid of cells in three shades. */
export declare const heatmapIcon: PrimitiveIcon;
/** A shaded header row above rules. */
export declare const dataTableIcon: PrimitiveIcon;
/** Panels of different sizes on a dashboard. */
export declare const gridIcon: PrimitiveIcon;
/** A panel that can't be drawn: a frame crossed out. */
export declare const unsupportedIcon: PrimitiveIcon;
