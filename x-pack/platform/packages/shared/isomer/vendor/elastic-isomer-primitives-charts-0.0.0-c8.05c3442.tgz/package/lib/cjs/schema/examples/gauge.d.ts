import type { PrimitiveExample } from '@elastic/isomer-sdk/schema';
import type { GaugeNode } from '../gauge';
/** A semicircle gauge with bands, a goal and band ticks. The catalog's example. */
export declare const gaugeSemiCircle: GaugeNode;
/** Named `gauge` examples covering the corpus edge cases, each valid in a composition. */
export declare const gaugeExamples: PrimitiveExample<GaugeNode>[];
