import type { PortableFormat } from '../format';
/** A number with up to three fraction digits. */
export declare const NUMBER: PortableFormat;
/** A percent with up to three fraction digits. */
export declare const PERCENT: PortableFormat;
/** Bytes with up to one fraction digit. */
export declare const BYTES: PortableFormat;
/** One hour in milliseconds. */
export declare const HOUR = 3600000;
/** The first timestamp of the time-series examples, 2026-11-03 UTC. */
export declare const START: number;
