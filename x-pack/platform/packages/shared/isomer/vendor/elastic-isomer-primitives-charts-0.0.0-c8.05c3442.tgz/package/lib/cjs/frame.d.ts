import type { Frame } from '@elastic/isomer-sdk';
import type { ColorScheme } from './scene/types';
/** The palette {@link chartsFrame} draws with, per scheme. */
export interface ChartsFrameTheme {
    readonly scheme: ColorScheme;
    readonly background: string;
    readonly text: string;
}
/** A content-sized page of charts. Register as `frames: { charts: chartsFrame }`. */
export declare const chartsFrame: Frame<ChartsFrameTheme>;
