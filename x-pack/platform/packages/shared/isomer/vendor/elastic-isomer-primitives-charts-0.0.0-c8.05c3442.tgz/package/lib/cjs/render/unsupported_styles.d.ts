export declare const unsupportedModule: import("@elastic/distillate").StylesModule<{
    root: import("@elastic/distillate").StyleHandle;
    title: import("@elastic/distillate").StyleHandle;
    body: import("@elastic/distillate").StyleHandle;
}>;
