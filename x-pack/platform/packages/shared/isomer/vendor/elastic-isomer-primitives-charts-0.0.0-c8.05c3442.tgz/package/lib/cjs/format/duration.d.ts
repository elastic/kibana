import type { PortableFormat } from '../schema/format';
type DurationFormat = Extract<PortableFormat, {
    kind: 'duration';
}>;
/**
 * Formats a number of `format.input` units in `format.output`, or in the
 * largest unit it is at least one of, with `Intl.NumberFormat`'s unit names.
 * Zero stays in its input unit when that is one a duration displays in. A
 * unit the environment cannot name falls back to milliseconds.
 */
export declare const formatDuration: (value: number, format: DurationFormat, locale: string) => string;
export {};
