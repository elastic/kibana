import type { MetricScene, XyScene } from './types';
/** The Scene for the `metric` example "Single value", in light. */
export declare const metricSingleValueScene: MetricScene;
/** The Scene for the `xyChart` example "Time series line", in light. */
export declare const xyTimeSeriesScene: XyScene;
/**
 * The Scene for the `xyChart` example "Interactive stacked bars", in light.
 * Its selections are the ones `chartEventExamples` raise.
 */
export declare const xyInteractiveScene: XyScene;
