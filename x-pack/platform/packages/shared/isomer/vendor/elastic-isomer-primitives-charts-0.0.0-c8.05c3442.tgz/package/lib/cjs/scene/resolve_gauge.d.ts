import type { GaugeNode } from '../schema/gauge';
import { type ResolveChartOptions } from './common';
import type { GaugeScene } from './types';
/** Lens's `getNiceRange(min, max).max`: `max` rounded up to a step of about a quarter of the range. */
export declare const niceMax: (min: number, max: number) => number;
/** The Scene of a `gauge` node. */
export declare const resolveGauge: (node: GaugeNode, options: ResolveChartOptions) => GaugeScene;
