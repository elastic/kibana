import type { Scene, SceneSize } from '../scene/types';
/** A chart's shape outside a sized container. */
export interface ChartSizeSpec {
    /** Width to height. */
    readonly aspectRatio: {
        readonly x: number;
        readonly y: number;
    };
    /** The least height, in pixels. */
    readonly minHeight?: number;
    /** The greatest width, in pixels. */
    readonly maxWidth?: number;
}
/** The height of boxes wrapped into rows `width` wide, as a centered flex row wraps them. */
export declare const wrappedHeight: (boxes: readonly SceneSize[], width: number) => number;
/** The size spec of a Scene's kind; none for a kind that sizes itself, such as a table. */
export declare const chartSizeSpec: (scene: Scene) => ChartSizeSpec | undefined;
/** The box a spec takes at `width`. */
export declare const chartSize: ({ aspectRatio, minHeight, maxWidth }: ChartSizeSpec, width?: number) => SceneSize;
/** A spec as the values of the `chartsScene` size vars, for the box a browser draws the chart in. */
export declare const chartSizeVars: ({ aspectRatio, minHeight, maxWidth, }: ChartSizeSpec) => {
    maxWidth?: string;
    minHeight?: string;
    aspectRatio: string;
};
