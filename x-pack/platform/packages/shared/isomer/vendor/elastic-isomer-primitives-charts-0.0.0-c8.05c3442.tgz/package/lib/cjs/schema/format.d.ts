import { z } from '@elastic/isomer-sdk/schema';
/** The cross-field rules `portableFormatSchema` states in its description, one sentence each. */
export declare const FORMAT_RULES: {
    readonly dateStyle: "A date format uses `dateStyle` and `timeStyle`, or individual date and time fields, not both.";
    readonly timeZone: "A date format’s `timeZone` is an IANA time zone or an offset that `Intl.DateTimeFormat` accepts.";
};
declare const DURATION_INPUT_UNITS: readonly ["picoseconds", "nanoseconds", "microseconds", "milliseconds", "seconds", "minutes", "hours", "days", "weeks", "months", "years"];
/** A unit a duration column's raw value can be stored in. */
export type DurationUnit = (typeof DURATION_INPUT_UNITS)[number];
declare const DURATION_OUTPUT_UNITS: readonly ["nanoseconds", "microseconds", "milliseconds", "seconds", "minutes", "hours", "days", "weeks", "months", "years"];
/** A unit a duration displays in. */
export type DurationOutputUnit = (typeof DURATION_OUTPUT_UNITS)[number];
/**
 * How a column formats its values, as ECMA-402 `Intl` options. Formats
 * outside this set arrive as pre-rendered `data.display` strings with a
 * `losses` entry.
 */
export declare const portableFormatSchema: z.ZodDiscriminatedUnion<[z.ZodObject<{
    notation: z.ZodOptional<z.ZodEnum<{
        standard: "standard";
        compact: "compact";
    }>>;
    minimumFractionDigits: z.ZodOptional<z.ZodInt>;
    maximumFractionDigits: z.ZodOptional<z.ZodInt>;
    signDisplay: z.ZodOptional<z.ZodEnum<{
        auto: "auto";
        always: "always";
        exceptZero: "exceptZero";
        never: "never";
    }>>;
    useGrouping: z.ZodOptional<z.ZodBoolean>;
    suffix: z.ZodOptional<z.ZodString>;
    kind: z.ZodLiteral<"number">;
}, z.core.$strict>, z.ZodObject<{
    fractional: z.ZodOptional<z.ZodBoolean>;
    minimumFractionDigits: z.ZodOptional<z.ZodInt>;
    maximumFractionDigits: z.ZodOptional<z.ZodInt>;
    signDisplay: z.ZodOptional<z.ZodEnum<{
        auto: "auto";
        always: "always";
        exceptZero: "exceptZero";
        never: "never";
    }>>;
    useGrouping: z.ZodOptional<z.ZodBoolean>;
    suffix: z.ZodOptional<z.ZodString>;
    kind: z.ZodLiteral<"percent">;
}, z.core.$strict>, z.ZodObject<{
    base: z.ZodOptional<z.ZodUnion<readonly [z.ZodLiteral<1000>, z.ZodLiteral<1024>]>>;
    unitDisplay: z.ZodOptional<z.ZodEnum<{
        long: "long";
        short: "short";
        narrow: "narrow";
    }>>;
    minimumFractionDigits: z.ZodOptional<z.ZodInt>;
    maximumFractionDigits: z.ZodOptional<z.ZodInt>;
    signDisplay: z.ZodOptional<z.ZodEnum<{
        auto: "auto";
        always: "always";
        exceptZero: "exceptZero";
        never: "never";
    }>>;
    useGrouping: z.ZodOptional<z.ZodBoolean>;
    suffix: z.ZodOptional<z.ZodString>;
    kind: z.ZodLiteral<"bytes">;
}, z.core.$strict>, z.ZodObject<{
    base: z.ZodOptional<z.ZodUnion<readonly [z.ZodLiteral<1000>, z.ZodLiteral<1024>]>>;
    unitDisplay: z.ZodOptional<z.ZodEnum<{
        long: "long";
        short: "short";
        narrow: "narrow";
    }>>;
    minimumFractionDigits: z.ZodOptional<z.ZodInt>;
    maximumFractionDigits: z.ZodOptional<z.ZodInt>;
    signDisplay: z.ZodOptional<z.ZodEnum<{
        auto: "auto";
        always: "always";
        exceptZero: "exceptZero";
        never: "never";
    }>>;
    useGrouping: z.ZodOptional<z.ZodBoolean>;
    suffix: z.ZodOptional<z.ZodString>;
    kind: z.ZodLiteral<"bits">;
}, z.core.$strict>, z.ZodObject<{
    unitDisplay: z.ZodOptional<z.ZodEnum<{
        long: "long";
        short: "short";
        narrow: "narrow";
    }>>;
    minimumFractionDigits: z.ZodOptional<z.ZodInt>;
    maximumFractionDigits: z.ZodOptional<z.ZodInt>;
    signDisplay: z.ZodOptional<z.ZodEnum<{
        auto: "auto";
        always: "always";
        exceptZero: "exceptZero";
        never: "never";
    }>>;
    useGrouping: z.ZodOptional<z.ZodBoolean>;
    suffix: z.ZodOptional<z.ZodString>;
    kind: z.ZodLiteral<"duration">;
    input: z.ZodEnum<{
        picoseconds: "picoseconds";
        nanoseconds: "nanoseconds";
        microseconds: "microseconds";
        milliseconds: "milliseconds";
        seconds: "seconds";
        minutes: "minutes";
        hours: "hours";
        days: "days";
        weeks: "weeks";
        months: "months";
        years: "years";
    }>;
    output: z.ZodOptional<z.ZodUnion<readonly [z.ZodEnum<{
        nanoseconds: "nanoseconds";
        microseconds: "microseconds";
        milliseconds: "milliseconds";
        seconds: "seconds";
        minutes: "minutes";
        hours: "hours";
        days: "days";
        weeks: "weeks";
        months: "months";
        years: "years";
    }>, z.ZodLiteral<"auto">]>>;
}, z.core.$strict>, z.ZodObject<{
    kind: z.ZodLiteral<"date">;
    timeZone: z.ZodOptional<z.ZodString>;
    dateStyle: z.ZodOptional<z.ZodEnum<{
        long: "long";
        short: "short";
        full: "full";
        medium: "medium";
    }>>;
    timeStyle: z.ZodOptional<z.ZodEnum<{
        long: "long";
        short: "short";
        full: "full";
        medium: "medium";
    }>>;
    weekday: z.ZodOptional<z.ZodEnum<{
        long: "long";
        short: "short";
        narrow: "narrow";
    }>>;
    year: z.ZodOptional<z.ZodEnum<{
        numeric: "numeric";
        "2-digit": "2-digit";
    }>>;
    month: z.ZodOptional<z.ZodEnum<{
        long: "long";
        short: "short";
        narrow: "narrow";
        numeric: "numeric";
        "2-digit": "2-digit";
    }>>;
    day: z.ZodOptional<z.ZodEnum<{
        numeric: "numeric";
        "2-digit": "2-digit";
    }>>;
    hour: z.ZodOptional<z.ZodEnum<{
        numeric: "numeric";
        "2-digit": "2-digit";
    }>>;
    minute: z.ZodOptional<z.ZodEnum<{
        numeric: "numeric";
        "2-digit": "2-digit";
    }>>;
    second: z.ZodOptional<z.ZodEnum<{
        numeric: "numeric";
        "2-digit": "2-digit";
    }>>;
    fractionalSecondDigits: z.ZodOptional<z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>, z.ZodLiteral<3>]>>;
    hour12: z.ZodOptional<z.ZodBoolean>;
    timeZoneName: z.ZodOptional<z.ZodEnum<{
        long: "long";
        short: "short";
        shortOffset: "shortOffset";
        longOffset: "longOffset";
    }>>;
}, z.core.$strict>, z.ZodObject<{
    kind: z.ZodLiteral<"text">;
}, z.core.$strict>], "kind">;
/** A format a renderer applies to a column's values. */
export type PortableFormat = z.infer<typeof portableFormatSchema>;
export {};
