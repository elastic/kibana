/**
 * The glyphs a chart can draw beside a value, line or event: what each shows,
 * and the EUI icon type it is drawn as by default. Without `eui`, or without
 * EUI, an engine draws the same subject itself.
 */
export declare const CHART_GLYPHS: {
    readonly alert: {
        readonly shows: "a warning triangle with an exclamation mark";
        readonly eui: "alert";
    };
    readonly asterisk: {
        readonly shows: "an asterisk";
        readonly eui: "asterisk";
    };
    readonly bell: {
        readonly shows: "a bell";
        readonly eui: "bell";
    };
    readonly bolt: {
        readonly shows: "a lightning bolt";
        readonly eui: "bolt";
    };
    readonly bug: {
        readonly shows: "a bug";
        readonly eui: "bug";
    };
    readonly circle: {
        readonly shows: "a filled circle";
        readonly eui: "dot";
    };
    readonly comment: {
        readonly shows: "a speech bubble";
        readonly eui: "editorComment";
    };
    readonly external: {
        readonly shows: "a box with an arrow leaving its corner";
        readonly eui: "external";
    };
    readonly flag: {
        readonly shows: "a flag on a pole";
        readonly eui: "flag";
    };
    readonly globe: {
        readonly shows: "a globe";
        readonly eui: "globe";
    };
    readonly heart: {
        readonly shows: "a heart";
        readonly eui: "heart";
    };
    readonly marker: {
        readonly shows: "a map pin marking a location";
        readonly eui: "mapMarker";
    };
    readonly pin: {
        readonly shows: "an outlined push pin";
        readonly eui: "pin";
    };
    readonly pinFilled: {
        readonly shows: "a filled push pin";
        readonly eui: "pinFilled";
    };
    readonly processor: {
        readonly shows: "a processor chip";
        readonly eui: "compute";
    };
    readonly sortDown: {
        readonly shows: "an arrow pointing down";
        readonly eui: "sortDown";
    };
    readonly sortUp: {
        readonly shows: "an arrow pointing up";
        readonly eui: "sortUp";
    };
    readonly star: {
        readonly shows: "an outlined star";
        readonly eui: "starEmpty";
    };
    readonly starFilled: {
        readonly shows: "a filled star";
        readonly eui: "starFilled";
    };
    readonly tag: {
        readonly shows: "a price tag";
        readonly eui: "tag";
    };
    readonly temperature: {
        readonly shows: "a thermometer";
        readonly eui: "temperature";
    };
    readonly triangle: {
        readonly shows: "a filled triangle pointing up";
    };
};
/** A glyph a chart can draw. */
export type ChartGlyph = keyof typeof CHART_GLYPHS;
