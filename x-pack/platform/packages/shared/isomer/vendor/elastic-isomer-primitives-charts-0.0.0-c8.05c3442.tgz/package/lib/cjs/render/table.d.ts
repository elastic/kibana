import type { ReactNode } from 'react';
import type { SceneRenderEnv, TableScene } from '../scene/types';
import type { ReactSceneRenderer } from './context';
/** The height a table draws at: the Scene's, else its lines and first page's rows. */
export declare const tableHeight: (scene: TableScene) => number;
type Classes = Pick<SceneRenderEnv, 'resolveClassName'> | undefined;
/**
 * Draws a table Scene as an HTML table, in the browser and on `snapshot`.
 * `styles` resolves its classes; absent, they are their readable names.
 */
export declare const TableView: ({ scene, styles, }: {
    scene: TableScene;
    styles?: Classes;
}) => ReactNode;
/**
 * The pack's own renderer for table Scenes. No chart engine draws a table, so
 * the pack does, the same in the browser and on Node.
 */
export declare const tableSceneRenderer: ReactSceneRenderer;
export {};
