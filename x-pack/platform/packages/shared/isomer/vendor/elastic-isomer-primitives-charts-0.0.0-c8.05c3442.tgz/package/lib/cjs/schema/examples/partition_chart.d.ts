import type { PrimitiveExample } from '@elastic/isomer-sdk/schema';
import type { PartitionChartNode } from '../partition_chart';
/** The smallest `partitionChart`: one pie layer. The catalog's example. */
export declare const partitionPie: PartitionChartNode;
/** Named `partitionChart` examples covering the corpus edge cases, each valid in a composition. */
export declare const partitionChartExamples: PrimitiveExample<PartitionChartNode>[];
