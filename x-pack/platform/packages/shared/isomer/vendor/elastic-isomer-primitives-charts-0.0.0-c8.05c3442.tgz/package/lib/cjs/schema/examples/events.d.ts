import type { ChartEvent } from '../events';
interface ChartEventExample {
    name: string;
    description: string;
    event: ChartEvent;
}
/** Events raised on {@link xyInteractive}, as every renderer must raise them. */
export declare const chartEventExamples: ChartEventExample[];
export {};
