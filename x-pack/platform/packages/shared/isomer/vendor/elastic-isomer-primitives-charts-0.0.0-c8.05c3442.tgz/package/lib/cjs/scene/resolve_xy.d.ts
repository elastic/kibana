import type { XyChartNode } from '../schema/xy_chart';
import { type ResolveChartOptions } from './common';
import type { XyScene } from './types';
/** The Scene of an `xyChart` node. */
export declare const resolveXy: (node: XyChartNode, options: ResolveChartOptions) => XyScene;
