import type { TagCloudNode } from '../schema/tag_cloud';
import { type ResolveChartOptions } from './common';
import type { TagCloudScene } from './types';
/** The Scene of a `tagCloud` node. */
export declare const resolveTagCloud: (node: TagCloudNode, options: ResolveChartOptions) => TagCloudScene;
