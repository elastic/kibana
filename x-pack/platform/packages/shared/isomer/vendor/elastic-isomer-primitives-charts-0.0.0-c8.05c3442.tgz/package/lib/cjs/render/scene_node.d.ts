import { type ReactNode } from 'react';
import type { Scene } from '../scene/types';
import type { ChartNode, ChartsReactEnv, ReactSceneRenderer, SceneResolver } from './context';
/** What a pack's shims share: how to resolve, and the renderers after the host's. */
export interface SceneShimConfig {
    readonly resolveScene: SceneResolver;
    /** Tried after the host's `sceneRenderers`. The last should support every kind. */
    readonly sceneRenderers: readonly ReactSceneRenderer[];
}
/** The height a Scene's link line takes below the chart. */
export declare const linkLineHeight: (scene: Scene) => number;
/**
 * Draws a chart node through the first renderer that runs here and supports
 * its kind, and throws when none does. Off native, the output sits in one
 * `div` that carries the node anchor, with the Scene's link on a line below
 * it; native output is the renderer's own.
 *
 * Without a host `size`, the chart takes its kind's size spec. On Node, or
 * for a `sized` renderer, it resolves for the spec's box; in a browser, a
 * `fluid` renderer's box takes the spec's shape and the renderer fills it.
 * A host `size` holds the link line too.
 */
export declare const renderSceneNode: (node: ChartNode, env: ChartsReactEnv, config: SceneShimConfig) => ReactNode;
