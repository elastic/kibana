import { z } from '@elastic/isomer-sdk/schema';
/** Where a node came from. Hosts use it to show capture time and to build the node again; it is never rendered. */
export declare const provenanceSchema: z.ZodObject<{
    host: z.ZodString;
    hostVersion: z.ZodOptional<z.ZodString>;
    capturedAt: z.ZodISODateTime;
    timeRange: z.ZodOptional<z.ZodObject<{
        from: z.ZodISODateTime;
        to: z.ZodISODateTime;
    }, z.core.$strict>>;
    meta: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnknown>>;
}, z.core.$strict>;
/** Where a node came from. */
export type Provenance = z.infer<typeof provenanceSchema>;
/** A record of something the source had that the node drops or approximates. */
export declare const lossSchema: z.ZodObject<{
    path: z.ZodString;
    kind: z.ZodEnum<{
        dropped: "dropped";
        approximated: "approximated";
        prerendered: "prerendered";
    }>;
    note: z.ZodString;
}, z.core.$strict>;
/** Something the source had that the node drops or approximates. */
export type Loss = z.infer<typeof lossSchema>;
