import { z } from '@elastic/isomer-sdk/schema';
import type { ChartColumn, ColumnType } from './data';
/** The rule every chart states for its column references. */
export declare const COLUMN_REF_RULE = "Every column reference names a column in `data.columns`.";
/** A column id, checked against `data.columns` by the chart that holds it. */
export declare const columnRefSchema: z.ZodString;
/** One column id found in a node, where it was found, and the types it accepts. */
export interface ColumnReference {
    path: (string | number)[];
    id: string;
    /** Types the reference accepts. Absent means any. */
    types?: readonly ColumnType[];
    /** Whether the column must not be `multivalue`. */
    single?: boolean;
    /** Reported in place of the rules' `type` sentence for this reference. */
    rule?: string;
}
/** The sentences a failed reference reports. */
interface ColumnReferenceRules {
    /** Reported for a reference that names no column. */
    missing: string;
    /** Reported for a reference to a column of a type it does not accept. */
    type: string;
    /** Reported for a `single` reference to a `multivalue` column. Absent means `type`. */
    single?: string;
    /** What the missing thing is called in the message. Absent means "column". */
    noun?: string;
}
/**
 * Adds an issue for each reference that names no column of `data`, or a column
 * of a type it does not accept.
 */
export declare const checkColumnReferences: (data: {
    readonly columns: readonly ChartColumn[];
} | undefined, references: readonly ColumnReference[], context: z.core.$RefinementCtx<unknown>, rules: ColumnReferenceRules) => void;
export {};
