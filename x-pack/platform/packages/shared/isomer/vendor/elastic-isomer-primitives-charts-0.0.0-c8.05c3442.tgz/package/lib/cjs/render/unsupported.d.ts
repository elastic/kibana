/** A visible placeholder: title, reason, and a link where there is one. */
export declare const unsupportedPrimitive: import("@elastic/isomer-sdk").PrimitiveDefinition<import("../schema/unsupported").UnsupportedNode, import("./context").ChartsPackTypes, import("zod").ZodObject<{
    type: import("zod").ZodLiteral<"unsupported">;
    title: import("zod").ZodString;
    reason: import("zod").ZodString;
    link: import("zod").ZodOptional<import("zod").ZodObject<{
        href: import("zod").ZodString;
        label: import("zod").ZodString;
    }, import("zod/v4/core").$strict>>;
    source: import("zod").ZodOptional<import("zod").ZodObject<{
        host: import("zod").ZodString;
        hostVersion: import("zod").ZodOptional<import("zod").ZodString>;
        capturedAt: import("zod").ZodISODateTime;
        timeRange: import("zod").ZodOptional<import("zod").ZodObject<{
            from: import("zod").ZodISODateTime;
            to: import("zod").ZodISODateTime;
        }, import("zod/v4/core").$strict>>;
        meta: import("zod").ZodOptional<import("zod").ZodRecord<import("zod").ZodString, import("zod").ZodUnknown>>;
    }, import("zod/v4/core").$strict>>;
} & {
    id: ReturnType<() => import("zod").ZodOptional<import("zod").ZodString>>;
    surfaces: ReturnType<() => import("zod").ZodOptional<import("zod").ZodArray<import("zod").ZodEnum<{
        react: "react";
        snapshot: "snapshot";
        text: "text";
        markdown: "markdown";
        slack: "slack";
    }>>>>;
}, import("zod/v4/core").$strip>>;
