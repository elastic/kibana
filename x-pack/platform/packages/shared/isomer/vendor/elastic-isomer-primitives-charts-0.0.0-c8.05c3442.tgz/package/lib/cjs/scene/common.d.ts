import type { Cell, ChartColumn, ChartData, ColumnType } from '../schema/data';
import type { Emphasis, SelectTarget } from '../schema/events';
import type { PortableFormat } from '../schema/format';
import type { ColorScheme, SceneChrome, SceneInteractions, SceneSize, SceneTable } from './types';
/** What the host draws a Scene for, passed to `resolveChart`. */
export interface ResolveChartOptions {
    /** The scheme every color in the Scene is concrete for. */
    scheme: ColorScheme;
    /** The size the host draws the Scene at, passed through. */
    size?: SceneSize | undefined;
    /** Absent means `en`. */
    locale?: string | undefined;
    /** IANA time zone for dates whose format names none. Absent means `UTC`. */
    timeZone?: string | undefined;
}
/** What every resolver step reads: the options, resolved, and the node's data. */
export interface Resolution {
    readonly scheme: ColorScheme;
    readonly size?: SceneSize;
    readonly locale: string;
    readonly timeZone: string;
    readonly chrome: SceneChrome;
    readonly data: ChartData;
    column(id: string): ChartColumn;
    cell(id: string, row: number): Cell;
    /** A cell's identity for grouping and matching: a scalar date by its instant, anything else by {@link cellKey}. */
    identity(id: string, row: number): string;
    /** The column's format, or the default for its type. */
    format(id: string): PortableFormat;
    /** A value formatted with `format`. */
    formatAs(value: Cell | undefined, format: PortableFormat): string;
    /** A cell as displayed: its `display` string, or its value formatted. */
    text(id: string, row: number): string;
    /** A value formatted as the column formats its cells. */
    valueText(id: string, value: Cell | undefined): string;
}
/** The {@link Resolution} of `data` under `options`. */
export declare const createResolution: (data: ChartData, { scheme, size, locale, timeZone }: ResolveChartOptions) => Resolution;
interface InteractionsInput {
    interactions?: {
        select?: readonly SelectTarget[] | undefined;
        brush?: {
            column: string;
        } | undefined;
        sync?: {
            cursor?: boolean | undefined;
            tooltips?: boolean | undefined;
        } | undefined;
        link?: {
            href: string;
            label: string;
        } | undefined;
    } | undefined;
    emphasis?: Emphasis | undefined;
}
/** The node's interactions, with defaults filled in. */
export declare const resolveInteractions: ({ interactions, emphasis, }: InteractionsInput) => SceneInteractions;
/** `label: value` pairs joined as a selection's description reads. */
export declare const describe: (parts: readonly (readonly [string, string])[]) => string;
/** A cell's finite number, or `undefined` when it has none. */
export declare const toNumber: (cell: Cell | undefined) => number | undefined;
/** The fields every Scene kind shares. */
export declare const sceneBase: (resolution: Resolution, node: {
    title?: string | undefined;
    description?: string | undefined;
}) => {
    chrome: SceneChrome;
    table: SceneTable;
    description?: string;
    title?: string;
    locale: string;
    timeZone: string;
    size?: SceneSize;
    scheme: ColorScheme;
};
/** "Title: sentence", or the sentence alone without a title. */
export declare const titled: (title: string | undefined, sentence: string) => string;
/** The documented color/series key encoding. No string produces `\null` or a leading `\[`. */
export declare const keyPart: (cell: Cell) => string;
/** Raw cell identity, independent of display text and scalar/array encoding. */
export declare const cellKey: (cell: Cell) => string;
/** A cell's identity in a column of `type`: a scalar date by its instant, anything else by {@link cellKey}. */
export declare const cellIdentity: (value: Cell, type: ColumnType) => string;
export {};
