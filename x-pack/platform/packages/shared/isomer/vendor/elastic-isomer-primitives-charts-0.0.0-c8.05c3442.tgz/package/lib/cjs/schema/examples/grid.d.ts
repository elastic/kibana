import type { PrimitiveExample } from '@elastic/isomer-sdk/schema';
import type { GridNode } from '../grid';
/** Named `grid` examples, each of which validates in a composition. */
export declare const gridExamples: PrimitiveExample<GridNode>[];
