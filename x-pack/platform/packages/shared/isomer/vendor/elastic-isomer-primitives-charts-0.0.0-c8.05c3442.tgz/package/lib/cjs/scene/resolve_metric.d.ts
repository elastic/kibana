import type { ColorBand } from '../schema/colors';
import type { MetricNode } from '../schema/metric';
import { type ResolveChartOptions } from './common';
import type { MetricScene } from './types';
/** The band `value` falls in: `from` inclusive, `to` exclusive except on the last band, as Lens's palette stops. */
export declare const bandFor: (bands: readonly ColorBand[], value: number) => ColorBand | undefined;
/** The Scene of a `metric` node. */
export declare const resolveMetric: (node: MetricNode, options: ResolveChartOptions) => MetricScene;
