/** A cached `Intl.NumberFormat`, falling back to `en` rather than the host default. */
export declare const numberFormat: (locale: string, options: Intl.NumberFormatOptions) => Intl.NumberFormat;
/** A cached `Intl.DateTimeFormat`, falling back to `en` rather than the host default. Throws a `RangeError` for a time zone the environment does not know. */
export declare const dateFormat: (locale: string, options: Intl.DateTimeFormatOptions) => Intl.DateTimeFormat;
/** `value` formatted, printing a negative value that rounds to zero as zero, not `-0`, unless the sign display is `always`. */
export declare const formatNumber: (formatter: Intl.NumberFormat, value: number) => string;
interface NumberFields {
    minimumFractionDigits?: number | undefined;
    maximumFractionDigits?: number | undefined;
    signDisplay?: Intl.NumberFormatOptions['signDisplay'] | undefined;
    useGrouping?: boolean | undefined;
}
/** The `Intl.NumberFormat` options a format states, without the ones it leaves absent. */
export declare const numberOptions: ({ minimumFractionDigits, maximumFractionDigits, signDisplay, useGrouping, }: NumberFields) => Intl.NumberFormatOptions;
export {};
