export declare const gridModule: {
    handles: {
        root: import("@elastic/distillate").StyleHandle;
        header: import("@elastic/distillate").StyleHandle;
        clipped: import("@elastic/distillate").StyleHandle;
        heading: import("@elastic/distillate").StyleHandle;
        description: import("@elastic/distillate").StyleHandle;
        sectionGap: import("@elastic/distillate").StyleHandle;
        panels: import("@elastic/distillate").StyleHandle;
        column: import("@elastic/distillate").StyleHandle;
        panel: import("@elastic/distillate").StyleHandle;
        placed: import("@elastic/distillate").StyleHandle;
        stacked: import("@elastic/distillate").StyleHandle;
        body: import("@elastic/distillate").StyleHandle;
        collapsed: import("@elastic/distillate").StyleHandle;
    };
    vars: {
        clip: import("@elastic/distillate").LocalVarGroup<"maxHeight">;
        place: import("@elastic/distillate").LocalVarGroup<"column" | "row" | "height">;
    };
    stylesheet: () => string;
};
