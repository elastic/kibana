import type { PrimitiveExample } from '@elastic/isomer-sdk/schema';
import type { MetricNode } from '../metric';
/** The smallest `metric`: one value from one row. The catalog's example. */
export declare const metricSingleValue: MetricNode;
/** Named `metric` examples covering the corpus edge cases, each valid in a composition. */
export declare const metricExamples: PrimitiveExample<MetricNode>[];
