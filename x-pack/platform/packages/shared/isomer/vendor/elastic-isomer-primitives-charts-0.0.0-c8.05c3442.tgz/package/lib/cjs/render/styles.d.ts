import type { CSSProperties } from 'react';
import { type LocalVarGroup, type StyleHandle, type StylesCollector, type StylesObject } from '@elastic/distillate';
import type { PrimitiveNode, StyledRenderContext } from '@elastic/isomer-sdk';
import type { HTMLStyleAdapter } from '@elastic/isomer-sdk/html';
/**
 * The one distillery every charts style module is authored in. Its modules
 * interpolate `CHARTS_THEME` values, so it declares no theme variables, and
 * each module's name starts with `charts` so no class collides with another
 * library's on the page.
 */
export declare const chartsDistillery: import("@elastic/distillate").Distillery<{}, {}>;
/** The pack's HTML style adapter: records the handles a render resolves and emits their rules. */
export declare const chartsStyleAdapter: HTMLStyleAdapter<PrimitiveNode, StylesCollector>;
type Authoring = Parameters<Parameters<typeof chartsDistillery.createStyleModule>[1]>[0];
/**
 * Authors a charts style module whose rules read module-local `vars`, and
 * returns the var groups beside its handles, and `stylesheet()`, the module's
 * own rules. A rule declares each var's default with `${group}`; a renderer
 * writes a value only a Scene knows, such as a series color or a box's size,
 * with {@link varStyle}.
 */
export declare const createVarsModule: <TVars, TStyles extends StylesObject>(name: string, vars: (define: Authoring["vars"]) => TVars, styles: (api: Authoring, vars: TVars) => TStyles) => {
    handles: import("@elastic/distillate").ResolvedStyles<TStyles>;
    vars: TVars;
    /** Every rule this module draws with, variants included, whatever else is loaded. */
    stylesheet: () => string;
};
/**
 * Sets a module's vars on one element: the `style` it returns holds custom
 * properties alone, each declared by the module, so every declaration stays
 * in the stylesheet. Absent values keep the module's default.
 */
export declare const varStyle: <TKey extends string>(group: LocalVarGroup<TKey>, values: Partial<Record<TKey, string | undefined>>) => CSSProperties;
/** `value` pixels, as a var's value: custom properties take no unitless length. */
export declare const px: (value: number) => string;
/** Resolves handles through the render's adapter, or to their readable names when it has none. */
export declare const cls: (context: Pick<StyledRenderContext, "resolveClassName"> | undefined, ...handles: ReadonlyArray<StyleHandle | false | undefined>) => string;
export {};
