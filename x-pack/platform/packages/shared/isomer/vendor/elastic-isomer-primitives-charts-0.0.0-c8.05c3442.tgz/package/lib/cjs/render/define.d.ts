import type { ChartsPackTypes } from './context';
/** `definePrimitive` bound to this pack's types. */
export declare const definePrimitive: <TNode extends import("@elastic/isomer-sdk").PrimitiveNode, TSchema extends import("@elastic/isomer-sdk").PrimitiveSchema = import("@elastic/isomer-sdk").PrimitiveSchema>(definition: import("@elastic/isomer-sdk").PrimitiveDefinition<TNode, ChartsPackTypes, TSchema>) => import("@elastic/isomer-sdk").PrimitiveDefinition<TNode, ChartsPackTypes, import("@elastic/isomer-sdk").WithNodeFields<TSchema>>;
