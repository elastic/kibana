import { z } from '@elastic/isomer-sdk/schema';
/**
 * A color, resolved by whoever built the node: concrete for both schemes,
 * a chrome token, or an index into the default categorical palette.
 */
export declare const colorValueSchema: z.ZodUnion<readonly [z.ZodObject<{
    light: z.ZodString;
    dark: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    token: z.ZodEnum<{
        text: "text";
        textSubdued: "textSubdued";
        axis: "axis";
        gridLine: "gridLine";
        background: "background";
        border: "border";
    }>;
}, z.core.$strict>, z.ZodObject<{
    palette: z.ZodLiteral<"categorical">;
    index: z.ZodInt;
}, z.core.$strict>]>;
/** A color for one scheme pair, a chrome token, or a categorical palette index. */
export type ColorValue = z.infer<typeof colorValueSchema>;
/**
 * How a cell becomes part of a `colors.byKey` key. Escaping keeps keys
 * unambiguous: a missing cell and the string "null" differ, and a part holding
 * ":" cannot be mistaken for two.
 */
export declare const KEY_PART_RULE = "A key part is the value as a string with each `\\` and `:` preceded by `\\`; a missing (null) cell is the key part `\\null`, and a multivalue cell is `\\` followed by the key part of its JSON text, such as `\\[\"a\"]`; no string produces either.";
/** The rule `chartColorsSchema` states for `colors.bands`. */
export declare const BAND_RULE = "Each band with both bounds has `from` below `to`, and bands ascend without overlapping.";
declare const colorBandSchema: z.ZodObject<{
    from: z.ZodOptional<z.ZodNumber>;
    to: z.ZodOptional<z.ZodNumber>;
    color: z.ZodUnion<readonly [z.ZodObject<{
        light: z.ZodString;
        dark: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        token: z.ZodEnum<{
            text: "text";
            textSubdued: "textSubdued";
            axis: "axis";
            gridLine: "gridLine";
            background: "background";
            border: "border";
        }>;
    }, z.core.$strict>, z.ZodObject<{
        palette: z.ZodLiteral<"categorical">;
        index: z.ZodInt;
    }, z.core.$strict>]>;
}, z.core.$strict>;
/** A color for values from `from` (inclusive) up to `to` (exclusive). */
export type ColorBand = z.infer<typeof colorBandSchema>;
/** The colors a node carries: per series or category key, and by value range. */
export declare const chartColorsSchema: z.ZodObject<{
    byKey: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodObject<{
        light: z.ZodString;
        dark: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        token: z.ZodEnum<{
            text: "text";
            textSubdued: "textSubdued";
            axis: "axis";
            gridLine: "gridLine";
            background: "background";
            border: "border";
        }>;
    }, z.core.$strict>, z.ZodObject<{
        palette: z.ZodLiteral<"categorical">;
        index: z.ZodInt;
    }, z.core.$strict>]>>>;
    bands: z.ZodOptional<z.ZodArray<z.ZodObject<{
        from: z.ZodOptional<z.ZodNumber>;
        to: z.ZodOptional<z.ZodNumber>;
        color: z.ZodUnion<readonly [z.ZodObject<{
            light: z.ZodString;
            dark: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            token: z.ZodEnum<{
                text: "text";
                textSubdued: "textSubdued";
                axis: "axis";
                gridLine: "gridLine";
                background: "background";
                border: "border";
            }>;
        }, z.core.$strict>, z.ZodObject<{
            palette: z.ZodLiteral<"categorical">;
            index: z.ZodInt;
        }, z.core.$strict>]>;
    }, z.core.$strict>>>;
}, z.core.$strict>;
/** Colors resolved by whoever built the node. */
export type ChartColors = z.infer<typeof chartColorsSchema>;
export {};
