import type { DataTableNode, DataTableSummary } from '../schema/data_table';
import { type ResolveChartOptions } from './common';
import type { TableScene } from './types';
/** Kibana's dash for a missing value in a table (`NULL_PLACEHOLDER`). */
export declare const TABLE_MISSING_TEXT = "-";
/** Lens's empty table message (`charts.noDataLabel`). */
export declare const TABLE_EMPTY_TEXT = "No results found";
/** Lens's summary labels (`getSummaryRowOptions`). */
export declare const SUMMARY_LABELS: Readonly<Record<DataTableSummary, string>>;
/** The Scene of a `dataTable` node. */
export declare const resolveTable: (node: DataTableNode, options: ResolveChartOptions) => TableScene;
