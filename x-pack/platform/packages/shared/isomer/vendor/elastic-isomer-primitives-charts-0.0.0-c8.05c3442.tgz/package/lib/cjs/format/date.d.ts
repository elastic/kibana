import type { PortableFormat } from '../schema/format';
type DateFormat = Extract<PortableFormat, {
    kind: 'date';
}>;
/**
 * Formats an instant with `Intl.DateTimeFormat`. `epoch` is milliseconds since
 * the epoch; the format's `timeZone`, when present, overrides `timeZone`.
 * Throws a `RangeError` for a time zone the environment does not know.
 */
export declare const formatDate: (epoch: number, { kind: _kind, timeZone: own, hour12, ...options }: DateFormat, { locale, timeZone }: {
    locale: string;
    timeZone: string;
}) => string;
/**
 * A date cell as epoch milliseconds: a number as it is, or an ISO 8601
 * date-time with a UTC offset parsed. `undefined` when it is neither.
 */
export declare const toEpoch: (value: unknown) => number | undefined;
export {};
