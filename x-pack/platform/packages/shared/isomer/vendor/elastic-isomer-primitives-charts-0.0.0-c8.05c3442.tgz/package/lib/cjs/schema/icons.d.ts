import { z } from '@elastic/isomer-sdk/schema';
/** A glyph by name. */
export declare const glyphSchema: z.ZodEnum<{
    alert: "alert";
    asterisk: "asterisk";
    bell: "bell";
    bolt: "bolt";
    bug: "bug";
    circle: "circle";
    comment: "comment";
    external: "external";
    flag: "flag";
    globe: "globe";
    heart: "heart";
    marker: "marker";
    pin: "pin";
    pinFilled: "pinFilled";
    processor: "processor";
    sortDown: "sortDown";
    sortUp: "sortUp";
    star: "star";
    starFilled: "starFilled";
    tag: "tag";
    temperature: "temperature";
    triangle: "triangle";
}>;
