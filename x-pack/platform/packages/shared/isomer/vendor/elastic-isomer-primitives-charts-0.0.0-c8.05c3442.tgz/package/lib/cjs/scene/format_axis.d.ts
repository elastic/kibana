import type { SceneAxis, XyScene } from './types';
/** A value on a continuous axis as the axis prints it, such as a tick an engine chose. */
export declare const formatAxisValue: ({ locale, timeZone }: Pick<XyScene, "locale" | "timeZone">, { format }: Pick<SceneAxis, "format">, value: number) => string;
