import { type CheckedComposition, type CheckedValidationResult, type Composition, type PrimitiveNode, type ValidationErrorMode } from '@elastic/isomer-sdk';
/** Validates `node` as the sole node of a view, for a validating surface's `renderNode`. */
export declare const checkNode: (validate: (composition: Composition) => CheckedValidationResult, node: PrimitiveNode, mode: ValidationErrorMode) => {
    composition: CheckedComposition;
    node: PrimitiveNode;
};
