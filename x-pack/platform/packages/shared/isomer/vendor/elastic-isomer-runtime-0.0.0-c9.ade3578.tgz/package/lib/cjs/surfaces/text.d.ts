import type { CheckedValidationResult, Composition, PrimitiveNode, ValidationErrorMode } from '@elastic/isomer-sdk';
import { type TextEnvelopeDispatcher, type TextEnvelopeOptions } from '@elastic/isomer-sdk/text';
/** {@link TextEnvelopeOptions} plus the surface's validation posture. */
export interface TextRenderOptions extends TextEnvelopeOptions {
    /** Defaults to `'throw'`: a string has nowhere to carry findings. `'collect'` renders anyway. */
    onValidationError?: ValidationErrorMode;
}
/** Options for {@link TextSurface.renderNode}: a lone node has no heading to draw. */
export type TextRenderNodeOptions = Pick<TextRenderOptions, 'onValidationError'>;
/** Renders a composition or node to plain text. */
export interface TextSurface {
    /** Always `true`: this surface validates the composition and renders the copy it checked, never the caller's value. */
    readonly validating: true;
    /** Renders a full composition to plain text. */
    render(composition: Composition, options?: TextRenderOptions): string;
    /** Renders a single primitive node to plain text. */
    renderNode(node: PrimitiveNode, options?: TextRenderNodeOptions): string;
}
/** Creates the `text` {@link RuntimeSurfaces} entry. */
export declare const createTextSurface: (dispatcher: TextEnvelopeDispatcher<PrimitiveNode>, validate: (composition: Composition) => CheckedValidationResult) => TextSurface;
