import { type AnyPrimitiveDefinition, type AnyPrimitivePack, type AuthoringJsonSchemaOptions, type HostCapabilities, type PrimitiveCatalogEntry, type PrimitiveGroup, type SurfaceSupport } from '@elastic/isomer-sdk';
import { type AuthoringDeclarationsOptions } from '@elastic/isomer-sdk/author';
import type { JsonSchema, RegisteredViewSummary } from '../registry';
import { type PropDescriptor } from './prop_descriptors';
export type { HostCapabilities, SurfaceSupport };
/** Options for the authoring material `getAuthoringContext` returns. */
export interface RuntimeAuthoringOptions extends AuthoringJsonSchemaOptions, AuthoringDeclarationsOptions {
}
/**
 * Everything a host hands an agent so it can answer a question with a view:
 * the composition contract, what it may compose from, and what it can request
 * by id.
 *
 * Both halves come from one call deliberately. An agent choosing between
 * "route to a registered view" and "compose from primitives" needs to see both
 * options at once.
 */
export interface RuntimeAuthoringContext {
    /** Authoring JSON Schema for a `Composition` built from this runtime's primitives. */
    schema: JsonSchema;
    /** The `body` of {@link RuntimeAuthoringContext.schema} on its own, for an editor that validates body nodes. */
    bodySchema: JsonSchema;
    /**
     * `.d.ts` source for the registered primitives, as an ambient module: a `<Type>Node`
     * per primitive with its catalog text as JSDoc, and the `BodyNode` union. See
     * {@link RuntimeAuthoringOptions.jsx} for the JSX components.
     */
    declarations: string;
    /** Catalog entries describing each available primitive, including one `example`. */
    primitives: PrimitiveCatalogEntry[];
    /** Every pack's primitive groups, in pack order, for an index catalog. */
    groups: PrimitiveGroup[];
    /**
     * Registered views an agent can request by id, with their input schemas.
     *
     * Read live rather than cached: a host may register views after building the
     * runtime, and an agent asking now should see what is registered now.
     */
    views: RegisteredViewSummary[];
    /**
     * The authoring JSON Schema restricted to `types`, e.g. for a registered
     * view's narrower input. Uncached, unlike {@link RuntimeAuthoringContext.schema}:
     * callers are expected to ask for a handful of subsets, not one per render.
     *
     * Throws `UNKNOWN_PRIMITIVE_TYPE` for a type this runtime does not register.
     */
    schemaFor(types: readonly string[]): JsonSchema;
    /**
     * The catalog entries of `types` and the `$defs` of {@link RuntimeAuthoringContext.schema}
     * they reach, for an agent that reads an index catalog and then looks up what it picks.
     *
     * Throws `UNKNOWN_PRIMITIVE_TYPE` for a type this runtime does not register.
     */
    describePrimitives(types: readonly string[]): PrimitiveDescriptions;
}
/** What {@link RuntimeAuthoringContext.describePrimitives} returns. */
export interface PrimitiveDescriptions {
    primitives: PrimitiveCatalogEntry[];
    /** `{ $defs }` only: the defs the types reach, keyed as in the full schema, with the body-node union stubbed. */
    schema: JsonSchema;
    /** Each requested type's properties, flattened from the full schema for a props table. */
    props: Readonly<Record<string, readonly PropDescriptor[]>>;
}
/**
 * Returns a factory that builds the authoring JSON Schema, declarations and
 * primitive catalog from `definitions` on its first call, reuses them on every
 * later call, and reads the view list fresh.
 *
 * Projecting a discriminated union to JSON Schema is expensive and fixed for
 * the runtime's lifetime, so it is cached, and a runtime that only renders
 * never pays for it. The registered-view list is cheap (each summary is
 * projected once at `register`) and changes as a host registers, so it is not.
 */
export declare const createRuntimeAuthoringContextFactory: (definitions: readonly AnyPrimitiveDefinition[], listViews: () => RegisteredViewSummary[], packs: readonly AnyPrimitivePack[], { jsx, moduleName, ...runtimeAuthoring }?: RuntimeAuthoringOptions) => (() => RuntimeAuthoringContext);
