import { type CheckedValidationResult, type Composition, type InputBudget, type PrimitiveNode, type ValidationError, type ValidationResult } from '@elastic/isomer-sdk';
import { type ZodType } from 'zod';
/** A JSON Schema document, as the authoring schema and a view's `inputSchema` are projected. */
export type JsonSchema = Record<string, unknown>;
/** The record a host passes to {@link ViewRegistry.request}, and `build`'s input when the view declares no schema. */
export type ViewInput = Record<string, unknown>;
/**
 * Thrown by {@link ViewRegistry.request} when `checkInputBudget` refuses the
 * input or it fails the view's Zod `input` schema. `errors` are the same
 * `ValidationError`s composition validation returns.
 *
 * Identify it by `name`, `code`, `viewId`, and `errors`, never `instanceof`.
 */
export declare class RegisteredViewInputError extends Error {
    readonly code: "VIEW_INPUT_INVALID";
    /** Id of the view whose input failed validation. */
    readonly viewId: string;
    readonly errors: ValidationError[];
    constructor(viewId: string, errors: ValidationError[]);
}
/** What a view's `build` receives. */
export interface ViewBuildArgs<THostContext, TInput> {
    /** Whatever the host passes to `request`: a session, a request, a services bundle. */
    context: THostContext;
    /** The input budget's plain copy of the host's record, parsed through the view's `input` schema when it declares one. */
    input: TInput;
}
/** A view registered with a {@link ViewRegistry}, as {@link defineView} builds it. */
export interface RegisteredView<THostContext = unknown, TInput = ViewInput, TNode extends PrimitiveNode = PrimitiveNode> {
    /** Unique key within the registry. */
    id: string;
    /** Display name shown to hosts and agents. */
    title: string;
    /** Longer summary of what the view shows. */
    description: string;
    /** Natural-language queries this view should match, for host-side search and routing. */
    answers: string[];
    /**
     * Zod schema for the view's input. When present, `registry.request` parses
     * the input through it before `build` runs (throwing
     * {@link RegisteredViewInputError} on failure) and derives the summary's
     * `inputSchema` from it. When absent, `build` receives the input budget's
     * plain copy of the record.
     */
    input?: ZodType<TInput>;
    /**
     * Builds the view's composition. Method syntax on purpose: parameter
     * bivariance lets a view typed for its own input sit in a list typed for
     * `unknown`, such as `IsomerRuntimeOptions.views`.
     */
    build(args: ViewBuildArgs<THostContext, TInput>): Composition<TNode> | Promise<Composition<TNode>>;
}
/** Options for {@link defineView}: a {@link RegisteredView} with `description` optional. */
export interface DefineViewOptions<THostContext, TInput, TNode extends PrimitiveNode = PrimitiveNode> extends Omit<RegisteredView<THostContext, TInput, TNode>, 'description'> {
    /** Longer summary; defaults to `title` when omitted. */
    description?: string;
}
/** Metadata for a registered view, as returned by {@link ViewRegistry.list} / `get`. */
export interface RegisteredViewSummary {
    /** Unique key within the registry. */
    id: string;
    /** Display name shown to hosts and agents. */
    title: string;
    /** Longer summary of what the view shows. */
    description: string;
    /** Natural-language queries this view should match, for host-side search and routing. */
    answers: string[];
    /** JSON Schema for the view's input, derived from its Zod schema when present. */
    inputSchema?: JsonSchema;
}
/** Result of {@link ViewRegistry.request}: the built composition plus its validation result. */
export interface ViewResponse<TNode extends PrimitiveNode = PrimitiveNode> {
    /** Summary of the requested view. */
    view: RegisteredViewSummary;
    /** The copy of the built composition that `validation` checked, or the built value when the input budget refused it. */
    composition: Composition<TNode>;
    /** Result of validating `composition`. */
    validation: ValidationResult;
}
/** Registry of views, created by {@link createViewRegistry}. */
export interface ViewRegistry<THostContext = unknown, TNode extends PrimitiveNode = PrimitiveNode> {
    /** Registers a view. Throws if `view.id` is already registered. */
    register: <TInput>(view: RegisteredView<THostContext, TInput, TNode>) => void;
    /** Lists summaries for all registered views. */
    list: () => RegisteredViewSummary[];
    /** Looks up a view's summary by id, or `undefined` if unregistered. */
    get: (id: string) => RegisteredViewSummary | undefined;
    /**
     * Checks `input` against the input budget and the view's schema (if any),
     * builds its composition, and validates the result. Throws
     * {@link RegisteredViewInputError} on refused or invalid input, or {@link IsomerError}
     * (`UNKNOWN_VIEW`) if `id` is unregistered.
     */
    request: (id: string, context: THostContext, input?: ViewInput) => Promise<ViewResponse<TNode>>;
}
/**
 * Builds a {@link RegisteredView}, defaulting `description` to `title`.
 *
 * Declaring a Zod `input` lets TypeScript infer `build`'s `input` type from
 * the schema, so the two cannot disagree.
 */
export declare const defineView: <THostContext = unknown, TInput = ViewInput, TNode extends PrimitiveNode = PrimitiveNode>(options: DefineViewOptions<THostContext, TInput, TNode>) => RegisteredView<THostContext, TInput, TNode>;
/**
 * Creates a {@link ViewRegistry} that validates built compositions with
 * `validateComposition`.
 */
export declare const createViewRegistry: <THostContext = unknown, TNode extends PrimitiveNode = PrimitiveNode>(validateComposition: (composition: Composition<TNode>) => CheckedValidationResult<TNode>, { inputBudget }?: {
    inputBudget?: InputBudget;
}) => ViewRegistry<THostContext, TNode>;
