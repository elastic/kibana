import { type PrimitiveConformanceHarness } from '@elastic/isomer-sdk/testing';
import type { IsomerRuntime } from '../assemble';
/**
 * Derives every {@link PrimitiveConformanceHarness} member `runtime` can
 * answer. The `snapshot` members are present only when the runtime has a
 * frame. `overrides` replace derived members and add what a runtime cannot
 * know: `nestForeignChild`, `sizesFromNodeHeights`, `estimateSnapshotHeight`,
 * `assertVarRefsHaveDeclarations`, or a `wrapComposition` that frames its node.
 *
 * `renderHTML` forwards `css` and `anchors` but not `names`, which no runtime
 * option carries.
 */
export declare const createRuntimeConformanceHarness: (runtime: IsomerRuntime, overrides?: Partial<PrimitiveConformanceHarness>) => PrimitiveConformanceHarness;
