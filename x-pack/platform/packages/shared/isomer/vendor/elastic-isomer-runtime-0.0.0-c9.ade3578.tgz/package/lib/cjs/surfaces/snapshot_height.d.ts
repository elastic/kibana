import { type AnyPrimitiveDefinition } from '@elastic/isomer-sdk';
/** A node this `snapshot` render measured as 0 because its primitive declares no `metrics.snapshotHeight`. */
export interface SnapshotHeightWarning {
    /** Path of the node within the composition, or `pages[n].…` on `renderPages`. */
    path: string;
    /** Safe to show a user. */
    message: string;
}
/**
 * Nodes in `body` that are visible on `snapshot` and declare no `metrics.snapshotHeight`.
 *
 * `prefix` is prepended to each path (`pages[0]` on a paged render, empty for
 * one composition). A node hidden from `snapshot` is skipped with its children.
 */
export declare const collectSnapshotHeightWarnings: (definitions: readonly AnyPrimitiveDefinition[], body: readonly unknown[], prefix: string) => readonly SnapshotHeightWarning[];
