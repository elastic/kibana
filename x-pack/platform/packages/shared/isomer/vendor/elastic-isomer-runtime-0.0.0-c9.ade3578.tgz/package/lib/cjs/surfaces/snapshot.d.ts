import { type ReactNode } from 'react';
import { type BoundFrame, type CheckedValidationResult, type Composition, type FrameSizing, type PrimitiveDispatcher, type PrimitiveNode, type PrimitiveStyleCollector, type RenderTheme, type ValidationErrorMode } from '@elastic/isomer-sdk';
import { type HTMLStyleAdapter } from '@elastic/isomer-sdk/html';
import type { RuntimePackTypes } from '../pack_types';
import { type SnapshotHeightWarning } from './snapshot_height';
export type { SnapshotHeightWarning };
/** Options for {@link SnapshotSurface.render} and {@link SnapshotSurface.renderPages}. */
export interface SnapshotRenderOptions {
    /** Which of the runtime's frames this render uses; defaults to its `defaultFrame`. */
    frame?: string;
    /** Overrides the frame's `defaultWidth`. */
    width?: number;
    /** Overrides the frame's estimated height, and its `sizing`: the result's `heightMode` is `fixed`. */
    height?: number;
    /** Theme mode; falls back to the composition's own `theme`. `auto` resolves light. */
    theme?: RenderTheme;
    /** Defaults to `'throw'`: an image is all or nothing. `'collect'` renders anyway. */
    onValidationError?: ValidationErrorMode;
    /** Renders node anchors, e.g. so `checkLayout` can pair a measured layout with its nodes. */
    anchors?: boolean;
}
/**
 * Options for {@link SnapshotSurface.renderNode}.
 *
 * Geometry is absent deliberately: one node is drawn with no surround, so there
 * is nothing for a width or a height to size.
 */
export type SnapshotRenderNodeOptions = Pick<SnapshotRenderOptions, 'frame' | 'theme' | 'anchors' | 'onValidationError'>;
/** One drawn page, as a React tree and as the static markup of that same tree. */
export interface SnapshotPage {
    /** A single root element, as image layout requires. */
    element: ReactNode;
    /** `element` rendered to static markup, for a backend that takes HTML. */
    html: string;
}
/**
 * A page and the stylesheet it is laid out against.
 *
 * Both are needed together: the page carries class names, and a rasterizer is
 * given `css` the way a browser is given a `<style>`. Everything but `element`
 * is plain data, so a host can cache it or rasterize it in another process.
 */
export interface SnapshotRenderResult extends SnapshotPage {
    /** The pack's CSS, with `light-dark(…)` already resolved to this render's scheme. */
    css: string;
    width: number;
    /** The frame's estimate, or the caller's `height`. Under `heightMode: 'content'`, a backend measures instead. */
    height: number;
    /**
     * `content` when the frame's `sizing` is `content` and no `height` was
     * given: `height` is an estimate, and an image backend sizes the output to
     * the laid-out root. `fixed` otherwise.
     */
    heightMode: FrameSizing;
    /**
     * Nodes this render measured as 0. Empty when `estimateHeight` never calls
     * `estimateSnapshotHeight`, when `height` is given, or when the frame sizes
     * to content.
     */
    warnings: readonly SnapshotHeightWarning[];
}
/** Several compositions laid out against one stylesheet, one page each, as a paged document needs. */
export interface SnapshotPagesResult {
    /** One page per composition, in order. */
    pages: readonly SnapshotPage[];
    /** The pack's CSS for every page, with `light-dark(…)` resolved to the document's scheme. */
    css: string;
    /** Every page's width. */
    width: number;
    /** Every page's height: the tallest estimate, or the caller's `height`. */
    height: number;
    /**
     * As on {@link SnapshotRenderResult}. Under `content` a backend measures
     * every page and sizes them all to the tallest.
     */
    heightMode: FrameSizing;
    /**
     * Nodes measured as 0, paths prefixed `pages[n].`. Empty when `height` is
     * given, when `estimateHeight` never calls `estimateSnapshotHeight`, or when
     * the frame sizes to content.
     */
    warnings: readonly SnapshotHeightWarning[];
}
/**
 * Renders a composition or node once, inside a frame, at a fixed size and one
 * color scheme: the same React tree the DOM gets, its markup, and the pack's
 * stylesheet.
 *
 * Rasterizing a snapshot to PNG, SVG, or PDF is a separate capability a host
 * opts into.
 */
export interface SnapshotSurface {
    /** Always `true`: this surface validates the composition and renders the copy it checked, never the caller's value. */
    readonly validating: true;
    /** Renders a full composition inside the chosen frame. */
    render(composition: Composition, options?: SnapshotRenderOptions): SnapshotRenderResult;
    /**
     * Renders several compositions under one frame with one stylesheet, one
     * page each. Every page is the same size, the tallest estimate unless
     * `height` is given (under a `content` frame, the tallest laid-out page,
     * which the backend measures), and the first composition's `theme` decides
     * the palette unless `theme` is given. `warnings` names nodes that estimate
     * measured as 0, under `pages[n].`.
     *
     * Throws `EMPTY_PAGES` for an empty list, and validates each composition in
     * order as {@link SnapshotSurface.render} does.
     */
    renderPages(compositions: readonly Composition[], options?: SnapshotRenderOptions): SnapshotPagesResult;
    /**
     * Renders a single primitive node with no surround. The result's `width` is
     * the frame's `defaultWidth`, its `height` the frame's estimate for a
     * one-node body, and its `heightMode` the frame's `sizing`.
     */
    renderNode(node: PrimitiveNode, options?: SnapshotRenderNodeOptions): SnapshotRenderResult;
}
/**
 * A frame together with the name the host registered it under.
 */
export interface NamedFrame {
    readonly name: string;
    readonly frame: BoundFrame;
}
/**
 * Creates the `snapshot` {@link RuntimeSurfaces} entry.
 *
 * Built only when a host supplies a frame: unlike the other five surfaces, a
 * snapshot cannot fall back to a generic envelope, because a frame is a
 * whole-document decision.
 */
export declare const createSnapshotSurface: <TRenderContext = unknown>(dispatcher: PrimitiveDispatcher<PrimitiveNode, RuntimePackTypes<TRenderContext>>, validate: (composition: Composition) => CheckedValidationResult, frameFor: (name: string | undefined) => NamedFrame, styleAdapter: HTMLStyleAdapter<PrimitiveNode, PrimitiveStyleCollector, TRenderContext> | undefined) => SnapshotSurface;
