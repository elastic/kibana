import type { ReactNode } from 'react';
import { type PrimitiveNode, type PrimitivePack, type SurfaceMap } from '@elastic/isomer-sdk';
import type { RuntimePackTypes } from '../pack_types';
/** The env bags as the runtime holds them: context erased along with the rest. */
type ErasedSurfaceMap = SurfaceMap<RuntimePackTypes<unknown>>;
/**
 * Renderer signatures an override may replace, as the runtime holds them:
 * heterogeneous node union, theme and context erased.
 *
 * Declared method-style so parameters are checked bivariantly: a host may write
 * an override against its own node type (`(node: TableNode) => …`) rather than
 * widening to `PrimitiveNode`.
 */
interface OverridableRenderers {
    react(node: PrimitiveNode, env: ErasedSurfaceMap['react']['env']): ReactNode;
    text(node: PrimitiveNode, env: ErasedSurfaceMap['text']['env']): string;
    markdown(node: PrimitiveNode, env: ErasedSurfaceMap['markdown']['env']): ErasedSurfaceMap['markdown']['output'];
    slack(node: PrimitiveNode, env: ErasedSurfaceMap['slack']['env']): ErasedSurfaceMap['slack']['output'];
}
/**
 * Per-primitive-type renderer replacements, keyed by primitive `type`.
 *
 * `applyRendererOverrides` already checks that the type and the surface key
 * are real; this closes the value side.
 */
export type RuntimeRendererOverrides = Readonly<Record<string, Partial<OverridableRenderers>>>;
/**
 * Returns `packs` with any matching entries in `overrides` merged into their
 * primitives' `renderers`. Throws if `overrides` targets a primitive type or a
 * surface key that no pack registers.
 *
 * Assumes the runtime's construction guards have already run.
 */
export declare const applyRendererOverrides: <TTheme>(packs: readonly PrimitivePack<TTheme>[], overrides: RuntimeRendererOverrides | undefined) => readonly PrimitivePack<TTheme>[];
export {};
