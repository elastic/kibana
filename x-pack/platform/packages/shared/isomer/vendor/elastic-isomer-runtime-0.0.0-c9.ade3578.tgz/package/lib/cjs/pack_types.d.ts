import type { PackTypes, PrimitiveRenderContext, PrimitiveStyleCollector } from '@elastic/isomer-sdk';
import type { SlackAssetCollector, SlackBlock } from '@elastic/isomer-sdk/slack';
/**
 * The pack types a runtime dispatches with: the host's render context, Block
 * Kit for Slack, and everything else erased, because one inventory serves
 * every pack.
 */
export interface RuntimePackTypes<TRenderContext = PrimitiveRenderContext> extends PackTypes {
    theme: unknown;
    context: TRenderContext;
    collector: PrimitiveStyleCollector;
    slackBlock: SlackBlock;
    slackCollector: SlackAssetCollector;
}
