import { type PrimitiveNode, type PrimitivePack, type PrimitiveStyleCollector } from '@elastic/isomer-sdk';
import type { HTMLStyleAdapter } from '../surfaces';
type ResolvedAdapter<TRenderContext> = HTMLStyleAdapter<PrimitiveNode, PrimitiveStyleCollector, TRenderContext>;
/** The adapter the HTML and `snapshot` surfaces run, and the packs whose renderers resolve through it. */
export interface RuntimeStyling<TTheme, TRenderContext> {
    readonly adapter: ResolvedAdapter<TRenderContext> | undefined;
    readonly packs: readonly PrimitivePack<TTheme>[];
}
/**
 * The host's adapter if it supplied one, otherwise the packs' own.
 *
 * Two or more pack adapters compose: each collects and styles its own pack's
 * nodes, and a pack without one resolves through the first that has one.
 */
export declare const resolveStyling: <TTheme, TRenderContext>(packs: readonly PrimitivePack<TTheme>[], hostAdapter: ResolvedAdapter<TRenderContext> | undefined) => RuntimeStyling<TTheme, TRenderContext>;
export {};
