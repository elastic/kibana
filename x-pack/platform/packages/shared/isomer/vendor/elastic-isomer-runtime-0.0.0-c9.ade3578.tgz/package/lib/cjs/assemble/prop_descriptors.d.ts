import type { JsonSchema } from '../registry';
/** One property of a primitive, flattened from the authoring JSON Schema. */
export interface PropDescriptor {
    name: string;
    /** Display form, e.g. `string`, `tone`, `primary | warning`, `string[]`. */
    type: string;
    kind: 'string' | 'number' | 'boolean' | 'enum' | 'array' | 'object' | 'other';
    /** Allowed values when `kind` is `enum`. */
    values?: readonly string[];
    required: boolean;
    description?: string;
}
/** A {@link PropDescriptor} list per type, read from `schema`'s `$defs`; empty for a type with no object properties. */
export declare const describeProps: (schema: JsonSchema, types: readonly string[]) => Record<string, PropDescriptor[]>;
