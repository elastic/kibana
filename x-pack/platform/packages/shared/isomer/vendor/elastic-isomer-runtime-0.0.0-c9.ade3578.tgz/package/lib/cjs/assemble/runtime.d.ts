import { type AnyPrimitiveDefinition, type CheckedValidationResult, type Composition, type EnhancementDefinition, type Frame, type InputBudget, type ParsedComposition, type PrimitiveNode, type PrimitivePack, type PrimitiveRenderContext, type PrimitiveStyleCollector } from '@elastic/isomer-sdk';
import type { ZodObject } from 'zod';
import { type RegisteredView, type ViewRegistry } from '../registry';
import { type HTMLStyleAdapter, type HtmlSurface, type MarkdownSurface, type ReactSurface, type SlackSurface, type SnapshotSurface, type TextSurface } from '../surfaces';
import { type HostCapabilities, type RuntimeAuthoringContext, type RuntimeAuthoringOptions } from './authoring';
import { type RuntimeRendererOverrides } from './overrides';
/** The frames a runtime can draw with, keyed by the name a render asks for. */
export type FrameMap<TTheme> = Readonly<Record<string, Frame<TTheme>>>;
/**
 * Options for {@link createIsomerRuntime}.
 *
 * `THostContext` is what the host passes to `viewRegistry.request` and a view's
 * `build` receives. `TRenderContext` is what a pack's `react` renderers
 * receive. `TTheme` is the palette every pack and frame agree on.
 */
export interface IsomerRuntimeOptions<THostContext = unknown, TRenderContext = PrimitiveRenderContext, TTheme = never> {
    /**
     * Primitive packs this runtime dispatches, validates, and renders.
     *
     * Purely additive: a pack is a vocabulary, so composing two of them composes
     * their node types and nothing else. What a composition is framed as comes
     * from {@link IsomerRuntimeOptions.frames} instead.
     */
    packs: readonly PrimitivePack<TTheme>[];
    /**
     * The documents the `snapshot` surface can draw, keyed by the name a render asks
     * for. Omit it and `surfaces.snapshot` is `undefined`. `TTheme` is inferred from
     * `packs` first, so a palette mismatch is reported against this field.
     */
    frames?: FrameMap<TTheme>;
    /** Frame used when a render names none; defaults to the sole entry. */
    defaultFrame?: string;
    /**
     * Formats the host ships beyond the runtime's own, reported by
     * `getCapabilities`: a rasterizer's, e.g. a takumi backend's `formats`.
     */
    formats?: readonly string[];
    /** Views to pre-register on the runtime's view registry. */
    views?: readonly RegisteredView<THostContext, unknown, PrimitiveNode>[];
    /** Per-primitive-type renderer replacements. */
    rendererOverrides?: RuntimeRendererOverrides;
    /**
     * The HTML surface's CSS and class-name strategy.
     *
     * Defaults to the packs' own adapters: each styles its own pack's nodes, and
     * a pack without one is styled by the first pack that has one. Passing this
     * replaces them all, such as a no-op when a CSS-bearing pack should emit no
     * CSS.
     *
     * Required when any pack declares `collectStyles` and no pack (or this
     * option) supplies an adapter.
     */
    styleAdapter?: HTMLStyleAdapter<PrimitiveNode, PrimitiveStyleCollector, TRenderContext>;
    /**
     * Fallback `aria-label` for the `html` wrapper, and the `react` one when
     * `wrapper` is set, when the composition has neither `meta.ariaLabel` nor a
     * `title`. Defaults to `'View'`.
     */
    defaultAriaLabel?: string;
    /** Options for the authoring schema and declarations `getAuthoringContext` returns. */
    authoring?: RuntimeAuthoringOptions;
    /**
     * Limits `checkInputBudget` applies in `parse`, `validate`, view input, and
     * every surface but `react`, which does not validate. Each limit set here
     * replaces the packs' budget: per limit, the largest any pack declares, and
     * never less than the SDK's default.
     */
    inputBudget?: InputBudget;
}
/**
 * One namespace per output format; each exposes `render` and `renderNode`
 * uniformly. `TSnapshot` is `SnapshotSurface` when the runtime was built with `frames`
 * and `undefined` when it was not; a runtime whose options are not statically
 * known carries the union. Every key but `html` is a `SurfaceName`; `html`
 * wraps the `react` output in a document and no node targets it.
 */
export interface RuntimeSurfaces<TRenderContext = PrimitiveRenderContext, TSnapshot extends SnapshotSurface | undefined = SnapshotSurface | undefined> {
    react: ReactSurface<TRenderContext>;
    html: HtmlSurface;
    text: TextSurface;
    markdown: MarkdownSurface;
    slack: SlackSurface;
    /** A fixed-size render inside a frame, or `undefined` when the host supplied no frame. */
    snapshot: TSnapshot;
}
/**
 * What {@link createIsomerRuntime} returns: the composed packs, one validator
 * and parser over their inventory, a view registry, one render surface per
 * format, and the authoring material an agent is handed.
 */
export interface IsomerRuntime<THostContext = unknown, TRenderContext = PrimitiveRenderContext, TTheme = never, TSnapshot extends SnapshotSurface | undefined = SnapshotSurface | undefined> {
    /**
     * The packs this runtime was built from, with renderer overrides applied.
     * `TTheme` defaults to `never` so a bare `IsomerRuntime` annotation accepts
     * a runtime built around any palette.
     */
    readonly packs: readonly PrimitivePack<TTheme>[];
    /** Every pack's definitions, flattened — the dispatcher's inventory. */
    readonly primitives: readonly AnyPrimitiveDefinition[];
    /** Every pack's enhancements, flattened — what `enhancements` render options resolve against. */
    readonly enhancements: readonly EnhancementDefinition[];
    /** Product-owned views, requested by id; the `views` option pre-registers. */
    readonly viewRegistry: ViewRegistry<THostContext, PrimitiveNode>;
    /** One render surface per output format; `snapshot` is `undefined` without `frames`. */
    readonly surfaces: RuntimeSurfaces<TRenderContext, TSnapshot>;
    /** Builds fresh authoring material (schema, declarations, catalog, views) for this runtime. */
    getAuthoringContext(): RuntimeAuthoringContext;
    /** Reports the primitive types, surfaces, and formats this runtime supports. */
    getCapabilities(): HostCapabilities;
    /**
     * Validates a composition against this runtime's primitives: the input
     * budget, the schema, then the semantic passes. `composition` on the result
     * is the plain copy it checked, which every validating surface renders.
     */
    validate(composition: Composition): CheckedValidationResult;
    /**
     * Parses an unknown value as a `Composition`: the input budget and the
     * schema, not the semantic passes `validate` runs.
     */
    parse(value: unknown): ParsedComposition;
    /**
     * This runtime's `Composition` schema — the same instance `validate`/`parse`
     * use internally, memoized per definitions-array identity.
     */
    getCompositionSchema(): ZodObject;
}
/**
 * Builds an {@link IsomerRuntime} from primitive packs: a dispatcher,
 * composition validator/parser, view registry, and one render surface per
 * format. Passing `frames` is what makes `surfaces.snapshot` present, and the
 * signature says so: with `frames` it is `SnapshotSurface`, without it is
 * `undefined`, and a call whose options are not a literal gets the union.
 */
export interface CreateIsomerRuntime {
    <THostContext = unknown, TRenderContext = PrimitiveRenderContext, TTheme = never>(options: IsomerRuntimeOptions<THostContext, TRenderContext, TTheme> & {
        frames: FrameMap<TTheme>;
    }): IsomerRuntime<THostContext, TRenderContext, TTheme, SnapshotSurface>;
    <THostContext = unknown, TRenderContext = PrimitiveRenderContext, TTheme = never>(options: IsomerRuntimeOptions<THostContext, TRenderContext, TTheme> & {
        frames?: undefined;
    }): IsomerRuntime<THostContext, TRenderContext, TTheme, undefined>;
    <THostContext = unknown, TRenderContext = PrimitiveRenderContext, TTheme = never>(options: IsomerRuntimeOptions<THostContext, TRenderContext, TTheme>): IsomerRuntime<THostContext, TRenderContext, TTheme>;
}
export declare const createIsomerRuntime: CreateIsomerRuntime;
