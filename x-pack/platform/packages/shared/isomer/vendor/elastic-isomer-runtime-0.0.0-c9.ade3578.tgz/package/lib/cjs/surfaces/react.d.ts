import { type ReactNode } from 'react';
import { type Composition, type EnhancementDefinition, type PrimitiveDispatcher, type PrimitiveNode, type PrimitiveRenderContext, type ReactContextArg } from '@elastic/isomer-sdk';
import { type CompositionWrapperOptions } from '@elastic/isomer-sdk/react';
import type { RuntimePackTypes } from '../pack_types';
export type { ReactContextArg };
/** Options for {@link ReactSurface.render} and, without `heading`, {@link ReactSurface.renderNode}. */
export type ReactRenderOptions<TRenderContext = PrimitiveRenderContext> = {
    /** Renders the leading `h2` / `p.sub`. Defaults to `true`. */
    heading?: boolean;
    /**
     * Wraps the content in the `.isomer[.framed][.fluid]` `section` the `html`
     * surface emits. `true` takes the defaults; an object sets `framed`,
     * `fluid`, `theme`, and `defaultAriaLabel`. Absent means bare content.
     */
    wrapper?: boolean | CompositionWrapperOptions;
    /**
     * Ids of the packs' enhancements to render with, as on the `html` surface:
     * those that apply reach every renderer as `context.enhancements`, turn node
     * anchors on when one asks, and run their `script` against the `wrapper`
     * section once it mounts. An id no pack registers is ignored. A new
     * composition or node object mounts a fresh section, so keep it stable
     * across re-renders. A `script` needs `wrapper`.
     */
    enhancements?: readonly string[];
} & (Record<string, never> extends TRenderContext ? {
    context?: TRenderContext;
} : {
    context: TRenderContext;
});
/** Options for {@link ReactSurface.renderNode}: a lone node has no heading to draw. */
export type ReactRenderNodeOptions<TRenderContext = PrimitiveRenderContext> = Omit<ReactRenderOptions<TRenderContext>, 'heading'>;
/**
 * The options argument, optional only when omitting it is sound: a pack that
 * narrows the render context with a required member makes it mandatory.
 */
export type ReactRenderArgs<TRenderContext, TOptions extends ReactRenderNodeOptions<TRenderContext> = ReactRenderOptions<TRenderContext>> = Record<string, never> extends TRenderContext ? [options?: TOptions] : [options: TOptions];
/**
 * Renders a composition or node to a React tree.
 *
 * The one non-validating surface, deliberately. React is the interactive
 * target, where a partial render beats a thrown error. It renders the value it
 * is given, reading it as it draws; a host that wants the other behaviour
 * calls `validate` itself and renders the result's `composition`.
 */
export interface ReactSurface<TRenderContext = PrimitiveRenderContext> {
    /** Always `false`: see the note above. */
    readonly validating: false;
    /** Renders a full composition to a React tree, bare unless `wrapper` is set. */
    render(composition: Composition, ...args: ReactRenderArgs<TRenderContext>): ReactNode;
    /** Renders a single primitive node to a React tree; a lone node has no heading to draw. */
    renderNode(node: PrimitiveNode, ...args: ReactRenderArgs<TRenderContext, ReactRenderNodeOptions<TRenderContext>>): ReactNode;
}
/**
 * Creates the `react` {@link RuntimeSurfaces} entry.
 *
 * @param enhancementDefinitions What `enhancements` ids resolve against.
 * @param defaultAriaLabel The `wrapper` fallback when the composition has
 * neither `meta.ariaLabel` nor a `title`; a `wrapper` object may override it.
 */
export declare const createReactSurface: <TRenderContext = PrimitiveRenderContext>(dispatcher: PrimitiveDispatcher<PrimitiveNode, RuntimePackTypes<TRenderContext>>, enhancementDefinitions?: readonly EnhancementDefinition[], defaultAriaLabel?: string) => ReactSurface<TRenderContext>;
