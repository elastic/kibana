import type { CheckedValidationResult, Composition, PrimitiveDispatcher, PrimitiveNode, PrimitiveRenderContext, PrimitiveStyleCollector } from '@elastic/isomer-sdk';
import { type EnhancementDefinition, type HTMLRenderOptions, type HTMLRenderResult, type HTMLStyleAdapter } from '@elastic/isomer-sdk/html';
import type { RuntimePackTypes } from '../pack_types';
export type { HTMLRenderOptions, HTMLRenderResult, HTMLStyleAdapter };
/** Renders a composition or node to an HTML document/fragment string. */
export interface HtmlSurface {
    /** Always `true`: this surface validates the composition and renders the copy it checked, never the caller's value. */
    readonly validating: true;
    /** Renders a full composition to an HTML document/fragment. */
    render(composition: Composition, options?: HTMLRenderOptions): HTMLRenderResult;
    /** Renders a single primitive node to HTML. */
    renderNode(node: PrimitiveNode, options?: HTMLRenderOptions): HTMLRenderResult;
}
/**
 * Creates the `html` {@link RuntimeSurfaces} entry.
 *
 * @param defaultAriaLabel Used only when the composition has neither
 * `meta.ariaLabel` nor a `title`.
 */
export declare const createHtmlSurface: <TRenderContext = PrimitiveRenderContext>(dispatcher: PrimitiveDispatcher<PrimitiveNode, RuntimePackTypes<TRenderContext>>, validate: (composition: Composition) => CheckedValidationResult, styleAdapter: HTMLStyleAdapter<PrimitiveNode, PrimitiveStyleCollector, TRenderContext> | undefined, enhancementDefinitions?: readonly EnhancementDefinition[], defaultAriaLabel?: string) => HtmlSurface;
