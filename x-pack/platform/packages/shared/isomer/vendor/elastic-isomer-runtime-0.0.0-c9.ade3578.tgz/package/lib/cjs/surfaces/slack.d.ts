import type { CheckedValidationResult, Composition, PrimitiveNode, ValidationErrorMode } from '@elastic/isomer-sdk';
import { type SlackEnvelopeDispatcher, type SlackEnvelopeOptions, type SlackEnvelopeResult } from '@elastic/isomer-sdk/slack';
/** {@link SlackEnvelopeOptions} plus the surface's validation posture. */
export interface SlackRenderOptions extends SlackEnvelopeOptions {
    /** Defaults to `'throw'`: a payload about to be posted carries no findings. `'collect'` renders anyway. */
    onValidationError?: ValidationErrorMode;
}
/** Options for {@link SlackSurface.renderNode}: {@link SlackRenderOptions} without a heading, which a lone node lacks. */
export type SlackRenderNodeOptions = Omit<SlackRenderOptions, 'heading'>;
/** What `render` and `renderNode` return: fallback `text`, `blocks` fitted to Slack's limits, and the `assets` the host uploads first. */
export type SlackRenderResult = SlackEnvelopeResult;
/** Renders a composition or node to Slack Block Kit blocks. */
export interface SlackSurface {
    /** Always `true`: this surface validates the composition and renders the copy it checked, never the caller's value. */
    readonly validating: true;
    /** Renders a full composition to a Slack message (blocks, fallback text, assets). */
    render(composition: Composition, options?: SlackRenderOptions): SlackRenderResult;
    /**
     * Renders a single primitive node as a Slack message of its own: the same
     * `{ text, blocks, assets }` as `render`, so a picture node reaches the host
     * as an upload request when `collectAssets` is set.
     */
    renderNode(node: PrimitiveNode, options?: SlackRenderNodeOptions): SlackRenderResult;
}
/** Creates the `slack` {@link RuntimeSurfaces} entry. */
export declare const createSlackSurface: (dispatcher: SlackEnvelopeDispatcher<PrimitiveNode>, validate: (composition: Composition) => CheckedValidationResult) => SlackSurface;
