import type { SceneTimeBand, SceneTimeTicks } from './types';
/** What {@link resolveTimeTicks} takes: the time domain and bucket Elastic Charts computes, and where labels print. */
export interface TimeTicksInput {
    /** The domain's first and last x, epoch milliseconds, before any bucket extension. */
    readonly min: number;
    readonly max: number;
    /** The bucket width, milliseconds: Elastic Charts' `minInterval`. */
    readonly interval: number;
    /** Bars fill each bucket, so the domain runs one bucket past `max`. */
    readonly extend: boolean;
    readonly locale: string;
    readonly timeZone: string;
    /** The widest plot the axis can be drawn at; bands for wider ones are left out. */
    readonly maxWidth?: number;
}
/**
 * The two-row time axis Elastic Charts draws for a domain and bucket, at every
 * plot width: one band per change in the rasters it picks.
 */
export declare const resolveTimeTicks: ({ min, max, interval, extend, locale, timeZone, maxWidth, }: TimeTicksInput) => SceneTimeTicks;
/** The band of `ticks` drawn at a plot `width` in CSS pixels: the last whose `from` it reaches. */
export declare const timeTicksAt: (ticks: SceneTimeTicks, width: number) => SceneTimeBand;
