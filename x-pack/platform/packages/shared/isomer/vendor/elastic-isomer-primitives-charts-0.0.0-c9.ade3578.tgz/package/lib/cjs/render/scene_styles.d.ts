export declare const sceneModule: {
    handles: {
        sized: import("@elastic/distillate").StyleHandle;
        link: import("@elastic/distillate").StyleHandle;
    };
    vars: {
        size: import("@elastic/distillate").LocalVarGroup<"maxWidth" | "aspectRatio" | "minHeight">;
        chrome: import("@elastic/distillate").LocalVarGroup<"fill" | "ink">;
    };
    stylesheet: () => string;
};
