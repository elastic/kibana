import { type PartialTheme, type Theme } from '@elastic/charts';
import type { ColorScheme, SceneChrome } from '@elastic/isomer-primitives-charts/scene';
/** Kibana's charts theme name for EUI's Borealis theme. */
export declare const KIBANA_THEME_NAME = "borealis";
/** Prepended to every chart font, as Kibana's `applyNumericFontFamily` does. */
export declare const ELASTIC_UI_NUMERIC_FONT_FAMILY = "'Elastic UI Numeric'";
/** Kibana's charts base theme for a scheme. */
export declare const kibanaBaseTheme: (scheme: ColorScheme) => Theme;
/** The Scene's chrome over the base theme: text, axis, grid line and background colors. */
export declare const chromeTheme: (chrome: SceneChrome) => PartialTheme;
