import { type ReactNode } from 'react';
import type { DebugState } from '@elastic/charts';
import { type SvgFont, type SvgTextWidthMeasure } from '@elastic/charts/dist/headless';
import { type Scene, type SceneEnvironment, type SceneRenderer } from '@elastic/isomer-primitives-charts/scene';
/** How {@link renderSceneSvg} draws text. */
export interface HeadlessSvgOptions {
    /** Draws text as this font's glyph outlines, so output is the same wherever it is drawn. */
    readonly font?: SvgFont;
    /** Measures text drawn as SVG `<text>`, when there is no `font`. Absent: Elastic Charts' Helvetica metrics. */
    readonly measureTextWidth?: SvgTextWidthMeasure;
}
/** A Scene drawn by {@link renderSceneSvg}: the SVG markup and its box. */
export interface HeadlessSvg {
    readonly svg: string;
    readonly width: number;
    readonly height: number;
    /** What `<Chart debugState>` reports, when the Elastic Charts build returns it. */
    readonly debugState?: DebugState;
}
/** Draws a `metric`, `xy`, `partition`, `heatmap`, `gauge` or `tagCloud` Scene as SVG at the Scene's `size`; an empty one as its note. */
export declare const renderSceneSvg: (scene: Scene, { font, measureTextWidth }?: HeadlessSvgOptions) => HeadlessSvg;
/** What {@link createElasticChartsHeadlessRenderer} takes: text options and where it runs. */
export interface HeadlessRendererOptions extends HeadlessSvgOptions {
    /**
     * Where the renderer runs. Absent: Node alone. Add `browser` where markup
     * is static, such as a preview of the `html` or `snapshot` surface.
     */
    readonly environments?: readonly SceneEnvironment[];
}
/**
 * Prefixes every id in an SVG and each reference to one. Elastic Charts names
 * its clip paths `clip0`, `clip1`, …, so two charts inline in one page would
 * otherwise clip with each other's paths. Identical drawings share a prefix,
 * and their paths are identical too.
 */
export declare const scopeSvgIds: (svg: string, scope: string) => string;
/**
 * A `SceneRenderer` drawing the chart's SVG inline in a `div`, so static
 * markup, such as the `snapshot` surface's, carries it to takumi. It is
 * `sized`: every Scene it draws carries a size. Register it in the charts
 * pack's `sceneRenderers`, since `snapshot` takes no host context.
 */
export declare const createElasticChartsHeadlessRenderer: ({ environments, ...options }?: HeadlessRendererOptions) => SceneRenderer<ReactNode>;
export { elasticChartsStylesheet } from './styles';
