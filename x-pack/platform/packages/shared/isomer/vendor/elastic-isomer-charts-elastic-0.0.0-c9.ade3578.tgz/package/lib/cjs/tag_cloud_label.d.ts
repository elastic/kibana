/** The label under a tag cloud, as Kibana's tag cloud draws it: EUI's `s` text, bold, on one line. */
export declare const TAG_CLOUD_LABEL: {
    /** In pixels. */
    readonly size: 14;
    /** In pixels: the cloud draws in the height above it. */
    readonly lineHeight: 20;
    /** EUI's bold. */
    readonly weight: 700;
};
