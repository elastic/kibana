import { type ReactNode } from 'react';
import { type SceneRenderer } from '@elastic/isomer-primitives-charts/scene';
import type { ElasticChartsOptions } from './options';
/** The Elastic Charts release this engine is built and tested against: Kibana's pin. */
export declare const ELASTIC_CHARTS_VERSION = "73.3.2";
/**
 * A `SceneRenderer` drawing Scenes with Elastic Charts, in the browser. The
 * page needs Elastic Charts' stylesheet for the Scene's scheme
 * (`@elastic/charts/dist/theme_light.css` or `theme_dark.css`); Kibana loads it.
 */
export declare const createElasticChartsRenderer: (options?: ElasticChartsOptions) => SceneRenderer<ReactNode>;
