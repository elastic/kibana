import type { Scene } from '@elastic/isomer-primitives-charts/scene';
/** The Scene's summary, then its authored description. */
export declare const ariaDescriptionOf: ({ summary, description }: Scene) => string;
