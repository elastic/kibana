export interface ElasticChartsOptions {
    /** Writes Elastic Charts' `DebugState` to the chart, as Kibana's functional tests read it. */
    readonly debugState?: boolean;
}
