import { type HeatmapScene, type MetricScene, type PartitionScene, type SceneRenderEnv, type TagCloudScene, type XyCategory, type XyMark, type XyScene, type XySeries } from '@elastic/isomer-primitives-charts/scene';
/** What each datum this engine passes Elastic Charts carries, so a hit names its mark. */
export interface XyDatum {
    readonly x: number | string;
    readonly y: number | null;
    /** The series' index in {@link seriesOf}. */
    readonly series: number;
    /** The mark's index in its series' `marks`. */
    readonly mark: number;
}
/** Whether an Elastic Charts datum is one this engine passed it. */
export declare const isXyDatum: (value: unknown) => value is XyDatum;
/** The Scene's series, in draw order, without its reference lines and annotations. */
export declare const seriesOf: (scene: XyScene) => readonly XySeries[];
/** The Scene mark an Elastic Charts geometry value was drawn from. */
export declare const markOf: (scene: XyScene, datum: unknown) => XyMark | undefined;
/** The category at `x`: the position itself on an ordinal axis, else the last at or before it. */
export declare const categoryAt: (scene: XyScene, x: unknown) => XyCategory | undefined;
/** The handlers this engine passes Elastic Charts for an xy Scene; empty when the chart offers nothing. */
export declare const xyHandlers: (scene: XyScene, env: SceneRenderEnv) => {
    onBrushEnd?: (area: {
        x?: unknown;
    }) => void;
    onProjectionClick?: ({ x }: {
        x: unknown;
        y?: unknown;
    }) => void;
    onElementClick?: (elements: readonly unknown[]) => void;
};
/** Raises the `legend` selection of `series`' legend item. */
export declare const legendSelect: (scene: XyScene, env: SceneRenderEnv, { key, series: { layer, y } }: XySeries, negate: boolean) => void;
/** The handlers this engine passes Elastic Charts for a metric Scene; empty when the chart offers nothing. */
export declare const metricHandlers: (scene: MetricScene, env: SceneRenderEnv) => {
    onElementClick?: never;
} | {
    onElementClick: (elements: readonly unknown[]) => void;
};
/** The handlers this engine passes Elastic Charts for a partition Scene; empty when the chart offers nothing. */
export declare const partitionHandlers: (scene: PartitionScene, env: SceneRenderEnv) => {
    onElementClick?: never;
} | {
    /** The innermost slice of the first element: the one the reader hit, as Kibana's partition click takes it. */
    onElementClick: (elements: readonly unknown[]) => void;
};
/** Raises the `slice` selection of the legend item for the slice `key` names. */
export declare const partitionLegendSelect: (scene: PartitionScene, env: SceneRenderEnv, key: string, negate: boolean) => void;
/** The handlers this engine passes Elastic Charts for a heatmap Scene; empty when the chart offers nothing. */
export declare const heatmapHandlers: (scene: HeatmapScene, env: SceneRenderEnv) => {
    onBrushEnd?: (area: {
        x?: unknown;
    }) => void;
    onElementClick?: (elements: readonly unknown[]) => void;
};
/** The handlers this engine passes Elastic Charts for a tag cloud Scene; empty when the chart offers nothing. */
export declare const tagCloudHandlers: (scene: TagCloudScene, env: SceneRenderEnv) => {
    onElementClick?: never;
} | {
    /** The word Elastic Charts reports: its datum names the Scene word. */
    onElementClick: (elements: readonly unknown[]) => void;
};
