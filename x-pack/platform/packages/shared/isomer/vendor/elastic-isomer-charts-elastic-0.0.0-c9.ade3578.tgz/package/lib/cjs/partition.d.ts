import type { ReactNode } from 'react';
import { type CustomTooltip, type PartialTheme } from '@elastic/charts';
import { type PartitionNode, type PartitionScene, type SceneRenderEnv } from '@elastic/isomer-primitives-charts/scene';
import type { ElasticChartsOptions } from './options';
/** What each datum this engine passes Elastic Charts carries: one Scene leaf. */
export interface PartitionDatum {
    /** The key of each slice on the leaf's path, outermost first. */
    readonly keys: readonly string[];
    readonly value: number;
}
/** Every slice of the Scene, depth first in draw order. */
export declare const slicesOf: (nodes: readonly PartitionNode[]) => readonly PartitionNode[];
/**
 * The Scene's leaves, depth first in draw order: the data Elastic Charts sums.
 * Each weighs its `value`, or its `share` where the values' sum is past
 * `Number.MAX_VALUE`, so Elastic Charts lays slices out in the Scene's
 * proportions either way.
 */
export declare const partitionData: (scene: PartitionScene) => PartitionDatum[];
/** Each slice's sum as Elastic Charts adds it from {@link partitionData}, by key. */
export declare const engineSums: (scene: PartitionScene) => Map<string, number>;
/** The Scene slice an Elastic Charts key names. */
export declare const sliceByKey: (scene: PartitionScene) => ReadonlyMap<string, PartitionNode>;
/**
 * Kibana's `rescaleFactor`: a pie, donut or waffle with slices under 2% of the
 * whole shrinks by 5% for each, at most 20%, to make room for outside labels.
 */
export declare const outerSizeRatio: (scene: PartitionScene) => number;
/** Kibana's partition theme for the Scene: `getPartitionTheme` over the Scene's chrome. */
export declare const partitionTheme: (scene: PartitionScene) => PartialTheme;
/** The hovered slice's tooltip from the Scene: the slice and each it sits in. */
export declare const partitionTooltip: (scene: PartitionScene) => CustomTooltip;
/**
 * The value text Elastic Charts draws. Slice labels ask for it through
 * `valueGetter`, which hands over `-1 - index` of the slice in
 * {@link slicesOf}, so each draws its own `valueLabel`. Legend values ask
 * with the slice's {@link engineSums} sum alone, so a sum two legend items
 * share with different `valueText`s prints none rather than another's.
 */
export declare const partitionValueFormatter: (scene: PartitionScene) => ((value: number) => string);
/** A partition Scene's spec elements, for `<Chart>` or headless drawing; `null` when it is empty. */
export declare const partitionSpecs: (scene: PartitionScene, env: SceneRenderEnv, options: ElasticChartsOptions) => ReactNode;
