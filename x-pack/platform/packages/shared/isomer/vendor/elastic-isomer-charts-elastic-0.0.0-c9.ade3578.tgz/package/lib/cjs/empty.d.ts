import type { Scene } from '@elastic/isomer-primitives-charts/scene';
/** The size of the note an empty chart draws: EUI's `s` text, as Lens's `VisualizationNoResults` sets it. */
export declare const EMPTY_TEXT_SIZE = 14;
/** Its line height, EUI's for `s` text: a note too wide for the chart wraps on these lines. */
export declare const EMPTY_LINE_HEIGHT = 20;
/** The note a Scene with nothing to draw shows instead, as the Scene states it. */
export declare const emptyTextOf: (scene: Scene) => string | undefined;
