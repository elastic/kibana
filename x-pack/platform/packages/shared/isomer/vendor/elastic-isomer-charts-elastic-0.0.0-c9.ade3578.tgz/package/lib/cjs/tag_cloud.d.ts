import type { ReactNode } from 'react';
import { type SceneRenderEnv, type TagCloudScene } from '@elastic/isomer-primitives-charts/scene';
import type { ElasticChartsOptions } from './options';
/** The font Kibana's tag cloud sets its words in. */
export declare const TAG_CLOUD_FONT_FAMILY = "'Elastic UI Numeric', 'Inter UI', sans-serif";
/** What each datum this engine passes Elastic Charts carries: one Scene word. */
export interface TagCloudDatum {
    readonly text: string;
    readonly weight: number;
    readonly color: string;
    /** The word's index in the Scene's `words`. */
    readonly index: number;
}
/** The Scene's words as Elastic Charts' word cloud data, each naming its word. */
export declare const tagCloudData: (scene: TagCloudScene) => TagCloudDatum[];
/** A tag cloud Scene's spec elements, for `<Chart>` or headless drawing; `null` when it is empty. */
export declare const tagCloudSpecs: (scene: TagCloudScene, env: SceneRenderEnv, options: ElasticChartsOptions) => ReactNode;
/** The cloud above its label, in the browser, as Kibana lays them out. */
export declare const TagCloudChart: ({ scene, env, options, }: {
    scene: TagCloudScene;
    env: SceneRenderEnv;
    options: ElasticChartsOptions;
}) => import("react").JSX.Element;
