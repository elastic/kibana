import type { ReactNode } from 'react';
import { type BulletProps } from '@elastic/charts';
import { type GaugeScene, type SceneRenderEnv } from '@elastic/isomer-primitives-charts/scene';
import type { ElasticChartsOptions } from './options';
/**
 * The Scene's bands as Elastic Charts' color bands: their edges as `steps`,
 * one color each, as Kibana passes them. A lone band goes as its color twice,
 * as Kibana passes an uncolored scale, so Elastic Charts draws it in that one
 * color rather than blending a second.
 */
export declare const gaugeColorBands: (scene: GaugeScene) => NonNullable<BulletProps["colorBands"]>;
/** The text Elastic Charts writes for a value on the scale: the Scene's for its value and goal, else `formatAxisValue`. */
export declare const gaugeValueFormatter: (scene: GaugeScene) => (value: number) => string;
/** A gauge Scene's spec elements, for `<Chart>` or headless drawing; `null` when it is empty. */
export declare const gaugeSpecs: (scene: GaugeScene, _env: SceneRenderEnv, options: ElasticChartsOptions) => ReactNode;
