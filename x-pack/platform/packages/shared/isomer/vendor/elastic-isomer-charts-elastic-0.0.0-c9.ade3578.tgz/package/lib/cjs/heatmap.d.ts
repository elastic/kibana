import type { ReactNode } from 'react';
import { type CustomTooltip, type HeatmapBandsColorScale, type PartialTheme } from '@elastic/charts';
import { type HeatmapScene, type SceneRenderEnv } from '@elastic/isomer-primitives-charts/scene';
import type { ElasticChartsOptions } from './options';
/** What each datum this engine passes Elastic Charts carries. */
export interface HeatmapDatum {
    /** The position's instant on a time axis; else its index in `x.categories`. */
    readonly x: number;
    /** The position's index in `y.categories`. */
    readonly y: number;
    /** `null` for a position no cell fills, which Elastic Charts still lays out. */
    readonly value: number | null;
}
/**
 * The data Elastic Charts draws: each Scene cell at its index, then a
 * valueless datum for each position no cell fills, so the axes hold every
 * position the Scene does.
 */
export declare const heatmapData: (scene: HeatmapScene) => HeatmapDatum[];
/** The Scene's bands as Elastic Charts' color scale: an open bound is infinite. */
export declare const heatmapColorScale: (scene: HeatmapScene) => HeatmapBandsColorScale;
/**
 * The text Elastic Charts writes for a value: a cell's `valueText`. It sees
 * only the value, so a value two cells share with different `valueText`s
 * prints none rather than another's.
 */
export declare const heatmapValueFormatter: (scene: HeatmapScene) => ((value: number) => string);
/** A position's label: its category's on an ordinal axis, `formatAxisValue` on a time axis. */
export declare const heatmapXLabel: (scene: HeatmapScene) => ((value: string | number) => string);
/** Kibana's heat map theme for the Scene: grid lines, cell labels and axis labels, padded as Kibana pads an axis with a column. */
export declare const heatmapTheme: (scene: HeatmapScene) => PartialTheme;
/** The hovered cell's tooltip from the Scene: its positions and its value. */
export declare const heatmapTooltip: (scene: HeatmapScene) => CustomTooltip;
/** A heatmap Scene's spec elements, for `<Chart>` or headless drawing; `null` when it is empty. */
export declare const heatmapSpecs: (scene: HeatmapScene, env: SceneRenderEnv, options: ElasticChartsOptions) => ReactNode;
