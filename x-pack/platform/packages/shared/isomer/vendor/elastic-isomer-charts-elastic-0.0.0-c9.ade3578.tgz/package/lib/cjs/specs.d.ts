import type { ReactNode } from 'react';
import type { Scene, SceneRenderEnv } from '@elastic/isomer-primitives-charts/scene';
import type { ElasticChartsOptions } from './options';
/** A metric, xy, partition, heatmap, gauge or tag cloud Scene as Elastic Charts spec elements; `null` for any other kind, or an empty Scene. */
export declare const sceneSpecs: (scene: Scene, env: SceneRenderEnv, options?: ElasticChartsOptions) => ReactNode;
