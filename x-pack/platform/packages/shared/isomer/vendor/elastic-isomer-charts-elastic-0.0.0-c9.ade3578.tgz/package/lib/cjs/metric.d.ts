import { type ReactNode } from 'react';
import { type MetricDatum, type PartialTheme } from '@elastic/charts';
import { type MetricScene, type MetricTile, type SceneRenderEnv } from '@elastic/isomer-primitives-charts/scene';
import type { ElasticChartsOptions } from './options';
/** Where a datum draws, and how its elements resolve their classes. */
type DatumEnv = Pick<SceneRenderEnv, 'environment' | 'resolveClassName'>;
/** The Elastic Charts datum for a tile. Its value prints the Scene's text, whatever Elastic Charts passes. */
export declare const metricDatum: (tile: MetricTile, env?: DatumEnv) => MetricDatum;
/** Tiles in rows of `layout.columns`, as Kibana slices them. */
export declare const metricGrid: (scene: MetricScene, env?: DatumEnv) => (MetricDatum | undefined)[][];
/** The metric overrides Kibana sets on `Settings`, from the Scene's layout and chrome. */
export declare const metricTheme: (scene: MetricScene) => PartialTheme;
/** A metric Scene's spec elements, for `<Chart>` or headless drawing. */
export declare const metricSpecs: (scene: MetricScene, env: SceneRenderEnv, options: ElasticChartsOptions) => ReactNode;
export {};
