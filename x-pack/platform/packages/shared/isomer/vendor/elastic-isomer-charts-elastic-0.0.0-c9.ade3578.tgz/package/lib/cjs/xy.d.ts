import type { ReactNode } from 'react';
import { type CustomTooltip, type PartialTheme } from '@elastic/charts';
import { type SceneAxis, type SceneRenderEnv, type XyScene, type XySeries } from '@elastic/isomer-primitives-charts/scene';
import { type XyDatum } from './events';
import type { ElasticChartsOptions } from './options';
/**
 * Labels a tick Elastic Charts chose: a category by its Scene label, a value
 * through `formatAxisValue`.
 */
export declare const tickLabeler: (axis: SceneAxis, scene: XyScene) => ((value: unknown) => string);
/** The datum for each mark, unstacked: Elastic Charts stacks it. */
export declare const seriesData: (series: XySeries, index: number) => XyDatum[];
/**
 * Each mark's label by the value Elastic Charts passes a value-label formatter.
 * A percentage stack passes each mark's share, which prints through its axis, as Lens labels it.
 * The formatter sees the value alone, so a value whose marks carry different
 * labels prints none rather than another mark's.
 */
export declare const valueLabeler: (series: XySeries, scene: XyScene, axis: SceneAxis | undefined) => (value: unknown) => string;
/**
 * The hovered marks as Lens lists them: the x position as the Scene's category
 * labels it (else as its axis labels it), then each series with its unstacked value.
 */
export declare const sceneTooltip: (scene: XyScene) => CustomTooltip;
/**
 * Elastic Charts paints annotations with `zIndex <= 0` beneath every series
 * and the rest above them, each band in spec order. A helper layer before the
 * first series goes beneath; any later one goes above, except a range, which
 * Kibana's xy chart always paints beneath the data (`annotations.tsx` leaves
 * its `RectAnnotation` at the default `zIndex`).
 */
export declare const layerZIndex: (scene: XyScene, position: number) => number;
/** The base theme's overrides: the Scene's chrome and legend truncation. */
export declare const xyTheme: (scene: XyScene) => PartialTheme;
/** An xy Scene's spec elements, for `<Chart>` or headless drawing. */
export declare const xySpecs: (scene: XyScene, env: SceneRenderEnv, options: ElasticChartsOptions) => ReactNode;
