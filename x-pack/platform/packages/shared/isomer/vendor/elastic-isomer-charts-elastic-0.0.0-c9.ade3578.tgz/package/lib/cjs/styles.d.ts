import { type LocalVarGroup, type StyleHandle } from '@elastic/isomer-primitives-charts/scene';
interface ElasticStyles {
    readonly handles: Readonly<Record<'secondary' | 'tooltip' | 'legendAction' | 'drawing' | 'fluidDrawing' | 'empty' | 'tagCloud' | 'tagCloudCloud' | 'tagCloudLabel', StyleHandle>>;
    readonly vars: {
        readonly ink: LocalVarGroup<'color'>;
        readonly anchor: LocalVarGroup<'top' | 'left'>;
        readonly box: LocalVarGroup<'width' | 'height' | 'maxWidth' | 'aspectRatio'>;
        readonly empty: LocalVarGroup<'width' | 'height' | 'ink' | 'fill'>;
        readonly tagCloud: LocalVarGroup<'width' | 'height' | 'ink' | 'fill'>;
    };
    readonly stylesheet: () => string;
}
export declare const elasticModule: ElasticStyles;
/**
 * Every rule this engine draws its own elements with, for a host that draws
 * the `react` surface and ships the CSS itself, beside the pack's
 * `chartsStylesheet()`. It holds them whether or not the engine had loaded
 * when the host built its stylesheet.
 */
export declare const elasticChartsStylesheet: () => string;
export {};
