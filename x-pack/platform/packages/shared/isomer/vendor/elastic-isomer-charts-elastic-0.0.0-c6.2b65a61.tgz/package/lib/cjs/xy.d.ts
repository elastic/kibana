import type { ReactNode } from 'react';
import { type PartialTheme } from '@elastic/charts';
import type { SceneAxis, SceneRenderEnv, XyScene, XySeries } from '@elastic/isomer-primitives-charts/scene';
import { type XyDatum } from './events';
import type { ElasticChartsOptions } from './options';
/**
 * A tick formatter that returns the Scene's label for each of its ticks.
 * Elastic Charts chooses tick positions itself; a position the Scene has no
 * tick for gets no label.
 */
export declare const tickLabeler: (axis: SceneAxis, scene: XyScene) => ((value: unknown) => string);
/** The datum for each mark, with the segment height when its series stacks. */
export declare const seriesData: (series: XySeries, index: number) => XyDatum[];
/** The base theme's overrides: the Scene's chrome and legend truncation. */
export declare const xyTheme: (scene: XyScene) => PartialTheme;
export declare const XyChart: ({ scene, env, options, }: {
    scene: XyScene;
    env: SceneRenderEnv;
    options: ElasticChartsOptions;
}) => ReactNode;
