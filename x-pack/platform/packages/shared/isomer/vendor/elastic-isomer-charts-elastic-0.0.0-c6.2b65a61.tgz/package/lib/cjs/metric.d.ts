import type { ReactNode } from 'react';
import { type MetricDatum, type PartialTheme } from '@elastic/charts';
import type { MetricScene, MetricTile, SceneRenderEnv } from '@elastic/isomer-primitives-charts/scene';
import type { ElasticChartsOptions } from './options';
/** The Elastic Charts datum for a tile. Its value prints the Scene's text, whatever Elastic Charts passes. */
export declare const metricDatum: (tile: MetricTile) => MetricDatum;
/** Tiles in rows of `layout.columns`, as Kibana slices them. */
export declare const metricGrid: (scene: MetricScene) => (MetricDatum | undefined)[][];
/** The metric overrides Kibana sets on `Settings`, from the Scene's layout and chrome. */
export declare const metricTheme: (scene: MetricScene) => PartialTheme;
export declare const MetricChart: ({ scene, env, options, }: {
    scene: MetricScene;
    env: SceneRenderEnv;
    options: ElasticChartsOptions;
}) => ReactNode;
