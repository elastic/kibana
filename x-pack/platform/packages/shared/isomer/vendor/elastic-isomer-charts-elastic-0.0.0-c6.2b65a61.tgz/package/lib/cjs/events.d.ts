import { type MetricScene, type SceneRenderEnv, type XyCategory, type XyMark, type XyScene } from '@elastic/isomer-primitives-charts/scene';
/** What each datum this engine passes Elastic Charts carries, so a hit names its mark. */
export interface XyDatum {
    readonly x: number | string;
    readonly y: number | null;
    /** The series' index in `scene.series`. */
    readonly series: number;
    /** The mark's index in its series' `marks`. */
    readonly mark: number;
}
/** The Scene mark an Elastic Charts geometry value was drawn from. */
export declare const markOf: (scene: XyScene, datum: unknown) => XyMark | undefined;
/** The category at `x`: the position itself on an ordinal axis, else the last at or before it. */
export declare const categoryAt: (scene: XyScene, x: unknown) => XyCategory | undefined;
/** The handlers this engine passes Elastic Charts for an xy Scene; empty when the chart offers nothing. */
export declare const xyHandlers: (scene: XyScene, env: SceneRenderEnv) => {
    onBrushEnd?: (area: {
        x?: unknown;
    }) => void;
    onProjectionClick?: ({ x }: {
        x: unknown;
        y?: unknown;
    }) => void;
    onElementClick?: (elements: readonly unknown[]) => void;
};
/** Raises the `legend` selection of the legend item for series `key`. */
export declare const legendSelect: (scene: XyScene, env: SceneRenderEnv, key: string, negate: boolean) => void;
/** The handlers this engine passes Elastic Charts for a metric Scene; empty when the chart offers nothing. */
export declare const metricHandlers: (scene: MetricScene, env: SceneRenderEnv) => {
    onElementClick?: never;
} | {
    onElementClick: (elements: readonly unknown[]) => void;
};
