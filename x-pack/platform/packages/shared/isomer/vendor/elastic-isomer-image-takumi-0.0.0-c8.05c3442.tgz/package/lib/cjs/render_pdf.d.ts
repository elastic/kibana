import type { PdfInput, TakumiPdfBackend, TakumiPdfOptions } from './backend';
import { type PngCheckedValidationResult, type PngValidationResult, type SnapshotOptions } from './render_png';
/**
 * The slice of `IsomerRuntime` this helper needs, declared structurally like
 * {@link PdfInput}. A runtime built with `frames` satisfies it.
 */
export interface PdfRuntime {
    validate(composition: unknown): PngCheckedValidationResult;
    surfaces: {
        snapshot: {
            renderPages(compositions: readonly unknown[], options?: SnapshotOptions & {
                onValidationError?: 'collect' | 'throw';
            }): PdfInput;
        };
    };
}
/** Options for {@link renderPdf}. */
export interface RenderPdfOptions extends TakumiPdfOptions {
    /** Forwarded to `runtime.surfaces.snapshot.renderPages`, so every page shares one frame. */
    snapshot?: SnapshotOptions;
}
/** What {@link renderPdf} resolves to: the bytes, the page count and size, and one finding set per composition. */
export interface RenderPdfResult {
    pdf: Buffer;
    pageCount: number;
    width: number;
    height: number;
    /** One per composition, in order. */
    validations: PngValidationResult[];
}
/**
 * Validates, renders, and writes a deck as one PDF in one call, a page per
 * composition.
 *
 * Every composition is rendered, even an invalid one: `validations` is how a
 * caller finds out, rather than a thrown error. What is drawn is the copy
 * validation checked. Validation runs twice, once here and once inside
 * `renderPages`, which discards its own result. An empty deck throws the
 * runtime's `EMPTY_PAGES`. Under a frame that sizes to content, the backend's
 * `fitPages` sizes every page to the tallest, and `height` reports it.
 */
export declare const renderPdf: (runtime: PdfRuntime, deck: readonly unknown[], backend: TakumiPdfBackend, { snapshot, ...options }?: RenderPdfOptions) => Promise<RenderPdfResult>;
