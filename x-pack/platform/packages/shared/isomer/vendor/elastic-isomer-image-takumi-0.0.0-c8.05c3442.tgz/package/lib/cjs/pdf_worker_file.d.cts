export function pdfWorker(): {
    file: string;
};
