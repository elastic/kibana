import type { FontDetails, FontLoader } from '@takumi-rs/core';
import type { MeasureOptions, NodeInput, RenderOptions } from 'takumi-pdf';
/**
 * The two `PdfRenderer` calls the backend makes, on a worker thread the
 * first call starts. Single use: once `close` is called, every call pending
 * or made after rejects with {@link PDF_ENGINE_CLOSED}.
 */
export interface PdfEngine {
    measure(node: NodeInput, options: MeasureOptions): Promise<{
        width: number;
        height: number;
    }>;
    render(node: NodeInput, options: RenderOptions): Promise<Uint8Array>;
    /** Rejects every pending call, without waiting on a font or image loader, and stops the worker. */
    close(): Promise<void>;
}
/** The `code` of the `IsomerError` a closed engine rejects with. */
export declare const PDF_ENGINE_CLOSED = "PDF_ENGINE_CLOSED";
/** A font whose bytes are read on demand. */
type LazyFont = Extract<FontLoader, {
    data: () => unknown;
}>;
/** A font as it crosses to the worker: a lazy `data()` is read here, and rebuilt there. */
export type PostedFont = {
    font: FontLoader;
    lazy: false;
} | {
    font: WithBytes<LazyFont>;
    lazy: true;
};
/** A lazy font with its bytes read, keeping each loader shape's own fields. */
type WithBytes<TFont> = TFont extends unknown ? Omit<TFont, 'data'> & {
    data: FontDetails['data'];
} : never;
/** What the worker starts with. */
export interface PdfWorkerData {
    fonts: readonly PostedFont[];
}
/** One `measure` or `render` call. */
type PdfCall = {
    op: 'measure';
    node: NodeInput;
    options: MeasureOptions;
} | {
    op: 'render';
    node: NodeInput;
    options: RenderOptions;
};
/** A call as posted to the worker. */
export type PdfWorkerRequest = PdfCall & {
    id: number;
};
/** The worker's answer: once when its fonts are registered, then once per call. */
export type PdfWorkerReply = {
    ready: true;
} | {
    ready: false;
    error: unknown;
} | {
    id: number;
    result: Uint8Array | {
        width: number;
        height: number;
    };
} | {
    id: number;
    error: unknown;
};
/** Where the worker's module is, and the `execArgv` it starts with. */
export interface PdfWorkerFile {
    file: string;
    execArgv?: string[];
}
/**
 * A {@link PdfEngine} over a `worker_threads` Worker, so takumi's wasm layout
 * and PDF writing never hold the calling thread. The first call starts the
 * worker, which registers `fonts` once; a worker that fails to start or
 * exits rejects the calls on it, and the next call starts another. The
 * worker holds the process open only while a call is posted to it.
 *
 * `worker` is for tests.
 */
export declare const createPdfEngine: (fonts: readonly FontLoader[], worker?: PdfWorkerFile) => PdfEngine;
export {};
