import type { FontLoader } from '@takumi-rs/core';
/**
 * Registers `fonts` on `engine` in order, the order being takumi's fallback
 * order, and resolves to `engine`.
 */
export declare const registerFonts: <TEngine extends {
    registerFont(font: FontLoader): Promise<unknown>;
}>(engine: TEngine, fonts: readonly FontLoader[]) => Promise<TEngine>;
