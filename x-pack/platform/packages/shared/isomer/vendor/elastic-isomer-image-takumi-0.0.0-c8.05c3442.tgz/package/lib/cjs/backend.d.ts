import { type FontLoader } from '@takumi-rs/core';
import type { ImagesInput } from 'takumi-pdf';
/**
 * How the output's height is decided, mirroring the SDK's `FrameSizing`.
 *
 * - `fixed`: the input's `height`.
 * - `content`: the height the markup lays out to at the input's `width`, so
 *   the input's `height` is only an estimate and is not read. The root's own
 *   height decides: a root pinned to a height measures as that height, and a
 *   percentage height does not resolve.
 */
export type HeightMode = 'fixed' | 'content';
/**
 * The part of a `snapshot` surface result this backend reads: the markup, the
 * stylesheet it is laid out against, and the viewport it was measured for.
 *
 * Declared structurally rather than imported from `@elastic/isomer-runtime`,
 * so this backend depends on no isomer package. `SnapshotRenderResult` satisfies it.
 */
export interface ImageInput {
    /** Static markup with a single root, as image layout requires. */
    html: string;
    /** The stylesheet the markup is laid out against, `light-dark(…)` already resolved. */
    css: string;
    /** The viewport, in CSS pixels; the output is this size unless `heightMode` is `content`. */
    width: number;
    height: number;
    /** Defaults to `fixed`. See {@link HeightMode}. */
    heightMode?: HeightMode | undefined;
}
/**
 * The part of a `snapshot` surface's `renderPages` result this backend reads:
 * one page's markup each, all laid out against one stylesheet at one size.
 * Structural like {@link ImageInput}; `SnapshotPagesResult` satisfies it.
 */
export interface PdfInput {
    /** One page per entry, in order, each static markup with a single root. */
    pages: readonly {
        html: string;
    }[];
    /** One stylesheet collected across every page. */
    css: string;
    /** Every page's size, in CSS pixels. */
    width: number;
    height: number;
    /** Defaults to `fixed`. Under `content`, every page is the height of the tallest laid-out page. */
    heightMode?: HeightMode | undefined;
}
/** Options for {@link createTakumiImageBackend}. */
export interface TakumiImageBackendOptions {
    /**
     * Fonts to register, in fallback order. A pack names families in its theme
     * and this backend holds no opinion about which; nothing is registered by
     * default, so an unregistered family falls back to takumi's built-in face.
     *
     * WOFF and WOFF2 are accepted as well as raw sfnt — `@takumi-rs/core` builds
     * with takumi's `woff`/`woff2` features, so a `@fontsource/*` file can be
     * passed as-is, as raw bytes or a lazy `data()`. A `FontLoader` string is a
     * URL fetched on demand, not a filesystem path.
     */
    fonts?: readonly FontLoader[];
    /** Byte budget for takumi's resource cache. `0` disables it. */
    cacheMaxBytes?: number;
}
/** Per-render overrides. Geometry comes from the input, not from here. */
export interface TakumiRenderOptions {
    /**
     * Raster pixels per CSS pixel: the PNG is `input.width * scale` by
     * `input.height * scale`, rounded. A layout fixed in CSS pixels is
     * unchanged; rounding moves the viewport by under half a raster pixel. `2`
     * gives a 2x raster. Defaults to `1`.
     */
    scale?: number;
    /**
     * Takumi's zoom at a fixed canvas: the tree is laid out at
     * `input.width / devicePixelRatio` CSS pixels and magnified to fill the
     * canvas, so above `1` the PNG keeps its size and shows less of the frame.
     * For a larger raster, use {@link TakumiRenderOptions.scale}.
     */
    devicePixelRatio?: number;
}
/** Document properties written into a PDF. */
export interface TakumiPdfMetadata {
    title?: string;
    description?: string;
    authors?: string[];
    keywords?: string[];
    creator?: string;
    /** UTC, `YYYY-MM-DD` or `YYYY-MM-DDTHH:MM:SS`. Fixing it makes the bytes stable across renders. */
    creationDate?: string;
}
/** Per-document options for {@link TakumiPdfBackend.pdf}. Geometry comes from the input. */
export interface TakumiPdfOptions {
    metadata?: TakumiPdfMetadata;
    /**
     * What a glyph no registered font covers becomes. The default, `'error'`,
     * rejects the render naming the code point, where `png` draws takumi's
     * built-in face instead; `'placeholder'` draws the font's glyph 0 and
     * `'blank'` draws nothing.
     */
    uncoveredText?: 'error' | 'placeholder' | 'blank';
    /**
     * Bytes for the `img` sources in the tree. The PDF engine fetches nothing,
     * so a remote `src` with no entry here draws blank; a `data:` URI needs none.
     */
    images?: ImagesInput;
    /** Writes a document outline from the headings. */
    outline?: boolean;
    /** BCP 47 tag for the document's language. */
    lang?: string;
    /** Paper color painted under every page; unset leaves the page empty. */
    backgroundColor?: string;
}
/** A laid-out element on the canvas, in pixels, with the elements nested in it. */
export interface LayoutBox {
    x: number;
    y: number;
    width: number;
    height: number;
    /** How much the box's x axis is scaled on the canvas, e.g. by `transform: scale()`. */
    scaleX: number;
    /** How much the box's y axis is scaled on the canvas. */
    scaleY: number;
    /** Whichever of `scaleX` and `scaleY` is further from 1, so any value but 1 means the box is scaled. */
    scale: number;
    /** Text laid out in this box, each run positioned on the canvas. */
    runs: {
        text: string;
        x: number;
        y: number;
        width: number;
        height: number;
    }[];
    /**
     * The element's attributes other than `class`, `id`, and `style`, such as
     * `data-*`. Absent when it has none, or when its parent's laid-out children
     * do not line up with its elements, as when inline content folds into runs.
     */
    attributes?: Record<string, string>;
    children: LayoutBox[];
}
/**
 * Rasterizes the `snapshot` surface's output.
 *
 * Both methods are one call over takumi: the tree is serialized, `fromHtml`
 * turns it into a takumi node tree and lifts the stylesheet out, and takumi
 * lays the result out at the input's viewport.
 */
export interface TakumiImageBackend {
    /** Renders to an encoded PNG. */
    png(input: ImageInput, options?: TakumiRenderOptions): Promise<Buffer>;
    /** Renders to an SVG document. Vector output, so raster options do not apply. */
    svg(input: ImageInput): Promise<string>;
    /**
     * The input with `heightMode: 'content'` resolved: `height` set to what the
     * markup lays out to, in CSS pixels, and `heightMode` to `fixed`. Any other
     * input is returned as it is. Costs a layout pass and no raster, so a
     * caller that needs the height as well as the image measures once and
     * renders the result. `devicePixelRatio` is the zoom `png` will use, if any.
     *
     * Optional so a custom backend need not measure; {@link renderPng} then
     * reports the input's estimate as the height.
     */
    fit?(input: ImageInput, options?: Pick<TakumiRenderOptions, 'devicePixelRatio'>): Promise<ImageInput>;
}
/** Writes the `snapshot` surface's pages as a PDF, one page each. */
export interface TakumiPdfBackend {
    /**
     * Renders one page per entry in `pages`, each the input's size with no
     * margin, so a frame fills its page. Vector output with selectable text and
     * the registered fonts subset and embedded. Throws on an empty `pages` list.
     * Under `heightMode: 'content'`, each page is laid out once more to find the
     * tallest, and every page takes that height.
     */
    pdf(input: PdfInput, options?: TakumiPdfOptions): Promise<Buffer>;
    /**
     * {@link TakumiImageBackend.fit} for pages: `height` set to the tallest
     * laid-out page, as the PDF engine lays it out, and `heightMode` to
     * `fixed`. Optional so a custom backend need not measure.
     */
    fitPages?(input: PdfInput, options?: TakumiPdfOptions): Promise<PdfInput>;
}
/** A {@link TakumiImageBackend} that also measures layout. */
export interface TakumiMeasuringBackend extends TakumiImageBackend {
    /** Lays the input out as {@link TakumiImageBackend.png} would, and returns every box, e.g. to find content past its area. */
    measure(input: ImageInput): Promise<LayoutBox>;
}
/** The formats a {@link TakumiBackend} writes, for `createIsomerRuntime({ formats })`. */
export declare const TAKUMI_FORMATS: readonly ["png", "svg", "pdf"];
/** Everything {@link createTakumiImageBackend} returns: raster, measure, and PDF. */
export interface TakumiBackend extends TakumiMeasuringBackend, TakumiPdfBackend {
    /** {@link TAKUMI_FORMATS}: one entry per method that writes a format. */
    readonly formats: typeof TAKUMI_FORMATS;
    fit: NonNullable<TakumiImageBackend['fit']>;
    fitPages: NonNullable<TakumiPdfBackend['fitPages']>;
    /**
     * Stops the PDF worker, if one was started. A `pdf` or `fitPages` in flight
     * rejects with an `IsomerError` coded `PDF_ENGINE_CLOSED`, without waiting
     * on a font or image loader; a later one starts a fresh worker.
     */
    close(): Promise<void>;
}
/**
 * Builds a {@link TakumiBackend} over one takumi renderer. `fonts` are
 * registered once, in order, before the first render; the PDF engine is
 * started on a worker thread on the first `pdf`, and registers them again.
 */
export declare const createTakumiImageBackend: ({ fonts, cacheMaxBytes, }?: TakumiImageBackendOptions) => TakumiBackend;
