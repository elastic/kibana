import type { Scene } from '@elastic/isomer-primitives-charts/scene';
export interface FontFile {
    readonly family: string;
    /** A TTF, OTF, WOFF or WOFF2 file, such as Kibana's own `Inter`. */
    readonly path: string;
}
export interface DrawOptions {
    /** Registered with Skia before the first drawing; text measures and draws in these. */
    readonly fonts?: readonly FontFile[];
    /** Device pixels per CSS pixel in the drawn images. Defaults to 2. */
    readonly pixelRatio?: number;
}
export interface DrawRequest {
    /** Defaults to the Scene's `size`. */
    readonly width?: number;
    readonly height?: number;
    /** Return Elastic Charts' `DebugState` with the drawing, as Kibana's functional tests read it. */
    readonly debugState?: boolean;
}
/** A chart as Elastic Charts drew it: markup whose canvases are PNG images, and the stylesheet it needs. */
export interface ChartDrawing {
    readonly html: string;
    readonly stylesheet: string;
    readonly width: number;
    readonly height: number;
    /** Elastic Charts' `DebugState`, when asked for and Elastic Charts reports one for the kind. */
    readonly debugState?: unknown;
}
export type SceneDraw = (scene: Scene, request?: DrawRequest) => ChartDrawing;
/** Closes a `minmax(…)` inside `repeat(…)` that Elastic Charts' Metric leaves open in its inline grid style. */
export declare const closeMetricGrid: (html: string) => string;
/**
 * Grid rows without `min-content`, which takumi cannot parse: content rows
 * become `auto` and the row that took the free space becomes `1fr`, the same
 * layout in a browser.
 */
export declare const contentRows: (css: string) => string;
/**
 * Grid tracks without `auto-fill` or `auto-fit`, which takumi cannot lay out:
 * as many `minmax(<size>px, …)` tracks as fit in `width`, the count a browser
 * computes. Elastic Charts' bottom legend uses them.
 */
export declare const fixedTracks: (css: string, width: number) => string;
/**
 * Draws Scenes in this thread. The first call installs a jsdom window as the
 * thread's globals, so this belongs on a worker thread, which
 * `createElasticChartsNodeRenderer` starts, or in a process that only draws.
 */
export declare const createSceneDraw: ({ fonts, pixelRatio, }?: DrawOptions) => Promise<SceneDraw>;
