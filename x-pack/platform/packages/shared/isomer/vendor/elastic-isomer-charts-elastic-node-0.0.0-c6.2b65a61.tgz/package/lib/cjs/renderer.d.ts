import type { Scene, SceneRenderer } from '@elastic/isomer-primitives-charts/scene';
import type { ChartDrawing, DrawOptions, DrawRequest } from './draw';
/** A draw as posted to the worker. */
export interface DrawMessage {
    readonly id: number;
    readonly scene: Scene;
    readonly request?: DrawRequest;
}
/** Sent once, when the worker can draw, or why it cannot. */
export type ReadyMessage = {
    ready: true;
} | {
    ready: false;
    error: string;
};
export type DrawReply = {
    id: number;
    drawing: ChartDrawing;
} | {
    id: number;
    error: string;
};
/** A `SceneRenderer` for Node whose drawing resolves on a worker thread. */
export interface ElasticChartsNodeRenderer extends SceneRenderer<Promise<ChartDrawing>> {
    /** Draws at a size other than the Scene's, or with Elastic Charts' `DebugState`. */
    draw(scene: Scene, request?: DrawRequest): Promise<ChartDrawing>;
    /** Stops the drawing thread; a draw after this rejects. */
    close(): Promise<void>;
}
/**
 * Starts a worker thread that draws Scenes with Elastic Charts in jsdom and
 * Skia, and resolves once it can draw, so loading jsdom, React and Elastic
 * Charts is paid here. Drawings are one at a time; the worker keeps the
 * process alive only while one is owed.
 */
export declare const createElasticChartsNodeRenderer: (options?: DrawOptions) => Promise<ElasticChartsNodeRenderer>;
