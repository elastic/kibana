export function chartsWorker(): {
    file: string;
};
export function chartsStylesheetPath(scheme: "light" | "dark"): string;
export function loadDrawingModules(): {
    reactDom: typeof import("react-dom");
    client: typeof import("react-dom/client");
    engine: typeof import("@elastic/isomer-charts-elastic");
};
