/** Whether `value` can carry properties: a non-null object or a function. */
export declare const isObjectLike: (value: unknown) => value is object;
/**
 * A view of `context` that reads `key` as `value` and everything else from
 * `context`, with methods bound to it once, so getters, private state,
 * `instanceof` and each method's identity behave as before, and a callable
 * context stays callable. For a container giving a child its own field, such
 * as a size. A context that is neither an object nor a function is returned
 * as it is.
 */
export declare const contextWith: <TContext>(context: TContext, key: string | symbol, value: unknown) => TContext;
