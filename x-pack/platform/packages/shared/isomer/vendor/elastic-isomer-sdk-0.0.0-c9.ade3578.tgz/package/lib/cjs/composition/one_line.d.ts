/** `text` on one line: each run of whitespace holding a line terminator becomes one space, and other whitespace stays as is. */
export declare const oneLine: (text: string) => string;
/** `text` as a JSON string on one line: `JSON.stringify` leaves U+2028 and U+2029 raw. */
export declare const quoteText: (text: string) => string;
/** A name for a one-line message: as it is when plain, else as {@link quoteText} quotes it. */
export declare const nameText: (name: string) => string;
