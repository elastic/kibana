/** Format hints a {@link StructuredValue} may carry. */
export declare const STRUCTURED_VALUE_FORMATS: readonly ["number", "compact", "percent", "currency", "bytes", "duration", "date", "relativeTime"];
/** One of {@link STRUCTURED_VALUE_FORMATS}. */
export type StructuredValueFormat = (typeof STRUCTURED_VALUE_FORMATS)[number];
/**
 * A raw quantity plus a format hint, so every surface renders the same string.
 *
 * Formatting happens once, in `formatDisplayValue`, rather than per renderer —
 * otherwise the text and Slack surfaces drift on rounding.
 */
export interface StructuredValue {
    /** Unformatted, in base units — a `percent` of `0.42` renders as 42%. */
    raw: number | string;
    /** How to render `raw`. Absent passes a string through and gives a number default formatting. */
    format?: StructuredValueFormat | undefined;
    /**
     * Fraction digits for numeric formats. `number`, `percent`, and `currency`
     * pad to it; omitted, `number` and `percent` keep at most two and `currency`
     * two. `compact` and `bytes` drop trailing zeros and keep one when omitted.
     */
    precision?: number | undefined;
    /** Three-letter currency code for `currency`; defaults to USD. */
    currency?: string | undefined;
}
/** A value-bearing field: preformatted prose, or a {@link StructuredValue} to format. */
export type DisplayValue = string | StructuredValue;
