/** A parsed JSON object, or a JSON Schema node. */
export type JsonObject = Record<string, unknown>;
/** The `$ref` prefix of a local `$defs` entry. */
export declare const DEF_PREFIX = "#/$defs/";
/** A non-null, non-array object. */
export declare const isJsonObject: (value: unknown) => value is JsonObject;
/** The `$defs` id a local `$ref` points at, or `undefined`. */
export declare const parseDefRef: (ref: unknown) => string | undefined;
/** `defs[id]`, ignoring inherited properties. */
export declare const ownDef: (defs: JsonObject, id: string) => unknown;
