import { type ChildNodeWalker } from '../composition/body_node_base';
/** The attribute {@link nodeAnchor} sets to a node's type, escaped so HTML parsing leaves it unchanged. */
export declare const NODE_ANCHOR_ATTRIBUTE = "data-isomer-node";
/**
 * A node type as its anchor carries it. Every character outside `[A-Za-z0-9_-]`
 * becomes `%<hex code point>;`, so the value survives HTML serialization and
 * parsing unchanged and never throws. A plain identifier stays as it is.
 */
export declare const anchorValue: (type: string) => string;
/**
 * Runs `render` with anchors on or off for every {@link nodeAnchor} it reaches,
 * whatever each render context says. The render must be synchronous; the
 * previous state comes back afterwards, even if it throws.
 */
export declare const withAnchors: <TResult>(on: boolean, render: () => TResult) => TResult;
/**
 * `context` for content a renderer draws that is not one of its `children`,
 * such as an embedded composition: nothing under it renders an anchor.
 *
 * The result is a view of `context`, not a copy: reads go to `context` itself,
 * with methods bound to it, so getters, methods, private state, and
 * `instanceof` behave as before. The mark survives a context derived from it
 * by spreading. A context that is neither an object nor a function is
 * returned as it is.
 */
export declare const withoutAnchors: <TContext>(context: TContext) => TContext;
/**
 * `context` with node anchors on, as an enhancement declaring `anchors: true`
 * turns them on. A view like {@link withoutAnchors}, which still wins.
 */
export declare const withNodeAnchors: <TContext>(context: TContext) => TContext;
/**
 * Props a `react` renderer spreads on its root element so runtime code can find
 * the node with {@link findNodeElementPairs}. Inside an HTML surface render the
 * surface decides; elsewhere, on the React and `snapshot` surfaces, `context.anchors`
 * does. Always empty under {@link withoutAnchors}.
 */
export declare const nodeAnchor: (context: unknown, { type }: {
    type: string;
}) => Readonly<Record<string, string>>;
/** The attribute {@link layoutRoom} sets. */
export declare const LAYOUT_ROOM_ATTRIBUTE = "data-isomer-room";
/**
 * Props a renderer spreads on an element inside its node that bounds the nodes
 * nested in it, such as a frame's body, so `checkLayout` measures them against
 * it. Rendered when {@link nodeAnchor} would be.
 */
export declare const layoutRoom: (context: unknown) => Readonly<Record<string, string>>;
/**
 * The nodes of `body` a render on `surface` draws, pre-order, each with its
 * path in validation's `body[0].items[1]` form. Nested nodes follow `react`,
 * as a container renders them through `renderReact` on either surface.
 */
export declare const anchoredNodePaths: (body: readonly unknown[], walk: ChildNodeWalker, surface?: "react" | "snapshot") => {
    node: unknown;
    path: string;
}[];
/** The `react`-visible nodes of `body`, pre-order: the order their anchors render in. */
export declare const anchoredNodes: (body: readonly unknown[], walk: ChildNodeWalker) => unknown[];
/** A node's `type`, when it has one. */
export declare const nodeType: (node: unknown) => string | undefined;
/**
 * The item each of `nodes` pairs with, from `anchored` in document order: the
 * k-th node of a type pairs with the k-th item whose anchor value is that
 * type's. A type whose node and item counts disagree pairs with nothing.
 */
export declare const pairAnchors: <TItem>(anchored: Iterable<readonly [value: string, item: TItem]>, nodes: readonly unknown[]) => (TItem | undefined)[];
/**
 * Every `react`-visible node of `body`, walked pre-order, with the element
 * its anchor marks under `root`, paired by {@link pairAnchors}. `root` holds
 * one render.
 *
 * Pairing holds because every renderer draws its `children` in the order its
 * definition's `children` returns them. A node that rendered nothing leaves
 * its type unpaired. A node object that appears twice appears twice here,
 * each time with its own element.
 */
export declare const findNodeElementPairs: (root: ParentNode, body: readonly unknown[], walk: ChildNodeWalker) => {
    node: unknown;
    element: Element | undefined;
}[];
