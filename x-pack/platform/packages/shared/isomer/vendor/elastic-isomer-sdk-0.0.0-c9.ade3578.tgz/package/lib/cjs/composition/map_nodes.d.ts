import type { ChildNodeWalker } from './body_node_base';
import type { Composition } from './composition';
import type { PrimitiveNode } from './node';
/**
 * Rebuilds `composition`'s body with `fn` applied to every node, including
 * the nested children `walk` yields.
 *
 * Post-order: a container reaches `fn` after its children have been mapped,
 * so `fn` sees the finished replacements in place. Build `walk` with
 * {@link createChildNodeWalker} over every pack in the composition.
 * A child path is the dotted `field` / `field[index]` form the SDK documents
 * (`items[0].node`); any other shape throws `UNSUPPORTED_CHILD_PATH`.
 * Walked without recursion, so depth is bounded by memory, not the call stack; a node nested in itself throws `CYCLIC_COMPOSITION`.
 */
export declare const mapCompositionNodes: <TNode extends PrimitiveNode = PrimitiveNode>(composition: Composition<TNode>, walk: ChildNodeWalker, fn: (node: PrimitiveNode) => PrimitiveNode) => Composition<TNode>;
