import type { SlackBlock } from './blocks';
/** Each block type in `blocks`, a container's children included, that Isomer does not model, once: {@link slackLimitProblems} cannot check those blocks. */
export declare const unmodeledSlackBlockTypes: (blocks: readonly SlackBlock[]) => string[];
/** Where a Slack message breaks `SLACK_LIMITS`, one message per problem; empty when Slack would accept it. */
export declare const slackLimitProblems: ({ text, blocks, }: {
    text: string;
    blocks: readonly SlackBlock[];
}) => string[];
