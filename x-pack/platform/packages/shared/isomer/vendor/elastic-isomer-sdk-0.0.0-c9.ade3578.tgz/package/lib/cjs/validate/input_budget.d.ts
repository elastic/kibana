import type { ValidationError } from '../composition/validation_error';
/** Objects and arrays nested in one another, the input itself included. */
export declare const MAX_INPUT_DEPTH = 64;
/** Every object, array, and leaf counts once. */
export declare const MAX_INPUT_VALUES = 20000;
/** Every object key and string, and each other leaf as `String` prints it. */
export declare const MAX_INPUT_CHARACTERS = 1000000;
/** Overrides for the limits {@link checkInputBudget} enforces; an omitted one keeps its default. */
export interface InputBudget {
    /** Defaults to {@link MAX_INPUT_DEPTH}. Zod parses what passes recursively, so a few hundred nested containers can exhaust the call stack. */
    depth?: number;
    /** Defaults to {@link MAX_INPUT_VALUES}. */
    values?: number;
    /** Defaults to {@link MAX_INPUT_CHARACTERS}. */
    characters?: number;
}
/** Whether `error` is a refusal before parsing, which no validation mode collects. */
export declare const isInputRefusal: ({ code, }: Pick<ValidationError, "code">) => boolean;
/** A plain copy of the input to parse in its place, or why there is none. */
export type InputBudgetCheck = {
    valid: true;
    value: unknown;
} | {
    valid: false;
    error: ValidationError;
};
/**
 * A plain copy of `value` within `budget`, or why there is none: it is over `budget` or is not plain data.
 *
 * Plain data is arrays without holes, objects whose prototype is `Object.prototype` or `null`, enumerable own data properties with string keys, and primitives other than functions.
 * Each property is read once, so a caller that parses the copy parses exactly what was checked; an array's other own properties are left out.
 * Iterative and cycle-safe. Its cost is linear in the input's size: it lists a container's own keys, then refuses past the value limit before reading any of them.
 */
export declare const checkInputBudget: (value: unknown, budget?: InputBudget) => InputBudgetCheck;
