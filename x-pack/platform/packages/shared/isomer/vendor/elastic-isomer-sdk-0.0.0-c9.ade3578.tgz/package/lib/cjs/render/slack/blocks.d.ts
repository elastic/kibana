export type { SlackActionElement, SlackActionsBlock, SlackBlock, SlackButtonElement, SlackCheckboxesElement, SlackContainerBlock, SlackContainerChildBlock, SlackContextBlock, SlackDividerBlock, SlackFileReference, SlackHeaderBlock, SlackHeaderLevel, SlackImageBlock, SlackImageElement, SlackMrkdwnTextObject, SlackMultiStaticSelectElement, SlackOptionGroup, SlackOptionObject, SlackOverflowElement, SlackPlainTextObject, SlackRadioButtonsElement, SlackRawTextElement, SlackRichTextBlock, SlackRichTextBlockElement, SlackRichTextInline, SlackRichTextLink, SlackRichTextList, SlackRichTextPreformatted, SlackRichTextQuote, SlackRichTextSection, SlackRichTextStyle, SlackRichTextTag, SlackRichTextText, SlackSectionAccessory, SlackSectionBlock, SlackStaticSelectElement, SlackTableBlock, SlackTableCell, SlackTableColumnSetting, SlackTagColor, SlackTextObject, SlackVideoBlock, } from '../../define/slack_blocks';
/**
 * Slack's published surface limits, enforced by the renderer so a composition
 * cannot silently trip Slack's validation.
 */
export declare const SLACK_LIMITS: {
    /** Top-level blocks; a `container`'s `child_blocks` do not count. */
    readonly blocksPerMessage: 50;
    /** `container.title`, which is `plain_text`. */
    readonly containerTitleChars: 150;
    /** `container.subtitle`. */
    readonly containerSubtitleChars: 150;
    /** `container.child_blocks`; Slack also requires at least one. */
    readonly containerChildBlocks: 10;
    /** `section.text`. */
    readonly sectionTextChars: 3000;
    /** One entry of `section.fields`. */
    readonly sectionFieldChars: 2000;
    /** One entry of `context.elements`. */
    readonly contextElementChars: 2000;
    /** `header.text`, which is `plain_text`. */
    readonly headerTextChars: 150;
    readonly fieldsPerSection: 10;
    /** Elements per `context` block. */
    readonly contextElements: 10;
    readonly buttonsPerActions: 25;
    /** Slack truncates the top-level `text` fallback in notifications around here. */
    readonly fallbackTextChars: 4000;
    /** `plain_text` option labels (selects, radio, checkboxes, overflow). */
    readonly optionTextChars: 75;
    /** Options per select, or per option group of one. */
    readonly optionsPerSelect: 100;
    /** Options per overflow menu (Slack caps overflow at 5). */
    readonly optionsPerOverflow: 5;
    /** Options per radio button group or checkboxes element. */
    readonly optionsPerChoice: 10;
    /** Option groups per select, each holding up to `optionsPerSelect` options. */
    readonly optionGroupsPerSelect: 100;
    /** An option's `value`, which interactions send back. */
    readonly optionValueChars: 150;
    /** A button's `value`. */
    readonly buttonValueChars: 2000;
    /** A button's or overflow option's `url`. */
    readonly urlChars: 3000;
    /** An interactive element's `action_id`. */
    readonly actionIdChars: 255;
    /** Max indent level for `rich_text_list`. */
    readonly richTextListMaxIndent: 8;
    /**
     * Characters across every table cell in one message. Slack publishes the
     * same 10,000 figure per table and per message, so the message-wide
     * aggregate is the binding one.
     * https://docs.slack.dev/reference/block-kit/blocks/table-block/
     */
    readonly tableCellCharsPerMessage: 10000;
    /** Rows per `table` block (includes the header row). */
    readonly tableRows: 100;
    /** Cells per `table` row / columns per table. */
    readonly tableColumns: 20;
    /** `image`/image-element `image_url` max length. */
    readonly imageUrlChars: 3000;
    /** `image`/image-element `alt_text` max length. */
    readonly imageAltTextChars: 2000;
    /** `image` block `title`. */
    readonly imageTitleChars: 2000;
    /** `video` block `title`; Slack requires fewer than 200. */
    readonly videoTitleChars: 199;
    /** `video` block `description`; Slack requires fewer than 200. */
    readonly videoDescriptionChars: 199;
    /** `video` block `author_name`; Slack requires fewer than 50. */
    readonly videoAuthorNameChars: 49;
    /** `button` element `text`. */
    readonly buttonTextChars: 75;
    /** Select `placeholder`. */
    readonly placeholderChars: 150;
    /** `option_groups[].label`. */
    readonly optionGroupLabelChars: 75;
};
