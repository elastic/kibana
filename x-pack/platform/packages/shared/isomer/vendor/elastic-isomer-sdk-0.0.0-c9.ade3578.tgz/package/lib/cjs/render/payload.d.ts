/**
 * Byte sizes of one rendered payload.
 *
 * `html` counts markup only: inlined CSS and script bytes are subtracted out
 * and reported under `css` / `js`. `total` counts each part exactly once,
 * whether or not the CSS was inlined.
 */
export interface PayloadMeasurement {
    html: number;
    css: number;
    js: number;
    total: number;
}
/** UTF-8 byte length of `value`, which is not `length` for non-ASCII text. */
export declare const byteLength: (value: string) => number;
