import { type ReactElement, type ReactNode } from 'react';
import type { z, ZodObject } from 'zod';
import type { Composition } from '../composition/composition';
import type { PrimitiveNode } from '../define/primitive_module';
import { type ZodWrapperOf } from '../define/zod_introspect';
import { type AuthoredChildBrand, type AuthoredNodesBrand, type AuthoredTextBrand, type AuthoredToItemBrand, type ItemSchema } from './authored_fields';
import { type AuthorComponent } from './jsx';
/** A {@link Composition} whose `body` is the pack's own authoring node type. */
export type AuthorComposition<TNode extends PrimitiveNode = PrimitiveNode> = Omit<Composition<TNode>, 'body'> & {
    body: TNode[];
};
/**
 * Props of the shim's root element: the composition fields minus `type`, with
 * `body` given either as an array or as JSX children.
 */
export interface CompositionAuthorProps<TNode extends PrimitiveNode = PrimitiveNode> extends Omit<AuthorComposition<TNode>, 'type' | 'body'> {
    /** Wins outright when present: `children` are then ignored, not merged. */
    body?: TNode[];
    /** Parsed into `body` only when `body` is absent. Each child must be an authoring element of a registered primitive type. */
    children?: ReactNode;
}
/** Literal `type` strings; wide `string` is dropped so a string index cannot collide with `component`. */
type LiteralType<T extends string> = string extends T ? never : T;
/** No keys. Intersects away, unlike `Record<string, never>`. */
type NoKeys = Record<never, never>;
type ShapeOf<T> = T extends {
    shape: infer Shape;
} ? Shape : NoKeys;
/** A primitive's schema type, or `never` when it declares none. */
type SchemaOf<P> = P extends {
    schema: infer S;
} ? S extends ZodObject ? S : never : never;
/** A bare `ZodObject` has a string index; a real shape does not. */
type LooseSchema<TSchema> = string extends keyof ShapeOf<TSchema> ? true : false;
type Branded<F> = F extends AuthoredChildBrand<string, unknown> | AuthoredTextBrand | AuthoredNodesBrand ? F : F extends ZodWrapperOf<infer Inner> ? Branded<Inner> : F;
type AuthoredNames<TSchema> = {
    [K in keyof ShapeOf<TSchema>]: Branded<ShapeOf<TSchema>[K]> extends AuthoredChildBrand<string, unknown> | AuthoredTextBrand | AuthoredNodesBrand ? K : never;
}[keyof ShapeOf<TSchema>];
type SlotValue<V> = NonNullable<V> extends readonly (infer Item)[] ? Item : NonNullable<V>;
/**
 * A field holding body nodes, or an array of them: its `type` is wide or one of
 * the pack's `TTypes`, so a discriminated config object does not count.
 */
type NodeSlotKey<T, TTypes extends string> = {
    [K in keyof T]-?: K extends 'type' ? never : SlotValue<T[K]> extends {
        type: infer Type extends string;
    } ? string extends Type ? K : [Type] extends [TTypes] ? K : never : never;
}[keyof T];
type IsUnion<T, U = T> = [T] extends [never] ? false : T extends unknown ? [U] extends [T] ? false : true : false;
/** `T` when it is exactly one key. */
type Only<T> = [T] extends [never] ? never : IsUnion<T> extends true ? never : T;
/**
 * The one unbranded node field JSX children fill. With several, each stays a
 * prop, as at runtime.
 */
type PassthroughSlot<TSchema extends ZodObject, TTypes extends string> = Only<Exclude<NodeSlotKey<z.infer<TSchema>, TTypes>, AuthoredNames<TSchema>>>;
type FilledNames<TSchema extends ZodObject, TTypes extends string> = AuthoredNames<TSchema> | PassthroughSlot<TSchema, TTypes>;
type AuthorPropsForSchema<TSchema extends ZodObject, TTypes extends string> = LooseSchema<TSchema> extends true ? Record<string, unknown> & {
    children?: ReactNode;
} : Omit<z.infer<TSchema>, 'type' | FilledNames<TSchema, TTypes>> & Partial<Pick<z.infer<TSchema>, Extract<FilledNames<TSchema, TTypes>, keyof z.infer<TSchema>>>> & {
    children?: ReactNode;
};
type AuthorPropsFor<P, TTypes extends string> = [SchemaOf<P>] extends [never] ? Record<string, unknown> & {
    children?: ReactNode;
} : AuthorPropsForSchema<SchemaOf<P>, TTypes>;
type ChildEntry<F, TOwner extends string, TDepth extends unknown[]> = 0 extends 1 & F ? NoKeys : F extends AuthoredChildBrand<infer Name, infer Props> ? [Name] extends [string] ? {
    [K in Capitalize<Name>]: AuthorComponent<Props & {
        children?: ReactNode;
    }, `${TOwner}.${K}`>;
} & (F extends AuthoredToItemBrand ? NoKeys : ChildComponentsOf<ItemSchema<F>, TOwner, [...TDepth, unknown]>) : NoKeys : NoKeys;
type UnionToIntersection<T> = (T extends unknown ? (value: T) => void : never) extends (value: infer R) => void ? R : never;
/** Child components branded on `TSchema`, then on each child's item schema, five levels deep. */
type ChildComponentsOf<TSchema, TOwner extends string, TDepth extends unknown[] = []> = TDepth['length'] extends 5 ? NoKeys : LooseSchema<TSchema> extends true ? NoKeys : UnionToIntersection<{
    [K in keyof ShapeOf<TSchema>]: ChildEntry<Branded<ShapeOf<TSchema>[K]>, TOwner, TDepth>;
}[keyof ShapeOf<TSchema>]>;
/** A primitive's child components, as members of its own component. */
type MembersOf<P, TType extends string> = [SchemaOf<P>] extends [never] ? NoKeys : ChildComponentsOf<SchemaOf<P>, TType>;
/**
 * PascalCase authoring components keyed from a pack's primitive `type` list.
 * `slideFrame` becomes `SlideFrame`. Props come from the primitive's schema,
 * and each branded child is a member: `SlideFrame.Footer`.
 */
export type PrimitiveComponentMap<TPrimitives extends readonly {
    type: string;
}[]> = {
    [P in TPrimitives[number] as Capitalize<LiteralType<P['type'] & string>>]: AuthorComponent<AuthorPropsFor<P, LiteralType<TPrimitives[number]['type'] & string>>, P['type'] & string> & MembersOf<P, P['type'] & string>;
};
/**
 * A pack's JSX authoring front: the root `Composition` element, one
 * PascalCase component per primitive with its branded children as members,
 * and the conversion back to plain data.
 */
export type JsxShim<TNode extends PrimitiveNode = PrimitiveNode, TPrimitives extends readonly {
    type: string;
}[] = readonly {
    type: string;
}[]> = {
    Composition: AuthorComponent<CompositionAuthorProps<TNode>, 'view'>;
    /** Throws when the root is not the `Composition` element, or when a child is not a registered primitive. */
    toComposition: (element: ReactElement<CompositionAuthorProps<TNode>>) => AuthorComposition<TNode>;
} & PrimitiveComponentMap<TPrimitives>;
/**
 * Builds a pack's {@link JsxShim} from its primitive list.
 *
 * Branded schema fields ({@link fromChildren}, {@link fromTextChildren}) fill
 * from JSX children, and each child becomes a member of its primitive's
 * component. Several branded fields share one children list, and each takes
 * the elements of its member.
 * Elements of a registered primitive that match none of them fill the one
 * unbranded child slot from {@link PrimitiveDefinition.children}, or the one
 * {@link fromNodeChildren} field. A primitive with no brand still fills that slot, array or
 * single node, from its children. That field is optional on the component's
 * props.
 */
export declare const buildJsxShim: <const TPrimitives extends readonly {
    type: string;
}[] = readonly {
    type: string;
}[], TNode extends PrimitiveNode = PrimitiveNode>(primitives?: TPrimitives) => JsxShim<TNode, TPrimitives>;
/** React children as a flat array, with fragments inlined. */
export declare const flattenChildren: (children: ReactNode) => ReactNode[];
/**
 * Children joined into one string. Throws on an element child, so a prop typed as text stays text. Collapses whitespace unless `{ collapseWhitespace: false }`; `{ dedent: true }` reads it as source, lines joined by `\n`.
 */
export declare const textFromChildren: (children: ReactNode, options?: {
    collapseWhitespace?: boolean;
    dedent?: boolean;
}) => string;
export {};
