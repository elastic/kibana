import { type ReactNode } from 'react';
import { type AnyPrimitiveDefinition, type DefaultPackTypes, type PackTypes, type PrimitiveNode, type RenderScope } from '../define/primitive_module';
import type { SlackLinkOptions } from './slack/format';
/**
 * Renders a node on any surface by looking its `type` up in one flattened
 * inventory.
 *
 * The seam that makes packs composable: a container recurses through the
 * {@link RenderScope} it is passed rather than through its own pack, so a node
 * owned by another pack still renders.
 */
export interface PrimitiveDispatcher<TNode extends PrimitiveNode, T extends PackTypes = DefaultPackTypes> extends RenderScope<T, TNode> {
    /**
     * The node's `react` renderer, gated on `snapshot` visibility and keyed for a
     * frame's sibling list. `key` must be unique among those siblings.
     * `theme` is the frame's resolved palette for this render, or `undefined`
     * outside a frame.
     */
    renderSnapshot(node: TNode, context: T['context'], theme: T['theme'] | undefined, key: string): ReactNode;
    /**
     * {@link RenderScope.renderSlack}, plus: a node `isSlackAssetType` names
     * becomes an `image` block when `collector` can allocate and the node is
     * visible on `snapshot`, which draws the picture, and
     * `options.baseUrl` reaches the renderer's env and every child it renders
     * through `scope`.
     */
    renderSlack(node: TNode, collector?: T['slackCollector'], options?: SlackLinkOptions): readonly T['slackBlock'][];
}
/** Runtime facts {@link createPrimitiveDispatcher} cannot derive from the inventory. */
export interface PrimitiveDispatcherOptions {
    /** Names this dispatcher in error messages. */
    label?: string;
    /**
     * Which node types render as a picture rather than as text, so the Slack
     * surface uploads an image instead of degrading to markdown. Supplied by the
     * runtime from each pack's `slackAssetTypes`.
     */
    isSlackAssetType?: ((type: string) => boolean) | undefined;
}
/**
 * Flattens `definitions` into one type-keyed inventory.
 *
 * Throws on a duplicate `type`: two packs claiming one node type has no correct
 * resolution, so it fails at construction rather than resolving arbitrarily per
 * render.
 */
export declare const createPrimitiveDispatcher: <TNode extends PrimitiveNode, T extends PackTypes = DefaultPackTypes>(definitions: readonly AnyPrimitiveDefinition[], options?: PrimitiveDispatcherOptions) => PrimitiveDispatcher<TNode, T>;
