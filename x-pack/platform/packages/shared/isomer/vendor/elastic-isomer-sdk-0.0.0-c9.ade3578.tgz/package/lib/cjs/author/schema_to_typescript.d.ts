import { type JsonObject } from '../validate/json_helpers';
export type { JsonObject };
/** Ids `z.toJSONSchema` gives a def no one named. */
export declare const ANONYMOUS_DEF: RegExp;
export declare const IDENTIFIER: RegExp;
/** `slideStats` becomes `SlideStats`; anything but letters and digits splits words. */
export declare const pascalCase: (value: string) => string;
/** A JSDoc block for `lines`, or `''` when there are none. */
export declare const jsDoc: (lines: readonly string[], pad: string) => string;
/** What {@link TypePrinter.members} prints and how. */
export interface MemberOptions {
    /** Properties left out. */
    omit?: ReadonlySet<string>;
    /** Properties printed optional whether or not the schema requires them. */
    optional?: ReadonlySet<string>;
}
export interface TypePrinterOptions {
    defs: JsonObject;
    /** TypeScript names for defs printed by reference; every other def is inlined. */
    names: ReadonlyMap<string, string>;
    /** A fresh, unused name, for a def inlining cannot express. */
    claim: (base: string) => string;
}
export interface TypePrinter {
    /** `schema` as a TypeScript type, written at `depth` levels of indent. */
    print: (schema: unknown, depth?: number) => string;
    /** The `key?: Type;` members of an object schema, with their JSDoc, at `depth + 1`. */
    members: (schema: JsonObject, depth: number, options?: MemberOptions) => string;
    /** Type aliases for the anonymous defs that refer to themselves. Call last. */
    promoted: () => string[];
}
/** A TypeScript printer over the subset of JSON Schema `z.toJSONSchema` emits. */
export declare const createTypePrinter: ({ defs, names, claim, }: TypePrinterOptions) => TypePrinter;
