import type { PrimitiveNode } from '../../composition/node';
import type { SlackAssetCollector, SlackAssetRequest } from '../../define/slack_assets';
export type { SlackAssetCollector, SlackAssetRequest };
/**
 * Whether Slack's servers can fetch `src` themselves: an `https:` URL with a
 * host, so a data URL or a host-relative path has to go through an upload.
 */
export declare const isSlackReachableImageUrl: (src: string) => boolean;
/**
 * A fresh {@link SlackAssetCollector} handing out `asset-0`, `asset-1`, … in
 * allocation order.
 */
export declare const createSlackAssetCollector: <TNode extends PrimitiveNode = PrimitiveNode>() => SlackAssetCollector<TNode>;
