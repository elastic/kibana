/**
 * Returns the URL, trimmed and with control characters stripped, when it
 * satisfies the navigation policy (`https:` / `http:` / `mailto:` / relative
 * path), `null` otherwise.
 */
export declare const sanitizeNavigationHref: (href: string) => string | null;
/**
 * Returns the URL, trimmed and with control characters stripped, when it
 * satisfies the asset policy (`https:` / `http:` / relative path /
 * `data:image/*`), `null` otherwise.
 */
export declare const sanitizeAssetUrl: (url: string) => string | null;
/** Checks a Markdown parser's decoded destination without decoding it again. */
export declare const sanitizeParsedNavigationHref: (href: string) => string | null;
/** Checks a Markdown parser's decoded image destination. */
export declare const sanitizeParsedAssetUrl: (url: string) => string | null;
/**
 * Render-time replacement for a navigation href that failed the policy: an
 * inert same-document link, so the label stays visible without a destination.
 */
export declare const BLOCKED_HREF = "#";
/** What {@link navigationHref} accepts, for a field description to state. */
export declare const NAVIGATION_HREF_RULE = "an https, http, or mailto URL, or a relative path";
/** What {@link assetUrl} accepts, for a field description to state. */
export declare const ASSET_URL_RULE = "an https, http, or data:image URL, or a relative path";
/** Validation message for {@link navigationHref}. */
export declare const NAVIGATION_HREF_MESSAGE = "must be an https, http, or mailto URL, or a relative path";
/** Validation message for {@link assetUrl}. */
export declare const ASSET_URL_MESSAGE = "must be an https, http, or data:image URL, or a relative path";
/** Options for {@link navigationHref} and {@link assetUrl}. */
export interface UrlSchemaOptions {
    /** Longest accepted value, in characters. */
    max?: number;
}
/**
 * Zod schema for an `href`-like field: the validation layer of the two-layer
 * policy, paired with {@link sanitizeNavigationHref} at render time.
 *
 * Its description states the rule, since a refinement's message does not
 * reach the authoring JSON Schema. A field that describes itself should end
 * with {@link NAVIGATION_HREF_RULE} so the model still reads it.
 */
export declare const navigationHref: (options?: UrlSchemaOptions) => import("zod").ZodString;
/**
 * Zod schema for a `src`-like field, paired with {@link sanitizeAssetUrl} at
 * render time. Describes itself as {@link navigationHref} does, with
 * {@link ASSET_URL_RULE}.
 */
export declare const assetUrl: (options?: UrlSchemaOptions) => import("zod").ZodString;
