import type { PrimitiveIcon } from '../define/primitive_icon';
import type { AnyPrimitiveDefinition, OptionalSurface } from '../define/primitive_module';
import type { EnhancementDefinition } from './enhancements';
/**
 * The authoring-schema material a pack contributes for its own primitives.
 *
 * A subset of `AuthoringJsonSchemaOptions`: `$id`, `title`, `description`, and
 * `composition` describe the whole authoring schema a runtime builds, which is
 * a host decision, not a pack one. `pack/` does not import `validate/` for
 * this, so the shape is declared here rather than reused by reference.
 */
export interface PackAuthoringOptions {
    /** `$def` id to `description`, for this pack's own primitives. */
    describe?: Readonly<Record<string, string>>;
    /** Headings an index catalog sorts this pack's primitives under, in order. A type in none is listed under {@link UNCATEGORIZED_GROUP_TITLE}. */
    groups?: readonly PrimitiveGroup[];
}
/** A titled set of primitive types, listed together in an index catalog. */
export interface PrimitiveGroup {
    title: string;
    types: readonly string[];
}
/** The index heading for primitives in no group. A pack cannot declare a group with this title. */
export declare const UNCATEGORIZED_GROUP_TITLE = "Uncategorized";
/**
 * The HTML style-adapter hooks a pack may declare. Typed loosely here so `pack/` does not import `render/`.
 */
export type PackStyleAdapter = {
    /** See {@link PrimitivePackInput.styleCollector}. */
    styleCollector?: string;
    /** The hooks of `HTMLStyleAdapter` from `./html`, erased: a fresh collector per render, the context renderers receive, and the stylesheet the collector produced. */
    createCollector: (...args: never[]) => object;
    createRenderContext: (...args: never[]) => unknown;
    renderStyles: (...args: never[]) => string;
};
/**
 * Limits a pack asks the input budget to allow, by name: the same fields as
 * the validator's `InputBudget`, each a positive integer.
 */
export interface PackInputBudget {
    depth?: number;
    values?: number;
    characters?: number;
}
/** What a pack author passes to {@link definePrimitivePack}. */
export interface PrimitivePackInput {
    /** Stable identifier, used in capability reports and error messages. */
    id: string;
    /**
     * The optional surfaces this pack's primitives implement.
     *
     * Only `slack`, and it stays optional per primitive: the dispatcher converts
     * the mandatory markdown to Block Kit, so declaring it reports an intent
     * rather than imposing a requirement. Omit it entirely for a pack that
     * renders Slack through that fallback.
     */
    surfaces?: readonly OptionalSurface[];
    /** This pack's vocabulary. Node types must be unique within it, or construction throws. */
    primitives: readonly AnyPrimitiveDefinition[];
    /**
     * Progressive enhancements this pack's primitives can apply, by id.
     *
     * Declared by the pack because an enhancement is a fact about its
     * vocabulary — a sortable table, a copyable code block — and a host
     * composing packs it did not write cannot be expected to know the ids.
     * The runtime flattens these across packs; duplicate ids are rejected.
     */
    enhancements?: readonly EnhancementDefinition[];
    /**
     * Types that render as a self-contained picture rather than as text.
     *
     * A channel that cannot draw them inline uploads an image instead: the Slack
     * dispatcher swaps such a node for an `image` block and an upload request, so
     * a chart arrives as a PNG rather than as a markdown approximation of one.
     *
     * Declared by the pack because it is a fact about the vocabulary, and a host
     * composing packs it did not write cannot be expected to know it.
     */
    slackAssetTypes?: readonly string[];
    /**
     * Default HTML style adapter for this pack's nodes. A runtime that omits
     * `styleAdapter` runs each pack's own and joins their stylesheets. Pass
     * `styleAdapter` on the runtime to replace them all.
     */
    styleAdapter?: PackStyleAdapter;
    /**
     * Names the collector shape this pack's `collectStyles` hooks mutate, so a
     * runtime can reject a pack paired with an adapter of a different tag.
     * Defaults to `styleAdapter.styleCollector`; a pack with neither opts out of
     * the check.
     */
    styleCollector?: string;
    /**
     * This pack's own contribution to the runtime's authoring JSON Schema.
     *
     * Merged across every composed pack, so a host does not hand-merge each
     * pack's `describe` into one options object itself. The
     * runtime-level `authoring` option is merged in last and wins on conflict.
     */
    authoring?: PackAuthoringOptions;
    /**
     * The input budget this pack's compositions need, where it is larger than
     * the SDK's default: a chart pack whose nodes carry their data inline needs
     * more values than a pack of message blocks.
     *
     * A runtime takes, per limit, the largest any of its packs declares and
     * never less than the default, so the budget grows with the packs
     * registered. A host's own `inputBudget` overrides it. Each limit is a
     * positive integer.
     */
    inputBudget?: PackInputBudget;
}
/**
 * A pack as the runtime sees it.
 *
 * `TTheme` is the palette this pack's `react` renderers read as `env.theme`
 * when drawn through the `snapshot` surface — a *lower bound* on whatever theme
 * the runtime holding it supplies. It is carried by
 * {@link PrimitivePack.__theme} rather than by any real field, because
 * `primitives` is erased to `AnyPrimitiveDefinition[]` and a heterogeneous
 * inventory has no single node type to be generic over.
 *
 * The bound is declared, not derived: nothing checks it against what the
 * renderers actually read. State it at the definition as
 * `definePrimitivePack<T>(input)`.
 * Bare `PrimitivePack` requires nothing and fits any runtime; a slot that must
 * hold packs of every palette is typed {@link AnyPrimitivePack}.
 */
export interface PrimitivePack<TTheme = unknown> {
    /** Unique among the packs a runtime composes, and used in error messages. */
    readonly id: string;
    /** See {@link PrimitivePackInput.surfaces}. */
    readonly surfaces: readonly OptionalSurface[];
    /** See {@link PrimitivePackInput.primitives}. */
    readonly primitives: readonly AnyPrimitiveDefinition[];
    /** Node types this pack owns, for duplicate detection across packs. */
    readonly types: ReadonlySet<string>;
    /**
     * Each primitive's `icon` by type, for the primitives that declare one, so a host listing them need not walk `primitives`.
     *
     * A frozen null-prototype dictionary: an absent type reads `undefined`, even `constructor`. Absent on a pack built by an SDK that predates icons; {@link iconsByType} derives it from `primitives`.
     */
    readonly icons?: Readonly<Record<string, PrimitiveIcon>>;
    /** See {@link PrimitivePackInput.enhancements}. */
    readonly enhancements: readonly EnhancementDefinition[];
    /** See {@link PrimitivePackInput.slackAssetTypes}. */
    readonly slackAssetTypes: ReadonlySet<string>;
    /** See {@link PrimitivePackInput.styleAdapter}. */
    readonly styleAdapter?: PackStyleAdapter;
    /** See {@link PrimitivePackInput.styleCollector}. */
    readonly styleCollector?: string;
    /** See {@link PrimitivePackInput.authoring}. */
    readonly authoring?: PackAuthoringOptions;
    /** The input budget the pack declares; see {@link PrimitivePackInput.inputBudget}. */
    readonly inputBudget?: Readonly<PackInputBudget>;
    /**
     * Phantom: never present at runtime, never read.
     *
     * A property rather than a method so `strictFunctionTypes` checks it
     * contravariantly. A method signature is bivariant, which would let a pack
     * needing richer tokens sit in a slot supplying fewer and then read a field
     * nothing supplies — the exact failure this marker exists to prevent.
     */
    readonly __theme?: (theme: TTheme) => void;
}
/**
 * A pack of any palette, for storage positions: `never` is assignable to every
 * requirement, so a slot typed this way holds every pack.
 */
export type AnyPrimitivePack = PrimitivePack<never>;
/**
 * Builds a {@link PrimitivePack}.
 *
 * `TTheme` is the palette a frame must supply for this pack's nodes to be drawn
 * on the `snapshot` surface: `definePrimitivePack<CoreTokens>(input)`. Omitted, it is
 * `unknown`, which requires nothing.
 */
export declare const definePrimitivePack: <TTheme = unknown>(input: PrimitivePackInput) => PrimitivePack<TTheme>;
/** Each definition's `icon` by type, null-prototype so a type such as `__proto__` is an ordinary key. */
export declare const iconsByType: (primitives: readonly AnyPrimitiveDefinition[]) => Readonly<Record<string, PrimitiveIcon>>;
