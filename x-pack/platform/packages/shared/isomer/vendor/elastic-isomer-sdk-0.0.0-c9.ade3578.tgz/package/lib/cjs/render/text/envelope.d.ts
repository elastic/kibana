import type { Composition } from '../../composition/composition';
import type { PrimitiveNode } from '../../define/primitive_module';
/** A pack's plain-text renderer for one node of its own type. */
export interface TextEnvelopeDispatcher<TNode extends PrimitiveNode> {
    /** Returns the empty string for a node with nothing to show; the envelope drops it rather than emitting a blank paragraph. */
    renderText(node: TNode): string;
}
/** Options for {@link renderTextEnvelope}. */
export interface TextEnvelopeOptions {
    /** Renders the composition's title and subtitle. Defaults to `true`. Pass `false` when the host already shows the title, or the body opens with its own. */
    heading?: boolean;
}
/** The composition as plain text: title uppercased, subtitle, then nodes. */
export declare const renderTextEnvelope: <TNode extends PrimitiveNode>(composition: Composition<TNode>, dispatcher: TextEnvelopeDispatcher<TNode>, { heading }?: TextEnvelopeOptions) => string;
