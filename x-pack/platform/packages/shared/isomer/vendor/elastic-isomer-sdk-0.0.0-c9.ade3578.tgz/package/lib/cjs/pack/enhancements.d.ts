import type { ChildNodeWalker } from '../composition/body_node_base';
import type { PrimitiveNode } from '../composition/node';
/**
 * A progressive enhancement any vocabulary pack may declare.
 *
 * Ids are open strings rather than a closed union so a second pack can
 * register one without editing a shared type. Duplicate ids across packs in
 * one runtime are rejected at construction.
 */
export interface EnhancementDefinition {
    /** What a renderer tests for via `context.enhancements`. Unique across a runtime's packs. */
    id: string;
    /** Short label for hosts; when omitted, use {@link EnhancementDefinition.id}. */
    name?: string;
    /** What enabling the enhancement does, for host UI and authoring material. */
    description?: string;
    /**
     * Whether this composition has anything for the enhancement to act on.
     * Gating on content rather than the opt-in alone is what keeps a composition
     * with no matching node from shipping the script.
     *
     * `walk` is the composition's child walker, so a match nested inside a
     * container from another pack is still found.
     */
    appliesTo: (body: readonly PrimitiveNode[], walk: ChildNodeWalker) => boolean;
    /**
     * A function body with `root: Element`, the render's `.isomer` section, in
     * scope. It runs in its own function, so a top-level `const` or `return`
     * cannot reach another enhancement. Absent when the host drives the
     * enhancement itself.
     *
     * It must not look for its root through `document.currentScript`, which is
     * `null` inside a shadow root. It must address markup through `data-*`
     * attributes rather than class names: class names are minified per render,
     * and a selector written against one is a contract nothing checks. An event
     * meant for the host sets `composed: true` as well as `bubbles: true`, or it
     * stops at a shadow boundary.
     */
    script?: string;
    /** Renders node anchors when resolved, for an enhancement that finds nodes with `findNodeElementPairs`. */
    anchors?: true;
}
/**
 * The `definitions` that apply to `body`, the first of each id, limited to
 * `requested` ids when given. The HTML and React surfaces both resolve through
 * it, so the two cannot disagree on which enhancements a render carries.
 */
export declare const resolveEnhancements: (body: readonly PrimitiveNode[], walk: ChildNodeWalker, definitions: readonly EnhancementDefinition[], requested?: readonly string[]) => EnhancementDefinition[];
/**
 * Wraps one script body in its own function, so its `const`s and a top-level
 * `return` stay its own. Anything that joins script bodies scopes each first.
 */
export declare const scopeScript: (body: string) => string;
/** Marks the `<script>` a `scripts: 'embedded'` render emits. */
export declare const EMBEDDED_SCRIPT_ATTRIBUTE = "data-isomer-script";
/**
 * Runs a `scripts: 'host'` render's `js` against the
 * `.isomer` section the host inserted.
 *
 * Needed wherever the HTML is inserted by the host rather than parsed with the
 * page, including every shadow root: such a `<script>` never runs, and one
 * that did would find no `document.currentScript`.
 *
 * Compiles with `new Function`, so a strict Content-Security-Policy must allow
 * `'unsafe-eval'`. A host that cannot should render with `scripts: 'embedded'`
 * into light DOM.
 */
export declare const runEnhancementScript: (js: string, root: Element) => void;
