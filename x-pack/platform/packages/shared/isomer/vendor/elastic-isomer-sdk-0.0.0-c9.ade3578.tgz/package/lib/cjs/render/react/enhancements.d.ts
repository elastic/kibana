import type { ChildNodeWalker } from '../../composition/body_node_base';
import type { PrimitiveNode } from '../../composition/node';
import { type EnhancementDefinition } from '../../pack/enhancements';
/**
 * The `definitions` that apply to `body`, the first of each id and limited to
 * `requested` ids when given, and `context` for a React render of it: carrying
 * their ids as `context.enhancements`, with `context.anchors` on when one
 * declares `anchors: true`. `context` is viewed, not copied, as the HTML
 * surface does.
 */
export declare const applyEnhancements: <TContext>(context: TContext, body: readonly PrimitiveNode[], walk: ChildNodeWalker, definitions: readonly EnhancementDefinition[], requested?: readonly string[]) => {
    context: TContext;
    applied: EnhancementDefinition[];
};
