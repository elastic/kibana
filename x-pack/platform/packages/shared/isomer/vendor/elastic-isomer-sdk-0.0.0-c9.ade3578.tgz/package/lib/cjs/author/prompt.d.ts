import type { PrimitiveCatalogEntry } from '../define/primitive_module';
import { type PrimitiveGroup } from '../pack/primitive_pack';
type JsonSchema = Record<string, unknown>;
/** Which authoring job the prompt frames for the model. */
export type AuthoringProfileId = 'general' | 'registered-view-router' | 'compose-from-primitives';
/**
 * A registered view, declared structurally so this module does not import the
 * runtime. {@link RegisteredViewSummary} must stay assignable to this.
 */
export interface AuthoringViewSummary {
    id: string;
    title: string;
    description?: string;
    /** Natural-language queries the view answers, printed so the model can route by them. */
    answers: readonly string[];
    /** JSON Schema for the view's input, printed inline when present. */
    inputSchema?: JsonSchema;
}
/** The pack-supplied material {@link buildAuthoringPrompt} assembles. */
export interface AuthoringPromptContext {
    guide: string;
    /** Absent or empty drops the `## Rules` section. */
    rules?: string;
    /** JSON Schema for a whole composition. Absent, or under the router profile, it is not inlined. */
    schema?: JsonSchema;
    /** Rendered as a bullet per entry, with its `useWhen`, `avoidWhen`, and `example`. */
    primitives: readonly PrimitiveCatalogEntry[];
    /** `'index'` lists each primitive's type and purpose only, for a host that serves the rest on request. */
    catalog?: 'full' | 'index';
    /** Headings an index sorts primitives under; a type in none is listed under {@link UNCATEGORIZED_GROUP_TITLE}. */
    groups?: readonly PrimitiveGroup[];
    /**
     * Extra host-supplied compositions beyond each primitive's catalog example.
     * Trimmed to the profile's budget. An empty list drops `## Examples`.
     */
    examples: readonly unknown[];
    /** Registered views the model can request by id. An empty list drops the section. */
    views?: readonly AuthoringViewSummary[];
    /** Defaults to `'# View authoring'`. */
    heading?: string;
    /** Replaces the profile's own framing sentence. */
    intro?: string;
}
/** One primitive's catalog bullet: its purpose, `useWhen`, `avoidWhen`, and example. */
export declare const formatPrimitiveEntry: (entry: PrimitiveCatalogEntry) => string;
/**
 * Assembles `context` into the prompt for `profile`, trimming the examples to
 * that profile's budget.
 *
 * The copy says "view" throughout because that is the wire discriminator and
 * the word models are trained and prompted on; pass `heading` and `intro` to
 * override it per host.
 */
export declare const buildAuthoringPrompt: (profile: AuthoringProfileId, context: AuthoringPromptContext) => string;
export {};
