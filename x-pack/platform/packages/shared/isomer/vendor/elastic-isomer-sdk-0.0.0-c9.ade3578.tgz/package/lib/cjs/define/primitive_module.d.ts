import type { ReactNode } from 'react';
import { z, type ZodObject, type ZodType } from 'zod';
import type { ActionEventRef } from '../composition/action_event';
import { type ChildNodeRef, type SurfaceName } from '../composition/body_node_base';
import type { PrimitiveNode } from '../composition/node';
import type { ValidationError } from '../composition/validation_error';
import type { MarkdownContent } from './markdown_content';
import type { PrimitiveExample } from './primitive_example';
import type { PrimitiveIcon } from './primitive_icon';
import type { SlackAssetCollector } from './slack_assets';
import type { SlackBlock } from './slack_blocks';
export type { PrimitiveNode };
/**
 * A primitive's entry in the catalog the authoring prompt is built from.
 *
 * Written for the model rather than for a developer: `useWhen` and `avoidWhen`
 * are what steer it away from reaching for the wrong primitive. `name` is the
 * one host-facing field, and the prompt never prints it.
 */
export interface PrimitiveCatalogEntry {
    type: string;
    /** Short name a host shows for the primitive, e.g. `Stat group`. Absent means the host derives one from `type`. */
    name?: string;
    /**
     * Description of this primitive's `$def` in the authoring JSON Schema.
     *
     * `z.toJSONSchema` drops refinements, so a cross-field rule is restated here.
     * {@link definePrimitive} copies `schema.description` when this is omitted.
     */
    description?: string;
    /** One line on what the primitive is for, in the model's voice. */
    purpose: string;
    /** Situations that call for this primitive. Phrase each as a user intent, not a shape. */
    useWhen: string[];
    /** Situations that look like a fit but are not, naming the primitive to reach for instead. */
    avoidWhen: string[];
    /** A node literal the authoring prompt inlines under this primitive. */
    example: unknown;
}
/** A style a renderer asks for by name, resolved to a class by the host's adapter. */
export interface StyleHandle {
    /** Stable lookup key. The adapter's map is keyed on this. */
    key: string;
    /** Debug-facing label, which an adapter may fold into a generated class name. */
    readableName: string;
}
/** Dotted path into a pack's theme tokens, e.g. `colors.text.subdued`. */
export type ThemeTokenPath = string;
/**
 * The sdk's own render context, and {@link DefaultPackTypes.context}.
 *
 * A pack with real theme tokens or a richer style-handle type declares its
 * own context in its {@link PackTypes}; {@link StyledRenderContext} is the
 * sdk's own extension. The bag is what lets a pack narrow without
 * re-declaring everything that mentions a context.
 */
export interface PrimitiveRenderContext {
    /**
     * The progressive enhancements this render may assume, by id. A set rather
     * than a field per feature so adding an enhancement costs no plumbing:
     * containers forward the whole context, and a renderer asks
     * `context.enhancements?.has('tableSort')`.
     *
     * Empty or absent is the baseline every host can render, so a renderer must
     * still answer the question on its own. See `docs/rendering.md`.
     */
    enhancements?: ReadonlySet<string>;
    /** Turns on `nodeAnchor` outside an HTML surface render, on the React and `snapshot` surfaces; inside one, the surface decides. */
    anchors?: boolean;
    /** Raises an interaction for the host to route. Absent means render non-interactively. */
    onEvent?: (event: ActionEventRef) => void;
}
/**
 * The render-context argument, optional only when omitting it is sound.
 *
 * The sdk's own {@link PrimitiveRenderContext} has no required field, so `{}`
 * is a complete value and a caller may leave it out. A pack that narrows the
 * context with a required member makes the argument mandatory.
 */
export type ReactContextArg<TContext> = Record<string, never> extends TContext ? [context?: TContext] : [context: TContext];
/**
 * {@link PrimitiveRenderContext} plus the CSS-in-JS hooks an HTML style adapter
 * supplies. A pack that styles differently uses its own `TContext` instead.
 */
export interface StyledRenderContext extends PrimitiveRenderContext {
    /** Resolves handles to a `className`. Absent means the host supplies no styling. */
    resolveClassName?: (...handles: StyleHandle[]) => string;
    /** Resolves a theme token to a CSS variable reference. Absent means inline the literal value. */
    cssVarRef?: (path: ThemeTokenPath) => `var(--${string})`;
}
/** Passed to a primitive's style collector so it can vary CSS by layout mode. */
export interface PrimitiveStyleCollectionContext {
    /** The render fills its container rather than sitting at a fixed width. */
    fluid?: boolean;
}
/** A pack's collected styles, opaque to the SDK. */
export type PrimitiveStyleCollector = object;
/**
 * The types a pack binds once and writes every primitive against: the palette
 * its frames supply, the context its `react` renderers receive, the collector
 * its `collectStyles` hooks mutate, and the Slack payload and collector types.
 *
 * Extend {@link DefaultPackTypes} and narrow only what the pack needs:
 *
 * ```ts
 * interface SlidesPackTypes extends DefaultPackTypes {
 *   theme: SlideTheme;
 *   context: SlideRenderContext;
 * }
 * ```
 */
export interface PackTypes {
    theme: unknown;
    context: unknown;
    collector: PrimitiveStyleCollector;
    slackBlock: unknown;
    slackCollector: unknown;
}
/** {@link PackTypes} as the sdk itself binds them, and the default everywhere. */
export interface DefaultPackTypes extends PackTypes {
    theme: unknown;
    context: PrimitiveRenderContext;
    collector: PrimitiveStyleCollector;
    slackBlock: SlackBlock;
    slackCollector: SlackAssetCollector;
}
/**
 * Each surface's renderer signature: the env bag it receives beyond the node,
 * and what it returns. A bag is additive: a new extra on a surface is not an
 * arity break.
 */
export interface SurfaceMap<T extends PackTypes = DefaultPackTypes> {
    react: {
        env: {
            context: T['context'];
            scope: RenderScope<T>;
            /**
             * The frame's resolved palette, inherited by descendants on `snapshot`.
             * Bare `react`/`html` renders leave it absent; browser colors follow CSS.
             */
            theme?: T['theme'];
        };
        output: ReactNode;
    };
    /**
     * Identical to `react`, and served by the same renderer: an image backend
     * lays out the pack's DOM tree and stylesheet rather than a second tree
     * authored for it. The surface stays separate so a node can be hidden from
     * snapshots alone, and so a {@link Frame} has something to draw inside.
     */
    snapshot: SurfaceMap<T>['react'];
    text: {
        env: {
            scope: RenderScope<T>;
        };
        output: string;
    };
    /** Content built with `md`, escaped where it lands; authored Markdown source goes through `md.authored`. */
    markdown: {
        env: {
            scope: RenderScope<T>;
        };
        output: MarkdownContent;
    };
    /**
     * Returns one payload or several, so a primitive need not wrap a single
     * payload in an array.
     */
    slack: {
        env: {
            collector?: T['slackCollector'];
            /** The host's absolute `http(s)` base for relative links; pass it to `slackLinkUrl` and `link`. `scope` already carries it to children. */
            baseUrl?: string;
            scope: RenderScope<T>;
        };
        output: T['slackBlock'] | readonly T['slackBlock'][];
    };
}
/**
 * The dispatcher a renderer is given so a container can recurse into a child
 * owned by another pack, passed as `scope` on every renderer's env bag.
 * Erased to {@link PrimitiveNode} by default: a heterogeneous inventory has no
 * single node type to name.
 */
export interface RenderScope<T extends PackTypes = DefaultPackTypes, TNode extends PrimitiveNode = PrimitiveNode> {
    /** Every primitive this dispatcher can reach, across all composed packs. */
    readonly definitions: readonly AnyPrimitiveDefinition[];
    /** Throws for an unknown node type; a missing primitive is a bug, not a degradation. */
    getDefinition(node: TNode): AnyPrimitiveDefinition;
    /** `undefined` when the node is hidden from `surface`, `sanitize` drops it, or its primitive declares no renderer for `surface`. */
    renderOn<S extends SurfaceName>(surface: S, node: TNode, extras: Omit<SurfaceMap<T>[S]['env'], 'scope'>): SurfaceMap<T>[S]['output'] | undefined;
    /**
     * The node's `react` renderer, or `undefined` when it is hidden or has none.
     * Inside a `snapshot` render, keeps snapshot visibility and the frame
     * palette. `context` may be omitted only when `{}` is a complete context for
     * the pack.
     */
    renderReact(node: TNode, ...context: ReactContextArg<T['context']>): ReactNode;
    /** Mutates `styles` with this node's contribution. */
    collectStyles(node: TNode, styles: T['collector'], context: PrimitiveStyleCollectionContext): void;
    /** `''` when the node is hidden from `text` or its primitive declares no `text` renderer. */
    renderText(node: TNode): string;
    /** The node's content serialized as GFM. */
    renderMarkdown(node: TNode): string;
    /** A child as content, for a container building with `md`; empty when the node is hidden from `markdown`. */
    renderMarkdownContent(node: TNode): MarkdownContent;
    /**
     * Empty when the node is hidden from `slack`, `sanitize` drops it, or its
     * renderer returns nothing. A node with no `slack` renderer degrades through
     * its markdown.
     */
    renderSlack(node: TNode, collector?: T['slackCollector']): readonly T['slackBlock'][];
    /** `0` when the node is hidden from `snapshot` or its primitive declares no `metrics.snapshotHeight`. */
    estimateSnapshotHeight(node: TNode): number;
    /**
     * Appends schema failures under `path` to `errors`, each naming `node`'s
     * type, and an unknown key on `node` listing the fields it declares.
     */
    validate(node: TNode, path: string, errors: ValidationError[]): void;
}
/** One surface's renderer for one node type, per {@link SurfaceMap}. */
export type Renderer<TNode extends PrimitiveNode, S extends SurfaceName, T extends PackTypes = DefaultPackTypes> = (node: TNode, env: SurfaceMap<T>[S]['env']) => SurfaceMap<T>[S]['output'];
/**
 * The surface a pack may declare beyond the mandatory three.
 *
 * Only `slack`, and even that stays optional per primitive: the dispatcher
 * converts the mandatory markdown to Block Kit, so a missing Slack renderer
 * degrades rather than disappearing. `snapshot` is not here because no primitive
 * implements it — the surface reuses `react`.
 */
export declare const OPTIONAL_SURFACES: readonly ["slack"];
/** One of the {@link OPTIONAL_SURFACES}. */
export type OptionalSurface = (typeof OPTIONAL_SURFACES)[number];
type MethodRenderer<TNode extends PrimitiveNode, S extends SurfaceName, T extends PackTypes> = {
    render(node: TNode, env: SurfaceMap<T>[S]['env']): SurfaceMap<T>[S]['output'];
}['render'];
/**
 * One renderer per surface a primitive implements.
 *
 * `react`, `text`, and `markdown` are always required: those three are what
 * make "every composition degrades" true. `react` serves the `snapshot` surface
 * too, so targeting images costs a primitive nothing.
 */
export type Renderers<TNode extends PrimitiveNode, T extends PackTypes = DefaultPackTypes> = {
    [S in Exclude<SurfaceName, OptionalSurface | 'snapshot'>]: MethodRenderer<TNode, S, T>;
} & {
    [S in OptionalSurface]?: MethodRenderer<TNode, S, T>;
};
/**
 * Measurements a frame can ask of a node before drawing it.
 *
 * `snapshotHeight` is optional. The height estimate is `0` when it is missing, so
 * a frame that sums node heights sizes short.
 */
export interface PrimitiveMetrics<TNode extends PrimitiveNode> {
    /** The node's drawn height in pixels at the frame's width. */
    snapshotHeight?: (node: TNode) => number;
}
/**
 * Every primitive's schema is an object schema, because {@link definePrimitive}
 * extends it with `id` and `surfaces` and the composition builds a
 * `z.discriminatedUnion('type', …)` over them. Typed as `ZodObject` rather
 * than `ZodType<unknown>` so a union or intersection schema is a compile
 * error at the definition, not a runtime failure at the first `.extend()`.
 * Zod 4 types `z.object().superRefine(…)` as a `ZodObject` and preserves the
 * refinement through `.extend()`, so top-level refinements are unaffected.
 */
export type PrimitiveSchema = ZodObject;
/**
 * The child-ref shape a primitive definition's own `children` returns.
 *
 * {@link ChildNodeRef} stays erased (`node: unknown`) because
 * `createChildNodeWalker` mixes children from every primitive type in the
 * runtime into one map and cannot name a single node type for them. A single
 * definition has no such excuse: its `children` should not type-check
 * against `unknown` and let something that is not a {@link PrimitiveNode} —
 * `null`, for instance — silently disappear from every tree walk.
 */
export interface PrimitiveChildRef extends ChildNodeRef {
    node: PrimitiveNode;
}
/**
 * One primitive: its node type, schema, catalog entry, and a renderer per
 * surface. The unit of vocabulary, and what {@link definePrimitive} takes.
 *
 * `T` is the pack's {@link PackTypes}, bound once with
 * {@link definePrimitiveFor} so each primitive names only `TNode`.
 */
export interface PrimitiveDefinition<TNode extends PrimitiveNode, T extends PackTypes = DefaultPackTypes, TSchema extends PrimitiveSchema = PrimitiveSchema> {
    /** The node's discriminant, and the key this primitive occupies in an inventory. */
    type: TNode['type'];
    /** How the authoring prompt describes this primitive to the model. */
    catalog: PrimitiveCatalogEntry;
    /** Host-facing glyph, never shown to the model. Absent means the host supplies its own. */
    icon?: PrimitiveIcon;
    /**
     * Driven by the conformance harness, bare or named; read them with
     * `exampleNodes` or `primitiveExamples`. The catalog `example` is what the
     * prompt shows.
     */
    examples: readonly (TNode | PrimitiveExample<TNode>)[];
    /**
     * This primitive on its own. A container declares
     * {@link PrimitiveDefinition.schemaFor} as well, and uses
     * {@link unresolvedBodyNodeSchema} in the child slot here.
     */
    schema: TSchema;
    /**
     * A container's schema, bound to the body-node union of the composition it is
     * being built into.
     *
     * Declaring the shape and letting each composition supply its own union is
     * what lets one primitive appear in two runtimes with different inventories:
     * `z.lazy` memoizes per instance, and an instance built here belongs to
     * exactly one union.
     */
    schemaFor?: (bodyNodeSchema: ZodType<unknown>) => PrimitiveSchema;
    /** One function per surface; `react` serves `snapshot` as well. */
    renderers: Renderers<TNode, T>;
    /** Sizing a frame can ask for before drawing. Absent means it cannot be measured. */
    metrics?: PrimitiveMetrics<TNode>;
    /**
     * Render-time URL trust, the second of the two layers in `validate/url.ts`.
     *
     * Returning `null` drops the node. Applied even to an unvalidated node, so a
     * renderer invoked directly still cannot emit an unsafe URL.
     */
    sanitize?: (node: TNode) => TNode | null;
    /**
     * Nested nodes, for containers, in the order the `react` renderer draws
     * them; `findNodeElementPairs` relies on it. Absent means a leaf.
     */
    children?: (node: TNode) => readonly PrimitiveChildRef[];
    /**
     * True when this node produces surface output of its own, not only via
     * {@link PrimitiveDefinition.children}. A non-empty `children` result is
     * otherwise the complete source of rendered content, so a hybrid container
     * that still owns string fields returns true to keep rendering when every
     * nested node is hidden from the surface.
     */
    hasOwnContent?: (node: TNode) => boolean;
    /** Contributes this node's CSS by mutating `styles`, once per node per render. */
    collectStyles?: (node: TNode, env: {
        styles: T['collector'];
        context: PrimitiveStyleCollectionContext;
    }) => void;
}
/**
 * {@link PrimitiveDefinition} with every type parameter erased, and the form an
 * inventory is stored in.
 *
 * A heterogeneous pack has no single `TNode` to be generic over, so every
 * function over the node degrades to `unknown` here.
 */
export interface AnyPrimitiveDefinition extends Pick<PrimitiveDefinition<PrimitiveNode>, 'type' | 'catalog' | 'icon' | 'examples' | 'schema' | 'schemaFor'> {
    renderers: {
        [S in keyof Renderers<PrimitiveNode>]: unknown;
    };
    metrics?: {
        [K in keyof PrimitiveMetrics<PrimitiveNode>]: unknown;
    };
    sanitize?: unknown;
    children?: unknown;
    hasOwnContent?: unknown;
    collectStyles?: unknown;
}
/** The `id` every node may carry, unique within a composition. */
export declare const bodyNodeIdSchema: z.ZodString;
/** The `surfaces` allowlist on a node. Absent means every surface; empty is rejected. */
export declare const bodyNodeSurfacesSchema: z.ZodArray<z.ZodEnum<{
    react: "react";
    snapshot: "snapshot";
    text: "text";
    markdown: "markdown";
    slack: "slack";
}>>;
/**
 * The child slot in a container's standalone {@link PrimitiveDefinition.schema},
 * where no body-node union is available.
 *
 * Deliberately permissive rather than `z.unknown()`: it still rejects a child
 * that is not a node at all, which is the error worth catching without an
 * inventory. Anything that depends on *which* types are legal — the validator,
 * the parser, the JSON Schema projection — goes through
 * {@link PrimitiveDefinition.schemaFor} and sees the real union.
 */
export declare const unresolvedBodyNodeSchema: z.ZodObject<{
    type: z.ZodString;
}, z.core.$loose>;
/**
 * Declares one primitive, extending its schema with the `id` and `surfaces`
 * fields every node carries, and closing it to unknown keys so a node is held
 * to the same rule as the composition root and the JSON Schema an agent reads.
 * A schema with its own catchall (`z.looseObject`) keeps it.
 *
 * A pack normally calls the form {@link definePrimitiveFor} binds to its own
 * {@link PackTypes}, so each primitive names only `TNode`.
 */
export declare const definePrimitive: <TNode extends PrimitiveNode, T extends PackTypes = DefaultPackTypes, TSchema extends PrimitiveSchema = PrimitiveSchema>(definition: PrimitiveDefinition<TNode, T, TSchema>) => PrimitiveDefinition<TNode, T, WithNodeFields<TSchema>>;
/**
 * {@link definePrimitive} bound to one pack's {@link PackTypes}.
 *
 * ```ts
 * const define = definePrimitiveFor<SlidesPackTypes>();
 * export const note = define({ type: 'note', … });
 * ```
 */
export declare const definePrimitiveFor: <T extends PackTypes>() => <TNode extends PrimitiveNode, TSchema extends PrimitiveSchema = PrimitiveSchema>(definition: PrimitiveDefinition<TNode, T, TSchema>) => PrimitiveDefinition<TNode, T, WithNodeFields<TSchema>>;
/**
 * `.extend()` on a generic `ZodObject` widens the shape to `any`, so the
 * return type is rebuilt from `TSchema`'s shape. The brand on a field schema
 * stays on that same object at runtime.
 */
export type WithNodeFields<TSchema extends PrimitiveSchema> = TSchema extends ZodObject<infer Shape> ? ZodObject<Shape & {
    id: ReturnType<typeof bodyNodeIdSchema.optional>;
    surfaces: ReturnType<typeof bodyNodeSurfacesSchema.optional>;
}> : PrimitiveSchema;
