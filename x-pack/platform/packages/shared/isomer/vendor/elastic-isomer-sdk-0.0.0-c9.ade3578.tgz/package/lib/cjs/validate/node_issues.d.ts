import type { core } from 'zod';
import type { ValidationError } from '../composition/validation_error';
import type { AnyPrimitiveDefinition } from '../define/primitive_module';
/** A node an issue path can start from, and its path. */
export type IssueRoot = readonly [node: unknown, path: string];
/**
 * Builds the formatter that converts Zod issues with {@link formatZodIssue},
 * each error naming the innermost node its path lands in when that node's type
 * is known, and an unknown key on a node appending {@link declaredFieldsNote}.
 */
export declare const createNodeIssueFormatter: (definitions: readonly AnyPrimitiveDefinition[]) => ((roots: readonly IssueRoot[], issues: ReadonlyArray<core.$ZodIssue>, basePath?: string) => ValidationError[]);
