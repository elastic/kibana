/**
 * Stable codes for {@link IsomerError}, {@link CompositionValidationError},
 * and the runtime's `RegisteredViewInputError`. Hosts branch on `code`, not
 * on `message`. Codes name the condition, not the throwing module: duplicate
 * type at `definePrimitivePack`, `composePacks`, and `createIsomerRuntime` is the same
 * `DUPLICATE_PRIMITIVE_TYPE`; the message names the layer.
 */
export declare const ISOMER_ERROR_CODES: {
    readonly AMBIGUOUS_FRAME: "AMBIGUOUS_FRAME";
    readonly AMBIGUOUS_STYLE_ADAPTER: "AMBIGUOUS_STYLE_ADAPTER";
    readonly AUTHOR_TYPE_MISMATCH: "AUTHOR_TYPE_MISMATCH";
    readonly AUTHORED_SCHEMA_REUSED: "AUTHORED_SCHEMA_REUSED";
    readonly COMPOSITION_INVALID: "COMPOSITION_INVALID";
    readonly CYCLIC_COMPOSITION: "CYCLIC_COMPOSITION";
    readonly DUPLICATE_AUTHORED_CHILD: "DUPLICATE_AUTHORED_CHILD";
    readonly DUPLICATE_ENHANCEMENT: "DUPLICATE_ENHANCEMENT";
    readonly DUPLICATE_FORMAT: "DUPLICATE_FORMAT";
    readonly DUPLICATE_PACK_ID: "DUPLICATE_PACK_ID";
    readonly DUPLICATE_PRIMITIVE_TYPE: "DUPLICATE_PRIMITIVE_TYPE";
    readonly DUPLICATE_VIEW: "DUPLICATE_VIEW";
    readonly EMPTY_FRAMES: "EMPTY_FRAMES";
    readonly EMPTY_PACK: "EMPTY_PACK";
    readonly EMPTY_PACKS: "EMPTY_PACKS";
    readonly EMPTY_PAGES: "EMPTY_PAGES";
    readonly EMPTY_VOCABULARY: "EMPTY_VOCABULARY";
    readonly ENHANCEMENT_ROOT_MISSING: "ENHANCEMENT_ROOT_MISSING";
    readonly EXPECTED_AUTHOR_COMPONENT: "EXPECTED_AUTHOR_COMPONENT";
    readonly EXPECTED_JSX_ELEMENT: "EXPECTED_JSX_ELEMENT";
    readonly EXPECTED_TEXT_CHILDREN: "EXPECTED_TEXT_CHILDREN";
    readonly INCOMPATIBLE_STYLE_COLLECTOR: "INCOMPATIBLE_STYLE_COLLECTOR";
    readonly INPUT_NOT_PLAIN_DATA: "INPUT_NOT_PLAIN_DATA";
    readonly INPUT_OVER_BUDGET: "INPUT_OVER_BUDGET";
    readonly INVALID_BASE_URL: "INVALID_BASE_URL";
    readonly INVALID_BODY_NODE: "INVALID_BODY_NODE";
    readonly INVALID_FRAME_BODY: "INVALID_FRAME_BODY";
    readonly INVALID_INPUT_BUDGET: "INVALID_INPUT_BUDGET";
    readonly INVALID_PACK_GROUPS: "INVALID_PACK_GROUPS";
    readonly MISSING_AUTHORED_TEXT: "MISSING_AUTHORED_TEXT";
    readonly MISSING_STYLE_ADAPTER: "MISSING_STYLE_ADAPTER";
    readonly RESERVED_NODE_FIELD: "RESERVED_NODE_FIELD";
    readonly UNEXPECTED_CHILDREN: "UNEXPECTED_CHILDREN";
    readonly UNKNOWN_FRAME: "UNKNOWN_FRAME";
    readonly UNKNOWN_PRIMITIVE_TYPE: "UNKNOWN_PRIMITIVE_TYPE";
    readonly UNKNOWN_SURFACE: "UNKNOWN_SURFACE";
    readonly UNKNOWN_VIEW: "UNKNOWN_VIEW";
    readonly UNSUPPORTED_CHILD_PATH: "UNSUPPORTED_CHILD_PATH";
    readonly VIEW_INPUT_INVALID: "VIEW_INPUT_INVALID";
    readonly VOCABULARY_UNRESOLVED: "VOCABULARY_UNRESOLVED";
};
/** One of {@link ISOMER_ERROR_CODES}. */
export type IsomerErrorCode = (typeof ISOMER_ERROR_CODES)[keyof typeof ISOMER_ERROR_CODES];
/**
 * Thrown for construction and authoring failures that are not a
 * `CompositionValidationError`.
 *
 * Identify it by `name` and `code`, never `instanceof`: the SDK ships both
 * ESM and CJS builds, so a host can hold two copies of this class and an
 * identity check would miss one.
 */
export declare class IsomerError extends Error {
    readonly code: IsomerErrorCode;
    constructor(code: IsomerErrorCode, message: string);
}
