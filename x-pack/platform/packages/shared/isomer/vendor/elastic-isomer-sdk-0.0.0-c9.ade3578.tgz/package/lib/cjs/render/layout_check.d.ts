import type { ChildNodeWalker } from '../composition/body_node_base';
/** A rectangle on the canvas, in pixels. */
export interface LayoutRect {
    readonly x: number;
    readonly y: number;
    readonly width: number;
    readonly height: number;
}
/** A laid-out element and the elements nested in it, as a layout engine measures them. */
export interface LayoutBox extends LayoutRect {
    /** Absent means unscaled. */
    readonly scale?: number;
    /** Text laid out in the box. */
    readonly runs?: readonly LayoutRect[];
    /** Where a {@link NODE_ANCHOR_ATTRIBUTE} is read from. */
    readonly attributes?: Readonly<Record<string, string>>;
    readonly children: readonly LayoutBox[];
}
/** A node drawn past the room its container gives it, or onto a sibling, by `by` pixels. */
export interface LayoutFinding {
    kind: 'overflow' | 'overlap';
    /** In validation's form, e.g. `body[1].items[0]`. */
    path: string;
    type: string;
    /** The sibling an `overlap` lands on. */
    with?: {
        path: string;
        type: string;
    };
    by: number;
}
/**
 * Where the nodes of `body` run past their room or onto each other in
 * `layout`, a measured render on `surface` with node anchors on. Empty when
 * nothing does.
 *
 * A node's room is the box of its nearest anchored or `layoutRoom` ancestor,
 * or `layout` at the top level, and only siblings under one room are
 * compared. Nothing inside a scaled box is checked. A finding is advice, not an error:
 * an overlap may be intended.
 */
export declare const checkLayout: (layout: LayoutBox, body: readonly unknown[], walk: ChildNodeWalker, surface: "react" | "snapshot") => LayoutFinding[];
