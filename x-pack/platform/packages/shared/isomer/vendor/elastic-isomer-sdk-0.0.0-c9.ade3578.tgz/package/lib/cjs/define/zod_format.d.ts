import type { core, ZodObject } from 'zod';
import type { ValidationError } from '../composition/validation_error';
/**
 * Builds a `body[3].items[0].label` style path from a Zod issue path. Empty
 * when the issue is at the schema root.
 */
export declare const formatPath: (segments: ReadonlyArray<PropertyKey>, basePath?: string) => string;
/**
 * Converts one Zod issue into a {@link ValidationError}.
 *
 * Schemas encode only the predicate (`must contain at least one bar`), so the
 * path stays separate. Missing required fields, enum issues, and unknown keys
 * are worded centrally, which is what keeps per-schema messages from restating
 * that boilerplate.
 *
 * Parse with `{ reportInput: true }`: Zod 4 omits `input` from an issue
 * otherwise, and a wrong type would then read as a missing field.
 */
export declare const formatZodIssue: (issue: core.$ZodIssue, basePath?: string) => ValidationError;
/** What an unknown-key error on a node of `schema` adds: the fields that node declares. */
export declare const declaredFieldsNote: ({ shape }: ZodObject) => string;
/** `must be one of: a, b`, each string option spelled as {@link nameText} spells it. */
export declare const oneOf: (options: readonly unknown[]) => string;
/**
 * Zod issues as {@link ValidationError}s, in order, each path under `basePath`.
 *
 * Missing required fields, enum issues, and unknown keys are worded centrally,
 * so a schema's own messages state only the predicate. Parse with
 * `{ reportInput: true }`: Zod 4 omits `input` from an issue otherwise, and a
 * wrong type would then read as a missing field.
 */
export declare const formatZodIssues: (issues: ReadonlyArray<core.$ZodIssue>, basePath?: string) => ValidationError[];
