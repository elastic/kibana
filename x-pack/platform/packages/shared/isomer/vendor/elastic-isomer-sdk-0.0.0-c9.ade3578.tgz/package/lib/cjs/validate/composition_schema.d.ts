import { z, type ZodObject, type ZodType } from 'zod';
import type { AnyPrimitiveDefinition } from '../define/primitive_module';
/** `Composition.meta`: provenance and freshness, every field optional. */
export declare const metaSchema: z.ZodObject<{
    source: z.ZodOptional<z.ZodString>;
    generatedAt: z.ZodOptional<z.ZodString>;
    ariaLabel: z.ZodOptional<z.ZodString>;
    provenance: z.ZodOptional<z.ZodObject<{
        source: z.ZodOptional<z.ZodString>;
        query: z.ZodOptional<z.ZodString>;
        provider: z.ZodOptional<z.ZodString>;
    }, z.core.$strip>>;
    freshness: z.ZodOptional<z.ZodObject<{
        asOf: z.ZodOptional<z.ZodString>;
        stale: z.ZodOptional<z.ZodBoolean>;
        ttlSeconds: z.ZodOptional<z.ZodNumber>;
    }, z.core.$strip>>;
    partialFailure: z.ZodOptional<z.ZodObject<{
        degraded: z.ZodOptional<z.ZodBoolean>;
        reason: z.ZodOptional<z.ZodString>;
    }, z.core.$strip>>;
}, z.core.$strip>;
/** Options for the `Composition` envelope schema a body-node union is wrapped in. */
export interface CompositionSchemaOptions {
    /** The union the envelope's `body` array holds, as {@link resolveVocabulary} builds it. */
    bodyNodeSchema: ZodType<unknown>;
}
/**
 * Wraps a body-node union in the `Composition` envelope.
 *
 * `.strict()`, so an unknown root key is an error rather than silently carried:
 * the format crosses vendor boundaries, and a typo'd field that validates is
 * worse than one that fails. Most callers want
 * {@link getCompositionSchemaForDefinitions} instead, which memoizes.
 */
export declare const buildCompositionSchema: ({ bodyNodeSchema, }: CompositionSchemaOptions) => ZodObject;
/**
 * One set of definitions resolved into a body-node union, with the schema
 * instance that actually landed in it per primitive type.
 *
 * The members matter to callers because a container's schema in the union is
 * built by `schemaFor` and is therefore *not* `definition.schema`. Anything
 * keyed on identity — the JSON Schema id registry, which names `$defs` — has to
 * be given these, or a container's projection silently loses its name.
 */
export interface ResolvedVocabulary {
    /** The discriminated union over every primitive type in this vocabulary. */
    bodyNodeSchema: ZodType<unknown>;
    /** Keyed by node type. A container's value comes from `schemaFor`, not `definition.schema`. */
    members: ReadonlyMap<string, ZodObject>;
}
/**
 * Builds a body-node union whose containers reference *this* union.
 *
 * The `z.lazy` closing the recursion is created here and discarded with the
 * vocabulary: it memoizes its getter after the first resolution, so one shared
 * across vocabularies would freeze on whichever union parsed first.
 */
export declare const resolveVocabulary: (definitions: readonly AnyPrimitiveDefinition[]) => ResolvedVocabulary;
/**
 * {@link resolveVocabulary}, discarding the member instances.
 *
 * Only for a caller with no id registry to name; anything projecting to JSON
 * Schema needs the members and should use {@link resolveVocabulary}.
 */
export declare const buildBodyNodeSchemaFromDefinitions: (definitions: readonly AnyPrimitiveDefinition[]) => ZodType<unknown>;
/**
 * A fresh `Composition` schema over `definitions`.
 *
 * Builds a new union per call. Prefer
 * {@link getCompositionSchemaForDefinitions} unless a fresh instance is
 * required.
 */
export declare const buildCompositionSchemaFromDefinitions: (definitions: readonly AnyPrimitiveDefinition[]) => ZodObject;
/**
 * {@link buildCompositionSchemaFromDefinitions}, memoized per definition array.
 * Prefer this whenever the caller does not need a fresh schema instance.
 */
export declare const getCompositionSchemaForDefinitions: (definitions: readonly AnyPrimitiveDefinition[]) => ZodObject;
