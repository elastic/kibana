/**
 * Escapes the three characters Slack treats as HTML in `mrkdwn` text.
 *
 * The formatting markers (`*`, `_`, `~`, `` ` ``) are left intact so callers
 * can compose markdown with them. Wrap text in {@link code} when literal
 * asterisks are needed.
 */
export declare const escapeMrkdwn: (value: string) => string;
/** `text` escaped and wrapped in mrkdwn bold markers. */
export declare const bold: (text: string) => string;
/** `text` escaped and wrapped in mrkdwn italic markers. */
export declare const italic: (text: string) => string;
/**
 * Inline code span. Contents are not mrkdwn-escaped, since `<` and friends are
 * literal inside a code span; only embedded backticks are demoted, to a
 * modifier letter that cannot close the span.
 */
export declare const code: (text: string) => string;
/**
 * Fenced code block. Slack honours the triple-backtick fence but not a language
 * hint. Embedded triple-backticks are demoted with a zero-width joiner so they
 * cannot terminate the block early.
 */
export declare const codeBlock: (text: string) => string;
/**
 * Whether `url` is an `http:` or `https:` URL with a DNS or IPv6 host that
 * `URL` prints as written, so nothing it repairs or encodes, such as a
 * backslash, whitespace, or non-ASCII, passes.
 */
export declare const isAbsoluteHttpUrl: (url: string) => boolean;
/** Where Slack output's relative links resolve. */
export interface SlackLinkOptions {
    /** Absolute `http(s)` URL a relative link resolves against; without it, a relative link prints its label. */
    baseUrl?: string;
}
/**
 * Throws `INVALID_BASE_URL` unless `baseUrl` is absent or an `http:` or
 * `https:` URL with a DNS or IPv6 host and no credentials.
 */
export declare const assertSlackBaseUrl: (baseUrl: string | undefined) => void;
/**
 * `href` when {@link sanitizeNavigationHref} passes it and it is an `http:` or
 * `https:` URL with a host, or a `mailto:` of well-formed mailboxes; `null`
 * otherwise. Slack has no page to resolve a relative URL against, so one links
 * only when `baseUrl` is given, resolved onto its origin; a fragment, such as
 * `BLOCKED_HREF`, never resolves.
 */
export declare const slackLinkUrl: (href: string, baseUrl?: string) => string | null;
/**
 * Slack mrkdwn link, `<url|label>`, or a bare `<url>` when `label` is omitted.
 *
 * URL and label are both escaped so `&` and `>` cannot break Slack's link
 * parser, and a `|` in the URL is percent-encoded so it cannot end the URL
 * early. A URL {@link slackLinkUrl} rejects degrades to plain escaped text
 * with no link.
 */
export declare const link: (url: string, label?: string, baseUrl?: string) => string;
/**
 * Truncates `value` to `max` UTF-16 code units at a grapheme boundary,
 * appending an ellipsis when it had to cut. Pass a `SLACK_LIMITS` constant as
 * the budget.
 */
export declare const clampSlackText: (value: string, max: number) => string;
/**
 * {@link clampSlackText} for `mrkdwn`: never cuts inside a `<…>` link or
 * mention or an entity. Formatting marks are left as they fall; Slack prints an
 * unclosed one as written.
 */
export declare const clampMrkdwn: (value: string, max: number) => string;
/**
 * `value` cut to `max` UTF-16 code units, never through a surrogate pair. For
 * opaque values a host reads back, which an ellipsis would change.
 */
export declare const cutSlackValue: (value: string, max: number) => string;
/**
 * Collapses whitespace and clamps to `SLACK_LIMITS.headerTextChars`. Header
 * text is `plain_text`, so no markdown survives — do not pre-format it.
 */
export declare const formatHeaderText: (value: string) => string;
