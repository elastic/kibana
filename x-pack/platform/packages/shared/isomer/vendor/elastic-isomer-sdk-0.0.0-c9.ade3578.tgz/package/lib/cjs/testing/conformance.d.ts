import type { ChildNodeWalker } from '../composition/body_node_base';
import type { Composition } from '../composition/composition';
import type { ValidationError } from '../composition/validation_error';
import type { AnyPrimitiveDefinition, PrimitiveNode } from '../define/primitive_module';
import type { HTMLRenderResult } from '../render/html/envelope';
import type { SlackBlock } from '../render/slack/blocks';
import type { ValidationResult } from '../validate/validation';
/**
 * The foreign node {@link PrimitiveConformanceHarness.nestForeignChild}
 * hands a container must render text/markdown containing this string, or the
 * cross-pack nesting case cannot tell a dropped child from an empty one.
 */
export declare const CONFORMANCE_FOREIGN_MARKER = "isomerConformanceForeign";
/** The `title` {@link PrimitiveConformanceHarness.wrapComposition} must give its composition. */
export declare const CONFORMANCE_FIXTURE_TITLE = "Conformance fixture";
/** One example node, paired with the definition that published it. */
export interface PrimitiveConformanceExample {
    readonly definition: AnyPrimitiveDefinition;
    /** Always `definition.type`, lifted onto the row so `it.each` titles can read it. */
    readonly type: string;
    /** Index into {@link AnyPrimitiveDefinition.examples}, and half of the preview hint a failure prints. */
    readonly exampleIndex: number;
    /** The example's `name`, absent for a bare node. */
    readonly exampleName?: string;
    readonly node: PrimitiveNode;
}
/** The subset of a host's HTML render options the cases exercise. */
export interface PrimitiveConformanceHtmlOptions {
    /** `'separate'` must move the stylesheet out of the markup and into `css`; the CSS cases assert against that field. */
    readonly css?: 'inline' | 'separate';
    /** `'readable'` must emit human-legible class names, which the CSS coverage case matches back against the emitted selectors. */
    readonly names?: string;
    /** Must render node anchors, as the `anchors` HTML render option does. */
    readonly anchors?: boolean;
}
/** The subset of a host's `snapshot` render result the cases assert on. */
export interface PrimitiveConformanceSnapshotResult {
    /** Must be empty for every published example. */
    readonly validationErrors: readonly ValidationError[];
    /** The frame's markup, stylesheet included or not. */
    readonly html: string;
    /** `total` is the rendered byte size, and must be positive. */
    readonly measurement: {
        readonly total: number;
    };
}
/** The subset of a host's Slack render result the cases assert on. */
export interface PrimitiveConformanceSlackResult {
    readonly blocks: readonly SlackBlock[];
    /** Notification fallback text. Must be non-empty. */
    readonly text: string;
}
/**
 * Pack-owned render and validation bindings. The cases cannot import a
 * vocabulary package, so the pack closes over its dispatcher, frame, and
 * theme when it builds this object.
 *
 * Unsuffixed members take a single node; the `Composition`-suffixed ones take
 * a whole {@link Composition}. Optional members gate the cases that need
 * them, so a pack supplies only what its surfaces can answer.
 */
export interface PrimitiveConformanceHarness {
    /**
     * The smallest composition that carries one node. Its `title` must be
     * {@link CONFORMANCE_FIXTURE_TITLE}, which the envelope cases look for as
     * `CONFORMANCE FIXTURE` in text and `# Conformance fixture` in markdown.
     */
    wrapComposition(node: PrimitiveNode): Composition;
    /** Validation errors for the node on its own. Must be empty for every published example. */
    validateNode(node: PrimitiveNode): readonly ValidationError[];
    /** Whole-composition validation. Must be `valid` with no `errors` for a wrapped example. */
    validateComposition(composition: Composition): ValidationResult;
    /** Must return something other than `undefined`; the case does not mount the element. */
    renderReact(node: PrimitiveNode): unknown;
    /** Drives the pack's style collection for one node. Must not throw. */
    collectStyles(node: PrimitiveNode): void;
    /** Must return a string with non-whitespace content. */
    renderText(node: PrimitiveNode): string;
    /** Must return a string with non-whitespace content. */
    renderMarkdown(node: PrimitiveNode): string;
    /** Must return at least one block, each an object with a string `type`. */
    renderSlack(node: PrimitiveNode): readonly SlackBlock[];
    /** `key` is unique per example and only has to survive into the React tree. Must not throw. Omit for a pack with no `snapshot` path. */
    renderSnapshotNode?(node: PrimitiveNode, key: string): unknown;
    /** Must be finite and greater than zero, so a frame can lay the node out unrendered. Omit for a pack with no `snapshot` path. */
    estimateSnapshotHeight?(node: PrimitiveNode): number;
    /**
     * Set `false` for a pack whose frame is a fixed size, so its primitives are
     * not required to report a positive `metrics.snapshotHeight`. Skips the
     * positive-finite height assertion.
     */
    sizesFromNodeHeights?: boolean;
    /**
     * For a container example, returns `container` with one of its children
     * replaced by a node from a pack the harness composed in only for this
     * check — never one `container`'s own pack registers. That node's `text`
     * and `markdown` renderers must emit {@link CONFORMANCE_FOREIGN_MARKER}.
     * Omit to skip the cross-pack nesting case.
     */
    nestForeignChild?(container: PrimitiveNode): PrimitiveNode;
    /**
     * Must honor {@link PrimitiveConformanceHtmlOptions}. Cases assert the
     * markup wraps the body in a `<section>`, that `measurement.js` is zero, and
     * that `validationErrors` is empty. Omit to skip the HTML cases.
     */
    renderHTML?(composition: Composition, options?: PrimitiveConformanceHtmlOptions): HTMLRenderResult;
    /**
     * The child walker over every definition the harness renders with. Set it
     * once every `react` renderer spreads `nodeAnchor` on its root; the anchor
     * case then asserts each node renders one.
     */
    anchorWalk?: ChildNodeWalker;
    /** Must throw when `css` references a `var(--name)` it never declares. Omit to skip the CSS variable case. */
    assertVarRefsHaveDeclarations?(css: string): void;
    /** Whole-composition text render, title envelope included. */
    renderTextComposition(composition: Composition): string;
    /** Whole-composition markdown render, title heading included. */
    renderMarkdownComposition(composition: Composition): string;
    /** Must lead with a `plain_text` header block carrying the composition title. */
    renderSlackComposition(composition: Composition): PrimitiveConformanceSlackResult;
    /** Must resolve to non-empty markup with no validation errors. Omit for a pack with no frame. */
    renderSnapshotComposition?(composition: Composition): Promise<PrimitiveConformanceSnapshotResult>;
}
/** One assertion, run once per example. */
export interface PrimitiveConformanceCase {
    readonly name: string;
    /** Signals failure by throwing. May be async, so a pack must await it. */
    readonly run: (example: PrimitiveConformanceExample, harness: PrimitiveConformanceHarness) => void | Promise<void>;
}
/** Every definition's examples, flattened to one row each. */
export declare const examplesFromDefinitions: (definitions: readonly AnyPrimitiveDefinition[]) => readonly PrimitiveConformanceExample[];
/** Every example crossed with every case, shaped for `it.each`. */
export declare const primitiveConformanceRows: (definitions: readonly AnyPrimitiveDefinition[]) => readonly (PrimitiveConformanceExample & PrimitiveConformanceCase)[];
/**
 * Asserts the inventory itself holds up: the pack has examples, every
 * definition contributes one, `catalog.name` and example names are non-empty,
 * example names are unique within their definition, each example's `type` matches its definition, and
 * `catalog.example` is within the input budget and parses or matches a
 * published example.
 */
export declare const runPrimitiveInventoryConformance: (definitions: readonly AnyPrimitiveDefinition[]) => void;
/**
 * Every assertion a primitive owes its callers, for a pack to drive with
 * `it.each`.
 */
export declare const primitiveConformanceCases: readonly PrimitiveConformanceCase[];
