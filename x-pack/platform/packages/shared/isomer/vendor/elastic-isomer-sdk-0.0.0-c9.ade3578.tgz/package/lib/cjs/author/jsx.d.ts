/**
 * Brand carrying the primitive type an authoring component stands for.
 *
 * `Symbol.for` rather than `Symbol()`: the SDK ships both ESM and CJS builds,
 * so a host can hold two copies of this module and a unique symbol would make
 * one build's components unreadable to the other's shim.
 */
export declare const authorType: unique symbol;
/**
 * A JSX component that renders `null` and exists only to carry `TType` through
 * the tree until the shim converts it to a composition.
 */
export interface AuthorComponent<TProps, TType extends string> {
    (props: TProps): null;
    readonly [authorType]: TType;
    /** Set to `type` by the shim. */
    displayName?: string;
}
/** The {@link AuthorComponent} for one primitive `type`. */
export declare const defineAuthorComponent: <TProps, TType extends string>(type: TType) => AuthorComponent<TProps, TType>;
