/** A tag found by {@link findHostTags}. */
export interface HostTag {
    /** Offset of the `<` in the source. */
    readonly index: number;
    /** The tag as written. */
    readonly raw: string;
    /** The name as listed in the options. */
    readonly name: string;
    /** Values as written, keyed by lower-cased name; a bare attribute is `''`. */
    readonly attributes: Readonly<Record<string, string>>;
}
/** Every tag named in `names` (matched case-insensitively and whole), in source order. */
export declare const findHostTags: (source: string, names: readonly string[]) => HostTag[];
