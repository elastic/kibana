import type { AnyPrimitiveDefinition } from '../define/primitive_module';
import { type CompositionJsonSchemaOptions } from './json_schema';
type JsonSchema = Record<string, unknown>;
/** Options for {@link buildAuthoringJsonSchema}. */
export interface AuthoringJsonSchemaOptions extends CompositionJsonSchemaOptions {
    /** `$def` id to `description`. Survives `z.toJSONSchema` dropping `.refine` text. */
    describe?: Readonly<Record<string, string>>;
}
/**
 * Projects a composition to the JSON Schema an agent reads.
 *
 * `buildCompositionJsonSchema` stays the validator projection. This walk
 * names shared SDK defs, inlines scalar leaves, and drops host-only fields.
 */
export declare const buildAuthoringJsonSchema: (definitions: readonly AnyPrimitiveDefinition[], options?: AuthoringJsonSchemaOptions) => JsonSchema;
/**
 * The `$defs` that `types` reach in a schema from {@link buildAuthoringJsonSchema},
 * keyed as `schema` keys them, with the body-node union stubbed so a container
 * does not pull in every primitive.
 */
export declare const authoringSchemaSubset: (schema: JsonSchema, types: readonly string[]) => {
    $defs: Record<string, unknown>;
};
/**
 * The `body` of a schema from {@link buildAuthoringJsonSchema} as a schema of
 * its own, for an editor that validates body nodes rather than a whole
 * composition. Carries the `$defs` the body reaches.
 */
export declare const authoringBodySchema: (schema: JsonSchema) => JsonSchema;
export {};
