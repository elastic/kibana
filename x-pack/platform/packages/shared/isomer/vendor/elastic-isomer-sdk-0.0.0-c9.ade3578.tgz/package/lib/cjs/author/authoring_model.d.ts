import { type AuthoredChildField, type AuthoredSpec } from './authored_fields';
export interface ChildSlot {
    array: boolean;
    field: string;
}
export interface AuthoringChild {
    field: AuthoredChildField;
    primitiveType: string;
    /** Property name on the primitive's component, e.g. `Item`. */
    member: string;
    /** What the member's elements carry as {@link authorType}, e.g. `slideList.Item`. */
    authorType: string;
    path: readonly AuthoredChildField[];
}
/** The {@link AuthoringChild.authorType} of `field`'s elements under the primitive `owner`. */
export declare const memberType: (owner: string, { name }: Pick<AuthoredChildField, "name">) => string;
export declare const createAuthoringModel: (primitives: readonly {
    type: string;
    schema?: unknown;
    children?: unknown;
}[]) => {
    authoredByType: Map<string, AuthoredSpec>;
    membersByType: Map<string, AuthoringChild[]>;
    childSlotsByType: Map<string, ChildSlot[]>;
};
/**
 * Reads {@link PrimitiveDefinition.children} against a probe node so JSX can
 * fill the same fields a tree walk would visit. Paths like `body[0]` are array
 * slots; a bare `header` is a single nested node.
 */
export declare const inferChildSlots: (children: unknown) => readonly ChildSlot[];
export declare const capitalize: (value: string) => string;
