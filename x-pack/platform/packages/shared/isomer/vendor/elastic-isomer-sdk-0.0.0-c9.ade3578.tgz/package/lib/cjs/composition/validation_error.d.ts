import { type IsomerErrorCode } from './error';
/**
 * One fatal validation finding.
 *
 * `path` locates the offending value (`body[3].items[0].label`) and is empty
 * for a finding about the document as a whole. `message` is a predicate
 * (`is required`, `must be one of: a, b`) so the two read as one sentence
 * through {@link formatValidationError}.
 */
export interface ValidationError {
    path: string;
    message: string;
    /** The `type` of the innermost primitive node `path` lands in, when there is one. */
    nodeType?: string;
    /** Set only on a refusal from `checkInputBudget`: `INPUT_OVER_BUDGET` or `INPUT_NOT_PLAIN_DATA`. */
    code?: IsomerErrorCode;
}
/** `<path> (in <nodeType>) <message>`, or the message alone for a root finding. */
export declare const formatValidationError: ({ path, message, nodeType, }: ValidationError) => string;
/**
 * Thrown when a `Composition` fails validation, carrying every finding
 * rather than only the first.
 *
 * Identify it by `name`, `code`, and `errors`, never `instanceof`: the SDK
 * ships both ESM and CJS builds, so a host can hold two copies of this class
 * and an identity check would miss one.
 */
export declare class CompositionValidationError extends Error {
    readonly code: "COMPOSITION_INVALID";
    readonly errors: ValidationError[];
    constructor(errors: ValidationError[]);
}
