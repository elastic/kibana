import { type ReactNode } from 'react';
import { type ChildNodeWalker } from '../../composition/body_node_base';
import type { Composition } from '../../composition/composition';
import type { RenderTheme } from '../../composition/named_color';
import type { ValidationError } from '../../composition/validation_error';
import type { AnyPrimitiveDefinition, PrimitiveNode, PrimitiveStyleCollectionContext, PrimitiveStyleCollector, StyledRenderContext } from '../../define/primitive_module';
import { type CheckedValidationResult, type ValidationErrorMode } from '../../validate/validation';
import { type PayloadMeasurement } from '../payload';
import { type ReactContentDispatcher } from '../react/content';
import { type EnhancementDefinition } from './enhancements';
/** Knobs for the HTML surface. Every field defaults, so `{}` is valid. */
export interface HTMLRenderOptions {
    /** Overrides {@link Composition.theme}; `auto` when neither is set. */
    theme?: RenderTheme;
    /** Drops whitespace between tags that spans a line break, leaving `<pre>`, `<script>`, `<style>`, and `<textarea>` content intact. Defaults to `true`. */
    minify?: boolean;
    /** Adds the `fluid` wrapper class and reaches the pack as {@link PrimitiveStyleCollectionContext.fluid}; the adapter decides what it changes. */
    fluid?: boolean;
    /** Adds the `framed` wrapper class the adapter styles as a frame. Defaults to `true`. */
    framed?: boolean;
    /**
     * Renders the composition's title and subtitle. Defaults to `true`. Set
     * `false` when the embedding host already shows the title itself — the title
     * still backs the wrapper's `aria-label`.
     */
    heading?: boolean;
    /** Whether the collected CSS is inlined as a `<style>` element. Defaults to `'inline'`. */
    css?: 'inline' | 'separate';
    /**
     * Who runs the enhancement script. Defaults to `'embedded'`: `html` carries
     * a `<script>` that finds its own `.isomer` section when the page parses it.
     *
     * `'embedded'` never runs inside a shadow root, or anywhere the host inserts
     * `html` itself (`innerHTML`, a React tree). Use `'host'` there: `html`
     * carries no `<script>`, and the host calls `runEnhancementScript(js,
     * section)` after inserting it.
     */
    scripts?: 'embedded' | 'host';
    /** Defaults to collecting into {@link HTMLRenderResult.validationErrors}; `'throw'` raises instead. Input the budget refused raises in either mode. */
    onValidationError?: ValidationErrorMode;
    /** Opt-in by {@link EnhancementDefinition.id}. One whose content gate does not match the body is dropped. */
    enhancements?: readonly string[];
    /** `true` renders node anchors whether or not an enhancement asks for them, e.g. for tests. `false` cannot turn off anchors an enhancement needs. */
    anchors?: boolean;
    /**
     * Resolves `light-dark(…)` in the stylesheet to one scheme's value. A browser
     * resolves it itself; an image is one static frame, so the `snapshot` surface sets
     * it.
     */
    scheme?: 'light' | 'dark';
}
/**
 * One rendered HTML payload.
 *
 * `body` is the primitive markup alone; `html` adds the wrapper element, on
 * the default `css: 'inline'` a `<style>`, and on the default
 * `scripts: 'embedded'` a `<script>`. `css` and `js` are populated either way.
 * `validationErrors` are the messages that survived
 * {@link HTMLRenderOptions.onValidationError}.
 */
export interface HTMLRenderResult {
    html: string;
    css: string;
    /**
     * The enhancement script as a function body over `root`, or `''`. Under
     * `scripts: 'embedded'` the `<script>` in `html` wraps the same body; under
     * `'host'` the host runs it with `runEnhancementScript`. It is never a
     * complete script on its own.
     */
    js: string;
    body: string;
    measurement: PayloadMeasurement;
    validationErrors: ValidationError[];
}
/**
 * A pack's HTML entry point: the React renderer plus the style pass that runs
 * ahead of it.
 */
export interface HTMLRenderDispatcher<TNode extends PrimitiveNode, TCollector extends PrimitiveStyleCollector = PrimitiveStyleCollector, TContext = StyledRenderContext> extends ReactContentDispatcher<TNode, TContext> {
    /** The whole composition's inventory: a child walker built from one pack's definitions cannot descend into another pack's container. */
    readonly definitions: readonly AnyPrimitiveDefinition[];
    /** One node's style pass, driven by {@link HTMLStyleAdapter.collectViewStyles} rather than called by the sdk. */
    collectStyles(node: TNode, collector: TCollector, context: PrimitiveStyleCollectionContext): void;
}
/**
 * The composition's child walker and the enhancements every loaded pack
 * declared. Threaded into the style adapter so content-gating can see a
 * table nested inside a container from another package.
 */
export interface HTMLEnhancementScope {
    walk: ChildNodeWalker;
    definitions: readonly EnhancementDefinition[];
}
/**
 * How a pack turns its nodes into CSS. Optional overall — without an adapter
 * the render still produces markup, just with no class names and an empty
 * `TContext`.
 */
export interface HTMLStyleAdapter<TNode extends PrimitiveNode = PrimitiveNode, TCollector extends PrimitiveStyleCollector = PrimitiveStyleCollector, TContext = StyledRenderContext> {
    /**
     * Names the collector shape {@link HTMLStyleAdapter.createCollector} returns, so a runtime can
     * reject a pack whose `collectStyles` hooks were written against a different one.
     */
    styleCollector?: string;
    /** One collector per render, shared by every other hook here and by both render passes. */
    createCollector(options: HTMLRenderOptions): TCollector;
    /**
     * Settles options that depend on the composition, before anything reads them.
     *
     * Needed by an adapter whose look is chosen per render: deciding `framed`
     * from the body has to happen before the wrapper class is written, not while
     * CSS is collected.
     */
    resolveOptions?(composition: Composition<TNode>, options: HTMLRenderOptions): HTMLRenderOptions;
    /**
     * The `.isomer` / `.isomer.framed` / `.isomer.fluid` rules around a rendered composition.
     * Named for the wrapper rather than the frame, which the sdk reserves for the
     * document a snapshot is drawn inside.
     */
    collectWrapperStyles?(collector: TCollector, options: HTMLRenderOptions): void;
    /** Walks the body into the collector, usually through {@link HTMLRenderDispatcher.collectStyles}. Runs before any markup exists. */
    collectViewStyles?(composition: Composition<TNode>, dispatcher: HTMLRenderDispatcher<TNode, TCollector, TContext>, collector: TCollector, context: PrimitiveStyleCollectionContext, options: HTMLRenderOptions, scope: HTMLEnhancementScope): void;
    /** Runs once the collection pass has rendered the body, for styles only a renderer can discover. That markup is discarded. */
    collectAfterRender?(composition: Composition<TNode>, collector: TCollector, options: HTMLRenderOptions): void;
    /**
     * Builds the render context handed to every `react` renderer. Called once
     * per pass, so an adapter that behaves differently while collecting returns
     * a different context then. Must be complete, because `TContext` is the
     * pack's own type. The sdk never writes to it: whether renderers anchor
     * is the surface's decision, whatever the context's `anchors` says.
     */
    createRenderContext(collector: TCollector, options: HTMLRenderOptions): TContext;
    /** The collected CSS as text, with no `<style>` wrapper; the sdk adds one when `css` is `'inline'`. */
    renderStyles(collector: TCollector, options: HTMLRenderOptions): string;
    /**
     * Added to the render's one script, ahead of the enhancements'. A function body with `root` in scope, under the same
     * rules as {@link EnhancementDefinition.script}.
     */
    getScriptText?(composition: Composition<TNode>, options: HTMLRenderOptions, scope: HTMLEnhancementScope): string;
}
/** What {@link renderHTMLWithDispatcher} needs beyond the composition. */
export interface HTMLDispatcherRenderOptions<TNode extends PrimitiveNode, TCollector extends PrimitiveStyleCollector = PrimitiveStyleCollector, TContext = StyledRenderContext> {
    dispatcher: HTMLRenderDispatcher<TNode, TCollector, TContext>;
    /** Runs once before rendering, which draws the composition it returns; {@link HTMLRenderOptions.onValidationError} decides what becomes of its errors. Defaults to `createCompositionValidator(dispatcher.definitions)`. */
    validate?: (composition: Composition<TNode>) => CheckedValidationResult<TNode>;
    options?: HTMLRenderOptions;
    /** Used only when the composition has neither `meta.ariaLabel` nor a `title`. Defaults to `'View'`. */
    defaultAriaLabel?: string;
    styleAdapter?: HTMLStyleAdapter<TNode, TCollector, TContext>;
    /**
     * Progressive enhancements declared by the packs this render was composed
     * from. The render resolves {@link HTMLRenderOptions.enhancements} against
     * them once, hands every renderer the set as `context.enhancements`, and
     * emits each resolved one's script.
     */
    enhancementDefinitions?: readonly EnhancementDefinition[];
}
/** What {@link collectHTMLStyles} runs a style adapter's hooks over. */
export interface HTMLStyleCollectionOptions<TNode extends PrimitiveNode, TCollector extends PrimitiveStyleCollector = PrimitiveStyleCollector, TContext = StyledRenderContext> {
    dispatcher: HTMLRenderDispatcher<TNode, TCollector, TContext>;
    /** Without one, nothing is collected: the context is `{}` and the CSS `''`. */
    styleAdapter?: HTMLStyleAdapter<TNode, TCollector, TContext> | undefined;
    /** Already settled by {@link HTMLStyleAdapter.resolveOptions}. */
    options: HTMLRenderOptions;
    /** Every composition the one stylesheet serves, such as a deck's pages. */
    compositions: readonly Composition<TNode>[];
    /**
     * Handed to {@link HTMLStyleAdapter.collectViewStyles}. Its `definitions`
     * are the enhancements an adapter may collect styles for; `[]` for none.
     */
    scope: HTMLEnhancementScope;
    /** Draws the collection pass from the context it is given. Its markup is discarded. */
    render: (context: TContext) => ReactNode;
    /** Renders the collection pass with node anchors on. Defaults to `false`. */
    anchors?: boolean;
}
/** A collected stylesheet and the render context that resolves against it. */
export interface HTMLStyleCollection<TContext = StyledRenderContext> {
    context: TContext;
    css: string;
}
/**
 * Runs a style adapter's collection pass: wrapper and view styles, a discarded
 * render, then {@link HTMLStyleAdapter.collectAfterRender}. Class names are
 * collected as a side effect of rendering, so `render` must be free of side
 * effects, and the final render must draw what it drew.
 */
export declare const collectHTMLStyles: <TNode extends PrimitiveNode, TCollector extends PrimitiveStyleCollector = PrimitiveStyleCollector, TContext = StyledRenderContext>({ dispatcher, styleAdapter, options, compositions, scope, render, anchors, }: HTMLStyleCollectionOptions<TNode, TCollector, TContext>) => HTMLStyleCollection<TContext>;
/**
 * Renders a composition to standalone HTML: the wrapper element, the pack's
 * markup, and its CSS either inlined or returned separately.
 *
 * Runs the pack twice when a style adapter is present — once to collect
 * styles, once with the render context those styles produced — so a
 * `renderReact` implementation must be free of side effects.
 */
export declare const renderHTMLWithDispatcher: <TNode extends PrimitiveNode, TCollector extends PrimitiveStyleCollector = PrimitiveStyleCollector, TContext = StyledRenderContext>(input: Composition<TNode>, { dispatcher, validate, options: rawOptions, defaultAriaLabel, styleAdapter, enhancementDefinitions, }: HTMLDispatcherRenderOptions<TNode, TCollector, TContext>) => HTMLRenderResult;
