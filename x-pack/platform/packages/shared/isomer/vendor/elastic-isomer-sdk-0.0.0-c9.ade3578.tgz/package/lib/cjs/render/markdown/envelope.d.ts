import type { Composition } from '../../composition/composition';
import type { PrimitiveNode } from '../../define/primitive_module';
import type { TextEnvelopeDispatcher } from '../text/envelope';
/** Adds GFM to {@link TextEnvelopeDispatcher}. */
export interface MarkdownEnvelopeDispatcher<TNode extends PrimitiveNode> extends TextEnvelopeDispatcher<TNode> {
    /** Returns the empty string for a node with nothing to show; the envelope drops it rather than emitting a blank block. */
    renderMarkdown(node: TNode): string;
}
/** Options for {@link renderMarkdownEnvelope}. */
export interface MarkdownEnvelopeOptions {
    /** Renders the composition's title and subtitle. Defaults to `true`. Pass `false` when the host already shows the title, or the body opens with its own. */
    heading?: boolean;
}
/**
 * The composition as GFM: title as `h1`, subtitle italicized, then every node
 * that rendered anything. The title and subtitle are text, escaped by
 * {@link serializeMarkdown}.
 */
export declare const renderMarkdownEnvelope: <TNode extends PrimitiveNode>(composition: Composition<TNode>, dispatcher: MarkdownEnvelopeDispatcher<TNode>, { heading }?: MarkdownEnvelopeOptions) => string;
