import type { MarkdownContent } from '../../define/markdown_content';
/** A piece of authored Markdown, or one of the host's elements cut out of it. */
export type AuthoredMarkdownSegment = {
    type: 'markdown';
    content: MarkdownContent;
    /** The text `content` was built from, for a host that stores a string and passes it to `md.authored` later. */
    source: string;
} | {
    type: 'element';
    /** The name as listed in {@link SplitAuthoredMarkdownOptions.elements}. */
    name: string;
    /** Attribute values as written, keyed by lower-cased name; a bare attribute is `''`. */
    attributes: Readonly<Record<string, string>>;
};
export interface SplitAuthoredMarkdownOptions {
    /** Tag names to cut out, matched case-insensitively and whole. */
    readonly elements: readonly string[];
}
/**
 * Splits authored Markdown at the host's own elements, such as
 * `<render_attachment id="…" />`, so the host can replace each with content
 * of its own without cutting the raw string. The source is parsed once, so a
 * tag in code, a link destination or title, an image's alt text, or raw HTML
 * stays text, and a list, table, quote, or emphasis around a tag stays whole.
 * Each `markdown` segment is sanitized as `md.authored` sanitizes; past the
 * parse budget the source is cut at each tag into inert pieces.
 *
 * @example
 * splitAuthoredMarkdown(message, { elements: ['render_attachment'] })
 */
export declare const splitAuthoredMarkdown: (source: string, { elements }: SplitAuthoredMarkdownOptions) => AuthoredMarkdownSegment[];
