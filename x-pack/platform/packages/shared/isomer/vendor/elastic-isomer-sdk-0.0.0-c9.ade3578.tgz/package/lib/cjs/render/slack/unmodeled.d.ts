import type { SlackBlock, SlackContainerChildBlock } from './blocks';
/** Whether Isomer models Block Kit blocks of `type`, so a renderer returns them as a {@link SlackBlock} without {@link unmodeledSlackBlock}. */
export declare const isModeledSlackBlockType: (type: string) => type is SlackBlock["type"];
/**
 * A Block Kit block Isomer does not model yet, typed so a `slack` renderer can return it or put it in a container's `child_blocks`.
 *
 * The envelope passes it through unfitted, so Slack rejects the whole message if it breaks a limit, or if Slack does not accept it inside a container. A literal `type` Isomer models does not compile: return that block unwrapped. Pass the block's interface as `TBlock` to check its fields.
 */
export declare const unmodeledSlackBlock: <const TBlock extends {
    readonly type: string;
}>(block: TBlock & (TBlock["type"] extends SlackBlock["type"] ? {
    readonly "Isomer models this block type: return it without unmodeledSlackBlock": never;
} : unknown)) => SlackContainerChildBlock;
/** Whether `block` came from {@link unmodeledSlackBlock}. The mark is a symbol key, so it never reaches the JSON sent to Slack. */
export declare const isUnmodeledSlackBlock: (block: unknown) => boolean;
