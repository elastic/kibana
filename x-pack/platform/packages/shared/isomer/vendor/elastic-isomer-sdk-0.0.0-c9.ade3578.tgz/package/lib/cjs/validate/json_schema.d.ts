import { type ZodType } from 'zod';
import type { AnyPrimitiveDefinition } from '../define/primitive_module';
type JsonSchema = Record<string, unknown>;
/** Options for {@link buildCompositionJsonSchema}. */
export interface CompositionJsonSchemaOptions {
    /** Base URI for the emitted schema, which `$ref`s resolve against. */
    $id?: string;
    /** Reaches the model, so it keeps the word "view". Defaults to `'View'`. */
    title?: string;
    /** Reaches the model too, so write it as guidance rather than as a type note. */
    description?: string;
    /**
     * Extra schemas to name in `$defs`, for types a pack references by `$ref`.
     * Each `id` becomes the `$defs` key, so it must be unique.
     */
    extraDefs?: readonly {
        schema: ZodType;
        id: string;
    }[];
    /** `ref` gives a repeated schema its own `$def`; `inline` repeats it. Defaults to `ref`. */
    reused?: 'ref' | 'inline';
}
/**
 * Projects the composition schema to JSON Schema draft 2020-12, for hosts
 * that validate outside TypeScript.
 *
 * `$defs` are named per primitive type, plus `bodyNode` for the union.
 * Agent-facing prompt text uses `buildAuthoringJsonSchema` instead.
 */
export declare const buildCompositionJsonSchema: (definitions: readonly AnyPrimitiveDefinition[], options?: CompositionJsonSchemaOptions) => JsonSchema;
export {};
