import type { DisplayValue, StructuredValue } from '../composition/structured_value';
/** Options for {@link formatDisplayValue}. */
export interface FormatDisplayValueOptions {
    /** Reference instant for `relativeTime`; defaults to the render time. */
    now?: Date;
}
/** Narrows a {@link DisplayValue} to the object form. */
export declare const isStructuredValue: (value: DisplayValue) => value is StructuredValue;
/**
 * Renders a {@link DisplayValue} for display. A bare string passes through; a
 * {@link StructuredValue} is formatted per its `format`.
 *
 * Numeric formats fall back to `String(raw)` for a string `raw` rather than
 * erroring. Locale is fixed to `en-US` and dates render in UTC so the same
 * composition formats identically on every host.
 */
export declare const formatDisplayValue: (value: DisplayValue, options?: FormatDisplayValueOptions) => string;
