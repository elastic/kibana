import { type MarkdownBlock, type MarkdownContent, type MarkdownInline, type MarkdownInlineInput } from '../../define/markdown_content';
/** The node type of Markdown printed as written. */
export declare const VERBATIM_TYPE = "isomerVerbatim";
export declare const verbatim: (markdown: string, source?: string) => MarkdownBlock;
/**
 * Builds Markdown as content rather than strings, so escaping follows where
 * each value lands. Links and images apply the URL policy in
 * `src/validate/url.ts`: a blocked link keeps its label on
 * {@link BLOCKED_HREF}, and a blocked image degrades to its alt text.
 *
 * @example
 * md.list(rows.map((row) => md.paragraph(md.strong(row.label), ': ', row.value)))
 */
export declare const md: {
    text: (value: string) => MarkdownInline;
    strong: (...children: MarkdownInlineInput[]) => MarkdownInline;
    emphasis: (...children: MarkdownInlineInput[]) => MarkdownInline;
    code: (value: string) => MarkdownInline;
    link: (label: MarkdownInlineInput | readonly MarkdownInlineInput[], href: string) => MarkdownInline;
    image: (alt: string, src: string) => MarkdownInline;
    /** A hard line break, printed as a backslash before the line ending. Inside a heading, strong, emphasis, link label, or table cell it is a space; at the start or end of any of these, or of a paragraph, it is dropped. */
    break: () => MarkdownInline;
    paragraph: (...children: MarkdownInlineInput[]) => MarkdownBlock;
    heading: (depth: 1 | 2 | 3 | 4 | 5 | 6, ...children: MarkdownInlineInput[]) => MarkdownBlock;
    /** A quote with no blocks, such as one holding only a hidden child, is dropped. */
    blockquote: (...children: MarkdownContent[]) => MarkdownContent;
    /**
     * An item that is inline input becomes one paragraph; one with no blocks,
     * such as a hidden child, is dropped. A `start` that would print a marker
     * GFM does not read as a list number is ignored.
     */
    list: (items: readonly (MarkdownInlineInput | MarkdownContent)[], { ordered, start }?: {
        ordered?: boolean;
        start?: number;
    }) => MarkdownBlock;
    /** A cell is one inline run or several. GFM trims a cell's edge whitespace. */
    table: (columns: readonly (MarkdownInlineInput | readonly MarkdownInlineInput[])[], rows: readonly (readonly (MarkdownInlineInput | readonly MarkdownInlineInput[])[])[]) => MarkdownBlock;
    /** An unsafe `language` is dropped. */
    codeBlock: (value: string, language?: string) => MarkdownBlock;
    /** Authored Markdown source, after {@link sanitizeAuthoredSource}; whitespace-only source is dropped. */
    authored: (source: string) => MarkdownContent;
};
/** Parsed mdast blocks as GFM, unsanitized, for `md.authored` to sanitize as it sanitizes source. */
export declare const printParsed: (nodes: readonly unknown[]) => string;
/** `content` as flat mdast blocks, typed `unknown` so no declaration names mdast. */
export declare const markdownBlocks: (content: MarkdownContent) => readonly unknown[];
/** `content` as GFM, without a trailing line break. */
export declare const serializeMarkdown: (content: MarkdownContent) => string;
