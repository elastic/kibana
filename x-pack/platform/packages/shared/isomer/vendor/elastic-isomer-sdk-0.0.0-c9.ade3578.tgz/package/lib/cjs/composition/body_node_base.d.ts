/**
 * Every surface a node renders on or is hidden from, in render order.
 *
 * `html` is not here: the runtime's `html` surface wraps `react` output in a
 * document, and no node targets it.
 */
export declare const SURFACE_NAMES: readonly ["react", "snapshot", "text", "markdown", "slack"];
/** One of the {@link SURFACE_NAMES}. */
export type SurfaceName = (typeof SURFACE_NAMES)[number];
/** The two fields every primitive node carries, whatever its pack. */
export interface BodyNodeBase {
    /** Unique within a composition, which `validate` enforces and `parse` does not. */
    id?: string;
    /** Surfaces this node appears on. Absent means every surface. */
    surfaces?: SurfaceName[];
}
/**
 * A child node together with the field path locating it inside its parent, so
 * an error path can name the field a child actually lives under. A container
 * that returned bare nodes would leave every caller guessing the field name.
 */
export interface ChildNodeRef {
    /** Erased: one walker spans every pack's node types, so it can name none of them. */
    node: unknown;
    /** Relative to the parent, e.g. `items[0].node`, `items[2].description`. */
    path: string;
}
/**
 * Walks nested nodes and, for a hybrid container, reports whether the parent
 * still produces output of its own. A non-empty `children` result is the
 * complete source of rendered content unless
 * {@link ChildNodeWalker.hasOwnContent} is true for that node.
 */
export type ChildNodeWalker = ((node: unknown) => ChildNodeRef[]) & {
    hasOwnContent?(node: unknown): boolean;
};
/**
 * Builds the {@link ChildNodeWalker} for one composition's inventory.
 *
 * Pass every pack's definitions: a walker missing one cannot see children of a
 * container that pack defines, and a tree walk would stop at its boundary.
 */
export declare const createChildNodeWalker: (definitions: readonly {
    type: string;
    children?: unknown;
    hasOwnContent?: unknown;
}[]) => ChildNodeWalker;
/** Joins a parent path with a {@link ChildNodeRef.path} fragment. */
export declare const childNodePath: (parent: string, child: string) => string;
/**
 * Whether any node visible on `surface` matches, descending through container
 * children via `walk`. A node (or a container ancestor) hidden from `surface`
 * is skipped along with its children.
 *
 * `walk` must span every pack in the composition: a walker built from one
 * pack's definitions cannot see children of a container defined in another.
 */
export declare const someBodyNode: (nodes: readonly unknown[], surface: SurfaceName, predicate: (node: unknown) => boolean, walk: ChildNodeWalker) => boolean;
/** Whether `node`'s own `surfaces` hint admits `surface`, ignoring its children. */
export declare const isVisibleOnSurface: (node: unknown, surface: SurfaceName) => boolean;
/**
 * Whether `node` puts anything on `surface` — itself or through a descendant.
 *
 * Stronger than {@link isVisibleOnSurface}: a container every one of whose
 * children is hidden renders nothing, even though its own hint allows the
 * surface. A hybrid container that also owns string fields declares
 * {@link ChildNodeWalker.hasOwnContent} and keeps rendering regardless.
 */
export declare const rendersOnSurface: (node: unknown, surface: SurfaceName, walk: ChildNodeWalker) => boolean;
