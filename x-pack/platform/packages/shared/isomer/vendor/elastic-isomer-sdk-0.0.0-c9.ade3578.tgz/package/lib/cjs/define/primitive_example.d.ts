import type { PrimitiveNode } from '../composition/node';
/** A published example with a name hosts can list it by. */
export interface PrimitiveExample<TNode extends PrimitiveNode = PrimitiveNode> {
    /** Short and unique within the primitive, such as `Warning tone`. */
    name: string;
    /** What the example demonstrates. */
    description?: string;
    node: TNode;
    /** Never set: an entry is a bare node exactly when it has a `type`. */
    type?: never;
}
/** An entry of `examples` read as one shape; `name` is absent for a bare node. */
export interface NormalizedPrimitiveExample<TNode extends PrimitiveNode = PrimitiveNode> {
    name?: string;
    description?: string;
    node: TNode;
}
/** The node type an `examples` entry holds. */
export type ExampleNode<TEntry> = TEntry extends PrimitiveExample<infer TNode> ? TNode : TEntry;
interface WithExamples {
    readonly examples: readonly (PrimitiveNode | PrimitiveExample)[];
}
/** Distributes over a union of definitions, so a mixed registry keeps every node type. */
type NodeOf<TDefinition extends WithExamples> = ExampleNode<TDefinition['examples'][number]>;
/** A definition's examples, bare or named, as {@link NormalizedPrimitiveExample}s. */
export declare const primitiveExamples: <TDefinition extends WithExamples>({ examples, }: TDefinition) => NormalizedPrimitiveExample<NodeOf<TDefinition>>[];
/** A definition's example nodes, without names. */
export declare const exampleNodes: <TDefinition extends WithExamples>({ examples, }: TDefinition) => NodeOf<TDefinition>[];
export {};
