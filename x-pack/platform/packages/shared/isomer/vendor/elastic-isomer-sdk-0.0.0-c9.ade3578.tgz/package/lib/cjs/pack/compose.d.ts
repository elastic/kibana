import type { PrimitiveIcon } from '../define/primitive_icon';
import type { AnyPrimitiveDefinition } from '../define/primitive_module';
import type { EnhancementDefinition } from './enhancements';
import { type AnyPrimitivePack } from './primitive_pack';
/**
 * One flattened inventory owned by {@link composePacks}.
 *
 * `definitions` is a stable array identity, which is what the composition
 * schema cache keys on — pass it through rather than flattening packs per call.
 */
export interface ComposedPacks {
    readonly definitions: readonly AnyPrimitiveDefinition[];
    readonly enhancements: readonly EnhancementDefinition[];
    /** Every definition's `icon` by type, in one frozen null-prototype dictionary. */
    readonly icons: Readonly<Record<string, PrimitiveIcon>>;
    readonly slackAssetTypes: ReadonlySet<string>;
}
/**
 * Flattens `packs` into one inventory, rejecting cross-pack duplicate node
 * types and duplicate enhancement ids. Every offender is named in one error,
 * so a bad three-pack composition reports all three at once.
 */
export declare const composePacks: (packs: readonly AnyPrimitivePack[]) => ComposedPacks;
