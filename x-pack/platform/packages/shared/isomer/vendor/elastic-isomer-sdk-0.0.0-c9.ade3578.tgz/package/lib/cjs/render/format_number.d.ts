/**
 * `1_284` to `1.3k`, `18_200_000` to `18.2m`, through `b` and `t`, with an
 * optional unit appended. `precision` is the decimals kept, `1` by default.
 *
 * `%` joins without a space because "99.2 %" reads wrong; every other unit gets
 * one.
 */
export declare const formatCompactNumber: (value: number, unit?: string, precision?: number) => string;
