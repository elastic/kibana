/** Portable color names shared by primitive packs and renderers. An exact subset of EUI's `NamedColor`. */
export type NamedColor = 'neutral' | 'primary' | 'accent' | 'success' | 'warning' | 'risk' | 'danger';
/** Every {@link NamedColor}, and the source `namedColorSchema` derives from. */
export declare const ALL_NAMED_COLORS: readonly NamedColor[];
/** Light/dark preference. `auto` resolves light wherever media queries are unavailable. */
export type RenderTheme = 'auto' | 'light' | 'dark';
