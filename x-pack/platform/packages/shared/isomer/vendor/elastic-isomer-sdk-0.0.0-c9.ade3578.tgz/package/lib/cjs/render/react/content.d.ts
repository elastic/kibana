import { type ReactElement, type ReactNode } from 'react';
import type { Composition } from '../../composition';
import type { RenderTheme } from '../../composition/named_color';
import type { PrimitiveNode, PrimitiveRenderContext } from '../../define';
/** A pack's React renderer for one node of its own type. */
export interface ReactContentDispatcher<TNode extends PrimitiveNode, TContext = PrimitiveRenderContext> {
    /** Must be side-effect free: the HTML surface calls it twice, once to collect styles and once to render. */
    renderReact(node: TNode, context?: TContext): ReactNode;
}
/** Options for {@link renderCompositionContent}. */
export interface ReactContentOptions {
    /**
     * Renders the composition's title and subtitle as the leading `h2` / `p.sub`.
     * Defaults to `true`. Pass `false` when the host already shows the title
     * itself; the title still backs the wrapper's `aria-label`.
     */
    heading?: boolean;
}
/**
 * A composition's heading and body as React nodes, without the surrounding
 * document or wrapper element.
 */
export declare const renderCompositionContent: <TNode extends PrimitiveNode, TContext = PrimitiveRenderContext>(composition: Composition<TNode>, dispatcher: ReactContentDispatcher<TNode, TContext>, context: TContext, { heading }?: ReactContentOptions) => ReactNode;
/** Options for {@link wrapCompositionContent}. */
export interface CompositionWrapperOptions {
    /** Adds the `framed` class. Defaults to `true`. */
    framed?: boolean;
    /** Adds the `fluid` class. */
    fluid?: boolean;
    /** Sets `data-theme` and `color-scheme`, which `light-dark()` resolves against; defaults to the composition's `theme`, and `auto` sets nothing so the page's scheme applies. */
    theme?: RenderTheme;
    /** Used only when the composition has neither `meta.ariaLabel` nor a `title`. Defaults to `'View'`. */
    defaultAriaLabel?: string;
}
/**
 * The one `.isomer[.framed][.fluid]` `section` every surface wraps rendered
 * content in: the `html` surface's document wrapper and a React host's.
 */
export declare const wrapCompositionContent: <TNode extends PrimitiveNode>(content: ReactNode, composition: Composition<TNode>, { framed, fluid, theme, defaultAriaLabel, }?: CompositionWrapperOptions) => ReactElement;
