import { type ReactNode } from 'react';
import type { MarkdownContent } from '../../define/markdown_content';
/**
 * Builder content as React elements: paragraphs, headings, lists, quotes, code, tables, and thematic breaks, with inline marks, links, and images. Source from `md.authored` is parsed as GFM, once, as the Markdown and Slack surfaces read it.
 *
 * Links and images follow `md`'s URL policy: a blocked link keeps its label on {@link BLOCKED_HREF}, and a blocked image degrades to its alt text.
 */
export declare const renderMarkdownContent: (content: MarkdownContent) => ReactNode;
