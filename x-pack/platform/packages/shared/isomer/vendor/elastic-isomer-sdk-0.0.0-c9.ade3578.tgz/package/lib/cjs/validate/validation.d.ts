import { type SurfaceName } from '../composition/body_node_base';
import type { Composition } from '../composition/composition';
import type { PrimitiveNode } from '../composition/node';
import { CompositionValidationError, type ValidationError } from '../composition/validation_error';
import type { AnyPrimitiveDefinition } from '../define/primitive_module';
import { type InputBudget } from './input_budget';
/**
 * A non-fatal validation finding, scoped to the surface it concerns.
 *
 * Warnings carry `surface` because every one of them is a statement about one
 * render target — a composition that draws nothing on `slack` is not news to a
 * caller rendering HTML. Without the scope a host receives every surface's
 * findings on every call and learns to ignore the channel.
 * {@link warningsForSurface} is the filter.
 */
export interface ValidationWarning {
    /** The render target this finding concerns, never the composition as a whole. */
    surface: SurfaceName;
    /**
     * Path of the offending node within the composition, absent for
     * whole-composition findings.
     */
    path?: string;
    /** Safe to show a user, and phrased for whoever can act on it. */
    message: string;
}
/**
 * The outcome of `validate`: errors are fatal, warnings are advisory.
 *
 * `valid` tracks `errors` only — a composition can be valid and still carry
 * warnings, which is the normal case for a surface gap.
 */
export interface ValidationResult {
    /** True when `errors` is empty, regardless of `warnings`. */
    valid: boolean;
    /** Fatal findings. Empty when `valid`. */
    errors: ValidationError[];
    /** Advisory findings, empty when there are none. */
    warnings: ValidationWarning[];
}
declare const checkedComposition: unique symbol;
/** The copy {@link createCompositionValidator} checked, which a validating render draws in place of the caller's value. The brand is type-only. */
export type CheckedComposition<TNode extends PrimitiveNode = PrimitiveNode> = Composition<TNode> & {
    readonly [checkedComposition]: true;
};
/** A {@link ValidationResult} with the composition it describes. */
export interface CheckedValidationResult<TNode extends PrimitiveNode = PrimitiveNode> extends ValidationResult {
    /** Undefined only when {@link checkInputBudget} refused the input. */
    composition: CheckedComposition<TNode> | undefined;
}
/** Narrows a result's warnings to the surface a caller is about to render. */
export declare const warningsForSurface: (result: ValidationResult, surface: SurfaceName) => ValidationWarning[];
/** Whether a render reports validation findings or raises on them. */
export type ValidationErrorMode = 'collect' | 'throw';
export { CompositionValidationError };
/** Raises {@link CompositionValidationError} when `mode` is `throw` and `result` is invalid, or in any mode when {@link checkInputBudget} refused the input, which nothing can render. */
export declare const enforceValidationMode: (result: ValidationResult, mode?: ValidationErrorMode) => void;
/** The composition `result` checked, which is what a render draws. Throws {@link CompositionValidationError} when `mode` is `'throw'` and `result` is invalid, or in any mode when {@link checkInputBudget} refused the input. */
export declare const compositionToRender: <TNode extends PrimitiveNode>(result: CheckedValidationResult<TNode>, mode?: ValidationErrorMode) => CheckedComposition<TNode>;
/** Options for {@link createCompositionValidator}. */
export interface CompositionValidatorOptions {
    /** Limits checked before the schema runs; see {@link checkInputBudget}. */
    inputBudget?: InputBudget;
}
/**
 * Builds the trusted-input validator: {@link checkInputBudget}, then the schema and the semantic passes on its copy, which the result carries.
 *
 * `definitions` is memoized on array identity, so a caller that rebuilds the
 * array per call (`createCompositionValidator(packs.flatMap(…))`) resolves a
 * fresh discriminated union each time. Hold the array `composePacks` returns
 * and reuse it across the validator, the parser, and the authoring context.
 */
export declare const createCompositionValidator: <TNode extends PrimitiveNode = PrimitiveNode>(definitions: readonly AnyPrimitiveDefinition[], options?: CompositionValidatorOptions) => ((composition: Composition<TNode>) => CheckedValidationResult<TNode>);
/** The outcome of `parse`. */
export interface ParsedComposition {
    /** True when the value matched the schema. Says nothing about id uniqueness. */
    valid: boolean;
    /** Schema failures. Empty when `valid`. */
    errors: ValidationError[];
    /** The parsed document, present only when `valid`. */
    composition?: Composition;
}
/**
 * Builds the untrusted-input parser: {@link checkInputBudget}, then the schema only on its copy, reported rather than thrown.
 *
 * Deliberately narrower than {@link createCompositionValidator}. This answers
 * "is this a `Composition`", not "is this a good one" — it does not run the
 * duplicate-id pass or produce warnings, so a composition with two nodes
 * sharing an `id` parses as valid. Id uniqueness is a `validate` guarantee, so
 * a caller that wants the semantic checks runs `validate` on the result.
 *
 * Shares {@link createCompositionValidator}'s memoization identity requirement.
 */
export declare const createCompositionParser: (definitions: readonly AnyPrimitiveDefinition[], { inputBudget }?: Pick<CompositionValidatorOptions, "inputBudget">) => ((value: unknown) => ParsedComposition);
