import type { AnyPrimitiveDefinition } from '../define/primitive_module';
type JsonSchema = Record<string, unknown>;
/** Options for {@link buildAuthoringDeclarations}. */
export interface AuthoringDeclarationsOptions {
    /** Also declare the components `buildJsxShim` builds for these primitives. Defaults to `false`. */
    jsx?: boolean;
    /** Ambient module identity. Defaults to `@elastic/isomer-authoring`. */
    moduleName?: string;
}
/** An ambient module for the schema from `buildAuthoringJsonSchema` and its primitive definitions. */
export declare const buildAuthoringDeclarations: (schema: JsonSchema, definitions: readonly AnyPrimitiveDefinition[], { jsx, moduleName, }?: AuthoringDeclarationsOptions) => string;
export {};
