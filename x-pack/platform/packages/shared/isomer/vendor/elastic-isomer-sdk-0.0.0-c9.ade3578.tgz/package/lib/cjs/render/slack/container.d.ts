import { type SlackBlock, type SlackContainerBlock, type SlackContainerChildBlock, type SlackHeaderLevel } from './blocks';
/** Options for {@link slackContainer}: the container's optional fields, and the level of the `header` it falls back to. */
export type SlackContainerOptions = Partial<Pick<SlackContainerBlock, 'block_id' | 'subtitle' | 'icon' | 'width' | 'is_collapsible' | 'default_collapsed' | 'has_header_divider'>> & {
    fallbackLevel?: SlackHeaderLevel;
};
/** A container Isomer fits, as opposed to one passed through `unmodeledSlackBlock`. */
export declare const isContainer: (block: SlackBlock) => block is SlackContainerBlock;
/** A container as the blocks it holds, led by its title and subtitle. */
export declare const unwrapContainer: ({ title, rich_text_title, subtitle, child_blocks }: SlackContainerBlock, level?: SlackHeaderLevel) => SlackContainerChildBlock[];
/**
 * `container` holding `children`, with any nested container unwrapped, since
 * Slack rejects one. A container left with no children, or more than
 * `containerChildBlocks`, is unwrapped itself.
 */
export declare const containerWithChildren: (container: SlackContainerBlock, children: readonly SlackBlock[], level?: SlackHeaderLevel) => SlackBlock[];
/**
 * A titled section as one Block Kit `container`, from its title and the
 * blocks its body rendered to, typically through `scope.renderSlack`.
 *
 * A nested container among `children` is unwrapped to its title and blocks.
 * With no children, or more than `SLACK_LIMITS.containerChildBlocks`, the
 * section falls back to a `header` at `fallbackLevel` followed by the blocks.
 */
export declare const slackContainer: (title: string, children: readonly SlackBlock[], { fallbackLevel, ...fields }?: SlackContainerOptions) => SlackBlock[];
