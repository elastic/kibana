/**
 * A 16×16 glyph a host shows beside the primitive: static SVG, inlinable without a renderer.
 *
 * Colours go through {@link ICON_VARS}, optionally with a `currentColor` or hex fallback; `assertPackIconsValid` from `./testing` enforces the rules.
 */
export interface PrimitiveIcon {
    svg: string;
}
/** The colour slots an icon may paint with, which a host sets per theme and mode. */
export declare const ICON_VARS: readonly ["--isomer-icon-accent", "--isomer-icon-bg", "--isomer-icon-fg", "--isomer-icon-muted"];
