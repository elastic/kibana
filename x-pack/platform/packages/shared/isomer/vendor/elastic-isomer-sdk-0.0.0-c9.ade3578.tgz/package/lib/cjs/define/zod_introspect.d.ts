import { type ZodType } from 'zod';
/** A schema's internal definition. */
export type ZodDef = ZodType['_zod']['def'];
/** The wrapper kinds whose `undefined`/`null` handling keeps the inner shape. */
export type ZodWrapperType = 'optional' | 'nullable' | 'default' | 'readonly';
/** Wrappers whose inner schema still describes the authored value. */
export declare const ZOD_WRAPPER_TYPES: ReadonlySet<string>;
/** A schema's input type, read without constraining `TSchema` to `ZodType`. */
export type ZodInputOf<TSchema> = TSchema extends {
    _zod: {
        input: infer Input;
    };
} ? Input : never;
/** A schema's output type, read without constraining `TSchema` to `ZodType`. */
export type ZodOutputOf<TSchema> = TSchema extends {
    _zod: {
        output: infer Output;
    };
} ? Output : never;
/** A {@link ZodWrapperType} layer around `TInner`, as the type system sees it. */
export type ZodWrapperOf<TInner> = {
    _zod: {
        def: {
            type: ZodWrapperType;
            innerType: TInner;
        };
    };
};
/** Whether `value` is a Zod schema: it carries a def with a type tag. */
export declare const isZodSchema: (value: unknown) => value is ZodType;
/** The def's type tag (`object`, `optional`, `array`, …), or `undefined` for a non-schema. */
export declare const zodDefType: (value: unknown) => string | undefined;
/** A schema's def, for cloning with {@link cloneZodSchema}. */
export declare const zodDef: (schema: ZodType) => ZodDef;
/**
 * The schema one wrapper layer holds, when `schema`'s type tag is in `types`;
 * otherwise `undefined`.
 */
export declare const unwrapZodOnce: (schema: unknown, types?: ReadonlySet<string>) => ZodType | undefined;
/** `schema` with every layer in `types` peeled off. */
export declare const unwrapZod: (schema: ZodType, types?: ReadonlySet<string>) => ZodType;
/** The element schema of an array schema, or `undefined`. */
export declare const zodArrayElement: (schema: ZodType) => ZodType | undefined;
/** The shape of an object schema, or `undefined`. */
export declare const zodObjectShape: (schema: ZodType) => Readonly<Record<string, ZodType>> | undefined;
/** Whether an object schema declares a `catchall` (including `.loose()`/`.strict()`). */
export declare const zodObjectHasCatchall: (schema: ZodType) => boolean;
/** The getter a `z.lazy` schema resolves through, or `undefined`. */
export declare const zodLazyGetter: (schema: ZodType) => (() => ZodType) | undefined;
/** The checks a schema carries: `.refine`, `.check`, `.max`, …. */
export declare const zodChecks: (schema: ZodType) => readonly unknown[];
/** Whether `check` is a custom check: `.refine`, `.superRefine`, or a `z.refine` given to `.check`. */
export declare const isZodCustomCheck: (check: unknown) => check is object;
/** The schemas `schema` holds directly: its inner, element, shape, options, a lazy schema's target, …. */
export declare const zodNestedSchemas: (schema: ZodType) => ZodType[];
/** A new schema of `schema`'s class built from `def`. */
export declare const cloneZodSchema: (schema: ZodType, def: ZodDef) => ZodType;
