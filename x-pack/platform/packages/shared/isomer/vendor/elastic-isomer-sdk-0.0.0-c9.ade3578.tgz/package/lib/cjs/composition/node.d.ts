import type { BodyNodeBase } from './body_node_base';
/**
 * One node in a `Composition`'s body, erased to its discriminator.
 *
 * A pack narrows `type` to its own literal union; the SDK holds this form
 * because a heterogeneous inventory has no single node type to name.
 */
export interface PrimitiveNode extends BodyNodeBase {
    type: string;
}
