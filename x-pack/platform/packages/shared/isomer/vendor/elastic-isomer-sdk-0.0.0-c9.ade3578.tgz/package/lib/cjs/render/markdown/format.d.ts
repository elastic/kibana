/** `markdown` as flat GFM mdast blocks, typed `unknown` so no declaration names mdast; `null` past the parse budget or the parser's recursion depth. */
export declare const parseGfmBlocks: (markdown: string) => readonly unknown[] | null;
/** {@link sanitizeMarkdownSource}'s result, and whether it degraded to inert text. */
export declare const sanitizeAuthoredSource: (markdown: string) => {
    markdown: string;
    inert: boolean;
};
/** Sanitizes GFM destinations and HTML; excessive syntax or length degrades to inert text. */
export declare const sanitizeMarkdownSource: (markdown: string) => string;
export declare const inert: (markdown: string) => string;
export declare const exceedsParseBudget: (markdown: string) => boolean;
