import type { ZodType } from 'zod';
import type { Composition } from '../composition/composition';
import type { PrimitiveNode } from '../define/primitive_module';
import type { AuthoredSpec } from './authored_fields';
import type { JsxShim } from './jsx_shim';
/** What {@link printNodeJsx} reads a pack's authoring from. */
export interface PrintJsxEnv {
    schemaFor: (type: string) => ZodType | undefined;
    /** Parses each candidate back, so a field prints as children only when that round-trips. */
    shim: JsxShim;
    /** Reads a schema's authoring brands; returning `undefined` prints every field as a prop. */
    readSpec?: (schema: ZodType) => AuthoredSpec | undefined;
}
/** A JavaScript literal for `value`, on one line when it fits. */
export declare const printValue: (value: unknown, indent?: string) => string;
/** Prints one node as authoring JSX for `buildJsxShim`'s components. */
export declare const printNodeJsx: (node: PrimitiveNode, env: PrintJsxEnv) => string;
/** The composition fields {@link printCompositionJsx} can print as props of `<Composition>`. */
export type PrintCompositionRoot = Omit<Composition, 'type' | 'body'>;
/**
 * Prints a composition body as JSX children of `<Composition>`, with `root`'s
 * fields, when given, as its props.
 */
export declare const printCompositionJsx: (body: readonly PrimitiveNode[], env: PrintJsxEnv, { root }?: {
    root?: PrintCompositionRoot | undefined;
}) => string;
