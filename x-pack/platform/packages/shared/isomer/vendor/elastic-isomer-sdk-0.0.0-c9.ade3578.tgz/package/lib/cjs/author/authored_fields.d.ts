import type { ReactNode } from 'react';
import type { ZodType } from 'zod';
import type { PrimitiveNode } from '../define/primitive_module';
import { type ZodInputOf, type ZodOutputOf, type ZodWrapperOf } from '../define/zod_introspect';
/**
 * Member name of the child component a schema field is filled from.
 *
 * `Symbol.for`: ESM and CJS builds must agree, same as `authorType`.
 */
export declare const authoredChild: unique symbol;
/** Phantom props type for the child component. Not set at runtime. */
export declare const authoredProps: unique symbol;
/** Set when a field is filled from text children. */
export declare const authoredText: unique symbol;
/** Set when a field is filled from primitive elements no other field claims. */
export declare const authoredNodes: unique symbol;
/** Holds a {@link fromChildren} brand's `toItem`. */
export declare const authoredToItem: unique symbol;
/**
 * A field filled from child elements of `TName`.
 *
 * Phantom: `z.infer` still reads the underlying schema. The shim reads `TName`
 * and `TProps` off the field type, and the symbols off the schema value.
 */
export interface AuthoredChildBrand<TName extends string, TProps> {
    readonly [authoredChild]: TName;
    readonly [authoredProps]: TProps;
}
/** A child field whose `toItem` builds each item, so the shim fills none of the item's own brands. */
export interface AuthoredToItemBrand {
    readonly [authoredToItem]: (props: never, context: AuthorChildContext) => unknown;
}
/** A field filled from text children. */
export interface AuthoredTextBrand {
    readonly [authoredText]: true;
}
/** A field filled from primitive elements, like a child slot the tree walk does not visit. */
export interface AuthoredNodesBrand {
    readonly [authoredNodes]: true;
}
/** What {@link fromChildren}'s `toItem` receives. */
export interface AuthorChildContext {
    /** Nested elements, parsed as body nodes. */
    parseChildren: (children: ReactNode) => PrimitiveNode[];
}
type ArrayItem<TSchema extends ZodType> = NonNullable<ZodOutputOf<TSchema>> extends readonly (infer Item)[] ? Item : NonNullable<ZodOutputOf<TSchema>>;
type Unwrapped<TSchema> = TSchema extends ZodWrapperOf<infer Inner> ? Unwrapped<Inner> : TSchema;
/** Whether `F`, or a wrapper layer of it, carries a {@link fromChildren} brand. */
type IsChildBranded<F> = F extends AuthoredChildBrand<string, unknown> ? true : F extends ZodWrapperOf<infer Inner> ? IsChildBranded<Inner> : false;
/** A branded field's item schema: the array element through any wrapper, or the unwrapped schema. */
export type ItemSchema<TSchema> = Unwrapped<TSchema> extends {
    element: infer Element;
} ? Element : Unwrapped<TSchema>;
/** Item fields a nested {@link fromChildren} brand fills from child elements. */
type ChildBrandedKeys<TItemSchema> = TItemSchema extends {
    shape: infer Shape;
} ? string extends keyof Shape ? never : {
    [K in keyof Shape]: IsChildBranded<Shape[K]> extends true ? K : never;
}[keyof Shape] : never;
/** `TOptional` is optional on the child props because text or child elements fill it. */
type ChildProps<TItem, TOptional extends PropertyKey> = [TOptional] extends [
    never
] ? TItem & {
    children?: ReactNode;
} : Omit<TItem, TOptional> & Partial<Pick<TItem, Extract<TOptional, keyof TItem>>> & {
    children?: ReactNode;
};
/**
 * Brands `schema` as JSX children of the member `name`, capitalized on the
 * primitive's component: `fromChildren('item', …)` on `slideList` is
 * `<SlideList.Item>`. Names are unique across a primitive's child tree.
 *
 * `options.text` copies leftover text onto that field. `options.toItem` replaces
 * the default prop copy; its props annotation is the child component's props.
 * The brand is read through `.optional()`, `.nullable()`, `.default()`, and
 * `.readonly()`; any other method clones without it, so call it on `schema`
 * before passing it in.
 */
export declare function fromChildren<const TName extends string, TSchema extends ZodType>(name: TName, schema: TSchema): TSchema & AuthoredChildBrand<TName, ChildProps<ArrayItem<TSchema>, ChildBrandedKeys<ItemSchema<TSchema>>>>;
export declare function fromChildren<const TName extends string, TSchema extends ZodType, const TText extends string>(name: TName, schema: TSchema, options: {
    text: TText;
    toItem?: never;
}): TSchema & AuthoredChildBrand<TName, ChildProps<ArrayItem<TSchema>, TText | ChildBrandedKeys<ItemSchema<TSchema>>>>;
export declare function fromChildren<const TName extends string, TSchema extends ZodType, TPropsSchema extends ZodType>(name: TName, schema: TSchema, options: {
    text?: string;
    propsSchema: TPropsSchema;
    toItem(props: ZodInputOf<TPropsSchema> & {
        children?: ReactNode;
    }, context: AuthorChildContext): unknown;
}): TSchema & AuthoredChildBrand<TName, ZodInputOf<TPropsSchema> & {
    children?: ReactNode;
}> & AuthoredToItemBrand;
export declare function fromChildren<const TName extends string, TSchema extends ZodType, TProps>(name: TName, schema: TSchema, options: {
    text?: string;
    toItem(props: TProps, context: AuthorChildContext): unknown;
    propsSchema?: never;
}): TSchema & AuthoredChildBrand<TName, TProps> & AuthoredToItemBrand;
/**
 * Brands `schema` as text children.
 *
 * Whitespace collapses unless `collapseWhitespace` is `false`. `dedent` keeps
 * it and reads the text as source, as {@link textFromChildren} does.
 */
export declare const fromTextChildren: <TSchema extends ZodType>(schema: TSchema, options?: {
    collapseWhitespace?: boolean;
    dedent?: boolean;
}) => TSchema & AuthoredTextBrand;
/**
 * Brands `schema`, a node or an array of nodes, as the primitive elements among
 * the children that no other field claims. Use it for nodes the tree walk does
 * not visit; a walked child slot fills from children already.
 */
export declare const fromNodeChildren: <TSchema extends ZodType>(schema: TSchema) => TSchema & AuthoredNodesBrand;
/** One {@link fromChildren} field as the shim reads it. */
export interface AuthoredChildField {
    field: string;
    /** The member name `fromChildren` was given, before capitalizing. */
    name: string;
    /** Field leftover text children fill. */
    textField?: string;
    /** Replaces the default prop copy. */
    toItem?: (props: object, context: AuthorChildContext) => unknown;
    /** The array element schema, or the field schema itself when it is not an array. */
    itemSchema: ZodType;
    /** Input props for a custom `toItem`, excluding JSX children. */
    propsSchema?: ZodType;
    /** Whether the field holds an array of items rather than one item. */
    array: boolean;
    /** Whether the field accepts `undefined`, so children may be omitted. */
    optional: boolean;
}
/** One {@link fromTextChildren} field as the shim reads it. */
export interface AuthoredTextField {
    field: string;
    /** `true` unless the brand was given `collapseWhitespace: false` or `dedent`. */
    collapseWhitespace: boolean;
    /** Set when the brand was given `dedent`. */
    dedent?: true;
    /** Whether the field accepts `undefined`, so text children may be omitted. */
    optional: boolean;
}
/** One {@link fromNodeChildren} field as the shim reads it. */
export interface AuthoredNodesField {
    field: string;
    /** Whether the field holds an array of nodes rather than one. */
    array: boolean;
}
/** The branded fields found on one object schema. */
export interface AuthoredSpec {
    children: AuthoredChildField[];
    text: AuthoredTextField[];
    /** Absent on a spec built by hand; read as none. */
    nodes?: AuthoredNodesField[];
}
/**
 * The branded fields on an object schema, top level only: read a child's own
 * brands from its {@link AuthoredChildField.itemSchema}.
 */
export declare const readAuthoredSpec: (schema: ZodType) => AuthoredSpec;
export {};
