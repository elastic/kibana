import type { Composition } from '../../composition/composition';
import type { PrimitiveNode } from '../../define/primitive_module';
import type { MarkdownEnvelopeDispatcher } from '../markdown/envelope';
import { type SlackAssetCollector, type SlackAssetRequest } from './assets';
import { type SlackBlock } from './blocks';
import { type SlackLinkOptions } from './format';
/**
 * Adds Block Kit to {@link MarkdownEnvelopeDispatcher}.
 *
 * `renderSlack` may return no blocks, in which case the node contributes
 * nothing — the envelope spreads what it is given and does not degrade. That is
 * the dispatcher's job: it renders the node's markdown instead. The markdown
 * renderer is what that fallback reads, so it stays required even for a pack
 * with full Slack coverage.
 */
export interface SlackEnvelopeDispatcher<TNode extends PrimitiveNode> extends MarkdownEnvelopeDispatcher<TNode> {
    /** `collector` is absent unless the caller opted into asset collection, so a renderer must still degrade an image it cannot upload. */
    renderSlack(node: TNode, collector?: SlackAssetCollector, options?: SlackLinkOptions): readonly SlackBlock[];
}
/** Options for {@link renderSlackEnvelope}. */
export interface SlackEnvelopeOptions extends SlackLinkOptions {
    /** Renders the composition's title and subtitle, in the blocks and the fallback `text`. Defaults to `true`. Pass `false` when the host already shows the title, or the body opens with its own. */
    heading?: boolean;
    /** Fallback `text` summary shown in notifications and previews, as `mrkdwn`; defaults to the text render, escaped. */
    text?: string;
    /** Whether to collect image upload requests alongside the blocks. */
    collectAssets?: boolean;
}
/** What {@link renderSlackEnvelope} returns: one `chat.postMessage` payload. */
export interface SlackEnvelopeResult {
    /** Fallback text for the message. */
    text: string;
    /** Block Kit blocks, fitted to Slack's limits. */
    blocks: SlackBlock[];
    /** Images referenced by `blocks` that the host must upload first. */
    assets: SlackAssetRequest[];
}
/**
 * The composition as a `chat.postMessage` payload: notification `text`, blocks,
 * and the images the host must upload first.
 *
 * Degradation for a node with no `slack` renderer is the dispatcher's, which
 * has to own it to reach a child nested inside a container. The result is
 * fitted to Slack's limits — text is clamped, blocks past a count limit and
 * `rich_text` elements past a section's limit split, tables past a table limit
 * or the message's cell budget become rich text, spacers and then whole blocks
 * are dropped — so the output is always postable, except for a block from
 * `unmodeledSlackBlock` or of a type Isomer does not model, which passes
 * through unfitted. `assets` stays empty unless `collectAssets` is set.
 */
export declare const renderSlackEnvelope: <TNode extends PrimitiveNode>(composition: Composition<TNode>, dispatcher: SlackEnvelopeDispatcher<TNode>, options?: SlackEnvelopeOptions) => SlackEnvelopeResult;
