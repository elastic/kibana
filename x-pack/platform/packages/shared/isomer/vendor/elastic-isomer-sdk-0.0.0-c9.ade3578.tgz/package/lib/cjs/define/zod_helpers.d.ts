import { z } from 'zod';
/**
 * A non-empty string.
 *
 * `message` is the suffix `formatZodIssue` prepends a path to, so phrase
 * it as a predicate (`must be a hex color`), not a sentence.
 */
export declare const requiredString: (message?: string) => z.ZodString;
export { z };
