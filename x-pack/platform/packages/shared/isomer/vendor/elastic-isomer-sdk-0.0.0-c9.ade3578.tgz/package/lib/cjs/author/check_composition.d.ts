import type { Composition } from '../composition/composition';
import type { PrimitiveNode } from '../composition/node';
import type { ValidationError } from '../composition/validation_error';
import type { ValidationWarning } from '../validate/validation';
/** The part of a runtime {@link checkComposition} calls. An `IsomerRuntime` satisfies it. */
export interface CompositionCheckRuntime {
    /** `composition` is the schema's output, with defaults and transforms applied; present only when `valid`. */
    parse(value: unknown): {
        valid: boolean;
        errors: readonly ValidationError[];
        composition?: Composition | undefined;
    };
    /** `composition` is the copy the result describes, and `undefined` only when the input budget refused it. */
    validate(composition: Composition): {
        valid: boolean;
        errors: readonly ValidationError[];
        warnings?: readonly ValidationWarning[] | undefined;
        composition: Composition | undefined;
    };
}
/** A body rule the runtime does not enforce on every surface. A `Frame` satisfies it. */
export interface CompositionCheckFrame {
    validateBody?(body: readonly PrimitiveNode[]): readonly string[];
}
/** The outcome of {@link checkComposition}. */
export type CompositionCheck = {
    valid: true;
    errors: readonly [];
    warnings: readonly ValidationWarning[];
    composition: Composition;
} | {
    valid: false;
    /** A frame rule's finding has an empty path. */
    errors: readonly ValidationError[];
    warnings: readonly ValidationWarning[];
    /** The validated copy, present when only the frame's rule failed. */
    composition?: Composition | undefined;
};
/** Parses a value of unknown shape, validates the parsed copy, then applies the frame's body rule to the copy the runtime checked. */
export declare const checkComposition: (runtime: CompositionCheckRuntime, value: unknown, frame?: CompositionCheckFrame) => CompositionCheck;
