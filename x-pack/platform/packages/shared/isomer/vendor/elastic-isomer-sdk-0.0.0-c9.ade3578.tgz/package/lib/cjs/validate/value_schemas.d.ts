import { z } from 'zod';
/** Derived from {@link ALL_NAMED_COLORS} rather than restating the literals. */
export declare const namedColorSchema: z.ZodEnum<{
    primary: "primary";
    danger: "danger";
    success: "success";
    neutral: "neutral";
    accent: "accent";
    warning: "warning";
    risk: "risk";
}>;
/** `RenderTheme`: the light/dark preference a caller asks for. */
export declare const renderThemeSchema: z.ZodEnum<{
    auto: "auto";
    light: "light";
    dark: "dark";
}>;
/**
 * The raw quantity plus a format hint, formatted once in a primitive's model so
 * every surface renders the same string. See `StructuredValue`.
 */
export declare const structuredValueSchema: z.ZodObject<{
    raw: z.ZodUnion<readonly [z.ZodNumber, z.ZodString]>;
    format: z.ZodOptional<z.ZodEnum<{
        number: "number";
        date: "date";
        compact: "compact";
        percent: "percent";
        currency: "currency";
        bytes: "bytes";
        duration: "duration";
        relativeTime: "relativeTime";
    }>>;
    precision: z.ZodOptional<z.ZodNumber>;
    currency: z.ZodOptional<z.ZodString>;
}, z.core.$strip>;
/** Value-bearing fields accept preformatted prose or a structured value. */
export declare const displayValueSchema: z.ZodUnion<readonly [z.ZodString, z.ZodObject<{
    raw: z.ZodUnion<readonly [z.ZodNumber, z.ZodString]>;
    format: z.ZodOptional<z.ZodEnum<{
        number: "number";
        date: "date";
        compact: "compact";
        percent: "percent";
        currency: "currency";
        bytes: "bytes";
        duration: "duration";
        relativeTime: "relativeTime";
    }>>;
    precision: z.ZodOptional<z.ZodNumber>;
    currency: z.ZodOptional<z.ZodString>;
}, z.core.$strip>]>;
