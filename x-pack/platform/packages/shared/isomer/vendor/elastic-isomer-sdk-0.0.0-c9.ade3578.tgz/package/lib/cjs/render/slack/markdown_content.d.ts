import type { MarkdownContent } from '../../define/markdown_content';
import { type SlackBlock } from './blocks';
import { type SlackLinkOptions } from './format';
/**
 * Builder content as Block Kit: paragraphs, headings, lists, quotes, and code
 * as `rich_text`, tables as `table` blocks, and thematic breaks as `divider`
 * blocks. A quote is one level, and inside a list item its blocks are the
 * item's. A run of rich-text blocks shares one `rich_text` block. Source from
 * `md.authored` is parsed as GFM and translated the same way.
 */
export declare const markdownContentToSlackBlocks: (content: MarkdownContent, options?: SlackLinkOptions) => SlackBlock[];
/**
 * GFM as Block Kit, parsed as CommonMark with GFM and translated as
 * {@link markdownContentToSlackBlocks} translates builder content. Source past
 * the parse budget that `md.authored` applies prints as literal paragraphs.
 */
export declare const gfmToSlackBlocks: (gfm: string, options?: SlackLinkOptions) => SlackBlock[];
