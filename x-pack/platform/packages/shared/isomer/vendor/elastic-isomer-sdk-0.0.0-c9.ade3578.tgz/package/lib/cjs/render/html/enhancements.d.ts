import { type EnhancementDefinition } from '../../pack/enhancements';
export type { EnhancementDefinition };
/** The scripts of `applied`, in order, each in its own function scope. */
export declare const enhancementScript: (applied: readonly EnhancementDefinition[]) => string;
/**
 * Binds `root` to the section that contains the emitted `<script>`. Inside a
 * shadow root `document.currentScript` is `null`, so there it warns instead.
 */
export declare const embedScript: (body: string) => string;
