import type { MarkdownContent } from '../../define/markdown_content';
/** GFM as mdast blocks with references resolved, typed `unknown[]` so no declaration names mdast; source past the parse budget is its literal paragraphs. */
export declare const gfmBlocks: (gfm: string) => readonly unknown[];
/** `content` as flat mdast blocks with authored source parsed, typed `unknown[]` so no declaration names mdast. */
export declare const resolvedMarkdownBlocks: (content: MarkdownContent) => readonly unknown[];
