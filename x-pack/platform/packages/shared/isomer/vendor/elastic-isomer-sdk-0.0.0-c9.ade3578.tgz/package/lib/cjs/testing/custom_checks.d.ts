import type { ZodType } from 'zod';
/** Options for {@link customChecksOf}. */
export interface CustomChecksOptions {
    /** Stops the walk at a nested schema, such as another primitive's, checked on its own. `schema` itself is never skipped. */
    skip?: (schema: ZodType) => boolean;
}
/**
 * Every custom check reachable from `schema` (`.refine`, `.superRefine`, a
 * `z.refine` given to `.check`, or a `z.custom` schema, which is its own check),
 * each the object Zod holds, so a pack can look up what it recorded when it made one.
 */
export declare const customChecksOf: (schema: ZodType, { skip }?: CustomChecksOptions) => object[];
