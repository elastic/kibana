/** Brands `md` output. `Symbol.for`: ESM and CJS builds must agree. */
export declare const markdownContent: unique symbol;
/** Inline Markdown built with `md`. */
export interface MarkdownInline {
    readonly [markdownContent]: 'inline';
}
/** Block Markdown built with `md`. */
export interface MarkdownBlock {
    readonly [markdownContent]: 'block';
}
/** What a `markdown` renderer may return in place of a string. Nested lists flatten. */
export type MarkdownContent = MarkdownBlock | readonly MarkdownContent[];
/** A string is text: escaped wherever it would read as Markdown, line breaks as spaces. */
export type MarkdownInlineInput = string | MarkdownInline;
