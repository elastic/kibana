export { type TextEnvelopeDispatcher, type TextEnvelopeOptions, renderTextEnvelope, } from '../render/text';
