import { z, type ZodType } from 'zod';
/** Input-schema copy without executable defaults or catch values. */
export declare const prepareAuthoringInput: (schema: ZodType) => {
    schema: z.ZodType<unknown, unknown, z.core.$ZodTypeInternals<unknown, unknown>>;
    metadata: z.core.$ZodRegistry<z.core.GlobalMeta, z.core.$ZodType<unknown, unknown, z.core.$ZodTypeInternals<unknown, unknown>>>;
};
