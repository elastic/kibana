import type { AnyPrimitiveDefinition } from '../define/primitive_module';
/** What {@link assertPackRegistrationComplete} needs to compare a pack against its directory. */
export interface PackRegistrationOptions {
    /** Directory whose subdirectories are one primitive each. A relative path resolves against the working directory; a `URL` is resolved with `fileURLToPath`. */
    primitivesDir: URL | string;
    /** The pack's registry array, as passed to `definePrimitivePack`. */
    registered: readonly AnyPrimitiveDefinition[];
    /** Subdirectory names that hold no primitive. */
    ignore?: readonly string[];
}
/**
 * Fails when the primitives directory and the pack's registry disagree: a
 * subdirectory with no entry file or no exported definition, a defined type
 * nothing registers, or a registered type no directory defines. Each problem
 * line carries its fix.
 *
 * A pack keeps two hand-written lists, the registry array and the body-node
 * union, and nothing in the type system relates either to the directory they
 * describe. A primitive absent from both lists leaves them agreeing with each
 * other, so it compiles and every other test passes while the primitive is
 * unreachable. This is the check that notices.
 *
 * @example
 * ```ts
 * await assertPackRegistrationComplete({
 *   primitivesDir: new URL('./primitives/', import.meta.url),
 *   registered: slideDeckPrimitives,
 * });
 * ```
 */
export declare const assertPackRegistrationComplete: ({ primitivesDir, registered, ignore, }: PackRegistrationOptions) => Promise<void>;
