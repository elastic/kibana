import { type PrimitivePack } from '../pack/primitive_pack';
/**
 * Fails when any icon in `pack` breaks the rules a host relies on to inline it: a single `<svg viewBox="0 0 16 16">` root, allowlisted shape elements and geometry or paint attributes, and paint limited to `none`, `currentColor`, or `var(--isomer-icon-*)` with an optional `currentColor` or hex fallback.
 *
 * @example
 * ```ts
 * assertPackIconsValid(slidesPack);
 * ```
 */
export declare const assertPackIconsValid: ({ icons, primitives, }: Pick<PrimitivePack, "icons" | "primitives">) => void;
