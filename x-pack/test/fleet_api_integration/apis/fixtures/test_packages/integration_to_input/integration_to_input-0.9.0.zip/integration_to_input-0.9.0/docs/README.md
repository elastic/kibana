# Log Package

The log package is used as a generic package based on which any log file can be tailed by adjusting the ingest pipeline.
