# System package

This is a very basic system package which contains the configurations for cpu, load and memory.
