# Endpoint package

This is a module for the Endpoint Kibana App and Elastic Endpoint. It sets up the templates, index patterns, aliases, and dashboards.
