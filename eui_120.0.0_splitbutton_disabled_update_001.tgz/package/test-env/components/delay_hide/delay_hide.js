"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.EuiDelayHide = void 0;
var _slicedToArray2 = _interopRequireDefault(require("@babel/runtime/helpers/slicedToArray"));
var _react = require("react");
/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */

function isComponentBecomingVisible() {
  var prevHide = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : false;
  var nextHide = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : false;
  return prevHide === true && nextHide === false;
}
var EuiDelayHide = exports.EuiDelayHide = function EuiDelayHide(_ref) {
  var _ref$hide = _ref.hide,
    hide = _ref$hide === void 0 ? false : _ref$hide,
    _ref$minimumDuration = _ref.minimumDuration,
    minimumDuration = _ref$minimumDuration === void 0 ? 1000 : _ref$minimumDuration,
    render = _ref.render;
  var _useState = (0, _react.useState)(hide),
    _useState2 = (0, _slicedToArray2.default)(_useState, 2),
    countdownExpired = _useState2[0],
    setCountdownExpired = _useState2[1];
  var _useState3 = (0, _react.useState)(hide),
    _useState4 = (0, _slicedToArray2.default)(_useState3, 2),
    prevHide = _useState4[0],
    setPrevHide = _useState4[1];
  if (hide !== prevHide) {
    setPrevHide(hide);
    if (isComponentBecomingVisible(prevHide, hide)) {
      setCountdownExpired(false);
    }
  }
  (0, _react.useEffect)(function () {
    if (countdownExpired === false) {
      var timeoutId = window.setTimeout(function () {
        return setCountdownExpired(true);
      }, minimumDuration);
      return function () {
        return window.clearTimeout(timeoutId);
      };
    }
  }, [countdownExpired, minimumDuration]);
  return hide === true && countdownExpired ? null : render();
};
EuiDelayHide.displayName = 'EuiDelayHide';