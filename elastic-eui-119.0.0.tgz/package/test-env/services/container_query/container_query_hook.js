"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.useEuiContainerQuery = useEuiContainerQuery;
var _slicedToArray2 = _interopRequireDefault(require("@babel/runtime/helpers/slicedToArray"));
var _react = require("react");
var _match_container = require("./match_container");
/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */

/**
 * React hook that subscribes to CSS container query changes.
 *
 * For this to work:
 * - a proper container (an element with e.g. `container-type: inline-size`) is needed, and
 * - the container MUST to be a parent of the element being observed
 *
 * @param containerCondition - A CSS `<container-condition>` string, e.g. `(width > 400px)` or `(min-width: 600px)`
 * @param name - Optional container name, e.g. `sidebar`
 * @returns An object containing:
 *   - `ref`: A ref to attach to the container element
 *   - `matches`: `true` if the container matches the condition, `false` otherwise
 *
 * @example
 * ```tsx
 * const { ref, matches } = useEuiContainerQuery('(width > 400px)');
 * return <div ref={ref}>{matches ? 'Wide' : 'Narrow'}</div>;
 * ```
 *
 * @see {@link https://developer.mozilla.org/en-US/docs/Web/CSS/Reference/At-rules/@container | MDN: @container}
 * @beta
 */
function useEuiContainerQuery(containerCondition, name) {
  var containerQueryString = name ? "".concat(name, " ").concat(containerCondition) : containerCondition;
  var ref = (0, _react.useRef)(null);
  var _useState = (0, _react.useState)(false),
    _useState2 = (0, _slicedToArray2.default)(_useState, 2),
    matches = _useState2[0],
    setMatches = _useState2[1];
  (0, _react.useEffect)(function () {
    if (!ref.current) return;
    var queryList = (0, _match_container.matchContainer)(ref.current, containerQueryString);
    var handleChange = function handleChange() {
      setMatches(queryList.matches);
    };
    setMatches(queryList.matches);
    queryList.addEventListener('change', handleChange);
    return function () {
      queryList.removeEventListener('change', handleChange);
      queryList.dispose();
    };
  }, [ref, containerQueryString]);
  return {
    ref: ref,
    matches: matches
  };
}