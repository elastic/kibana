"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
var _typeof = require("@babel/runtime/helpers/typeof");
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.icon = void 0;
var _extends2 = _interopRequireDefault(require("@babel/runtime/helpers/extends"));
var _objectWithoutProperties2 = _interopRequireDefault(require("@babel/runtime/helpers/objectWithoutProperties"));
var React = _interopRequireWildcard(require("react"));
var _react2 = require("@emotion/react");
var _excluded = ["title", "titleId"];
/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */
// THIS IS A GENERATED FILE. DO NOT MODIFY MANUALLY. @see scripts/compile-icons.js
function _getRequireWildcardCache(e) { if ("function" != typeof WeakMap) return null; var r = new WeakMap(), t = new WeakMap(); return (_getRequireWildcardCache = function _getRequireWildcardCache(e) { return e ? t : r; })(e); }
function _interopRequireWildcard(e, r) { if (!r && e && e.__esModule) return e; if (null === e || "object" != _typeof(e) && "function" != typeof e) return { default: e }; var t = _getRequireWildcardCache(r); if (t && t.has(e)) return t.get(e); var n = { __proto__: null }, a = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var u in e) if ("default" !== u && {}.hasOwnProperty.call(e, u)) { var i = a ? Object.getOwnPropertyDescriptor(e, u) : null; i && (i.get || i.set) ? Object.defineProperty(n, u, i) : n[u] = e[u]; } return n.default = e, t && t.set(e, n), n; }
var EuiIconBackgroundTask = function EuiIconBackgroundTask(_ref) {
  var title = _ref.title,
    titleId = _ref.titleId,
    props = (0, _objectWithoutProperties2.default)(_ref, _excluded);
  return (0, _react2.jsx)("svg", (0, _extends2.default)({
    xmlns: "http://www.w3.org/2000/svg",
    width: 16,
    height: 16,
    viewBox: "0 0 16 16",
    "aria-labelledby": titleId
  }, props), title ? (0, _react2.jsx)("title", {
    id: titleId
  }, title) : null, (0, _react2.jsx)("path", {
    fillRule: "evenodd",
    d: "M11.157 9.013a1.004 1.004 0 0 1 .373.14l4 2.5a1 1 0 0 1 0 1.695l-4 2.5A1 1 0 0 1 10 15v-5l.009-.135a1 1 0 0 1 .407-.677l.1-.063a1 1 0 0 1 .641-.112ZM11 15l4-2.5-1.122-.702-.849-.53L11 10v5Z",
    clipRule: "evenodd"
  }), (0, _react2.jsx)("path", {
    d: "M6.45 13.794a5.99 5.99 0 0 0 1.55.205v1a6.993 6.993 0 0 1-1.81-.24l.26-.965Zm-2.692-1.552c.373.373.792.692 1.243.952l-.5.866a6.99 6.99 0 0 1-1.45-1.11l.707-.708ZM2.205 9.55a6.06 6.06 0 0 0 .6 1.449l-.433.249-.433.25a7.07 7.07 0 0 1-.7-1.688l.483-.13.483-.13ZM8.001.999a7 7 0 0 1 7 7c0 .683-.1 1.342-.284 1.966l-.887-.555a5.97 5.97 0 0 0 .171-1.411 6 6 0 0 0-6-6v-1ZM2.805 4.997A6.013 6.013 0 0 0 2 7.998L1.001 8a7.022 7.022 0 0 1 .937-3.502l.867.5ZM6.45 2.201a6.036 6.036 0 0 0-2.692 1.554L3.405 3.4l-.353-.353a7.036 7.036 0 0 1 3.137-1.812l.26.966Z"
  }));
};
var icon = exports.icon = EuiIconBackgroundTask;