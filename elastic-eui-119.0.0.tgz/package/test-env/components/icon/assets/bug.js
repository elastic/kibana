"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
var _typeof = require("@babel/runtime/helpers/typeof");
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.icon = void 0;
var _extends2 = _interopRequireDefault(require("@babel/runtime/helpers/extends"));
var _objectWithoutProperties2 = _interopRequireDefault(require("@babel/runtime/helpers/objectWithoutProperties"));
var React = _interopRequireWildcard(require("react"));
var _react2 = require("@emotion/react");
var _excluded = ["title", "titleId"];
/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */
// THIS IS A GENERATED FILE. DO NOT MODIFY MANUALLY. @see scripts/compile-icons.js
function _getRequireWildcardCache(e) { if ("function" != typeof WeakMap) return null; var r = new WeakMap(), t = new WeakMap(); return (_getRequireWildcardCache = function _getRequireWildcardCache(e) { return e ? t : r; })(e); }
function _interopRequireWildcard(e, r) { if (!r && e && e.__esModule) return e; if (null === e || "object" != _typeof(e) && "function" != typeof e) return { default: e }; var t = _getRequireWildcardCache(r); if (t && t.has(e)) return t.get(e); var n = { __proto__: null }, a = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var u in e) if ("default" !== u && {}.hasOwnProperty.call(e, u)) { var i = a ? Object.getOwnPropertyDescriptor(e, u) : null; i && (i.get || i.set) ? Object.defineProperty(n, u, i) : n[u] = e[u]; } return n.default = e, t && t.set(e, n), n; }
var EuiIconBug = function EuiIconBug(_ref) {
  var title = _ref.title,
    titleId = _ref.titleId,
    props = (0, _objectWithoutProperties2.default)(_ref, _excluded);
  return (0, _react2.jsx)("svg", (0, _extends2.default)({
    xmlns: "http://www.w3.org/2000/svg",
    width: 16,
    height: 16,
    viewBox: "0 0 16 16",
    "aria-labelledby": titleId
  }, props), title ? (0, _react2.jsx)("title", {
    id: titleId
  }, title) : null, (0, _react2.jsx)("path", {
    fillRule: "evenodd",
    d: "m6 2.294.896.895a3.309 3.309 0 0 1 2.208 0L10 2.294V1.001h1v1.293a1 1 0 0 1-.293.707l-.682.68c.665.489 1.194 1.207 1.537 2.05L13 4.294V2h1v2.293a1 1 0 0 1-.293.707l-1.821 1.82c.074.382.114.778.114 1.18h1.293a1 1 0 0 1 .707.293l1.354 1.353-.707.707L13.293 9h-1.375a5.828 5.828 0 0 1-.54 1.672L12.708 12a1 1 0 0 1 .293.707V15h-1v-2.293l-1.17-1.17C10.124 12.429 9.14 13 8.001 13s-2.123-.57-2.831-1.463L4 12.708v2.293H3v-2.293a1 1 0 0 1 .293-.707l1.327-1.328A5.829 5.829 0 0 1 4.082 9H2.707l-1.353 1.354-.708-.708L2 8.294a1 1 0 0 1 .707-.293H4c0-.402.039-.798.113-1.18l-1.82-1.82A1 1 0 0 1 2 4.294V2h1v2.293L4.438 5.73c.342-.843.872-1.561 1.536-2.05L5.293 3A1 1 0 0 1 5 2.294V1.001h1v1.293ZM5.401 6A4.985 4.985 0 0 0 5 8c0 2.08 1.154 3.628 2.5 3.94V7h1v4.941c1.346-.313 2.5-1.86 2.5-3.94 0-.746-.149-1.423-.401-2H5.4ZM8 4c-.727 0-1.432.368-1.977 1h3.954C9.432 4.368 8.727 4 8 4Z",
    clipRule: "evenodd"
  }));
};
var icon = exports.icon = EuiIconBug;