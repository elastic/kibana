"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
var _typeof = require("@babel/runtime/helpers/typeof");
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.icon = void 0;
var _extends2 = _interopRequireDefault(require("@babel/runtime/helpers/extends"));
var _objectWithoutProperties2 = _interopRequireDefault(require("@babel/runtime/helpers/objectWithoutProperties"));
var React = _interopRequireWildcard(require("react"));
var _react2 = require("@emotion/react");
var _excluded = ["title", "titleId"];
/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */
// THIS IS A GENERATED FILE. DO NOT MODIFY MANUALLY. @see scripts/compile-icons.js
function _getRequireWildcardCache(e) { if ("function" != typeof WeakMap) return null; var r = new WeakMap(), t = new WeakMap(); return (_getRequireWildcardCache = function _getRequireWildcardCache(e) { return e ? t : r; })(e); }
function _interopRequireWildcard(e, r) { if (!r && e && e.__esModule) return e; if (null === e || "object" != _typeof(e) && "function" != typeof e) return { default: e }; var t = _getRequireWildcardCache(r); if (t && t.has(e)) return t.get(e); var n = { __proto__: null }, a = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var u in e) if ("default" !== u && {}.hasOwnProperty.call(e, u)) { var i = a ? Object.getOwnPropertyDescriptor(e, u) : null; i && (i.get || i.set) ? Object.defineProperty(n, u, i) : n[u] = e[u]; } return n.default = e, t && t.set(e, n), n; }
var EuiIconChartWaterfall = function EuiIconChartWaterfall(_ref) {
  var title = _ref.title,
    titleId = _ref.titleId,
    props = (0, _objectWithoutProperties2.default)(_ref, _excluded);
  return (0, _react2.jsx)("svg", (0, _extends2.default)({
    xmlns: "http://www.w3.org/2000/svg",
    width: 16,
    height: 16,
    viewBox: "0 0 16 16",
    "aria-labelledby": titleId
  }, props), title ? (0, _react2.jsx)("title", {
    id: titleId
  }, title) : null, (0, _react2.jsx)("path", {
    d: "M2 14h13v1H2a1 1 0 0 1-1-1V1h1v13Z"
  }), (0, _react2.jsx)("path", {
    fillRule: "evenodd",
    d: "M13.102 10.005A1 1 0 0 1 14 11v1l-.005.102a1 1 0 0 1-.893.893L13 13h-3l-.103-.005a1 1 0 0 1-.892-.893L9 12v-1a1 1 0 0 1 .897-.995L10 10h3l.102.005ZM10 12h3v-1h-3v1Z",
    clipRule: "evenodd"
  }), (0, _react2.jsx)("path", {
    d: "M4 12H3v-1h1v1Zm2 0H5v-1h1v1Zm2 0H7v-1h1v1Z"
  }), (0, _react2.jsx)("path", {
    fillRule: "evenodd",
    d: "M11 6a1 1 0 0 1 1 1v1a1 1 0 0 1-.898.995L11 9H8l-.103-.005a1 1 0 0 1-.892-.892L7 8V7a1 1 0 0 1 1-1h3ZM8 8h3V7H8v1Z",
    clipRule: "evenodd"
  }), (0, _react2.jsx)("path", {
    d: "M4 8H3V7h1v1Zm2 0H5V7h1v1Zm8 0h-1V7h1v1Z"
  }), (0, _react2.jsx)("path", {
    fillRule: "evenodd",
    d: "M11.102 2.005A1 1 0 0 1 12 3v1l-.005.103a1 1 0 0 1-.893.892L11 5H4l-.103-.005a1 1 0 0 1-.892-.892L3 4V3a1 1 0 0 1 .897-.995L4 2h7l.102.005ZM4 4h7V3H4v1Z",
    clipRule: "evenodd"
  }), (0, _react2.jsx)("path", {
    d: "M14 4h-1V3h1v1Z"
  }));
};
var icon = exports.icon = EuiIconChartWaterfall;