"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
var _typeof = require("@babel/runtime/helpers/typeof");
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.icon = void 0;
var _extends2 = _interopRequireDefault(require("@babel/runtime/helpers/extends"));
var _objectWithoutProperties2 = _interopRequireDefault(require("@babel/runtime/helpers/objectWithoutProperties"));
var React = _interopRequireWildcard(require("react"));
var _react2 = require("@emotion/react");
var _excluded = ["title", "titleId"];
/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */
// THIS IS A GENERATED FILE. DO NOT MODIFY MANUALLY. @see scripts/compile-icons.js
function _getRequireWildcardCache(e) { if ("function" != typeof WeakMap) return null; var r = new WeakMap(), t = new WeakMap(); return (_getRequireWildcardCache = function _getRequireWildcardCache(e) { return e ? t : r; })(e); }
function _interopRequireWildcard(e, r) { if (!r && e && e.__esModule) return e; if (null === e || "object" != _typeof(e) && "function" != typeof e) return { default: e }; var t = _getRequireWildcardCache(r); if (t && t.has(e)) return t.get(e); var n = { __proto__: null }, a = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var u in e) if ("default" !== u && {}.hasOwnProperty.call(e, u)) { var i = a ? Object.getOwnPropertyDescriptor(e, u) : null; i && (i.get || i.set) ? Object.defineProperty(n, u, i) : n[u] = e[u]; } return n.default = e, t && t.set(e, n), n; }
var EuiIconEyeSlash = function EuiIconEyeSlash(_ref) {
  var title = _ref.title,
    titleId = _ref.titleId,
    props = (0, _objectWithoutProperties2.default)(_ref, _excluded);
  return (0, _react2.jsx)("svg", (0, _extends2.default)({
    xmlns: "http://www.w3.org/2000/svg",
    width: 16,
    height: 16,
    viewBox: "0 0 16 16",
    "aria-labelledby": titleId
  }, props), title ? (0, _react2.jsx)("title", {
    id: titleId
  }, title) : null, (0, _react2.jsx)("path", {
    fillRule: "evenodd",
    d: "M4.925 13.197C5.841 13.675 6.875 14 8 14c2.407 0 4.402-1.488 5.707-2.793a16.045 16.045 0 0 0 2.105-2.62l.032-.05.009-.015.003-.005v-.001S15.858 8.514 15 8l.857.514a1 1 0 0 0 0-1.029l-.001-.002-.003-.005-.01-.015a5.978 5.978 0 0 0-.144-.227 16.043 16.043 0 0 0-2.183-2.63l-.707.707A14.611 14.611 0 0 1 14.999 8s-3 5-7 5c-.824 0-1.606-.213-2.328-.55l-.746.747ZM15 8l.857-.515L15 8Z",
    clipRule: "evenodd"
  }), (0, _react2.jsx)("path", {
    d: "m6.262 10.445-1.5 1.5-.721.722-2.687 2.687-.707-.707 14-14 .707.707-2.586 2.585-.71.71-1.613 1.613-.722.722-2.739 2.74-.722.721Zm.961.453A3.001 3.001 0 0 0 10.9 7.223l-.903.903a2 2 0 0 1-1.87 1.87l-.903.902Z"
  }), (0, _react2.jsx)("path", {
    fillRule: "evenodd",
    d: "M11.075 2.804C10.16 2.324 9.125 2 8 2 5.593 2 3.598 3.488 2.293 4.793a16.04 16.04 0 0 0-2.106 2.62 5.95 5.95 0 0 0-.031.05l-.01.015-.002.005v.001c-.001 0-.002.001.856.516l-.858-.515c-.19.317-.19.713 0 1.03l.002.002.003.005.009.015a6.117 6.117 0 0 0 .145.227 16.042 16.042 0 0 0 2.183 2.63l.707-.706C1.827 9.378 1 8 1 8s3-5 7-5c.825 0 1.607.213 2.329.55l.746-.746ZM.143 8.515 1 8c-.858.514-.857.515-.857.515Z",
    clipRule: "evenodd"
  }), (0, _react2.jsx)("path", {
    d: "M8.777 5.102a3.004 3.004 0 0 0-3.675 3.675l.902-.902a2 2 0 0 1 1.871-1.871l.902-.902Z"
  }));
};
var icon = exports.icon = EuiIconEyeSlash;