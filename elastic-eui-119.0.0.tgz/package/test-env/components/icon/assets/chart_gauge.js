"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
var _typeof = require("@babel/runtime/helpers/typeof");
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.icon = void 0;
var _extends2 = _interopRequireDefault(require("@babel/runtime/helpers/extends"));
var _objectWithoutProperties2 = _interopRequireDefault(require("@babel/runtime/helpers/objectWithoutProperties"));
var React = _interopRequireWildcard(require("react"));
var _react2 = require("@emotion/react");
var _excluded = ["title", "titleId"];
/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */
// THIS IS A GENERATED FILE. DO NOT MODIFY MANUALLY. @see scripts/compile-icons.js
function _getRequireWildcardCache(e) { if ("function" != typeof WeakMap) return null; var r = new WeakMap(), t = new WeakMap(); return (_getRequireWildcardCache = function _getRequireWildcardCache(e) { return e ? t : r; })(e); }
function _interopRequireWildcard(e, r) { if (!r && e && e.__esModule) return e; if (null === e || "object" != _typeof(e) && "function" != typeof e) return { default: e }; var t = _getRequireWildcardCache(r); if (t && t.has(e)) return t.get(e); var n = { __proto__: null }, a = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var u in e) if ("default" !== u && {}.hasOwnProperty.call(e, u)) { var i = a ? Object.getOwnPropertyDescriptor(e, u) : null; i && (i.get || i.set) ? Object.defineProperty(n, u, i) : n[u] = e[u]; } return n.default = e, t && t.set(e, n), n; }
var EuiIconChartGauge = function EuiIconChartGauge(_ref) {
  var title = _ref.title,
    titleId = _ref.titleId,
    props = (0, _objectWithoutProperties2.default)(_ref, _excluded);
  return (0, _react2.jsx)("svg", (0, _extends2.default)({
    xmlns: "http://www.w3.org/2000/svg",
    width: 16,
    height: 16,
    viewBox: "0 0 16 16",
    "aria-labelledby": titleId
  }, props), title ? (0, _react2.jsx)("title", {
    id: titleId
  }, title) : null, (0, _react2.jsx)("path", {
    d: "M8 2c1.315 0 2.63.37 3.778 1.107l-.725.726A5.99 5.99 0 0 0 8 3a5.98 5.98 0 0 0-4.242 1.758A5.98 5.98 0 0 0 2 9a5.98 5.98 0 0 0 1.758 4.242l-.708.708A6.98 6.98 0 0 1 1 9a6.98 6.98 0 0 1 2.05-4.95A6.98 6.98 0 0 1 8 2Zm5.892 3.222A6.987 6.987 0 0 1 15 9a6.98 6.98 0 0 1-2.05 4.95l-.708-.708A5.98 5.98 0 0 0 14 9a5.99 5.99 0 0 0-.834-3.053l.726-.725Z"
  }), (0, _react2.jsx)("path", {
    d: "M4.465 11.828a.5.5 0 1 1 .707.707.5.5 0 0 1-.707-.707Zm6.363 0a.5.5 0 1 1 .707.708.5.5 0 0 1-.707-.708Z"
  }), (0, _react2.jsx)("path", {
    fillRule: "evenodd",
    d: "M13.35 4.35 9.719 7.98a2 2 0 0 1-2.738 2.738l-.63.632-.7-.7.631-.631A2 2 0 0 1 9.018 7.28l3.632-3.63.7.699ZM8 8a1 1 0 1 0 0 2 1 1 0 0 0 0-2Z",
    clipRule: "evenodd"
  }), (0, _react2.jsx)("path", {
    d: "M3.5 8.5a.5.5 0 1 1 0 1 .5.5 0 0 1 0-1Zm9 0a.5.5 0 1 1 0 1 .5.5 0 0 1 0-1ZM4.465 5.465a.5.5 0 1 1 .707.707.5.5 0 0 1-.707-.707ZM8 4a.5.5 0 1 1 0 1 .5.5 0 0 1 0-1Z"
  }));
};
var icon = exports.icon = EuiIconChartGauge;