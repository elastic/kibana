"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
var _typeof = require("@babel/runtime/helpers/typeof");
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.icon = void 0;
var _extends2 = _interopRequireDefault(require("@babel/runtime/helpers/extends"));
var _objectWithoutProperties2 = _interopRequireDefault(require("@babel/runtime/helpers/objectWithoutProperties"));
var React = _interopRequireWildcard(require("react"));
var _react2 = require("@emotion/react");
var _excluded = ["title", "titleId"];
/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */
// THIS IS A GENERATED FILE. DO NOT MODIFY MANUALLY. @see scripts/compile-icons.js
function _getRequireWildcardCache(e) { if ("function" != typeof WeakMap) return null; var r = new WeakMap(), t = new WeakMap(); return (_getRequireWildcardCache = function _getRequireWildcardCache(e) { return e ? t : r; })(e); }
function _interopRequireWildcard(e, r) { if (!r && e && e.__esModule) return e; if (null === e || "object" != _typeof(e) && "function" != typeof e) return { default: e }; var t = _getRequireWildcardCache(r); if (t && t.has(e)) return t.get(e); var n = { __proto__: null }, a = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var u in e) if ("default" !== u && {}.hasOwnProperty.call(e, u)) { var i = a ? Object.getOwnPropertyDescriptor(e, u) : null; i && (i.get || i.set) ? Object.defineProperty(n, u, i) : n[u] = e[u]; } return n.default = e, t && t.set(e, n), n; }
var EuiIconChartHeatmap = function EuiIconChartHeatmap(_ref) {
  var title = _ref.title,
    titleId = _ref.titleId,
    props = (0, _objectWithoutProperties2.default)(_ref, _excluded);
  return (0, _react2.jsx)("svg", (0, _extends2.default)({
    xmlns: "http://www.w3.org/2000/svg",
    width: 16,
    height: 16,
    viewBox: "0 0 16 16",
    "aria-labelledby": titleId
  }, props), title ? (0, _react2.jsx)("title", {
    id: titleId
  }, title) : null, (0, _react2.jsx)("path", {
    d: "M2 14h13v1H2a1 1 0 0 1-1-1V1h1v13Z"
  }), (0, _react2.jsx)("path", {
    fillRule: "evenodd",
    d: "M5 10a1 1 0 0 1 1 1v1a1 1 0 0 1-.897.995L5 13H4l-.103-.005a1 1 0 0 1-.892-.893L3 12v-1a1 1 0 0 1 1-1h1Zm-1 2h1v-1H4v1Zm9-2a1 1 0 0 1 1 1v1a1 1 0 0 1-.898.995L13 13h-1l-.102-.005a1 1 0 0 1-.893-.893L11 12v-1a1 1 0 0 1 1-1h1Zm-1 2h1v-1h-1v1Z",
    clipRule: "evenodd"
  }), (0, _react2.jsx)("path", {
    d: "M9 12H8v-1h1v1Z"
  }), (0, _react2.jsx)("path", {
    fillRule: "evenodd",
    d: "M5 6a1 1 0 0 1 1 1v1a1 1 0 0 1-.897.995L5 9H4l-.103-.005a1 1 0 0 1-.892-.892L3 8V7a1 1 0 0 1 1-1h1ZM4 8h1V7H4v1Zm5-2a1 1 0 0 1 1 1v1a1 1 0 0 1-.897.995L9 9H8l-.103-.005a1 1 0 0 1-.892-.892L7 8V7a1 1 0 0 1 1-1h1ZM8 8h1V7H8v1Z",
    clipRule: "evenodd"
  }), (0, _react2.jsx)("path", {
    d: "M13 8h-1V7h1v1Z"
  }), (0, _react2.jsx)("path", {
    fillRule: "evenodd",
    d: "M9 2a1 1 0 0 1 1 1v1a1 1 0 0 1-.897.995L9 5H8l-.103-.005a1 1 0 0 1-.892-.892L7 4V3a1 1 0 0 1 1-1h1ZM8 4h1V3H8v1Zm5-2a1 1 0 0 1 1 1v1a1 1 0 0 1-.898.995L13 5h-1l-.102-.005a1 1 0 0 1-.893-.892L11 4V3a1 1 0 0 1 1-1h1Zm-1 2h1V3h-1v1Z",
    clipRule: "evenodd"
  }), (0, _react2.jsx)("path", {
    d: "M5 4H4V3h1v1Z"
  }));
};
var icon = exports.icon = EuiIconChartHeatmap;