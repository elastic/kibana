"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
var _typeof = require("@babel/runtime/helpers/typeof");
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.icon = void 0;
var _extends2 = _interopRequireDefault(require("@babel/runtime/helpers/extends"));
var _objectWithoutProperties2 = _interopRequireDefault(require("@babel/runtime/helpers/objectWithoutProperties"));
var React = _interopRequireWildcard(require("react"));
var _react2 = require("@emotion/react");
var _excluded = ["title", "titleId"];
/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */
// THIS IS A GENERATED FILE. DO NOT MODIFY MANUALLY. @see scripts/compile-icons.js
function _getRequireWildcardCache(e) { if ("function" != typeof WeakMap) return null; var r = new WeakMap(), t = new WeakMap(); return (_getRequireWildcardCache = function _getRequireWildcardCache(e) { return e ? t : r; })(e); }
function _interopRequireWildcard(e, r) { if (!r && e && e.__esModule) return e; if (null === e || "object" != _typeof(e) && "function" != typeof e) return { default: e }; var t = _getRequireWildcardCache(r); if (t && t.has(e)) return t.get(e); var n = { __proto__: null }, a = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var u in e) if ("default" !== u && {}.hasOwnProperty.call(e, u)) { var i = a ? Object.getOwnPropertyDescriptor(e, u) : null; i && (i.get || i.set) ? Object.defineProperty(n, u, i) : n[u] = e[u]; } return n.default = e, t && t.set(e, n), n; }
var EuiIconDatabase = function EuiIconDatabase(_ref) {
  var title = _ref.title,
    titleId = _ref.titleId,
    props = (0, _objectWithoutProperties2.default)(_ref, _excluded);
  return (0, _react2.jsx)("svg", (0, _extends2.default)({
    xmlns: "http://www.w3.org/2000/svg",
    width: 16,
    height: 16,
    viewBox: "0 0 16 16",
    "aria-labelledby": titleId
  }, props), title ? (0, _react2.jsx)("title", {
    id: titleId
  }, title) : null, (0, _react2.jsx)("path", {
    d: "M13 10.941a5.18 5.18 0 0 1-.94.443C10.996 11.77 9.56 12 8 12c-1.561 0-2.997-.23-4.06-.616A5.181 5.181 0 0 1 3 10.94v1.56c0 .076.04.212.258.4.216.185.558.375 1.024.544C5.21 13.781 6.524 14 8 14s2.79-.219 3.718-.556c.466-.17.808-.359 1.024-.545.218-.187.258-.323.258-.399v-1.559Zm0-3a5.185 5.185 0 0 1-.94.443C10.996 8.77 9.56 9 8 9c-1.561 0-2.997-.23-4.06-.616A5.185 5.185 0 0 1 3 7.94V9.5c0 .076.04.212.258.4.216.185.558.375 1.024.544C5.21 10.781 6.524 11 8 11s2.79-.219 3.718-.556c.466-.17.808-.359 1.024-.545.218-.187.258-.323.258-.399V7.941Zm0-3a5.185 5.185 0 0 1-.94.443C10.996 5.77 9.56 6 8 6c-1.561 0-2.997-.23-4.06-.616A5.185 5.185 0 0 1 3 4.94V6.5c0 .076.04.212.258.4.216.185.558.375 1.024.544C5.21 7.782 6.524 8 8 8s2.79-.218 3.718-.556c.466-.17.808-.359 1.024-.545.218-.187.258-.323.258-.399V4.941ZM13 3.5c0-.076-.04-.212-.258-.4-.216-.185-.558-.375-1.024-.544C10.79 2.218 9.476 2 8 2s-2.79.218-3.718.556c-.466.17-.808.359-1.024.545C3.04 3.288 3 3.424 3 3.5c0 .076.04.212.258.4.216.185.558.375 1.024.544C5.21 4.782 6.524 5 8 5s2.79-.218 3.718-.556c.466-.17.808-.359 1.024-.545.218-.187.258-.323.258-.399Zm1 9c0 .477-.268.866-.606 1.157-.341.293-.805.534-1.334.727C10.996 14.77 9.56 15 8 15c-1.561 0-2.997-.23-4.06-.616-.529-.193-.993-.434-1.334-.727C2.267 13.366 2 12.977 2 12.5v-9c0-.477.267-.866.606-1.157.341-.293.805-.534 1.334-.727C5.003 1.23 6.44 1 8 1c1.561 0 2.996.23 4.06.616.529.193.993.434 1.334.727.338.291.606.68.606 1.157v9Z"
  }));
};
var icon = exports.icon = EuiIconDatabase;