"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
var _typeof = require("@babel/runtime/helpers/typeof");
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.icon = void 0;
var _extends2 = _interopRequireDefault(require("@babel/runtime/helpers/extends"));
var _objectWithoutProperties2 = _interopRequireDefault(require("@babel/runtime/helpers/objectWithoutProperties"));
var React = _interopRequireWildcard(require("react"));
var _react2 = require("@emotion/react");
var _excluded = ["title", "titleId"];
/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */
// THIS IS A GENERATED FILE. DO NOT MODIFY MANUALLY. @see scripts/compile-icons.js
function _getRequireWildcardCache(e) { if ("function" != typeof WeakMap) return null; var r = new WeakMap(), t = new WeakMap(); return (_getRequireWildcardCache = function _getRequireWildcardCache(e) { return e ? t : r; })(e); }
function _interopRequireWildcard(e, r) { if (!r && e && e.__esModule) return e; if (null === e || "object" != _typeof(e) && "function" != typeof e) return { default: e }; var t = _getRequireWildcardCache(r); if (t && t.has(e)) return t.get(e); var n = { __proto__: null }, a = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var u in e) if ("default" !== u && {}.hasOwnProperty.call(e, u)) { var i = a ? Object.getOwnPropertyDescriptor(e, u) : null; i && (i.get || i.set) ? Object.defineProperty(n, u, i) : n[u] = e[u]; } return n.default = e, t && t.set(e, n), n; }
var EuiIconAt = function EuiIconAt(_ref) {
  var title = _ref.title,
    titleId = _ref.titleId,
    props = (0, _objectWithoutProperties2.default)(_ref, _excluded);
  return (0, _react2.jsx)("svg", (0, _extends2.default)({
    xmlns: "http://www.w3.org/2000/svg",
    width: 16,
    height: 16,
    viewBox: "0 0 16 16",
    "aria-labelledby": titleId
  }, props), title ? (0, _react2.jsx)("title", {
    id: titleId
  }, title) : null, (0, _react2.jsx)("path", {
    fillRule: "evenodd",
    d: "M8.001 1a6.98 6.98 0 0 1 4.95 2.05A6.983 6.983 0 0 1 15 8v.014l-.001.033c0 .029 0 .071-.003.123a8.019 8.019 0 0 1-.264 1.717c-.134.47-.348.985-.695 1.39a2.33 2.33 0 0 1-.143.153 1.987 1.987 0 0 1-.921.515A2.05 2.05 0 0 1 12.5 12c-.668 0-1.175-.3-1.535-.72a3.356 3.356 0 0 1-.575-1.025C9.77 11.294 8.732 12 7.5 12 5.497 12 4 10.134 4 8s1.497-4 3.5-4c1 0 1.875.466 2.5 1.198V4h1v4.03l.004.1a6.336 6.336 0 0 0 .228 1.482c.115.404.277.765.493 1.016.202.236.445.372.776.372s.574-.136.776-.372c.215-.25.378-.61.494-1.015a6.44 6.44 0 0 0 .2-1.114c.014-.153.022-.281.026-.37C14 8.087 14 8.053 14 8.03V8h-.001a5.98 5.98 0 0 0-1.756-4.242A5.982 5.982 0 0 0 8.001 2a5.98 5.98 0 0 0-4.243 1.758A5.978 5.978 0 0 0 2 8c0 1.536.585 3.07 1.757 4.242A5.98 5.98 0 0 0 8 14a5.983 5.983 0 0 0 3.539-1.156c.291.098.611.156.96.156l.187-.005c.082-.005.163-.014.242-.025A6.98 6.98 0 0 1 8 15a6.98 6.98 0 0 1-4.95-2.05A6.982 6.982 0 0 1 .999 8c0-1.79.685-3.583 2.052-4.95A6.98 6.98 0 0 1 8 1ZM7.5 5C6.189 5 5 6.268 5 8s1.189 3 2.5 3S10 9.732 10 8 8.811 5 7.5 5Z",
    clipRule: "evenodd"
  }));
};
var icon = exports.icon = EuiIconAt;