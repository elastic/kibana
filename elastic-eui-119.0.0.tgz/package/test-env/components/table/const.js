"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.EUI_TABLE_CSS_CONTAINER_NAME = void 0;
/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */

/**
 * CSS Container name of the `EuiTable` component.
 * It can be used for dimensional and scroll-state queries.
 *
 * @see {@link EuiTable}
 */
var EUI_TABLE_CSS_CONTAINER_NAME = exports.EUI_TABLE_CSS_CONTAINER_NAME = 'EuiTable';