"use strict";

var _typeof = require("@babel/runtime/helpers/typeof");
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.useEuiTableWithinStickyHeader = exports.EuiTableWithinStickyHeaderProvider = void 0;
var _react = _interopRequireWildcard(require("react"));
var _react2 = require("@emotion/react");
function _getRequireWildcardCache(e) { if ("function" != typeof WeakMap) return null; var r = new WeakMap(), t = new WeakMap(); return (_getRequireWildcardCache = function _getRequireWildcardCache(e) { return e ? t : r; })(e); }
function _interopRequireWildcard(e, r) { if (!r && e && e.__esModule) return e; if (null === e || "object" != _typeof(e) && "function" != typeof e) return { default: e }; var t = _getRequireWildcardCache(r); if (t && t.has(e)) return t.get(e); var n = { __proto__: null }, a = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var u in e) if ("default" !== u && {}.hasOwnProperty.call(e, u)) { var i = a ? Object.getOwnPropertyDescriptor(e, u) : null; i && (i.get || i.set) ? Object.defineProperty(n, u, i) : n[u] = e[u]; } return n.default = e, t && t.set(e, n), n; }
/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */

var EuiTableWithinStickyHeaderContext = /*#__PURE__*/(0, _react.createContext)(false);

/**
 * React context provider to detect whether a component is rendered
 * inside <EuiTableStickyHeader> to prevent duplicated header cell renders.
 * @internal
 */
var EuiTableWithinStickyHeaderProvider = exports.EuiTableWithinStickyHeaderProvider = function EuiTableWithinStickyHeaderProvider(_ref) {
  var children = _ref.children;
  return (0, _react2.jsx)(EuiTableWithinStickyHeaderContext.Provider, {
    value: true
  }, children);
};

/**
 * Returns true if the component (usually the EuiTableHeaderCell or EuiTableHeaderCellCheckbox)
 * is rendered inside EuiTableStickyHeader.
 * @internal
 */
var useEuiTableWithinStickyHeader = exports.useEuiTableWithinStickyHeader = function useEuiTableWithinStickyHeader() {
  return (0, _react.useContext)(EuiTableWithinStickyHeaderContext);
};