"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
var _typeof = require("@babel/runtime/helpers/typeof");
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.EuiButtonGroup = exports.BUTTON_GROUP_GUTTER_SIZES = void 0;
var _extends2 = _interopRequireDefault(require("@babel/runtime/helpers/extends"));
var _objectWithoutProperties2 = _interopRequireDefault(require("@babel/runtime/helpers/objectWithoutProperties"));
var _classnames = _interopRequireDefault(require("classnames"));
var _propTypes = _interopRequireDefault(require("prop-types"));
var _react = _interopRequireWildcard(require("react"));
var _services = require("../../../services");
var _accessibility = require("../../accessibility");
var _button_group_button = require("./button_group_button");
var _button_context = require("../button_context");
var _button_group = require("./button_group.styles");
var _react2 = require("@emotion/react");
var _excluded = ["className", "buttonSize", "color", "idSelected", "idToSelectedMap", "isDisabled", "hasAriaDisabled", "isFullWidth", "isIconOnly", "legend", "name", "onChange", "options", "type"],
  _excluded2 = ["className", "children", "legend", "buttonSize", "variant", "gutterSize", "isDisabled", "hasAriaDisabled", "isFullWidth", "onChange"];
/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */
function _getRequireWildcardCache(e) { if ("function" != typeof WeakMap) return null; var r = new WeakMap(), t = new WeakMap(); return (_getRequireWildcardCache = function _getRequireWildcardCache(e) { return e ? t : r; })(e); }
function _interopRequireWildcard(e, r) { if (!r && e && e.__esModule) return e; if (null === e || "object" != _typeof(e) && "function" != typeof e) return { default: e }; var t = _getRequireWildcardCache(r); if (t && t.has(e)) return t.get(e); var n = { __proto__: null }, a = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var u in e) if ("default" !== u && {}.hasOwnProperty.call(e, u)) { var i = a ? Object.getOwnPropertyDescriptor(e, u) : null; i && (i.get || i.set) ? Object.defineProperty(n, u, i) : n[u] = e[u]; } return n.default = e, t && t.set(e, n), n; }
var EuiButtonGroupOptions = function EuiButtonGroupOptions(_ref) {
  var className = _ref.className,
    _ref$buttonSize = _ref.buttonSize,
    buttonSize = _ref$buttonSize === void 0 ? 's' : _ref$buttonSize,
    _ref$color = _ref.color,
    color = _ref$color === void 0 ? 'text' : _ref$color,
    _ref$idSelected = _ref.idSelected,
    idSelected = _ref$idSelected === void 0 ? '' : _ref$idSelected,
    _ref$idToSelectedMap = _ref.idToSelectedMap,
    idToSelectedMap = _ref$idToSelectedMap === void 0 ? {} : _ref$idToSelectedMap,
    _ref$isDisabled = _ref.isDisabled,
    isDisabled = _ref$isDisabled === void 0 ? false : _ref$isDisabled,
    _ref$hasAriaDisabled = _ref.hasAriaDisabled,
    hasAriaDisabled = _ref$hasAriaDisabled === void 0 ? false : _ref$hasAriaDisabled,
    _ref$isFullWidth = _ref.isFullWidth,
    isFullWidth = _ref$isFullWidth === void 0 ? false : _ref$isFullWidth,
    _ref$isIconOnly = _ref.isIconOnly,
    isIconOnly = _ref$isIconOnly === void 0 ? false : _ref$isIconOnly,
    legend = _ref.legend,
    name = _ref.name,
    onChange = _ref.onChange,
    _ref$options = _ref.options,
    options = _ref$options === void 0 ? [] : _ref$options,
    _ref$type = _ref.type,
    type = _ref$type === void 0 ? 'single' : _ref$type,
    rest = (0, _objectWithoutProperties2.default)(_ref, _excluded);
  var wrapperCssStyles = [_button_group.euiButtonGroupStyles.euiButtonGroup, isFullWidth && _button_group.euiButtonGroupStyles.fullWidth];
  var styles = (0, _services.useEuiMemoizedStyles)(_button_group.euiButtonGroupButtonsStyles);
  var cssStyles = [styles.euiButtonGroup__buttons, isFullWidth && styles.fullWidth, styles.size[buttonSize]];
  var classes = (0, _classnames.default)('euiButtonGroup', {
    'euiButtonGroup-isDisabled': isDisabled
  }, className);
  var typeIsSingle = type === 'single';
  var groupDisabledProps = {
    disabled: hasAriaDisabled ? undefined : isDisabled,
    'aria-disabled': hasAriaDisabled ? isDisabled : undefined
  };
  return (0, _react2.jsx)("fieldset", (0, _extends2.default)({
    css: wrapperCssStyles,
    className: classes
  }, rest, groupDisabledProps), (0, _react2.jsx)(_accessibility.EuiScreenReaderOnly, null, (0, _react2.jsx)("legend", null, legend)), (0, _react2.jsx)("div", {
    css: cssStyles,
    className: "euiButtonGroup__buttons"
  }, options.map(function (option) {
    return (0, _react2.jsx)(_button_group_button.EuiButtonGroupButton, (0, _extends2.default)({
      key: option.id,
      isDisabled: isDisabled,
      hasAriaDisabled: hasAriaDisabled
    }, option, {
      onClick: typeIsSingle ? function () {
        return onChange(option.id, option.value);
      } : function () {
        return onChange(option.id);
      },
      isSelected: typeIsSingle ? option.id === idSelected : idToSelectedMap[option.id],
      color: color,
      size: buttonSize,
      isIconOnly: isIconOnly
    }));
  })));
};
EuiButtonGroupOptions.propTypes = {
  className: _propTypes.default.string,
  "aria-label": _propTypes.default.string,
  "data-test-subj": _propTypes.default.string,
  css: _propTypes.default.any,
  isDisabled: _propTypes.default.bool,
  hasAriaDisabled: _propTypes.default.bool,
  /**
       * Typical sizing is `s`. Medium `m` size should be reserved for major features.
       * `compressed` is meant to be used alongside and within compressed forms.
       */
  buttonSize: _propTypes.default.oneOf(["s", "m", "compressed"]),
  /**
       * Expands the whole group to the full width of the container.
       * Each button gets equal widths no matter the content
       */
  isFullWidth: _propTypes.default.bool,
  /**
       * Hides the label to only show the `iconType` provided by the `option`
       */
  isIconOnly: _propTypes.default.bool,
  /**
       * A hidden group title (required for accessibility)
       */
  legend: _propTypes.default.string.isRequired,
  /**
       * Any of the named color palette options.
       *
       * Do not use the following colors for standalone buttons directly,
       * they exist to serve other components:
       *  - accent
       *  - warning
       */
  color: _propTypes.default.any,
  /**
           * Default for `type` is single so it can also be excluded
           */
  /**
       * Actual type is `'single' | 'multi'`.
       * Determines how the selection of the group should be handled.
       * With `'single'` only one option can be selected at a time (similar to radio group).
       * With `'multi'` multiple options selected (similar to checkbox group).
       */
  type: _propTypes.default.oneOfType([_propTypes.default.oneOfType([_propTypes.default.oneOf(["single", "multi"]), _propTypes.default.oneOf(["single"])]), _propTypes.default.oneOf(["multi"])]),
  /**
       * An array of {@link EuiButtonGroupOptionProps}
       */
  options: _propTypes.default.arrayOf(_propTypes.default.shape({
    /**
       * Each option must have a unique `id` for maintaining selection
       */
    id: _propTypes.default.string.isRequired,
    /**
       * Each option must have a `label` even for icons which will be applied as the `aria-label`
       */
    label: _propTypes.default.node.isRequired,
    /**
       * The value of the radio input.
       */
    value: _propTypes.default.any,
    /**
       * The type of the underlying HTML button
       */
    type: _propTypes.default.any,
    /**
       * By default, will use the button text for the native browser title.
       *
       * This can be either customized or unset via `title: ''` if necessary.
       */
    title: _propTypes.default.any,
    /**
       * Optional custom tooltip content for the button
       */
    toolTipContent: _propTypes.default.node,
    /**
       * Optional props to pass to the underlying **[EuiToolTip](https://eui.elastic.co/docs/components/display/tooltip/)**
       */
    toolTipProps: _propTypes.default.any,
    className: _propTypes.default.string,
    "aria-label": _propTypes.default.string,
    "data-test-subj": _propTypes.default.string,
    css: _propTypes.default.any,
    /**
       * Controls the disabled behavior via the native `disabled` attribute.
       */
    isDisabled: _propTypes.default.bool,
    /**
       * NOTE: Beta feature, may be changed or removed in the future
       *
       * Changes the native `disabled` attribute to `aria-disabled` to preserve focusability.
       * This results in a semantically disabled button without the default browser handling of the disabled state.
       *
       * Use e.g. when a disabled button should have a tooltip.
       */
    hasAriaDisabled: _propTypes.default.bool
  }).isRequired).isRequired,
  /**
           * @deprecated No longer needed. You can safely remove this prop entirely
           */
  name: _propTypes.default.string,
  /**
           * Styles the selected option to look selected (usually with `fill`)
           * Required by and only used in `type='single'`.
           */
  idSelected: _propTypes.default.string,
  /**
           * Multi: Returns the `id` of the clicked option
           */
  /**
           * Single: Returns the `id` of the clicked option and the `value`
           */
  onChange: _propTypes.default.func,
  /**
           * A map of `id`s as keys with the selected boolean values.
           * Required by and only used in `type='multi'`.
           */
  idToSelectedMap: _propTypes.default.shape({})
};
var BUTTON_GROUP_GUTTER_SIZES = exports.BUTTON_GROUP_GUTTER_SIZES = ['none', 'xs', 's', 'm', 'l', 'xl'];
var EuiButtonGroupChildren = function EuiButtonGroupChildren(_ref2) {
  var className = _ref2.className,
    children = _ref2.children,
    legend = _ref2.legend,
    _ref2$buttonSize = _ref2.buttonSize,
    buttonSize = _ref2$buttonSize === void 0 ? 's' : _ref2$buttonSize,
    _ref2$variant = _ref2.variant,
    variant = _ref2$variant === void 0 ? 'default' : _ref2$variant,
    _ref2$gutterSize = _ref2.gutterSize,
    gutterSize = _ref2$gutterSize === void 0 ? 's' : _ref2$gutterSize,
    _ref2$isDisabled = _ref2.isDisabled,
    isDisabled = _ref2$isDisabled === void 0 ? false : _ref2$isDisabled,
    _ref2$hasAriaDisabled = _ref2.hasAriaDisabled,
    hasAriaDisabled = _ref2$hasAriaDisabled === void 0 ? false : _ref2$hasAriaDisabled,
    _ref2$isFullWidth = _ref2.isFullWidth,
    isFullWidth = _ref2$isFullWidth === void 0 ? false : _ref2$isFullWidth,
    _onChange = _ref2.onChange,
    rest = (0, _objectWithoutProperties2.default)(_ref2, _excluded2);
  var wrapperCssStyles = [_button_group.euiButtonGroupStyles.euiButtonGroup, isFullWidth && _button_group.euiButtonGroupStyles.fullWidth];
  var styles = (0, _services.useEuiMemoizedStyles)(_button_group.euiButtonGroupButtonsStyles);
  var cssStyles = [styles.euiButtonGroup__buttons, isFullWidth && styles.fullWidth, gutterSize && gutterSize !== 'none' && styles.gutterSize[gutterSize]];
  var classes = (0, _classnames.default)('euiButtonGroup', {
    'euiButtonGroup-isDisabled': isDisabled
  }, className);
  var contextValue = (0, _react.useMemo)(function () {
    return {
      size: buttonSize,
      isDisabled: isDisabled || undefined,
      hasAriaDisabled: hasAriaDisabled || undefined,
      fullWidth: isFullWidth
    };
  }, [buttonSize, isDisabled, hasAriaDisabled, isFullWidth]);
  return (0, _react2.jsx)("div", (0, _extends2.default)({
    css: wrapperCssStyles,
    className: classes,
    role: "group",
    "data-variant": variant,
    "data-size": buttonSize,
    "aria-label": legend,
    "aria-disabled": isDisabled || undefined
  }, rest), (0, _react2.jsx)("div", {
    css: cssStyles,
    className: "euiButtonGroup__buttons"
  }, (0, _react2.jsx)(_button_context.EuiButtonContext.Provider, {
    value: contextValue
  }, children)));
};

/* Overloaded call signatures let one `EuiButtonGroup` component support both
the `options` API and the `children` API, each with its own precise prop
type, without adding another union layer. */
EuiButtonGroupChildren.propTypes = {
  className: _propTypes.default.string,
  "aria-label": _propTypes.default.string,
  "data-test-subj": _propTypes.default.string,
  css: _propTypes.default.any,
  isDisabled: _propTypes.default.bool,
  hasAriaDisabled: _propTypes.default.bool,
  // Prevents the `options` API from being used in this mode
  /**
       * A group title (required for accessibility).
       * Rendered as `aria-label` on the group element.
       */
  legend: _propTypes.default.string.isRequired,
  /**
       * Pass button components (`EuiButton`, `EuiButtonEmpty`, `EuiButtonIcon`) as children,
       * some specific wrappers, like `EuiToolTip` and `EuiPopover` are allowed.
       */
  children: _propTypes.default.node.isRequired,
  /**
       * Typical sizing is `s`. Medium `m` size should be reserved for major features.
       */
  buttonSize: _propTypes.default.oneOf(["s", "m"]),
  /**
       * Defines the type of a button group, which renders visually and functionally different:
       * - default: arranges buttons in a horizontal row with optional gutter via `gutterSize`
       */
  variant: _propTypes.default.oneOf(["default"]),
  /**
       * Defines the gutter size between children buttons.
       * Applies only when `variant="default"`.
       */
  gutterSize: _propTypes.default.any,
  /**
       * Expands the whole group to the full width of the container.
       * `EuiButton` children will stretch to fill the available space via their `fullWidth` prop.
       */
  isFullWidth: _propTypes.default.bool,
  /**
       * Callback fired when a child button is selected.
       * Returns the `id` of the clicked option.
       * Applies only for `variant="selection"`.
       */
  onChange: _propTypes.default.func
};
// Renders either the (legacy) `options` API or the `children` API depending on which props are provided.
var EuiButtonGroup = exports.EuiButtonGroup = function EuiButtonGroup(props) {
  var options = props.options;
  if (options) {
    return (0, _react2.jsx)(EuiButtonGroupOptions, props);
  }
  return (0, _react2.jsx)(EuiButtonGroupChildren, props);
};