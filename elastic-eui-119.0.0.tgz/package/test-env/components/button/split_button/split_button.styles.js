"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.euiSplitButtonStyles = exports.euiSplitButtonDividerStyles = exports.euiSplitButtonActionStyles = void 0;
var _react = require("@emotion/react");
var _global_styling = require("../../../global_styling");
/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */

var primaryDisabledSelector = ".euiSplitButtonActionPrimary:is(".concat(_global_styling.euiDisabledSelector, ")");
var secondaryDisabledSelector = ".euiSplitButtonActionSecondary:is(".concat(_global_styling.euiDisabledSelector, ")");
var euiSplitButtonStyles = exports.euiSplitButtonStyles = function euiSplitButtonStyles(euiThemeContext, backgroundColor) {
  var euiTheme = euiThemeContext.euiTheme;
  var buttonSizeMap = (0, _global_styling.euiButtonSizeMap)(euiThemeContext);
  var borderStyles = function borderStyles(color) {
    return "\n    &::after {\n      content: '';\n      position: absolute;\n      inset: 0;\n      border: ".concat(euiTheme.border.width.thin, " solid ").concat(color, ";\n      border-radius: ").concat(euiTheme.border.radius.control, ";\n      pointer-events: none;\n    }\n  ");
  };
  return {
    euiSplitButton: /*#__PURE__*/(0, _react.css)("position:relative;display:inline-flex;align-items:center;flex-wrap:nowrap;padding:", euiTheme.size.xs, ";border-radius:", euiTheme.border.radius.control, ";background-color:", backgroundColor, ";&:where([data-size='s']){block-size:", buttonSizeMap.s.height, ";}&:where([data-size='m']){block-size:", buttonSizeMap.m.height, ";}&:has(", primaryDisabledSelector, ", ", secondaryDisabledSelector, "){background-color:", euiTheme.colors.backgroundBaseDisabled, ";};label:euiSplitButton;"),
    hasBorder: /*#__PURE__*/(0, _react.css)((0, _global_styling.highContrastModeStyles)(euiThemeContext, {
      none: "\n          &:where(:not([data-fill])):not(:has(".concat(primaryDisabledSelector, ", ").concat(secondaryDisabledSelector, ")) {\n            ").concat(borderStyles("var(--euiSplitButtonBorderColor)"), "\n          }\n        "),
      preferred: "\n          &:where(:not([data-fill])) {\n            ".concat(borderStyles("var(--euiSplitButtonBorderColor)"), "\n\n            &:has(").concat(primaryDisabledSelector, ", ").concat(secondaryDisabledSelector, ") {\n              ").concat(borderStyles(euiTheme.colors.borderBaseDisabled), "\n            }\n          }\n\n          &:where([data-fill]):has(").concat(primaryDisabledSelector, ", ").concat(secondaryDisabledSelector, ") {\n            ").concat(borderStyles(euiTheme.colors.borderBaseDisabled), "\n          }\n        "),
      forced: "\n          ".concat(borderStyles("var(--euiSplitButtonBorderColor)"), "\n        ")
    }), ";;label:hasBorder;")
  };
};
var euiSplitButtonActionStyles = exports.euiSplitButtonActionStyles = function euiSplitButtonActionStyles(euiThemeContext, size) {
  var euiTheme = euiThemeContext.euiTheme;
  var buttonSizeMap = (0, _global_styling.euiButtonSizeMap)(euiThemeContext);

  // uses smaller sizes due to the buttons being inset into the parent container
  var buttonSize = size === 's' ? buttonSizeMap.xs.height : buttonSizeMap.s.height;
  var buttonMinWidth = size === 's' ? buttonSizeMap.xs.minWidth : buttonSizeMap.s.minWidth;
  var buttonRadius = size === 's' ? buttonSizeMap.xs.radiusInset : buttonSizeMap.s.radiusInset;
  var commonStyles = "\n    block-size: ".concat(buttonSize, ";\n    border-radius: ").concat(buttonRadius, ";\n    /* prevent issues in jsdom where pointer-events: none is inherited from the pseudo element */\n    pointer-events: auto;\n\n     /* zero-specificity ancestor :has() check */\n    &:where(:not(:has(").concat(primaryDisabledSelector, ", ").concat(secondaryDisabledSelector, ")) &) {\n      border: none;\n    }\n    \n    &:where(:has(").concat(primaryDisabledSelector, ", ").concat(secondaryDisabledSelector, ") &) {\n      &:is(").concat(_global_styling.euiDisabledSelector, ") {\n        border: none;\n      }\n    }\n   \n  ");
  return {
    euiSplitButtonActionPrimary: /*#__PURE__*/(0, _react.css)(commonStyles, " z-index:", euiTheme.levels.content, ";&:not(:has(svg:only-child)){min-inline-size:", buttonMinWidth, "px;}&:has(svg:only-child){inline-size:", buttonSize, ";};label:euiSplitButtonActionPrimary;"),
    euiSplitButtonActionSecondary: /*#__PURE__*/(0, _react.css)(commonStyles, " inline-size:", buttonSize, ";;label:euiSplitButtonActionSecondary;")
  };
};
var euiSplitButtonDividerStyles = exports.euiSplitButtonDividerStyles = function euiSplitButtonDividerStyles(euiThemeContext, color) {
  var euiTheme = euiThemeContext.euiTheme;
  return {
    divider: /*#__PURE__*/(0, _react.css)("block-size:calc(100% - ", euiTheme.size.s, ");border-inline-start:", euiTheme.border.width.thin, " solid ", color, ";", (0, _global_styling.logicalCSS)('margin-horizontal', euiTheme.size.xs), ";&:where(\n          ", primaryDisabledSelector, " + &,\n          :has(~ ", secondaryDisabledSelector, ")\n        ){border-color:", euiTheme.colors.borderBaseDisabled, ";};label:divider;")
  };
};