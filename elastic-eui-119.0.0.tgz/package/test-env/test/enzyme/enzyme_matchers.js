"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.setupEuiEnzymeMatchers = exports.hasEuiDisabledProp = exports.euiEnzymeMatchers = void 0;
var _typeof2 = _interopRequireDefault(require("@babel/runtime/helpers/typeof"));
/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */

/* eslint-env jest */

var euiEnzymeMatchers = exports.euiEnzymeMatchers = {
  /**
   * Checks if an Enzyme wrapper has an EUI disabled state.
   * It looks for `disabled`, `isDisabled` and `aria-disabled` props
   */
  toHaveEuiDisabledProp: function toHaveEuiDisabledProp(props) {
    if (!props || (0, _typeof2.default)(props) !== 'object') {
      throw new Error('toHaveEuiDisabledProp() must be called with the props value from ReactWrapper.props()');
    }
    var isDisabled = hasEuiDisabledProp(props);
    return {
      message: function message() {
        return isDisabled ? 'Expected component NOT to have EUI disabled prop, but it was disabled' : 'Expected component to have EUI disabled prop (`disabled`, `isDisabled` or `aria-disabled="true"`)';
      },
      pass: isDisabled
    };
  }
};
var setupEuiEnzymeMatchers = exports.setupEuiEnzymeMatchers = function setupEuiEnzymeMatchers() {
  expect.extend(euiEnzymeMatchers);
};

/* Utilities */

/**
 * Checks if a ReactWrapper has one of the following disabled props enabled:
 * `disabled`, `isDisabled` or attribute or `aria-disabled="true"`.
 */
var hasEuiDisabledProp = exports.hasEuiDisabledProp = function hasEuiDisabledProp(props) {
  return props.disabled === true || props.isDisabled === true || props['aria-disabled'] === true || props['aria-disabled'] === 'true';
};