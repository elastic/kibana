"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.euiBadgeStyles = void 0;
var _react = require("@emotion/react");
var _global_styling = require("../../global_styling");
var _color_utils = require("./color_utils");
function _EMOTION_STRINGIFIED_CSS_ERROR__() { return "You have tried to stringify object returned from `css` function. It isn't supposed to be used directly (e.g. as value of the `className` prop), but rather handed to emotion so it can handle it (e.g. as value of `css` prop)."; } /*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */
var _ref = process.env.NODE_ENV === "production" ? {
  name: "1jbvl30-euiBadge__iconButton",
  styles: "font-size:0;&:disabled{cursor:not-allowed;}.euiBadge__icon{margin:0!important;};label:euiBadge__iconButton;"
} : {
  name: "1jbvl30-euiBadge__iconButton",
  styles: "font-size:0;&:disabled{cursor:not-allowed;}.euiBadge__icon{margin:0!important;};label:euiBadge__iconButton;",
  toString: _EMOTION_STRINGIFIED_CSS_ERROR__
};
var _ref2 = process.env.NODE_ENV === "production" ? {
  name: "1hw5vc4-clickable",
  styles: "cursor:pointer;label:clickable;"
} : {
  name: "1hw5vc4-clickable",
  styles: "cursor:pointer;label:clickable;",
  toString: _EMOTION_STRINGIFIED_CSS_ERROR__
};
var euiBadgeStyles = exports.euiBadgeStyles = function euiBadgeStyles(euiThemeContext) {
  var euiTheme = euiThemeContext.euiTheme;
  var badgeColors = (0, _color_utils.euiBadgeColors)(euiThemeContext);
  var defaultBadgeColors = badgeColors.fill.default;
  var focusOutlineOffset = (0, _global_styling.mathWithUnits)([euiTheme.focus.width, euiTheme.border.width.thin], function (x, y) {
    return x + y;
  });
  var setBadgeColorVars = function setBadgeColorVars(colors) {
    return "\n    --euiBadgeTextColor: ".concat(colors.color, ";\n    --euiBadgeBackgroundColor: ").concat(colors.backgroundColor, ";\n    --euiBadgeBackgroundHoverColor: ").concat(colors.backgroundHover, ";\n    --euiBadgeBackgroundActiveColor: ").concat(colors.backgroundActive, ";\n    ").concat(colors.borderColor ? "--euiBadgeBorder: ".concat(euiTheme.border.width.thin, " solid ").concat(colors.borderColor, ";") : '', "\n  ");
  };
  var getButtonInteractionStyles = function getButtonInteractionStyles(euiThemeContext) {
    var type = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 'fill';
    return "\n      ".concat((0, _global_styling.euiButtonInteractionStyles)(euiThemeContext, {
      color: 'var(--euiBadgeTextColor)',
      background: 'var(--euiBadgeBackgroundColor)',
      borderColor: 'var(--euiBadgeBorder)',
      backgroundHover: 'var(--euiBadgeBackgroundHoverColor)',
      backgroundActive: 'var(--euiBadgeBackgroundActiveColor)'
    }, type), "\n    ");
  };
  var highContrastStyles = (0, _global_styling.highContrastModeStyles)(euiThemeContext, {
    preferred: "\n      text-decoration: underline;\n    ",
    forced: "\n      &::after { display: none; }\n    "
  });
  var focusStyles = "\n    &:focus {\n      ".concat((0, _global_styling.euiFocusRing)(euiThemeContext, 'outset'), "\n      /* uses custom offset as the default \"outset\" is not enough */\n      outline-offset: ").concat(focusOutlineOffset, ";\n    }\n  ");
  var getClickableStyles = function getClickableStyles(interactionStyles) {
    return "\n    &:not(:disabled) {\n      ".concat(interactionStyles, "\n\n      &:hover,\n      &:focus {\n        ").concat(highContrastStyles, "\n      }\n\n      ").concat(focusStyles, "\n    }\n\n    &:disabled {\n      cursor: not-allowed;\n    }\n  ");
  };
  var customInteractiveStyles = "\n    &:hover {\n      background-color: var(--euiBadgeBackgroundHoverColor);\n    }\n\n    &:active {\n      background-color: var(--euiBadgeBackgroundActiveColor);\n    }\n\n    ".concat(focusStyles, "\n  ");
  var inlinePadding = (0, _global_styling.mathWithUnits)(
  // Account for the (usually transparent) border so that the visual
  // padding is of size s
  [euiTheme.size.s, euiTheme.border.width.thin], function (size, borderWidth) {
    return size - borderWidth;
  });
  return {
    euiBadge: /*#__PURE__*/(0, _react.css)("display:inline-block;vertical-align:middle;", (0, _global_styling.logicalShorthandCSS)('padding', "0 ".concat(inlinePadding)), " ", (0, _global_styling.logicalCSS)('max-width', '100%'), " font-size:", (0, _global_styling.euiFontSize)(euiThemeContext, 'xs').fontSize, ";line-height:", (0, _global_styling.mathWithUnits)(
    // Account for the border
    [euiTheme.size.base, euiTheme.border.width.thin], function (x, y) {
      return x + y * 2;
    }), ";font-weight:", euiTheme.font.weight.medium, ";white-space:nowrap;text-decoration:none;cursor:inherit;border:", euiTheme.border.width.thin, " solid transparent;border-radius:", euiTheme.size.l, ";", (0, _global_styling.logicalTextAlignCSS)('left'), "color:var(--euiBadgeTextColor, ", defaultBadgeColors.color, ");background-color:var(\n        --euiBadgeBackgroundColor,\n        ", defaultBadgeColors.backgroundColor, "\n      );", (0, _global_styling.highContrastModeStyles)(euiThemeContext, {
      preferred: "border: var(--euiBadgeBorder, ".concat(euiTheme.border.thin, ");")
    }), "*::selection{color:var(\n          --euiBadgeBackgroundColor,\n          ", defaultBadgeColors.backgroundColor, "\n        );background-color:var(--euiBadgeTextColor, ", defaultBadgeColors.color, ");}&:focus-within{", (0, _global_styling.euiFocusRing)(euiThemeContext), ";}&+.euiBadge{", (0, _global_styling.logicalCSS)('margin-left', euiTheme.size.xs), ";};label:euiBadge;"),
    iconOnly: /*#__PURE__*/(0, _react.css)("padding-inline:", (0, _global_styling.mathWithUnits)(
    // Account for the border
    [euiTheme.size.xs, euiTheme.border.width.thin], function (size, borderWidth) {
      return size - borderWidth;
    }), ";;label:iconOnly;"),
    get clickable() {
      // ensures border colors are aligned with the background colors
      var borderHoverStyles = "\n        &:hover { \n          border-color: var(--euiBadgeBackgroundHoverColor);\n        }\n        &:active {\n          border-color: var(--euiBadgeBackgroundActiveColor);\n        }\n      ";
      return {
        fill: /*#__PURE__*/(0, _react.css)(getClickableStyles(getButtonInteractionStyles(euiThemeContext, 'fill')), " ", borderHoverStyles, ";;label:fill;"),
        base: /*#__PURE__*/(0, _react.css)(getClickableStyles(getButtonInteractionStyles(euiThemeContext, 'overlay')), " ", (0, _global_styling.highContrastModeStyles)(euiThemeContext, {
          none: borderHoverStyles
        }), ";;label:base;"),
        // hollow has a visible border that must not be overwritten on hover
        hollow: /*#__PURE__*/(0, _react.css)(getClickableStyles(getButtonInteractionStyles(euiThemeContext, 'overlay')), " &:hover,&:focus{", highContrastStyles, ";};label:hollow;"),
        custom: /*#__PURE__*/(0, _react.css)("&:not(:disabled){", customInteractiveStyles, ";&:hover,&:focus{", highContrastStyles, ";}};label:custom;")
      };
    },
    // on icon button hover, we apply hover styles on the entire badge
    get iconClickable() {
      var iconButtonSelector = function iconButtonSelector() {
        var state = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : ':hover';
        return "&:not(:disabled):where(:has(.euiBadge__iconButton".concat(state, "))");
      };
      var borderHoverStyles = "\n        border-color: var(--euiBadgeBackgroundHoverColor);\n      ";
      return {
        fill: /*#__PURE__*/(0, _react.css)(iconButtonSelector(), "{", getButtonInteractionStyles(euiThemeContext, 'fill'), " ", borderHoverStyles, ";}", iconButtonSelector(':is(:hover, :focus)'), "{", highContrastStyles, ";};label:fill;"),
        base: /*#__PURE__*/(0, _react.css)(iconButtonSelector(), "{", getButtonInteractionStyles(euiThemeContext, 'overlay'), " ", (0, _global_styling.highContrastModeStyles)(euiThemeContext, {
          none: borderHoverStyles
        }), ";}", iconButtonSelector(':is(:hover, :focus)'), "{", highContrastStyles, ";};label:base;"),
        // hollow has a visible border that must not be overwritten on hover
        hollow: /*#__PURE__*/(0, _react.css)(iconButtonSelector(), "{", getButtonInteractionStyles(euiThemeContext, 'overlay'), ";}", iconButtonSelector(':is(:hover, :focus)'), "{", highContrastStyles, ";};label:hollow;"),
        custom: /*#__PURE__*/(0, _react.css)(iconButtonSelector(':is(:hover, :focus)'), "{", highContrastStyles, " ", customInteractiveStyles, ";};label:custom;")
      };
    },
    colors: {
      fill: {
        default: /*#__PURE__*/(0, _react.css)(setBadgeColorVars(badgeColors.fill.default), " border-color:", badgeColors.fill.default.borderColor, ";;label:default;"),
        hollow: /*#__PURE__*/(0, _react.css)(setBadgeColorVars(badgeColors.hollow), " border-color:", badgeColors.hollow.borderColor, ";;label:hollow;"),
        primary: /*#__PURE__*/(0, _react.css)(setBadgeColorVars(badgeColors.fill.primary), ";label:primary;"),
        accent: /*#__PURE__*/(0, _react.css)(setBadgeColorVars(badgeColors.fill.accent), ";label:accent;"),
        neutral: /*#__PURE__*/(0, _react.css)(setBadgeColorVars(badgeColors.fill.neutral), ";label:neutral;"),
        success: /*#__PURE__*/(0, _react.css)(setBadgeColorVars(badgeColors.fill.success), ";label:success;"),
        warning: /*#__PURE__*/(0, _react.css)(setBadgeColorVars(badgeColors.fill.warning), ";label:warning;"),
        risk: /*#__PURE__*/(0, _react.css)(setBadgeColorVars(badgeColors.fill.risk), ";label:risk;"),
        danger: /*#__PURE__*/(0, _react.css)(setBadgeColorVars(badgeColors.fill.danger), ";label:danger;")
      },
      base: {
        default: /*#__PURE__*/(0, _react.css)(setBadgeColorVars(badgeColors.base.default), " border-color:", badgeColors.base.default.borderColor, ";;label:default;"),
        hollow: /*#__PURE__*/(0, _react.css)(setBadgeColorVars(badgeColors.hollow), " border-color:", badgeColors.hollow.borderColor, ";;label:hollow;"),
        primary: /*#__PURE__*/(0, _react.css)(setBadgeColorVars(badgeColors.base.primary), ";label:primary;"),
        accent: /*#__PURE__*/(0, _react.css)(setBadgeColorVars(badgeColors.base.accent), ";label:accent;"),
        neutral: /*#__PURE__*/(0, _react.css)(setBadgeColorVars(badgeColors.base.neutral), ";label:neutral;"),
        success: /*#__PURE__*/(0, _react.css)(setBadgeColorVars(badgeColors.base.success), ";label:success;"),
        warning: /*#__PURE__*/(0, _react.css)(setBadgeColorVars(badgeColors.base.warning), ";label:warning;"),
        risk: /*#__PURE__*/(0, _react.css)(setBadgeColorVars(badgeColors.base.risk), ";label:risk;"),
        danger: /*#__PURE__*/(0, _react.css)(setBadgeColorVars(badgeColors.base.danger), ";label:danger;")
      }
    },
    disabled: /*#__PURE__*/(0, _react.css)(setBadgeColorVars(badgeColors.disabled), " border-color:", badgeColors.disabled.borderColor, ";*::selection{color:", euiTheme.colors.backgroundBasePlain, ";};label:disabled;"),
    // Content wrapper
    euiBadge__content: /*#__PURE__*/(0, _react.css)((0, _global_styling.logicalCSS)(
    // Ensure proper height in case of just displaying an icon
    'min-height', "".concat((0, _global_styling.mathWithUnits)(euiTheme.border.width.thin, function (x) {
      return euiTheme.base + x * 2;
    }))), " display:flex;align-items:center;overflow:hidden;;label:euiBadge__content;"),
    // Text
    text: {
      euiBadge__text: /*#__PURE__*/(0, _react.css)((0, _global_styling.euiTextTruncate)(), " padding-inline:", euiTheme.size.xxs, ";cursor:inherit;;label:euiBadge__text;"),
      clickable: _ref2
    },
    // Icon
    icon: {
      euiBadge__icon: /*#__PURE__*/(0, _react.css)(";label:euiBadge__icon;"),
      right: /*#__PURE__*/(0, _react.css)("&:not(:only-child){", (0, _global_styling.logicalCSS)('margin-left', euiTheme.size.xxs), ";};label:right;"),
      left: /*#__PURE__*/(0, _react.css)("&:not(:only-child){", (0, _global_styling.logicalCSS)('margin-right', euiTheme.size.xxs), ";};label:left;")
    },
    // Clickable icons (iconOnClick)
    iconButton: {
      euiBadge__iconButton: _ref,
      right: /*#__PURE__*/(0, _react.css)((0, _global_styling.logicalCSS)('margin-left', euiTheme.size.xxs), ";;label:right;"),
      left: /*#__PURE__*/(0, _react.css)((0, _global_styling.logicalCSS)('margin-right', euiTheme.size.xxs), ";;label:left;")
    },
    // Used in badges with both onClick & iconOnClick
    euiBadge__childButton: /*#__PURE__*/(0, _react.css)((0, _global_styling.euiTextTruncate)(), " text-align:inherit;font-weight:inherit;line-height:inherit;color:inherit;&:disabled{cursor:not-allowed;}&:not(:disabled){&:hover,&:focus{text-decoration:underline;}};label:euiBadge__childButton;")
  };
};