"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "EuiBanner", {
  enumerable: true,
  get: function get() {
    return _banner.EuiBanner;
  }
});
var _banner = require("./banner");