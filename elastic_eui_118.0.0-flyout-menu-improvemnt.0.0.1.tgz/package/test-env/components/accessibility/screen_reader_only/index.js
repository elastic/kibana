"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "EuiScreenReaderOnly", {
  enumerable: true,
  get: function get() {
    return _screen_reader_only.EuiScreenReaderOnly;
  }
});
Object.defineProperty(exports, "euiScreenReaderOnly", {
  enumerable: true,
  get: function get() {
    return _screen_reader_only2.euiScreenReaderOnly;
  }
});
var _screen_reader_only = require("./screen_reader_only");
var _screen_reader_only2 = require("./screen_reader_only.styles");