"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.euiSkipLinkStyles = void 0;
var _react = require("@emotion/react");
function _EMOTION_STRINGIFIED_CSS_ERROR__() { return "You have tried to stringify object returned from `css` function. It isn't supposed to be used directly (e.g. as value of the `className` prop), but rather handed to emotion so it can handle it (e.g. as value of `css` prop)."; } /*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */
var _ref = process.env.NODE_ENV === "production" ? {
  name: "eeqcf0-absolute",
  styles: "&:focus{position:absolute;};label:absolute;"
} : {
  name: "eeqcf0-absolute",
  styles: "&:focus{position:absolute;};label:absolute;",
  toString: _EMOTION_STRINGIFIED_CSS_ERROR__
};
var _ref2 = process.env.NODE_ENV === "production" ? {
  name: "2vmb4n-euiSkipLink",
  styles: "transition:none!important;&:focus{animation:none!important;};label:euiSkipLink;"
} : {
  name: "2vmb4n-euiSkipLink",
  styles: "transition:none!important;&:focus{animation:none!important;};label:euiSkipLink;",
  toString: _EMOTION_STRINGIFIED_CSS_ERROR__
};
var euiSkipLinkStyles = exports.euiSkipLinkStyles = function euiSkipLinkStyles(_ref3) {
  var euiTheme = _ref3.euiTheme;
  return {
    euiSkipLink: _ref2,
    // Positions
    // Set positions on focus only as to not override screenReaderOnly position
    // When positioned absolutely, consumers still need to tell it WHERE (top,left,etc...)
    absolute: _ref,
    fixed: /*#__PURE__*/(0, _react.css)("position:fixed!important;&:focus{inset-block-start:", euiTheme.size.xs, ";inset-inline-start:", euiTheme.size.xs, ";z-index:", Number(euiTheme.levels.header) + 1, ";};label:fixed;")
  };
};