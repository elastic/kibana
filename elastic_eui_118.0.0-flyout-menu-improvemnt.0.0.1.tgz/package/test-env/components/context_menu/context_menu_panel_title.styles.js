"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.euiContextMenuPanelTitleStyles = void 0;
var _react = require("@emotion/react");
var _global_styling = require("../../global_styling");
var _title = require("../title/title.styles");
var _list_item_layout = require("../list_item_layout/_list_item_layout.styles");
/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */

var euiContextMenuPanelTitleStyles = exports.euiContextMenuPanelTitleStyles = function euiContextMenuPanelTitleStyles(euiThemeContext) {
  var _euiListItemVariables = (0, _list_item_layout.euiListItemVariables)(euiThemeContext),
    textPadding = _euiListItemVariables.textPadding;
  return {
    euiContextMenuPanelTitle: /*#__PURE__*/(0, _react.css)("display:flex;align-items:center;", (0, _global_styling.logicalCSS)('padding-horizontal', textPadding.horizontal), " ", (0, _title.euiTitle)(euiThemeContext, 'xxs'), ";;label:euiContextMenuPanelTitle;"),
    text: /*#__PURE__*/(0, _react.css)("flex-grow:1;overflow:hidden;", (0, _global_styling.logicalCSS)('padding-vertical', textPadding.vertical), " ", (0, _global_styling.logicalCSS)('padding-horizontal', textPadding.horizontal), ";;label:text;")
  };
};