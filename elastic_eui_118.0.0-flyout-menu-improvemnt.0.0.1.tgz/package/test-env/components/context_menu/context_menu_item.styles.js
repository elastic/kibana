"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.euiContextMenuItemStyles = void 0;
var _react = require("@emotion/react");
var _global_styling = require("../../global_styling");
function _EMOTION_STRINGIFIED_CSS_ERROR__() { return "You have tried to stringify object returned from `css` function. It isn't supposed to be used directly (e.g. as value of the `className` prop), but rather handed to emotion so it can handle it (e.g. as value of `css` prop)."; } /*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */
var _ref = process.env.NODE_ENV === "production" ? {
  name: "4ak4s8-euiContextMenuItem__arrow",
  styles: "align-self:flex-end;label:euiContextMenuItem__arrow;"
} : {
  name: "4ak4s8-euiContextMenuItem__arrow",
  styles: "align-self:flex-end;label:euiContextMenuItem__arrow;",
  toString: _EMOTION_STRINGIFIED_CSS_ERROR__
};
var _ref2 = process.env.NODE_ENV === "production" ? {
  name: "o1gg22-euiContextMenuItem__text",
  styles: "flex-grow:1;overflow:hidden;label:euiContextMenuItem__text;"
} : {
  name: "o1gg22-euiContextMenuItem__text",
  styles: "flex-grow:1;overflow:hidden;label:euiContextMenuItem__text;",
  toString: _EMOTION_STRINGIFIED_CSS_ERROR__
};
var _ref3 = process.env.NODE_ENV === "production" ? {
  name: "1lzohcs-euiContextMenu__icon",
  styles: "flex-shrink:0;label:euiContextMenu__icon;"
} : {
  name: "1lzohcs-euiContextMenu__icon",
  styles: "flex-shrink:0;label:euiContextMenu__icon;",
  toString: _EMOTION_STRINGIFIED_CSS_ERROR__
};
var _ref4 = process.env.NODE_ENV === "production" ? {
  name: "flyqrm-center",
  styles: ".euiListItemLayout__prepend{align-self:center;};label:center;"
} : {
  name: "flyqrm-center",
  styles: ".euiListItemLayout__prepend{align-self:center;};label:center;",
  toString: _EMOTION_STRINGIFIED_CSS_ERROR__
};
var _ref5 = process.env.NODE_ENV === "production" ? {
  name: "1qfbla9-euiContextMenuItem",
  styles: "display:flex;label:euiContextMenuItem;"
} : {
  name: "1qfbla9-euiContextMenuItem",
  styles: "display:flex;label:euiContextMenuItem;",
  toString: _EMOTION_STRINGIFIED_CSS_ERROR__
};
var euiContextMenuItemStyles = exports.euiContextMenuItemStyles = function euiContextMenuItemStyles(euiThemeContext) {
  var euiTheme = euiThemeContext.euiTheme;
  return {
    euiContextMenuItem: _ref5,
    layoutAlign: {
      center: _ref4,
      top: /*#__PURE__*/(0, _react.css)(".euiListItemLayout__prepend{align-self:flex-start;", (0, _global_styling.logicalCSS)('margin-top', euiTheme.size.s), ";};label:top;"),
      bottom: /*#__PURE__*/(0, _react.css)(".euiListItemLayout__prepend{align-self:flex-end;", (0, _global_styling.logicalCSS)('margin-bottom', euiTheme.size.s), ";};label:bottom;")
    },
    // Children
    euiContextMenu__icon: _ref3,
    text: {
      euiContextMenuItem__text: _ref2
    },
    euiContextMenuItem__arrow: _ref,
    // Colors - maps button color names to text color overrides
    colors: Object.fromEntries(_global_styling.EXTENDED_BUTTON_COLORS.map(function (color) {
      return [color, /*#__PURE__*/(0, _react.css)("color:", (0, _global_styling.euiButtonEmptyColor)(euiThemeContext, color).color, ";;label:colors;")];
    }))
  };
};