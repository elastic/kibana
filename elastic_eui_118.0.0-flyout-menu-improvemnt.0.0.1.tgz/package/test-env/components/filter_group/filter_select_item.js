"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
var _typeof = require("@babel/runtime/helpers/typeof");
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.EuiFilterSelectItem = void 0;
var _extends2 = _interopRequireDefault(require("@babel/runtime/helpers/extends"));
var _defineProperty2 = _interopRequireDefault(require("@babel/runtime/helpers/defineProperty"));
var _objectWithoutProperties2 = _interopRequireDefault(require("@babel/runtime/helpers/objectWithoutProperties"));
var _react = _interopRequireWildcard(require("react"));
var _propTypes = _interopRequireDefault(require("prop-types"));
var _classnames = _interopRequireDefault(require("classnames"));
var _services = require("../../services");
var _flex = require("../flex");
var _tool_tip = require("../tool_tip");
var _icon = require("../icon");
var _filter_select_item = require("./filter_select_item.styles");
var _react2 = require("@emotion/react");
var _excluded = ["children", "className", "disabled", "checked", "isFocused", "showIcons", "toolTipContent", "toolTipProps", "style", "truncateContent", "forwardRef"];
/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */
function _getRequireWildcardCache(e) { if ("function" != typeof WeakMap) return null; var r = new WeakMap(), t = new WeakMap(); return (_getRequireWildcardCache = function _getRequireWildcardCache(e) { return e ? t : r; })(e); }
function _interopRequireWildcard(e, r) { if (!r && e && e.__esModule) return e; if (null === e || "object" != _typeof(e) && "function" != typeof e) return { default: e }; var t = _getRequireWildcardCache(r); if (t && t.has(e)) return t.get(e); var n = { __proto__: null }, a = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var u in e) if ("default" !== u && {}.hasOwnProperty.call(e, u)) { var i = a ? Object.getOwnPropertyDescriptor(e, u) : null; i && (i.get || i.set) ? Object.defineProperty(n, u, i) : n[u] = e[u]; } return n.default = e, t && t.set(e, n), n; }
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { (0, _defineProperty2.default)(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
var resolveIconAndColor = function resolveIconAndColor(checked) {
  if (!checked) {
    return {
      icon: 'empty'
    };
  }
  return checked === 'on' ? {
    icon: 'check',
    color: 'text'
  } : {
    icon: 'cross',
    color: 'text'
  };
};

/**
 * TODO: This component should removed in favor of EuiSelectable usage
 * once EuiComboBox has been converted to dogfood EuiSelectable.
 *
 * @deprecated - Use EuiSelectable instead
 */
var EuiFilterSelectItemComponent = function EuiFilterSelectItemComponent(_ref) {
  var children = _ref.children,
    className = _ref.className,
    disabled = _ref.disabled,
    checked = _ref.checked,
    isFocused = _ref.isFocused,
    _ref$showIcons = _ref.showIcons,
    showIcons = _ref$showIcons === void 0 ? true : _ref$showIcons,
    toolTipContent = _ref.toolTipContent,
    toolTipProps = _ref.toolTipProps,
    style = _ref.style,
    _ref$truncateContent = _ref.truncateContent,
    truncateContent = _ref$truncateContent === void 0 ? true : _ref$truncateContent,
    forwardRef = _ref.forwardRef,
    rest = (0, _objectWithoutProperties2.default)(_ref, _excluded);
  var theme = (0, _services.useEuiTheme)();
  var buttonRef = (0, _react.useRef)(null);
  var tooltipRef = (0, _react.useRef)(null);
  var combinedButtonRefs = (0, _react.useMemo)(function () {
    return [buttonRef, forwardRef];
  }, [forwardRef]);
  var setButtonRef = (0, _services.useCombinedRefs)(combinedButtonRefs);
  var previousIsFocused = (0, _react.useRef)(isFocused);
  var isMounted = (0, _react.useRef)(false);
  var hasToolTip =
  // we're using isValidElement here as EuiToolTipAnchor uses
  // cloneElement to enhance the element with required attributes
  /*#__PURE__*/(0, _react.isValidElement)(children) && !disabled && toolTipContent;
  (0, _react.useEffect)(function () {
    if (isMounted.current && isFocused && !previousIsFocused.current) {
      var _buttonRef$current, _buttonRef$current$sc;
      (_buttonRef$current = buttonRef.current) === null || _buttonRef$current === void 0 || (_buttonRef$current$sc = _buttonRef$current.scrollIntoView) === null || _buttonRef$current$sc === void 0 || _buttonRef$current$sc.call(_buttonRef$current, {
        block: 'nearest'
      });
    }
    if (hasToolTip && (!isMounted.current || isFocused !== previousIsFocused.current)) {
      if (isFocused) {
        var _tooltipRef$current;
        (_tooltipRef$current = tooltipRef.current) === null || _tooltipRef$current === void 0 || _tooltipRef$current.showToolTip();
      } else {
        var _tooltipRef$current2;
        (_tooltipRef$current2 = tooltipRef.current) === null || _tooltipRef$current2 === void 0 || _tooltipRef$current2.hideToolTip();
      }
    }
    previousIsFocused.current = isFocused;
    isMounted.current = true;
  }, [hasToolTip, isFocused]);
  var styles = (0, _filter_select_item.euiFilterSelectItemStyles)(theme);
  var cssStyles = [styles.euiFilterSelectItem, isFocused && styles.isFocused];
  var classes = (0, _classnames.default)('euiFilterSelectItem', className);
  var anchorProps = undefined;
  if (hasToolTip) {
    var _toolTipProps$anchorP, _toolTipProps$anchorP2;
    var anchorStyles = toolTipProps !== null && toolTipProps !== void 0 && (_toolTipProps$anchorP = toolTipProps.anchorProps) !== null && _toolTipProps$anchorP !== void 0 && _toolTipProps$anchorP.style ? _objectSpread(_objectSpread({}, toolTipProps === null || toolTipProps === void 0 || (_toolTipProps$anchorP2 = toolTipProps.anchorProps) === null || _toolTipProps$anchorP2 === void 0 ? void 0 : _toolTipProps$anchorP2.style), style) : style;
    anchorProps = toolTipProps !== null && toolTipProps !== void 0 && toolTipProps.anchorProps ? _objectSpread(_objectSpread({}, toolTipProps.anchorProps), {}, {
      style: anchorStyles
    }) : {
      style: style
    };
  }
  var iconNode;
  if (showIcons) {
    var _resolveIconAndColor = resolveIconAndColor(checked),
      icon = _resolveIconAndColor.icon,
      color = _resolveIconAndColor.color;
    iconNode = (0, _react2.jsx)(_flex.EuiFlexItem, {
      grow: false
    }, (0, _react2.jsx)(_icon.EuiIcon, {
      color: color,
      type: icon
    }));
  }
  var optionItem = (0, _react2.jsx)("button", (0, _extends2.default)({
    ref: setButtonRef,
    role: "option",
    type: "button",
    "aria-selected": checked === 'on',
    className: classes,
    css: cssStyles,
    disabled: disabled,
    "aria-disabled": disabled,
    style: !hasToolTip ? style : undefined
  }, rest), (0, _react2.jsx)(_flex.EuiFlexGroup, {
    alignItems: "center",
    gutterSize: "s",
    component: "span",
    responsive: false
  }, iconNode, (0, _react2.jsx)(_flex.EuiFlexItem, {
    className: (0, _classnames.default)('euiFilterSelectItem__content', truncateContent && 'eui-textTruncate'),
    component: "span"
  }, children)));
  return hasToolTip ? (0, _react2.jsx)(_tool_tip.EuiToolTip, (0, _extends2.default)({
    ref: tooltipRef,
    display: "block",
    content: toolTipContent,
    position: "left"
  }, toolTipProps, {
    anchorProps: anchorProps
  }), optionItem) : optionItem;
};

/**
 * @deprecated - Use EuiSelectable instead
 */
EuiFilterSelectItemComponent.propTypes = {
  checked: _propTypes.default.oneOf(["on", "off"]),
  showIcons: _propTypes.default.bool,
  isFocused: _propTypes.default.bool,
  truncateContent: _propTypes.default.bool,
  toolTipContent: _propTypes.default.node,
  toolTipProps: _propTypes.default.any,
  forwardRef: _propTypes.default.func,
  className: _propTypes.default.string,
  "aria-label": _propTypes.default.string,
  "data-test-subj": _propTypes.default.string,
  css: _propTypes.default.any
};
var EuiFilterSelectItem = exports.EuiFilterSelectItem = EuiFilterSelectItemComponent;