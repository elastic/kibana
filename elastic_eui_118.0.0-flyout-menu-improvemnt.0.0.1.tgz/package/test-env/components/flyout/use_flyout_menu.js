"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.useEuiFlyoutMenu = void 0;
var _objectWithoutProperties2 = _interopRequireDefault(require("@babel/runtime/helpers/objectWithoutProperties"));
var _services = require("../../services");
var _const = require("./const");
var _react = require("react");
var _classnames = _interopRequireDefault(require("classnames"));
var _excluded = ["titleId"];
/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */
/**
 * @internal
 */

/**
 * Hook to manage flyout menu state and rendering logic.
 * Determines whether the menu should be rendered based on display mode
 * and menu content, and computes the appropriate aria-labelledby value.
 *
 * @internal
 */
var useEuiFlyoutMenu = exports.useEuiFlyoutMenu = function useEuiFlyoutMenu(_ref) {
  var _flyoutMenuProps$hist, _flyoutMenuProps$hist2, _flyoutMenuProps$lead, _flyoutMenuProps$lead2, _flyoutMenuProps$trai, _flyoutMenuProps$trai2, _flyoutMenuProps$cust, _flyoutMenuProps$cust2;
  var _flyoutMenuProps = _ref.flyoutMenuProps,
    flyoutMenuDisplayMode = _ref.flyoutMenuDisplayMode,
    _ariaLabelledBy = _ref.ariaLabelledBy;
  var generatedMenuId = (0, _services.useGeneratedHtmlId)();
  var _ref2 = _flyoutMenuProps || {},
    _titleId = _ref2.titleId,
    flyoutMenuProps = (0, _objectWithoutProperties2.default)(_ref2, _excluded);
  var hasMenu = !!_flyoutMenuProps;
  var flyoutMenuId = (0, _react.useMemo)(function () {
    if (!hasMenu) return undefined;
    return _titleId || generatedMenuId;
  }, [hasMenu, _titleId, generatedMenuId]);

  // Determine if the menu has any content
  // hasBackButton or hasHistory or hasLeadingActions or hasTrailingActions
  // or hasCustomActions (deprecated alias) or hasVisibleTitle or hasPagination
  var menuHasContent = hasMenu && (!!flyoutMenuProps.showBackButton || ((_flyoutMenuProps$hist = (_flyoutMenuProps$hist2 = flyoutMenuProps.historyItems) === null || _flyoutMenuProps$hist2 === void 0 ? void 0 : _flyoutMenuProps$hist2.length) !== null && _flyoutMenuProps$hist !== void 0 ? _flyoutMenuProps$hist : 0) >= _const.MIN_HISTORY_ITEMS || ((_flyoutMenuProps$lead = (_flyoutMenuProps$lead2 = flyoutMenuProps.leadingActions) === null || _flyoutMenuProps$lead2 === void 0 ? void 0 : _flyoutMenuProps$lead2.length) !== null && _flyoutMenuProps$lead !== void 0 ? _flyoutMenuProps$lead : 0) > 0 || ((_flyoutMenuProps$trai = (_flyoutMenuProps$trai2 = flyoutMenuProps.trailingActions) === null || _flyoutMenuProps$trai2 === void 0 ? void 0 : _flyoutMenuProps$trai2.length) !== null && _flyoutMenuProps$trai !== void 0 ? _flyoutMenuProps$trai : 0) > 0 || ((_flyoutMenuProps$cust = (_flyoutMenuProps$cust2 = flyoutMenuProps.customActions) === null || _flyoutMenuProps$cust2 === void 0 ? void 0 : _flyoutMenuProps$cust2.length) !== null && _flyoutMenuProps$cust !== void 0 ? _flyoutMenuProps$cust : 0) > 0 ||
  // Component defaults to hiding the title, so only explicit false means the title will be visible
  !!(flyoutMenuProps.title && flyoutMenuProps.hideTitle === false) || !!(flyoutMenuProps.pagination && flyoutMenuProps.pagination.total >= 1));

  // Determine if the menu should be rendered based on the display mode and menu content
  var shouldRenderMenu = (0, _react.useMemo)(function () {
    if (!hasMenu) return false;
    if (flyoutMenuDisplayMode === _const.MENU_DISPLAY_ALWAYS) return true;
    if (flyoutMenuDisplayMode === _const.MENU_DISPLAY_AUTO) return menuHasContent;
    return false;
  }, [hasMenu, flyoutMenuDisplayMode, menuHasContent]);

  // If the flyout menu is to be rendered, ensure the flyout has aria-labelledby referencing the menu's titleId
  var ariaLabelledBy = (0, _react.useMemo)(function () {
    if (flyoutMenuId && shouldRenderMenu) {
      return (0, _classnames.default)(flyoutMenuId, _ariaLabelledBy);
    }
    return _ariaLabelledBy;
  }, [flyoutMenuId, _ariaLabelledBy, shouldRenderMenu]);
  return {
    flyoutMenuId: flyoutMenuId,
    flyoutMenuProps: flyoutMenuProps,
    shouldRenderMenu: shouldRenderMenu,
    ariaLabelledBy: ariaLabelledBy
  };
};