"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.MIN_HISTORY_ITEMS = exports.MENU_DISPLAY_AUTO = exports.MENU_DISPLAY_ALWAYS = exports.FLYOUT_TYPES = exports.FLYOUT_SIZES = exports.FLYOUT_SIDES = exports.FLYOUT_PADDING_SIZES = exports.FLYOUT_MENU_DISPLAY_MODES = exports.DEFAULT_TYPE = exports.DEFAULT_SIZE = exports.DEFAULT_SIDE = exports.DEFAULT_PUSH_MIN_BREAKPOINT = exports.DEFAULT_PADDING_SIZE = exports.DEFAULT_MENU_DISPLAY_MODE = void 0;
exports.isEuiFlyoutSizeNamed = isEuiFlyoutSizeNamed;
/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */

/** Allowed flyout render types. */
var FLYOUT_TYPES = exports.FLYOUT_TYPES = ['push', 'overlay'];
/** Type representing a supported flyout render type. */

/** Allowed flyout attachment sides. */
var FLYOUT_SIDES = exports.FLYOUT_SIDES = ['left', 'right'];
/** Type representing a supported flyout side. */

/** Allowed named flyout sizes used by the manager. */
var FLYOUT_SIZES = exports.FLYOUT_SIZES = ['s', 'm', 'l', 'fill'];
/** Type representing a supported named flyout size. */

/** Menu display mode: always render menu when flyoutMenuProps is provided. */
var MENU_DISPLAY_ALWAYS = exports.MENU_DISPLAY_ALWAYS = 'always';
/** Menu display mode: only render menu when it has content (back button, history, title, or actions). */
var MENU_DISPLAY_AUTO = exports.MENU_DISPLAY_AUTO = 'auto';
/** Allowed flyout menu display modes. */
var FLYOUT_MENU_DISPLAY_MODES = exports.FLYOUT_MENU_DISPLAY_MODES = [MENU_DISPLAY_ALWAYS, MENU_DISPLAY_AUTO];
/** Type representing a supported flyout menu display mode. */

/**
 * Minimum number of history items required to render the flyout menu's history popover.
 */
var MIN_HISTORY_ITEMS = exports.MIN_HISTORY_ITEMS = 2;

/** Allowed padding sizes for flyout content. */
var FLYOUT_PADDING_SIZES = exports.FLYOUT_PADDING_SIZES = ['none', 's', 'm', 'l'];
/** Type representing a supported flyout padding size. */

/** Default minimum breakpoint at which push-type flyouts begin to push content. */
var DEFAULT_PUSH_MIN_BREAKPOINT = exports.DEFAULT_PUSH_MIN_BREAKPOINT = 'l';
/** Default flyout type when none is provided. */
var DEFAULT_TYPE = exports.DEFAULT_TYPE = 'overlay';
/** Default side where flyouts anchor when none is provided. */
var DEFAULT_SIDE = exports.DEFAULT_SIDE = 'right';
/** Default named flyout size. */
var DEFAULT_SIZE = exports.DEFAULT_SIZE = 'm';
/** Default padding size inside flyouts. */
var DEFAULT_PADDING_SIZE = exports.DEFAULT_PADDING_SIZE = 'l';
/** Default flyout menu display mode. */
var DEFAULT_MENU_DISPLAY_MODE = exports.DEFAULT_MENU_DISPLAY_MODE = MENU_DISPLAY_AUTO;

/**
 * Custom type checker for named flyout sizes since the prop
 * `size` can also be CSSProperties['width'] (string | number)
 */
function isEuiFlyoutSizeNamed(value) {
  return FLYOUT_SIZES.includes(value);
}