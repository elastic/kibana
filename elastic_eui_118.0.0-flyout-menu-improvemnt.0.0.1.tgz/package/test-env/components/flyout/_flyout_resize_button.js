"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.EuiFlyoutResizeButton = void 0;
var _extends2 = _interopRequireDefault(require("@babel/runtime/helpers/extends"));
var _objectWithoutProperties2 = _interopRequireDefault(require("@babel/runtime/helpers/objectWithoutProperties"));
var _react = _interopRequireDefault(require("react"));
var _services = require("../../services");
var _resizable_container = require("../resizable_container");
var _flyout_resize_button = require("./_flyout_resize_button.styles");
var _react2 = require("@emotion/react");
var _excluded = ["type", "side", "ownFocus", "isPushed"];
/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */
var EuiFlyoutResizeButton = exports.EuiFlyoutResizeButton = function EuiFlyoutResizeButton(_ref) {
  var type = _ref.type,
    side = _ref.side,
    ownFocus = _ref.ownFocus,
    isPushed = _ref.isPushed,
    resizableButtonProps = (0, _objectWithoutProperties2.default)(_ref, _excluded);
  var hasOverlay = ownFocus && type === 'overlay';
  var styles = (0, _services.useEuiMemoizedStyles)(_flyout_resize_button.euiFlyoutResizeButtonStyles);
  var cssStyles = [styles.root, styles[type][side], !hasOverlay && styles.noOverlay.root, !hasOverlay && styles.noOverlay[side]];
  return (0, _react2.jsx)(_resizable_container.EuiResizableButton, (0, _extends2.default)({
    isHorizontal: true,
    indicator: "border",
    css: cssStyles
  }, resizableButtonProps));
};