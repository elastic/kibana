"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.useFlyoutLayoutMode = exports.useApplyFlyoutLayoutMode = exports.getWidthFromSize = void 0;
var _slicedToArray2 = _interopRequireDefault(require("@babel/runtime/helpers/slicedToArray"));
var _react = require("react");
var _services = require("../../../services");
var _component_defaults = require("../../provider/component_defaults");
var _resize_observer = require("../../observer/resize_observer");
var _actions = require("./actions");
var _hooks = require("./hooks");
var _const = require("./const");
/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */

/**
 * Hook to handle responsive layout mode for managed flyouts.
 * Decides whether to place flyouts side-by-side or stacked based on
 * the reference width (the reference container's width, defaulting to
 * document.body when not set) and flyout widths/sizes.
 */
var useApplyFlyoutLayoutMode = exports.useApplyFlyoutLayoutMode = function useApplyFlyoutLayoutMode() {
  var _ref, _sessions, _state$flyouts$find, _state$flyouts$find2, _context$state;
  var _useEuiTheme = (0, _services.useEuiTheme)(),
    euiTheme = _useEuiTheme.euiTheme;
  var context = (0, _hooks.useFlyoutManager)();
  var state = context === null || context === void 0 ? void 0 : context.state;

  // Read the container from manager state (set by flyout components when they
  // receive a container prop), falling back to componentDefaults (used when
  // the container is configured globally, e.g. by Kibana). Resolve getter
  // and selector string so defaults can supply () => HTMLElement | null or
  // a CSS selector to avoid race when the element is not yet in the DOM.
  var stateContainerElement = state === null || state === void 0 ? void 0 : state.containerElement;
  var _usePropsWithComponen = (0, _component_defaults.usePropsWithComponentDefaults)('EuiFlyout', {}),
    defaultContainerRaw = _usePropsWithComponen.container;
  var defaultContainer = defaultContainerRaw == null ? null : typeof defaultContainerRaw === 'function' ? defaultContainerRaw() : typeof defaultContainerRaw === 'string' ? function () {
    if (typeof document === 'undefined') return null;
    var el = document.querySelector(defaultContainerRaw);
    return el instanceof HTMLElement ? el : null;
  }() : defaultContainerRaw instanceof HTMLElement ? defaultContainerRaw : null;
  var container = (_ref = stateContainerElement !== null && stateContainerElement !== void 0 ? stateContainerElement : defaultContainer) !== null && _ref !== void 0 ? _ref : null;

  // Derive all session/flyout data from the single context read above
  var sessions = state === null || state === void 0 ? void 0 : state.sessions;
  var currentSession = sessions ? (_sessions = sessions[sessions.length - 1]) !== null && _sessions !== void 0 ? _sessions : null : null;
  var parentFlyoutId = currentSession === null || currentSession === void 0 ? void 0 : currentSession.mainFlyoutId;
  var childFlyoutId = currentSession === null || currentSession === void 0 ? void 0 : currentSession.childFlyoutId;
  var parentFlyout = parentFlyoutId ? (_state$flyouts$find = state === null || state === void 0 ? void 0 : state.flyouts.find(function (f) {
    return f.flyoutId === parentFlyoutId;
  })) !== null && _state$flyouts$find !== void 0 ? _state$flyouts$find : null : null;
  var childFlyout = childFlyoutId ? (_state$flyouts$find2 = state === null || state === void 0 ? void 0 : state.flyouts.find(function (f) {
    return f.flyoutId === childFlyoutId;
  })) !== null && _state$flyouts$find2 !== void 0 ? _state$flyouts$find2 : null : null;
  var parentWidth = parentFlyout === null || parentFlyout === void 0 ? void 0 : parentFlyout.width;
  var childWidth = childFlyout === null || childFlyout === void 0 ? void 0 : childFlyout.width;
  var hasFlyouts = Boolean(parentFlyoutId);

  // Observe the container element's width (returns { width: 0 } when null)
  var containerDimensions = (0, _resize_observer.useResizeObserver)(container !== null && container !== void 0 ? container : null, 'width');
  var _useState = (0, _react.useState)(typeof window !== 'undefined' ? window.innerWidth : Infinity),
    _useState2 = (0, _slicedToArray2.default)(_useState, 2),
    windowWidth = _useState2[0],
    setWindowWidth = _useState2[1];

  // Use container width when available, otherwise fall back to window width
  var containerWidth = container ? containerDimensions.width || container.clientWidth : 0;
  var referenceWidth = containerWidth || windowWidth;

  // Extract specific context values
  var dispatch = context === null || context === void 0 ? void 0 : context.dispatch;
  var currentLayoutMode = context === null || context === void 0 || (_context$state = context.state) === null || _context$state === void 0 ? void 0 : _context$state.layoutMode;
  var setMode = (0, _react.useCallback)(function (layoutMode) {
    if (dispatch) {
      dispatch((0, _actions.setLayoutMode)(layoutMode));
    }
  }, [dispatch]);

  // Only listen to window resize when not using a container
  (0, _react.useEffect)(function () {
    if (typeof window === 'undefined' || container) {
      return;
    }
    var rafId = 0;
    var handleResize = function handleResize() {
      if (rafId) {
        cancelAnimationFrame(rafId);
      }
      rafId = requestAnimationFrame(function () {
        return setWindowWidth(window.innerWidth);
      });
    };
    window.addEventListener('resize', handleResize);
    return function () {
      if (rafId) {
        cancelAnimationFrame(rafId);
      }
      window.removeEventListener('resize', handleResize);
    };
  }, [container]);

  // Calculate the desired layout mode
  var desiredLayoutMode = (0, _react.useMemo)(function () {
    // Skip calculation if no flyouts open
    if (!hasFlyouts) {
      return null;
    }

    // Thresholds to prevent thrashing near the breakpoint.
    var THRESHOLD_TO_SIDE_BY_SIDE = 85;
    var THRESHOLD_TO_STACKED = 95;

    // If the reference width is too small, set the mode to stacked.
    //
    // The value is based on the maximum width of a flyout in
    // `composeFlyoutSizing` in `flyout.styles.ts` multiplied
    // by 2 (open flyouts side-by-side).
    if (referenceWidth < Math.round(euiTheme.breakpoint.s * 1.4)) {
      return _const.LAYOUT_MODE_STACKED;
    }
    if (!childFlyoutId) {
      return _const.LAYOUT_MODE_SIDE_BY_SIDE;
    }
    var isFillParent = (parentFlyout === null || parentFlyout === void 0 ? void 0 : parentFlyout.size) === 'fill';
    var isFillChild = (childFlyout === null || childFlyout === void 0 ? void 0 : childFlyout.size) === 'fill';
    var hasFill = isFillParent || isFillChild;
    var parentWidthValue = parentWidth;
    var childWidthValue = childWidth;

    // Resolve unmeasured widths. For fill-size flyouts, estimate as
    // (90% of referenceWidth − sibling width) rather than a flat 90%.
    // This avoids the combined estimate exceeding 90% and incorrectly
    // triggering stacked mode on initial mount.
    if (!parentWidthValue && parentFlyout !== null && parentFlyout !== void 0 && parentFlyout.size) {
      if (isFillParent && childWidthValue) {
        parentWidthValue = Math.max(0, Math.round(referenceWidth * 0.9 - childWidthValue));
      } else {
        parentWidthValue = getWidthFromSize(parentFlyout.size, referenceWidth);
      }
    }
    if (!childWidthValue && childFlyout !== null && childFlyout !== void 0 && childFlyout.size) {
      if (isFillChild && parentWidthValue) {
        childWidthValue = Math.max(0, Math.round(referenceWidth * 0.9 - parentWidthValue));
      } else {
        childWidthValue = getWidthFromSize(childFlyout.size, referenceWidth);
      }
    }
    if (!parentWidthValue || !childWidthValue) {
      return _const.LAYOUT_MODE_SIDE_BY_SIDE;
    }
    var combinedWidth = parentWidthValue + childWidthValue;
    var combinedWidthPercentage = combinedWidth / referenceWidth * 100;

    // Fill flyouts defeat the hysteresis thresholds, so use the
    // reference-width breakpoint alone to decide the layout mode.
    if (hasFill) {
      return referenceWidth >= Math.round(euiTheme.breakpoint.s * 1.4) ? _const.LAYOUT_MODE_SIDE_BY_SIDE : _const.LAYOUT_MODE_STACKED;
    }
    if (currentLayoutMode === _const.LAYOUT_MODE_STACKED) {
      return combinedWidthPercentage <= THRESHOLD_TO_SIDE_BY_SIDE ? _const.LAYOUT_MODE_SIDE_BY_SIDE : _const.LAYOUT_MODE_STACKED;
    } else {
      return combinedWidthPercentage >= THRESHOLD_TO_STACKED ? _const.LAYOUT_MODE_STACKED : _const.LAYOUT_MODE_SIDE_BY_SIDE;
    }
  }, [hasFlyouts, referenceWidth, euiTheme, childFlyoutId, parentWidth, childWidth, parentFlyout === null || parentFlyout === void 0 ? void 0 : parentFlyout.size, childFlyout === null || childFlyout === void 0 ? void 0 : childFlyout.size, currentLayoutMode]);

  // Apply the desired layout mode
  (0, _react.useEffect)(function () {
    if (desiredLayoutMode && currentLayoutMode !== desiredLayoutMode) {
      setMode(desiredLayoutMode);
    }
  }, [desiredLayoutMode, currentLayoutMode, setMode]);

  // Store reference width in manager state when flyouts are open so the resize
  // clamp uses the same value as layout mode, avoiding resize past the container.
  (0, _react.useEffect)(function () {
    if (dispatch && hasFlyouts && Number.isFinite(referenceWidth)) {
      dispatch((0, _actions.setReferenceWidth)(referenceWidth));
    }
  }, [dispatch, hasFlyouts, referenceWidth]);
};

/**
 * Convert a flyout `size` value to a pixel width.
 * When `referenceWidth` is provided, named sizes are calculated as a percentage
 * of that width (container-relative). Otherwise falls back to `window.innerWidth`.
 */
var getWidthFromSize = exports.getWidthFromSize = function getWidthFromSize(size, referenceWidth) {
  if (typeof size === 'number') {
    return size;
  }
  if (typeof size === 'string') {
    var parsed = parseInt(size, 10);
    if (!Number.isNaN(parsed)) {
      return parsed;
    }
    var refWidth = referenceWidth !== null && referenceWidth !== void 0 ? referenceWidth : typeof window !== 'undefined' ? window.innerWidth : 0;

    // Size is a function of a percentage of the reference width,
    // matching the proportions defined in `composeFlyoutSizing`
    switch (size) {
      case 's':
        return Math.round(refWidth * 0.25);
      case 'm':
        return Math.round(refWidth * 0.5);
      case 'l':
        return Math.round(refWidth * 0.75);
      case 'fill':
        return Math.round(refWidth * 0.9);
      default:
        break;
    }
  }
  return 0;
};

/** Current layout mode for managed flyouts (`side-by-side` or `stacked`). */
var useFlyoutLayoutMode = exports.useFlyoutLayoutMode = function useFlyoutLayoutMode() {
  var _context$state2;
  var context = (0, _hooks.useFlyoutManager)();
  return (context === null || context === void 0 || (_context$state2 = context.state) === null || _context$state2 === void 0 ? void 0 : _context$state2.layoutMode) || _const.LAYOUT_MODE_SIDE_BY_SIDE;
};