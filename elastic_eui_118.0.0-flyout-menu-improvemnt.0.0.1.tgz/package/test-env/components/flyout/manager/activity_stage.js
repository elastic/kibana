"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.useFlyoutActivityStage = void 0;
var _react = require("react");
var _const = require("./const");
var _actions = require("./actions");
var _provider = require("./provider");
/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */

/**
 * Returns the final stage after an animation completes.
 * OPENING/RETURNING -> ACTIVE; CLOSING -> INACTIVE; BACKGROUNDING -> BACKGROUNDED.
 */
var getNextStage = function getNextStage(stage) {
  switch (stage) {
    case _const.STAGE_OPENING:
    case _const.STAGE_RETURNING:
      return _const.STAGE_ACTIVE;
    case _const.STAGE_CLOSING:
      return _const.STAGE_INACTIVE;
    case _const.STAGE_BACKGROUNDING:
      return _const.STAGE_BACKGROUNDED;
    default:
      return null;
  }
};

/**
 * Encapsulates all activity-stage transitions and animation-driven updates
 * for managed flyouts.
 *
 * Performance: reads `useFlyoutManager()` once and derives isActive,
 * hasChild, and layoutMode inline (replaces useIsFlyoutActive,
 * useHasChildFlyout, useFlyoutLayoutMode hooks).
 */
var useFlyoutActivityStage = exports.useFlyoutActivityStage = function useFlyoutActivityStage(_ref) {
  var _sessions, _state$sessions$find, _state$layoutMode, _state$flyouts$find;
  var flyoutId = _ref.flyoutId,
    level = _ref.level,
    _ref$shouldAnimate = _ref.shouldAnimate,
    shouldAnimate = _ref$shouldAnimate === void 0 ? false : _ref$shouldAnimate;
  var ctx = (0, _provider.useFlyoutManager)();
  var state = ctx === null || ctx === void 0 ? void 0 : ctx.state;

  // Derive all needed values from single context read
  var sessions = state === null || state === void 0 ? void 0 : state.sessions;
  var currentSession = sessions ? (_sessions = sessions[sessions.length - 1]) !== null && _sessions !== void 0 ? _sessions : null : null;
  var isActive = (currentSession === null || currentSession === void 0 ? void 0 : currentSession.mainFlyoutId) === flyoutId || (currentSession === null || currentSession === void 0 ? void 0 : currentSession.childFlyoutId) === flyoutId;
  var session = (_state$sessions$find = state === null || state === void 0 ? void 0 : state.sessions.find(function (s) {
    return s.mainFlyoutId === flyoutId || s.childFlyoutId === flyoutId;
  })) !== null && _state$sessions$find !== void 0 ? _state$sessions$find : null;
  var hasChild = !!(session !== null && session !== void 0 && session.childFlyoutId);
  var layoutMode = (_state$layoutMode = state === null || state === void 0 ? void 0 : state.layoutMode) !== null && _state$layoutMode !== void 0 ? _state$layoutMode : _const.LAYOUT_MODE_SIDE_BY_SIDE;
  var stage = (state === null || state === void 0 || (_state$flyouts$find = state.flyouts.find(function (f) {
    return f.flyoutId === flyoutId;
  })) === null || _state$flyouts$find === void 0 ? void 0 : _state$flyouts$find.activityStage) || (isActive ? _const.STAGE_ACTIVE : _const.STAGE_INACTIVE);
  var stageRef = (0, _react.useRef)(stage);
  if (stageRef.current !== stage) {
    stageRef.current = stage;
  }
  var transitionTo = (0, _react.useCallback)(function (nextStage) {
    var _ctx$dispatch;
    ctx === null || ctx === void 0 || (_ctx$dispatch = ctx.dispatch) === null || _ctx$dispatch === void 0 || _ctx$dispatch.call(ctx, (0, _actions.setActivityStage)(flyoutId, nextStage));
    stageRef.current = nextStage;
  }, [ctx, flyoutId]);

  /**
   * 1. ACTIVE -> CLOSING (or INACTIVE when !shouldAnimate) when no longer the active flyout.
   * 2. INACTIVE -> RETURNING (or ACTIVE when !shouldAnimate) when it becomes active again.
   * 3. (Main only) ACTIVE + stacked + has child -> BACKGROUNDING (or BACKGROUNDED when !shouldAnimate).
   * 4. (Main only) BACKGROUNDED/BACKGROUNDING + (child gone OR side-by-side) -> RETURNING (or ACTIVE when !shouldAnimate).
   */
  (0, _react.useEffect)(function () {
    var s = stageRef.current;
    var next = null;
    if (s === _const.STAGE_ACTIVE && !isActive) {
      next = shouldAnimate ? _const.STAGE_CLOSING : _const.STAGE_INACTIVE;
    } else if (s === _const.STAGE_INACTIVE && isActive) {
      next = shouldAnimate ? _const.STAGE_RETURNING : _const.STAGE_ACTIVE;
    } else if (level === _const.LEVEL_MAIN && isActive && s === _const.STAGE_ACTIVE && hasChild && layoutMode === _const.LAYOUT_MODE_STACKED) {
      next = shouldAnimate ? _const.STAGE_BACKGROUNDING : _const.STAGE_BACKGROUNDED;
    } else if (level === _const.LEVEL_MAIN && (s === _const.STAGE_BACKGROUNDED || s === _const.STAGE_BACKGROUNDING) && (!hasChild || layoutMode === _const.LAYOUT_MODE_SIDE_BY_SIDE)) {
      next = shouldAnimate ? _const.STAGE_RETURNING : _const.STAGE_ACTIVE;
    }
    if (next && next !== s) {
      transitionTo(next);
    }
  }, [isActive, hasChild, layoutMode, level, shouldAnimate, transitionTo, stage]);

  /**
   * onAnimationEnd: browser signal when a CSS animation completes.
   * Calls transitionTo to move to the final stage (e.g. CLOSING -> INACTIVE).
   */
  var onAnimationEnd = (0, _react.useCallback)(function () {
    var currentStage = stageRef.current;
    var nextStage = getNextStage(currentStage);
    if (nextStage && nextStage !== currentStage) {
      transitionTo(nextStage);
    }
  }, [transitionTo]);
  return {
    activityStage: stage,
    onAnimationEnd: onAnimationEnd
  };
};