"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
var _typeof = require("@babel/runtime/helpers/typeof");
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.useDataGridFullScreenSelector = void 0;
var _slicedToArray2 = _interopRequireDefault(require("@babel/runtime/helpers/slicedToArray"));
var _react = _interopRequireWildcard(require("react"));
var _services = require("../../../services");
var _tool_tip = require("../../tool_tip");
var _button = require("../../button");
var _i18n = require("../../i18n");
var _fullscreen_selector = require("./fullscreen_selector.styles");
var _react2 = require("@emotion/react");
function _getRequireWildcardCache(e) { if ("function" != typeof WeakMap) return null; var r = new WeakMap(), t = new WeakMap(); return (_getRequireWildcardCache = function _getRequireWildcardCache(e) { return e ? t : r; })(e); }
function _interopRequireWildcard(e, r) { if (!r && e && e.__esModule) return e; if (null === e || "object" != _typeof(e) && "function" != typeof e) return { default: e }; var t = _getRequireWildcardCache(r); if (t && t.has(e)) return t.get(e); var n = { __proto__: null }, a = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var u in e) if ("default" !== u && {}.hasOwnProperty.call(e, u)) { var i = a ? Object.getOwnPropertyDescriptor(e, u) : null; i && (i.get || i.set) ? Object.defineProperty(n, u, i) : n[u] = e[u]; } return n.default = e, t && t.set(e, n), n; }
/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */

var GRID_IS_FULLSCREEN_CLASSNAME = 'euiDataGrid__restrictBody';
var useDataGridFullScreenSelector = exports.useDataGridFullScreenSelector = function useDataGridFullScreenSelector(onFullScreenChange) {
  var _useState = (0, _react.useState)(false),
    _useState2 = (0, _slicedToArray2.default)(_useState, 2),
    isFullScreen = _useState2[0],
    setIsFullScreen = _useState2[1];
  var toggleFullScreen = (0, _react.useCallback)(function () {
    setIsFullScreen(function (prevValue) {
      onFullScreenChange === null || onFullScreenChange === void 0 || onFullScreenChange(!prevValue);
      return !prevValue;
    });
  }, [onFullScreenChange]);
  var _useEuiI18n = (0, _i18n.useEuiI18n)(['euiFullscreenSelector.fullscreenButton', 'euiFullscreenSelector.fullscreenButtonActive'], ['Enter fullscreen', 'Exit fullscreen']),
    _useEuiI18n2 = (0, _slicedToArray2.default)(_useEuiI18n, 2),
    fullScreenButton = _useEuiI18n2[0],
    fullScreenButtonActive = _useEuiI18n2[1];
  var fullScreenSelector = (0, _react.useMemo)(function () {
    return (0, _react2.jsx)(_tool_tip.EuiToolTip, {
      content: isFullScreen ? (0, _react2.jsx)(_react.default.Fragment, null, fullScreenButtonActive, " (", (0, _react2.jsx)("kbd", null, "esc"), ")") : fullScreenButton
    }, (0, _react2.jsx)(_button.EuiButtonIcon, {
      size: "xs",
      iconType: isFullScreen ? 'fullScreenExit' : 'fullScreen',
      color: "text",
      "aria-pressed": isFullScreen,
      "data-test-subj": "dataGridFullScreenButton",
      onClick: toggleFullScreen,
      "aria-label": isFullScreen ? fullScreenButtonActive : fullScreenButton
    }));
  }, [isFullScreen, fullScreenButtonActive, fullScreenButton, toggleFullScreen]);
  var handleGridKeyDown = (0, _react.useCallback)(function (event) {
    switch (event.key) {
      case _services.keys.ESCAPE:
        if (isFullScreen) {
          event.preventDefault();
          setIsFullScreen(false);
          onFullScreenChange === null || onFullScreenChange === void 0 || onFullScreenChange(false);
        }
        break;
    }
  }, [isFullScreen, onFullScreenChange]);
  var styles = (0, _services.useEuiMemoizedStyles)(_fullscreen_selector.euiDataGridFullScreenStyles);
  (0, _react.useEffect)(function () {
    // When the data grid is fullscreen, we add a class to the body to remove the extra scrollbar and stay above any fixed headers
    if (isFullScreen) {
      document.body.classList.add(GRID_IS_FULLSCREEN_CLASSNAME, styles.euiDataGrid__restrictBody);
      return function () {
        document.body.classList.remove(GRID_IS_FULLSCREEN_CLASSNAME, styles.euiDataGrid__restrictBody);
      };
    }
  }, [isFullScreen, styles.euiDataGrid__restrictBody]);
  return {
    isFullScreen: isFullScreen,
    setIsFullScreen: setIsFullScreen,
    fullScreenSelector: fullScreenSelector,
    handleGridKeyDown: handleGridKeyDown,
    fullScreenStyles: styles['euiDataGrid--fullScreen']
  };
};