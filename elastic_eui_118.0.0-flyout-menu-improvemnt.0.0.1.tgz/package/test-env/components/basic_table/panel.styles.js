"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.euiBasicTablePanelStyles = void 0;
var _react = require("@emotion/react");
var _global_styling = require("../../global_styling");
/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */

var euiBasicTablePanelStyles = exports.euiBasicTablePanelStyles = function euiBasicTablePanelStyles(_ref) {
  var euiTheme = _ref.euiTheme;
  return /*#__PURE__*/(0, _react.css)("background-color:", euiTheme.colors.backgroundBaseSubdued, ";border:", euiTheme.border.thin, ";border-block-end-width:0;", (0, _global_styling.logicalShorthandCSS)('border-radius', "".concat(euiTheme.border.radius.medium, " ").concat(euiTheme.border.radius.medium, " 0 0")), "&+&{border-start-start-radius:0;border-start-end-radius:0;};label:euiBasicTablePanelStyles;");
};