"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.useEuiBasicTablePanelProps = exports.EUI_BASIC_TABLE_PANEL_CLASS_NAME = void 0;
var _services = require("../../services");
var _panel = require("./panel.styles");
/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */

/**
 * @internal
 */
var EUI_BASIC_TABLE_PANEL_CLASS_NAME = exports.EUI_BASIC_TABLE_PANEL_CLASS_NAME = 'euiBasicTablePanel';

/**
 * A utility hook that returns props needed to be passed to element(s) being
 * a part of the paneled table look and feel (e.g., a toolbar above the table).
 * @beta
 */
var useEuiBasicTablePanelProps = exports.useEuiBasicTablePanelProps = function useEuiBasicTablePanelProps() {
  var css = (0, _services.useEuiMemoizedStyles)(_panel.euiBasicTablePanelStyles);
  return {
    css: css,
    className: EUI_BASIC_TABLE_PANEL_CLASS_NAME
  };
};