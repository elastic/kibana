"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.euiButtonGroupStyles = exports.euiButtonGroupButtonsStyles = void 0;
var _react = require("@emotion/react");
var _global_styling = require("../../../global_styling");
var _high_contrast = require("../../../global_styling/functions/high_contrast");
var _form = require("../../form/form.styles");
function _EMOTION_STRINGIFIED_CSS_ERROR__() { return "You have tried to stringify object returned from `css` function. It isn't supposed to be used directly (e.g. as value of the `className` prop), but rather handed to emotion so it can handle it (e.g. as value of `css` prop)."; } /*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */
var euiButtonGroupStyles = exports.euiButtonGroupStyles = {
  euiButtonGroup: /*#__PURE__*/(0, _react.css)("display:inline-block;", (0, _global_styling.logicalCSS)('max-width', '100%'), " position:relative;;label:euiButtonGroup;"),
  fullWidth: process.env.NODE_ENV === "production" ? {
    name: "jl0hie-fullWidth",
    styles: "display:block;label:fullWidth;"
  } : {
    name: "jl0hie-fullWidth",
    styles: "display:block;label:fullWidth;",
    toString: _EMOTION_STRINGIFIED_CSS_ERROR__
  }
};
var euiButtonGroupButtonsStyles = exports.euiButtonGroupButtonsStyles = function euiButtonGroupButtonsStyles(euiThemeContext) {
  var euiTheme = euiThemeContext.euiTheme;
  var buttonSizes = {
    s: "\n      border-radius: ".concat(euiTheme.border.radius.small, ";\n      ").concat(_highContrastStyles(euiThemeContext), "\n    "),
    m: "\n      border-radius: ".concat(euiTheme.border.radius.medium, ";\n      ").concat(_highContrastStyles(euiThemeContext), "\n    ")
  };
  var _euiFormVariables = (0, _form.euiFormVariables)(euiThemeContext),
    controlCompressedHeight = _euiFormVariables.controlCompressedHeight,
    controlCompressedBorderRadius = _euiFormVariables.controlCompressedBorderRadius,
    backgroundColor = _euiFormVariables.backgroundColor,
    borderColor = _euiFormVariables.borderColor;
  return {
    // Base
    euiButtonGroup__buttons: /*#__PURE__*/(0, _react.css)((0, _global_styling.logicalCSS)('max-width', '100%'), " display:flex;align-items:center;&:where([data-variant='default'] &){flex-wrap:wrap;}&:where([data-size='s'] &){", buttonSizes.s, ";}&:where([data-size='m'] &){", buttonSizes.m, ";};label:euiButtonGroup__buttons;"),
    fullWidth: /*#__PURE__*/(0, _react.css)((0, _global_styling.logicalCSS)('width', '100%'), " .euiButtonGroupButton,.euiButtonGroup__tooltipWrapper{flex:1;", (0, _global_styling.logicalCSS)('width', '100%'), ";}.euiButton{flex-grow:1;inline-size:auto;}.euiButtonEmpty{flex-shrink:0;};label:fullWidth;"),
    // Sizes
    size: {
      m: /*#__PURE__*/(0, _react.css)(buttonSizes.m, ";;label:m;"),
      s: /*#__PURE__*/(0, _react.css)(buttonSizes.s, ";;label:s;"),
      compressed: /*#__PURE__*/(0, _react.css)((0, _global_styling.logicalCSS)('height', controlCompressedHeight), " background-color:", backgroundColor, ";border:", euiTheme.border.width.thin, " solid ", borderColor, ";border-radius:", controlCompressedBorderRadius, ";", _highContrastStyles(euiThemeContext, true), ";;label:compressed;")
    },
    gutterSize: {
      xs: /*#__PURE__*/(0, _react.css)("gap:", euiTheme.size.xs, ";;label:xs;"),
      s: /*#__PURE__*/(0, _react.css)("gap:", euiTheme.size.s, ";;label:s;"),
      m: /*#__PURE__*/(0, _react.css)("gap:", euiTheme.size.base, ";;label:m;"),
      l: /*#__PURE__*/(0, _react.css)("gap:", euiTheme.size.l, ";;label:l;"),
      xl: /*#__PURE__*/(0, _react.css)("gap:", euiTheme.size.xl, ";;label:xl;")
    }
  };
};
var _highContrastStyles = function _highContrastStyles(euiThemeContext, compressed) {
  var euiTheme = euiThemeContext.euiTheme;
  return (0, _high_contrast.highContrastModeStyles)(euiThemeContext, {
    preferred: compressed ? "\n        .euiButtonGroupButton {\n          border: none;\n        }\n      " : '',
    forced: "\n      .euiButtonGroupButton-isSelected {\n        ".concat((0, _high_contrast.preventForcedColors)(euiThemeContext), "\n        color: ").concat(euiTheme.colors.emptyShade, ";\n        background-color: ").concat(euiTheme.colors.fullShade, ";\n\n        &:is(:hover, :focus):not(").concat(_global_styling.euiDisabledSelector, ") {\n          &::before {\n            border-color: ").concat(euiTheme.colors.textInverse, ";\n          }\n        }\n      }\n\n      .euiButtonGroupButton:is(").concat(_global_styling.euiDisabledSelector, ") {\n        opacity: 0.5;\n      }\n    ")
  });
};