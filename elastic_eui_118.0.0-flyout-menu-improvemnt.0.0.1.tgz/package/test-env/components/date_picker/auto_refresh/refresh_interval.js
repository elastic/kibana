"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
var _typeof = require("@babel/runtime/helpers/typeof");
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.EuiRefreshInterval = void 0;
var _defineProperty2 = _interopRequireDefault(require("@babel/runtime/helpers/defineProperty"));
var _slicedToArray2 = _interopRequireDefault(require("@babel/runtime/helpers/slicedToArray"));
var _react = _interopRequireWildcard(require("react"));
var _services = require("../../../services");
var _i18n = require("../../i18n");
var _flex = require("../../flex");
var _form = require("../../form");
var _accessibility = require("../../accessibility");
var _time_options = require("../super_date_picker/time_options");
var _quick_select_panel = require("../super_date_picker/quick_select_popover/quick_select_panel");
var _react2 = require("@emotion/react");
function _getRequireWildcardCache(e) { if ("function" != typeof WeakMap) return null; var r = new WeakMap(), t = new WeakMap(); return (_getRequireWildcardCache = function _getRequireWildcardCache(e) { return e ? t : r; })(e); }
function _interopRequireWildcard(e, r) { if (!r && e && e.__esModule) return e; if (null === e || "object" != _typeof(e) && "function" != typeof e) return { default: e }; var t = _getRequireWildcardCache(r); if (t && t.has(e)) return t.get(e); var n = { __proto__: null }, a = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var u in e) if ("default" !== u && {}.hasOwnProperty.call(e, u)) { var i = a ? Object.getOwnPropertyDescriptor(e, u) : null; i && (i.get || i.set) ? Object.defineProperty(n, u, i) : n[u] = e[u]; } return n.default = e, t && t.set(e, n), n; }
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { (0, _defineProperty2.default)(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; } /*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */
var MILLISECONDS_IN_SECOND = 1000;
var MILLISECONDS_IN_MINUTE = MILLISECONDS_IN_SECOND * 60;
var MILLISECONDS_IN_HOUR = MILLISECONDS_IN_MINUTE * 60;
var fromMilliseconds = function fromMilliseconds(milliseconds, unit) {
  var round = function round(value) {
    return parseFloat(value.toFixed(2));
  };
  if (unit === 'h' || !unit && milliseconds > MILLISECONDS_IN_HOUR) {
    return {
      units: 'h',
      value: round(milliseconds / MILLISECONDS_IN_HOUR)
    };
  }
  if (unit === 'm' || !unit && milliseconds > MILLISECONDS_IN_MINUTE) {
    return {
      units: 'm',
      value: round(milliseconds / MILLISECONDS_IN_MINUTE)
    };
  }
  return {
    units: 's',
    value: round(milliseconds / MILLISECONDS_IN_SECOND)
  };
};
var toMilliseconds = function toMilliseconds(units, value) {
  switch (units) {
    case 'h':
      return Math.round(value * MILLISECONDS_IN_HOUR);
    case 'm':
      return Math.round(value * MILLISECONDS_IN_MINUTE);
    case 's':
    default:
      return Math.round(value * MILLISECONDS_IN_SECOND);
  }
};
var getMinInterval = function getMinInterval(minInterval, unit) {
  if (!minInterval) return 0;
  var _fromMilliseconds = fromMilliseconds(minInterval, unit),
    value = _fromMilliseconds.value;
  return Math.floor(value || 0);
};
var EuiRefreshInterval = exports.EuiRefreshInterval = function EuiRefreshInterval(_ref) {
  var _ref$isPaused = _ref.isPaused,
    isPaused = _ref$isPaused === void 0 ? true : _ref$isPaused,
    _ref$refreshInterval = _ref.refreshInterval,
    refreshInterval = _ref$refreshInterval === void 0 ? 1000 : _ref$refreshInterval,
    _ref$minInterval = _ref.minInterval,
    minInterval = _ref$minInterval === void 0 ? 0 : _ref$minInterval,
    intervalUnits = _ref.intervalUnits,
    onRefreshChange = _ref.onRefreshChange;
  var _useState = (0, _react.useState)(function () {
      return _objectSpread(_objectSpread({}, fromMilliseconds(refreshInterval || 0, intervalUnits)), {}, {
        min: getMinInterval(minInterval, intervalUnits)
      });
    }),
    _useState2 = (0, _slicedToArray2.default)(_useState, 2),
    state = _useState2[0],
    setState = _useState2[1];
  var refreshSelectionId = (0, _services.useGeneratedHtmlId)({
    prefix: 'euiRefreshInterval'
  });
  var _useI18nTimeOptions = (0, _time_options.useI18nTimeOptions)(),
    refreshUnitsOptions = _useI18nTimeOptions.refreshUnitsOptions;
  var applyRefreshInterval = function applyRefreshInterval(nextState) {
    var units = nextState.units,
      value = nextState.value;
    if (value === '') {
      return;
    }
    if (!onRefreshChange) {
      return;
    }
    var refreshIntervalMs = Math.max(toMilliseconds(units, value), minInterval || 0);
    onRefreshChange({
      refreshInterval: refreshIntervalMs,
      intervalUnits: units,
      isPaused: refreshIntervalMs <= 0 ? true : !!isPaused
    });
  };
  var onValueChange = function onValueChange(event) {
    var sanitizedValue = parseFloat(event.target.value);
    var newValue = isNaN(sanitizedValue) ? '' : sanitizedValue;
    var nextState = _objectSpread(_objectSpread({}, state), {}, {
      value: newValue
    });
    setState(nextState);
    applyRefreshInterval(nextState);
  };
  var onUnitsChange = function onUnitsChange(event) {
    var units = event.target.value;
    var nextState = _objectSpread(_objectSpread({}, state), {}, {
      units: units,
      min: getMinInterval(minInterval, units)
    });
    setState(nextState);
    applyRefreshInterval(nextState);
  };
  var startRefresh = function startRefresh() {
    var value = state.value,
      units = state.units;
    if (value !== '' && value > 0 && onRefreshChange !== undefined) {
      onRefreshChange({
        refreshInterval: toMilliseconds(units, value),
        intervalUnits: units,
        isPaused: false
      });
    }
  };
  var handleKeyDown = function handleKeyDown(_ref2) {
    var key = _ref2.key;
    if (key === 'Enter') {
      startRefresh();
    }
  };
  var toggleRefresh = function toggleRefresh() {
    if (!onRefreshChange || state.value === '') {
      return;
    }
    var units = state.units,
      value = state.value;
    onRefreshChange({
      refreshInterval: toMilliseconds(units, value),
      intervalUnits: units,
      isPaused: !isPaused
    });
  };
  var renderScreenReaderText = function renderScreenReaderText() {
    var value = state.value,
      units = state.units;
    var options = refreshUnitsOptions.find(function (_ref3) {
      var value = _ref3.value;
      return value === units;
    });
    var optionText = options ? options.text : '';
    var fullDescription = isPaused ? (0, _react2.jsx)(_i18n.EuiI18n, {
      token: "euiRefreshInterval.fullDescriptionOff",
      default: "Refresh is off, interval set to {optionValue} {optionText}.",
      values: {
        optionValue: value,
        optionText: optionText
      }
    }) : (0, _react2.jsx)(_i18n.EuiI18n, {
      token: "euiRefreshInterval.fullDescriptionOn",
      default: "Refresh is on, interval set to {optionValue} {optionText}.",
      values: {
        optionValue: value,
        optionText: optionText
      }
    });
    return (0, _react2.jsx)(_accessibility.EuiScreenReaderOnly, null, (0, _react2.jsx)("p", {
      id: refreshSelectionId
    }, fullDescription));
  };
  var value = state.value,
    units = state.units,
    min = state.min;
  return (0, _react2.jsx)(_i18n.EuiI18n, {
    tokens: ['euiRefreshInterval.toggleLabel', 'euiRefreshInterval.toggleAriaLabel', 'euiRefreshInterval.valueAriaLabel', 'euiRefreshInterval.unitsAriaLabel'],
    defaults: ['Refresh every', 'Toggle refresh', 'Refresh interval value', 'Refresh interval units']
  }, function (_ref4) {
    var _ref5 = (0, _slicedToArray2.default)(_ref4, 4),
      toggleLabel = _ref5[0],
      toggleAriaLabel = _ref5[1],
      valueAriaLabel = _ref5[2],
      unitsAriaLabel = _ref5[3];
    return (0, _react2.jsx)(_quick_select_panel.EuiQuickSelectPanel, null, (0, _react2.jsx)(_flex.EuiFlexGroup, {
      alignItems: "center",
      gutterSize: "s",
      responsive: false,
      wrap: true
    }, (0, _react2.jsx)(_flex.EuiFlexItem, {
      grow: false
    }, (0, _react2.jsx)(_form.EuiSwitch, {
      "data-test-subj": "superDatePickerToggleRefreshButton",
      checked: !isPaused,
      onChange: toggleRefresh,
      compressed: true
      // The IDs attached to this visible label are unused - we override with our own aria-label
      ,
      label: (0, _react2.jsx)(_form.EuiFormLabel, null, toggleLabel),
      "aria-label": toggleAriaLabel,
      "aria-labelledby": undefined,
      "aria-describedby": refreshSelectionId
    })), (0, _react2.jsx)(_flex.EuiFlexItem, {
      style: {
        minWidth: 60
      }
    }, (0, _react2.jsx)(_form.EuiFieldNumber, {
      compressed: true,
      fullWidth: true,
      value: value,
      min: min,
      onChange: onValueChange,
      onKeyDown: handleKeyDown,
      isInvalid: !isPaused && (value === '' || value <= 0),
      disabled: isPaused,
      "aria-label": valueAriaLabel,
      "aria-describedby": refreshSelectionId,
      "data-test-subj": "superDatePickerRefreshIntervalInput"
    })), (0, _react2.jsx)(_flex.EuiFlexItem, {
      style: {
        minWidth: 100
      },
      grow: 2
    }, (0, _react2.jsx)(_form.EuiSelect, {
      compressed: true,
      fullWidth: true,
      "aria-label": unitsAriaLabel,
      "aria-describedby": refreshSelectionId,
      value: units,
      disabled: isPaused,
      options: refreshUnitsOptions,
      onChange: onUnitsChange,
      onKeyDown: handleKeyDown,
      "data-test-subj": "superDatePickerRefreshIntervalUnitsSelect"
    }))), renderScreenReaderText());
  });
};
EuiRefreshInterval.displayName = 'EuiRefreshInterval';