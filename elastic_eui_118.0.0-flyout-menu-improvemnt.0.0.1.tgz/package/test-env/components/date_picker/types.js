"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.REFRESH_UNIT_OPTIONS = void 0;
/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */

/**
 * String as either datemath (e.g.: now, now-15m, now-15m/m) or
 * absolute date in the format 'YYYY-MM-DDTHH:mm:ss.SSSZ'
 */

var REFRESH_UNIT_OPTIONS = exports.REFRESH_UNIT_OPTIONS = ['s', 'm', 'h'];