"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.euiTimeZoneDisplayStyles = void 0;
var _react = require("@emotion/react");
var _global_styling = require("../../../../global_styling");
/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */

var euiTimeZoneDisplayStyles = exports.euiTimeZoneDisplayStyles = function euiTimeZoneDisplayStyles(euiThemeContext) {
  var euiTheme = euiThemeContext.euiTheme;

  // This padding should probably not be part of this component to make it really reusable

  return {
    euiTimeZoneDisplay: /*#__PURE__*/(0, _react.css)((0, _global_styling.logicalCSS)('padding-horizontal', euiTheme.size.s), " ", (0, _global_styling.logicalCSS)('padding-bottom', euiTheme.size.s), ";;label:euiTimeZoneDisplay;")
  };
};