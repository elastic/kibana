"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.euiCheckboxControlStyles = void 0;
var _react = require("@emotion/react");
var _form = require("../form.styles");
function _EMOTION_STRINGIFIED_CSS_ERROR__() { return "You have tried to stringify object returned from `css` function. It isn't supposed to be used directly (e.g. as value of the `className` prop), but rather handed to emotion so it can handle it (e.g. as value of `css` prop)."; } /*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */
var _ref = process.env.NODE_ENV === "production" ? {
  name: "u54glv-indeterminate",
  styles: "transform:scale(0.5);label:indeterminate;"
} : {
  name: "u54glv-indeterminate",
  styles: "transform:scale(0.5);label:indeterminate;",
  toString: _EMOTION_STRINGIFIED_CSS_ERROR__
};
var euiCheckboxControlStyles = exports.euiCheckboxControlStyles = function euiCheckboxControlStyles(euiThemeContext) {
  var euiTheme = euiThemeContext.euiTheme;
  var controlStyles = (0, _form.euiFormCustomControlStyles)(euiThemeContext);
  return {
    euiCheckboxControl: /*#__PURE__*/(0, _react.css)(controlStyles.input.fauxInput, " border-radius:", euiTheme.border.radius.small, ";;label:euiCheckboxControl;"),
    enabled: {
      selected: /*#__PURE__*/(0, _react.css)(controlStyles.input.enabled.selected, ";label:selected;"),
      unselected: /*#__PURE__*/(0, _react.css)(controlStyles.input.enabled.unselected, ";label:unselected;"),
      excluded: /*#__PURE__*/(0, _react.css)(controlStyles.input.enabled.selected, " background-color:", euiTheme.colors.backgroundFilledDanger, ";border-color:", euiTheme.colors.backgroundFilledDanger, ";;label:excluded;")
    },
    disabled: {
      selected: /*#__PURE__*/(0, _react.css)(controlStyles.input.disabled.selected, ";label:selected;"),
      unselected: /*#__PURE__*/(0, _react.css)(controlStyles.input.disabled.unselected, ";label:unselected;")
    },
    icon: {
      euiCheckbox__icon: /*#__PURE__*/(0, _react.css)(";label:euiCheckbox__icon;"),
      check: /*#__PURE__*/(0, _react.css)(controlStyles.input.icon, " stroke:currentColor;;label:check;"),
      indeterminate: _ref
    }
  };
};