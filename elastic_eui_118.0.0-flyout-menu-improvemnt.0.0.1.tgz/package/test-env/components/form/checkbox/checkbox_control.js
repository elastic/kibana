"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.EuiCheckboxControl = void 0;
var _extends2 = _interopRequireDefault(require("@babel/runtime/helpers/extends"));
var _objectWithoutProperties2 = _interopRequireDefault(require("@babel/runtime/helpers/objectWithoutProperties"));
var _react = _interopRequireDefault(require("react"));
var _propTypes = _interopRequireDefault(require("prop-types"));
var _classnames = _interopRequireDefault(require("classnames"));
var _services = require("../../../services");
var _icon = require("../../icon");
var _checkbox_control = require("./checkbox_control.styles");
var _react2 = require("@emotion/react");
var _excluded = ["className", "checked", "indeterminate", "excluded", "disabled"];
/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */
/**
 * Presentation-only checkbox control element. Renders a checkbox square and state icon only without functionality.
 */
var EuiCheckboxControl = exports.EuiCheckboxControl = function EuiCheckboxControl(_ref) {
  var className = _ref.className,
    _ref$checked = _ref.checked,
    checked = _ref$checked === void 0 ? false : _ref$checked,
    _ref$indeterminate = _ref.indeterminate,
    indeterminate = _ref$indeterminate === void 0 ? false : _ref$indeterminate,
    _ref$excluded = _ref.excluded,
    excluded = _ref$excluded === void 0 ? false : _ref$excluded,
    _ref$disabled = _ref.disabled,
    disabled = _ref$disabled === void 0 ? false : _ref$disabled,
    rest = (0, _objectWithoutProperties2.default)(_ref, _excluded);
  var isSelected = checked || indeterminate || excluded;
  var isExcluded = excluded && !indeterminate;
  var classes = (0, _classnames.default)('euiCheckboxControl', className);
  var styles = (0, _services.useEuiMemoizedStyles)(_checkbox_control.euiCheckboxControlStyles);
  var cssStyles = [styles.euiCheckboxControl, disabled ? isSelected ? styles.disabled.selected : styles.disabled.unselected : isExcluded ? styles.enabled.excluded : isSelected ? styles.enabled.selected : styles.enabled.unselected];
  var iconStyles = [styles.icon.euiCheckbox__icon, indeterminate ? styles.icon.indeterminate : styles.icon.check];
  var iconType = indeterminate ? 'stopFill' : excluded ? 'cross' : checked ? 'check' : 'empty';
  return (0, _react2.jsx)("span", (0, _extends2.default)({
    css: cssStyles,
    className: classes
  }, rest), (0, _react2.jsx)(_icon.EuiIcon, {
    role: "presentation",
    css: iconStyles,
    type: iconType,
    size: "m"
  }));
};
EuiCheckboxControl.propTypes = {
  /**
     * Renders a checked variant.
     * @default false
     */
  checked: _propTypes.default.bool,
  /**
     * Renders an indeterminate variant.
     * This overrides any other variant.
     * @default false
     */
  indeterminate: _propTypes.default.bool,
  /**
     * Renders an excluded variant.
     * This overrides the checked variant.
     * @default false
     */
  excluded: _propTypes.default.bool,
  /**
     * Renders a disabled variant.
     * @default false
     */
  disabled: _propTypes.default.bool,
  className: _propTypes.default.string,
  "aria-label": _propTypes.default.string,
  "data-test-subj": _propTypes.default.string,
  css: _propTypes.default.any
};