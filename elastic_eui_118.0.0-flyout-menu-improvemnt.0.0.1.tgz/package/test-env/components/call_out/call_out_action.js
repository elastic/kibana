"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.EuiCallOutAction = void 0;
var _extends2 = _interopRequireDefault(require("@babel/runtime/helpers/extends"));
var _objectWithoutProperties2 = _interopRequireDefault(require("@babel/runtime/helpers/objectWithoutProperties"));
var _react = _interopRequireDefault(require("react"));
var _classnames = _interopRequireDefault(require("classnames"));
var _button2 = require("../button");
var _with_popover = require("../popover/with_popover");
var _with_tooltip = require("../tool_tip/with_tooltip");
var _react2 = require("@emotion/react");
var _excluded = ["children", "actionType", "color", "tooltipProps", "popoverProps", "className"];
/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */
var EuiCallOutAction = exports.EuiCallOutAction = function EuiCallOutAction(_ref) {
  var children = _ref.children,
    _ref$actionType = _ref.actionType,
    actionType = _ref$actionType === void 0 ? 'primary' : _ref$actionType,
    _ref$color = _ref.color,
    color = _ref$color === void 0 ? 'primary' : _ref$color,
    tooltipProps = _ref.tooltipProps,
    popoverProps = _ref.popoverProps,
    className = _ref.className,
    rest = (0, _objectWithoutProperties2.default)(_ref, _excluded);
  var classes = (0, _classnames.default)('euiCallOutAction', className);
  if (actionType === 'primary') {
    var button = (0, _react2.jsx)(_button2.EuiButton, (0, _extends2.default)({
      className: classes,
      size: "s",
      color: color
    }, rest), children);
    return (0, _with_popover.withEuiPopover)((0, _with_tooltip.withEuiToolTip)(button, tooltipProps), popoverProps);
  } else {
    var _button = (0, _react2.jsx)(_button2.EuiButtonEmpty, (0, _extends2.default)({
      className: classes,
      size: "s",
      color: color
    }, rest), children);
    return (0, _with_popover.withEuiPopover)((0, _with_tooltip.withEuiToolTip)(_button, tooltipProps), popoverProps);
  }
};