"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.sortMapBySmallToLargeValues = exports.sortMapByLargeToSmallValues = void 0;
var _slicedToArray2 = _interopRequireDefault(require("@babel/runtime/helpers/slicedToArray"));
/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */

var sortMapByLargeToSmallValues = exports.sortMapByLargeToSmallValues = function sortMapByLargeToSmallValues(breakpointsMap) {
  return Object.fromEntries(Object.entries(breakpointsMap).sort(function (_ref, _ref2) {
    var _ref3 = (0, _slicedToArray2.default)(_ref, 2),
      a = _ref3[1];
    var _ref4 = (0, _slicedToArray2.default)(_ref2, 2),
      b = _ref4[1];
    return b - a;
  }));
};
var sortMapBySmallToLargeValues = exports.sortMapBySmallToLargeValues = function sortMapBySmallToLargeValues(breakpointsMap) {
  return Object.fromEntries(Object.entries(breakpointsMap).sort(function (_ref5, _ref6) {
    var _ref7 = (0, _slicedToArray2.default)(_ref5, 2),
      a = _ref7[1];
    var _ref8 = (0, _slicedToArray2.default)(_ref6, 2),
      b = _ref8[1];
    return a - b;
  }));
};