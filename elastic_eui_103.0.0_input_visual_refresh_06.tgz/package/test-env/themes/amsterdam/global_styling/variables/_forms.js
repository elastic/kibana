"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.forms = void 0;
var _defineProperty2 = _interopRequireDefault(require("@babel/runtime/helpers/defineProperty"));
var _slicedToArray2 = _interopRequireDefault(require("@babel/runtime/helpers/slicedToArray"));
var _euiThemeCommon = require("@elastic/eui-theme-common");
var _utils = require("../../../../services/theme/utils");
var _manipulation = require("../../../../services/color/manipulation");
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { (0, _defineProperty2.default)(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; } /*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */
var _forms = {
  background: (0, _utils.computed)(function (_ref) {
    var _ref2 = (0, _slicedToArray2.default)(_ref, 1),
      lightestShade = _ref2[0];
    return (0, _manipulation.tint)(lightestShade, 0.6);
  }, ['colors.lightestShade']),
  backgroundDisabled: (0, _utils.computed)(function (_ref3) {
    var _ref4 = (0, _slicedToArray2.default)(_ref3, 1),
      lightestShade = _ref4[0];
    return (0, _manipulation.darken)(lightestShade, 0.05);
  }, ['colors.lightestShade']),
  backgroundReadOnly: (0, _utils.computed)(function (_ref5) {
    var _ref6 = (0, _slicedToArray2.default)(_ref5, 1),
      emptyShade = _ref6[0];
    return emptyShade;
  }, ['colors.emptyShade']),
  backgroundFocused: (0, _utils.computed)(function (_ref7) {
    var _ref8 = (0, _slicedToArray2.default)(_ref7, 1),
      emptyShade = _ref8[0];
    return emptyShade;
  }, ['colors.emptyShade']),
  backgroundAutofilled: (0, _utils.computed)(function (_ref9) {
    var _ref10 = (0, _slicedToArray2.default)(_ref9, 1),
      primary = _ref10[0];
    var background = (0, _manipulation.tint)(primary, 0.8);
    return (0, _manipulation.tint)(background, 0.7);
  }, ['colors.primary']),
  backgroundDropping: 'transparent',
  prependBackground: (0, _utils.computed)(function (_ref11) {
    var _ref12 = (0, _slicedToArray2.default)(_ref11, 1),
      lightShade = _ref12[0];
    return (0, _manipulation.tint)(lightShade, 0.5);
  }, ['colors.lightShade']),
  border: (0, _utils.computed)(function (_ref13) {
    var _ref14 = (0, _slicedToArray2.default)(_ref13, 1),
      lightShade = _ref14[0];
    var color = (0, _manipulation.darken)(lightShade, 4);
    return (0, _manipulation.transparentize)(color, 0.1);
  }, ['colors.lightShade']),
  borderDisabled: (0, _utils.computed)(function (_ref15) {
    var _ref16 = (0, _slicedToArray2.default)(_ref15, 1),
      lightShade = _ref16[0];
    var color = (0, _manipulation.darken)(lightShade, 4);
    return (0, _manipulation.transparentize)(color, 0.1);
  }, ['colors.lightShade']),
  borderFocused: (0, _utils.computed)(function (_ref17) {
    var _ref18 = (0, _slicedToArray2.default)(_ref17, 1),
      primary = _ref18[0];
    return primary;
  }, ['colors.primary']),
  borderInvalid: (0, _utils.computed)(function (_ref19) {
    var _ref20 = (0, _slicedToArray2.default)(_ref19, 1),
      danger = _ref20[0];
    return danger;
  }, ['colors.danger']),
  borderHovered: (0, _utils.computed)(function (_ref21) {
    var _ref22 = (0, _slicedToArray2.default)(_ref21, 1),
      lightShade = _ref22[0];
    var color = (0, _manipulation.darken)(lightShade, 4);
    return (0, _manipulation.transparentize)(color, 0.1);
  }, ['colors.lightShade']),
  borderInvalidHovered: (0, _utils.computed)(function (_ref23) {
    var _ref24 = (0, _slicedToArray2.default)(_ref23, 1),
      danger = _ref24[0];
    return danger;
  }, ['colors.danger']),
  borderAutofilled: (0, _utils.computed)(function (_ref25) {
    var _ref26 = (0, _slicedToArray2.default)(_ref25, 1),
      primaryText = _ref26[0];
    return (0, _manipulation.transparentize)(primaryText, 0.2);
  }, ['colors.primaryText']),
  borderAutofilledHovered: (0, _utils.computed)(function (_ref27) {
    var _ref28 = (0, _slicedToArray2.default)(_ref27, 1),
      primaryText = _ref28[0];
    return (0, _manipulation.transparentize)(primaryText, 0.2);
  }, ['colors.primaryText']),
  clearButtonBackground: (0, _utils.computed)(function (_ref29) {
    var _ref30 = (0, _slicedToArray2.default)(_ref29, 1),
      mediumShade = _ref30[0];
    return mediumShade;
  }, ['colors.mediumShade']),
  controlBorder: (0, _utils.computed)(function (_ref31) {
    var _ref32 = (0, _slicedToArray2.default)(_ref31, 1),
      lightestShade = _ref32[0];
    return (0, _manipulation.shade)(lightestShade, 0.4);
  }, ['colors.lightestShade']),
  controlBorderSelected: (0, _utils.computed)(function (_ref33) {
    var _ref34 = (0, _slicedToArray2.default)(_ref33, 1),
      lightestShade = _ref34[0];
    return (0, _manipulation.shade)(lightestShade, 0.4);
  }, ['colors.lightestShade']),
  controlBorderDisabled: (0, _utils.computed)(function (_ref35) {
    var _ref36 = (0, _slicedToArray2.default)(_ref35, 1),
      lightestShade = _ref36[0];
    return (0, _manipulation.shade)(lightestShade, 0.4);
  }, ['colors.lightestShade']),
  controlBackgroundUnselected: (0, _utils.computed)(function (_ref37) {
    var _ref38 = (0, _slicedToArray2.default)(_ref37, 1),
      emptyShade = _ref38[0];
    return emptyShade;
  }, ['colors.emptyShade']),
  controlBackgroundDisabled: (0, _utils.computed)(function (_ref39) {
    var _ref40 = (0, _slicedToArray2.default)(_ref39, 1),
      lightShade = _ref40[0];
    return lightShade;
  }, ['colors.lightShade']),
  colorHasPlaceholder: (0, _utils.computed)(function (_ref41) {
    var _ref42 = (0, _slicedToArray2.default)(_ref41, 1),
      subduedText = _ref42[0];
    return (0, _manipulation.tint)(subduedText, 0.08);
  }, ['colors.subduedText']),
  colorDisabled: (0, _utils.computed)(function (_ref43) {
    var _ref44 = (0, _slicedToArray2.default)(_ref43, 1),
      mediumShade = _ref44[0];
    return mediumShade;
  }, ['colors.mediumShade']),
  iconDisabled: (0, _utils.computed)(function (_ref45) {
    var _ref46 = (0, _slicedToArray2.default)(_ref45, 1),
      darkShade = _ref46[0];
    return darkShade;
  }, ['colors.darkShade'])
};
var _dark_forms = _objectSpread(_objectSpread({}, _forms), {}, {
  background: (0, _utils.computed)(function (_ref47) {
    var _ref48 = (0, _slicedToArray2.default)(_ref47, 1),
      lightestShade = _ref48[0];
    return (0, _manipulation.shade)(lightestShade, 0.4);
  }, ['colors.lightestShade']),
  backgroundFocused: (0, _utils.computed)(function (_ref49) {
    var _ref50 = (0, _slicedToArray2.default)(_ref49, 1),
      emptyShade = _ref50[0];
    return (0, _manipulation.shade)(emptyShade, 0.4);
  }, ['colors.emptyShade']),
  backgroundAutofilled: (0, _utils.computed)(function (_ref51) {
    var _ref52 = (0, _slicedToArray2.default)(_ref51, 1),
      primary = _ref52[0];
    var background = (0, _manipulation.shade)(primary, 0.7);
    return (0, _manipulation.shade)(background, 0.5);
  }, ['colors.primary']),
  prependBackground: (0, _utils.computed)(function (_ref53) {
    var _ref54 = (0, _slicedToArray2.default)(_ref53, 1),
      lightShade = _ref54[0];
    return (0, _manipulation.shade)(lightShade, 0.15);
  }, ['colors.lightShade']),
  border: (0, _utils.computed)(function (_ref55) {
    var _ref56 = (0, _slicedToArray2.default)(_ref55, 1),
      ghost = _ref56[0];
    return (0, _manipulation.transparentize)(ghost, 0.1);
  }, ['colors.ghost']),
  clearButtonBackground: (0, _utils.computed)(function (_ref57) {
    var _ref58 = (0, _slicedToArray2.default)(_ref57, 1),
      darkShade = _ref58[0];
    return darkShade;
  }, ['colors.darkShade']),
  controlBorder: (0, _utils.computed)(function (_ref59) {
    var _ref60 = (0, _slicedToArray2.default)(_ref59, 1),
      lightestShade = _ref60[0];
    return (0, _manipulation.tint)(lightestShade, 0.31);
  }, ['colors.lightestShade']),
  controlBorderSelected: (0, _utils.computed)(function (_ref61) {
    var _ref62 = (0, _slicedToArray2.default)(_ref61, 1),
      lightestShade = _ref62[0];
    return (0, _manipulation.tint)(lightestShade, 0.31);
  }, ['colors.lightestShade']),
  controlBorderDisabled: (0, _utils.computed)(function (_ref63) {
    var _ref64 = (0, _slicedToArray2.default)(_ref63, 1),
      lightestShade = _ref64[0];
    return (0, _manipulation.tint)(lightestShade, 0.31);
  }, ['colors.lightestShade'])
});
var forms = exports.forms = {
  maxWidth: (0, _utils.computed)(function (_ref65) {
    var _ref66 = (0, _slicedToArray2.default)(_ref65, 1),
      base = _ref66[0];
    return (0, _euiThemeCommon.mathWithUnits)(base, function (x) {
      return x * 25;
    });
  }, ['size.base']),
  LIGHT: _forms,
  DARK: _dark_forms
};