"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.euiButtonDisplayContentStyles = void 0;
var _react = require("@emotion/react");
var _services = require("../../../services");
var _global_styling = require("../../../global_styling");
/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */

var euiButtonDisplayContentStyles = exports.euiButtonDisplayContentStyles = function euiButtonDisplayContentStyles(euiThemeContext) {
  var euiTheme = euiThemeContext.euiTheme;
  var isRefreshVariant = (0, _services.isEuiThemeRefreshVariant)(euiThemeContext, 'buttonVariant');
  var refreshVariantStyles = "\n      /* ensure content stays ontop of hover pseudo element */\n      position: relative;\n    ";
  return {
    // Base
    euiButtonDisplayContent: /*#__PURE__*/(0, _react.css)((0, _global_styling.logicalCSS)('height', '100%'), " ", (0, _global_styling.logicalCSS)('width', '100%'), " display:flex;justify-content:center;align-items:center;vertical-align:middle;gap:", euiTheme.size.s, ";", isRefreshVariant && refreshVariantStyles, ";;label:euiButtonDisplayContent;")
  };
};