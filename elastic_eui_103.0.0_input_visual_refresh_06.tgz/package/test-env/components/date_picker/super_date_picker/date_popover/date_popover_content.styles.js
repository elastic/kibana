"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.euiDatePopoverContentStyles = void 0;
var _react = require("@emotion/react");
var _global_styling = require("../../../../global_styling");
var _form = require("../../../form/form.styles");
/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */

var euiDatePopoverContentStyles = exports.euiDatePopoverContentStyles = function euiDatePopoverContentStyles(euiThemeContext) {
  var _euiFormVariables = (0, _form.euiFormVariables)(euiThemeContext),
    maxWidth = _euiFormVariables.maxWidth;
  return {
    euiDatePopoverContent: /*#__PURE__*/(0, _react.css)("&,& .react-datepicker{", (0, _global_styling.logicalCSS)('width', maxWidth), " ", (0, _global_styling.logicalCSS)('max-width', '100%'), " ", (0, _global_styling.euiMaxBreakpoint)(euiThemeContext, 's'), "{", (0, _global_styling.logicalCSS)('width', '284px'), ";}};label:euiDatePopoverContent;")
  };
};