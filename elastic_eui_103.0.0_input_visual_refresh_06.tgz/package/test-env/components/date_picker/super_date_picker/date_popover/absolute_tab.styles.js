"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.euiAbsoluteTabDateFormStyles = void 0;
var _react = require("@emotion/react");
var _global_styling = require("../../../../global_styling");
function _EMOTION_STRINGIFIED_CSS_ERROR__() { return "You have tried to stringify object returned from `css` function. It isn't supposed to be used directly (e.g. as value of the `className` prop), but rather handed to emotion so it can handle it (e.g. as value of `css` prop)."; } /*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */
var _ref = process.env.NODE_ENV === "production" ? {
  name: "1oht9b5-euiAbsoluteTabDateForm__submit",
  styles: "flex-shrink:0;label:euiAbsoluteTabDateForm__submit;"
} : {
  name: "1oht9b5-euiAbsoluteTabDateForm__submit",
  styles: "flex-shrink:0;label:euiAbsoluteTabDateForm__submit;",
  toString: _EMOTION_STRINGIFIED_CSS_ERROR__
};
var euiAbsoluteTabDateFormStyles = exports.euiAbsoluteTabDateFormStyles = function euiAbsoluteTabDateFormStyles(euiThemeContext) {
  var euiTheme = euiThemeContext.euiTheme;
  return {
    euiAbsoluteTabDateForm: /*#__PURE__*/(0, _react.css)((0, _global_styling.logicalCSS)('padding-horizontal', euiTheme.size.s), " ", (0, _global_styling.logicalCSS)('padding-bottom', euiTheme.size.s), ";;label:euiAbsoluteTabDateForm;"),
    euiAbsoluteTabDateForm__submit: _ref,
    euiAbsoluteTabDateForm__row: /*#__PURE__*/(0, _react.css)("flex-grow:1;.euiFormRow__text{", (0, _global_styling.logicalCSS)('margin-right', (0, _global_styling.mathWithUnits)([euiTheme.size.xl, euiTheme.size.s], function (submitButtonSize, gapSize) {
      return -1 * (submitButtonSize + gapSize);
    })), ";};label:euiAbsoluteTabDateForm__row;")
  };
};