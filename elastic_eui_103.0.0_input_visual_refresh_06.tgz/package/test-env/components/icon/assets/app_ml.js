"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
var _typeof = require("@babel/runtime/helpers/typeof");
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.icon = void 0;
var _extends2 = _interopRequireDefault(require("@babel/runtime/helpers/extends"));
var _objectWithoutProperties2 = _interopRequireDefault(require("@babel/runtime/helpers/objectWithoutProperties"));
var React = _interopRequireWildcard(require("react"));
var _react2 = require("@emotion/react");
var _excluded = ["title", "titleId"];
/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */
// THIS IS A GENERATED FILE. DO NOT MODIFY MANUALLY. @see scripts/compile-icons.js
function _getRequireWildcardCache(e) { if ("function" != typeof WeakMap) return null; var r = new WeakMap(), t = new WeakMap(); return (_getRequireWildcardCache = function _getRequireWildcardCache(e) { return e ? t : r; })(e); }
function _interopRequireWildcard(e, r) { if (!r && e && e.__esModule) return e; if (null === e || "object" != _typeof(e) && "function" != typeof e) return { default: e }; var t = _getRequireWildcardCache(r); if (t && t.has(e)) return t.get(e); var n = { __proto__: null }, a = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var u in e) if ("default" !== u && {}.hasOwnProperty.call(e, u)) { var i = a ? Object.getOwnPropertyDescriptor(e, u) : null; i && (i.get || i.set) ? Object.defineProperty(n, u, i) : n[u] = e[u]; } return n.default = e, t && t.set(e, n), n; }
var EuiIconAppMl = function EuiIconAppMl(_ref) {
  var title = _ref.title,
    titleId = _ref.titleId,
    props = (0, _objectWithoutProperties2.default)(_ref, _excluded);
  return (0, _react2.jsx)("svg", (0, _extends2.default)({
    xmlns: "http://www.w3.org/2000/svg",
    width: 32,
    height: 32,
    viewBox: "0 0 32 32",
    "aria-labelledby": titleId
  }, props), title ? (0, _react2.jsx)("title", {
    id: titleId
  }, title) : null, (0, _react2.jsx)("path", {
    d: "M10 18v.56a1 1 0 0 1-.68.95L3 21.61V10a1 1 0 0 1 .4-.8l3.2-2.4-1.2-1.6-3.2 2.4A3 3 0 0 0 1 10v12a3 3 0 0 0 1.2 2.4l3.2 2.4 1.2-1.6-2.47-1.85 5.82-1.95A3 3 0 0 0 12 18.56V18h-2zM29.8 7.6l-3.2-2.4-1.2 1.6 3.2 2.4a1 1 0 0 1 .4.8v11.61l-6.32-2.11a1 1 0 0 1-.68-.95V18h-2v.56a3 3 0 0 0 2.05 2.85l5.82 1.94-2.47 1.85 1.2 1.6 3.2-2.4A3 3 0 0 0 31 22V10a3 3 0 0 0-1.2-2.4z",
    className: "euiIcon__fillSecondary"
  }), (0, _react2.jsx)("path", {
    d: "M11 6A3 3 0 0 1 8.88.88a3.07 3.07 0 0 1 4.24 0A3 3 0 0 1 11 6zm0-4a1 1 0 1 0-.012 2A1 1 0 0 0 11 2zm0 30a3 3 0 0 1-2.12-5.12 3.07 3.07 0 0 1 4.24 0A3 3 0 0 1 11 32zm0-4a1 1 0 1 0-.012 2A1 1 0 0 0 11 28zm0-12a3 3 0 0 1-2.12-5.12 3.07 3.07 0 0 1 4.24 0A3 3 0 0 1 11 16zm0-4a1 1 0 1 0-.012 2A1 1 0 0 0 11 12zm10-6A3 3 0 0 1 18.88.88a3.07 3.07 0 0 1 4.24 0A3 3 0 0 1 21 6zm0-4a1 1 0 1 0-.012 2A1 1 0 0 0 21 2zm0 30a3 3 0 0 1-2.12-5.12 3.07 3.07 0 0 1 4.24 0A3 3 0 0 1 21 32zm0-4a1 1 0 1 0-.012 2A1 1 0 0 0 21 28zm0-12a3 3 0 0 1-2.12-5.12 3.07 3.07 0 0 1 4.24 0A3 3 0 0 1 21 16zm0-4a1 1 0 1 0-.012 2A1 1 0 0 0 21 12z"
  }));
};
var icon = exports.icon = EuiIconAppMl;