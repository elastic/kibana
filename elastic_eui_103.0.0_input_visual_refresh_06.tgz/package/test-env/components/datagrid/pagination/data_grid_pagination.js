"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
var _typeof = require("@babel/runtime/helpers/typeof");
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.shouldRenderPagination = exports.EuiDataGridPagination = void 0;
var _toConsumableArray2 = _interopRequireDefault(require("@babel/runtime/helpers/toConsumableArray"));
var _react = _interopRequireWildcard(require("react"));
var _services = require("../../../services");
var _i18n = require("../../i18n");
var _table_pagination = require("../../table/table_pagination");
var _focus = require("../utils/focus");
var _data_grid_pagination = require("./data_grid_pagination.styles");
var _react2 = require("@emotion/react");
function _getRequireWildcardCache(e) { if ("function" != typeof WeakMap) return null; var r = new WeakMap(), t = new WeakMap(); return (_getRequireWildcardCache = function _getRequireWildcardCache(e) { return e ? t : r; })(e); }
function _interopRequireWildcard(e, r) { if (!r && e && e.__esModule) return e; if (null === e || "object" != _typeof(e) && "function" != typeof e) return { default: e }; var t = _getRequireWildcardCache(r); if (t && t.has(e)) return t.get(e); var n = { __proto__: null }, a = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var u in e) if ("default" !== u && {}.hasOwnProperty.call(e, u)) { var i = a ? Object.getOwnPropertyDescriptor(e, u) : null; i && (i.get || i.set) ? Object.defineProperty(n, u, i) : n[u] = e[u]; } return n.default = e, t && t.set(e, n), n; }
/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */

/**
 * Do not render the pagination when:
 * 1. Rows count is less than min pagination option (rows per page)
 * 2. Rows count is less than pageSize (the case when there are no pageSizeOptions provided)
 */
var shouldRenderPagination = exports.shouldRenderPagination = function shouldRenderPagination(rowCount, _ref) {
  var pageSize = _ref.pageSize,
    pageSizeOptions = _ref.pageSizeOptions;
  var minSizeOption = (0, _toConsumableArray2.default)(pageSizeOptions).sort(function (a, b) {
    return a - b;
  })[0];
  return !(rowCount < (minSizeOption || pageSize));
};
var EuiDataGridPagination = exports.EuiDataGridPagination = function EuiDataGridPagination(_ref2) {
  var pageIndex = _ref2.pageIndex,
    pageSize = _ref2.pageSize,
    pageSizeOptions = _ref2.pageSizeOptions,
    _onChangePage = _ref2.onChangePage,
    onChangeItemsPerPage = _ref2.onChangeItemsPerPage,
    rowCount = _ref2.rowCount,
    controls = _ref2.controls,
    ariaLabel = _ref2['aria-label'];
  var styles = (0, _services.useEuiMemoizedStyles)(_data_grid_pagination.euiDataGridPaginationStyles);
  var detailedPaginationLabel = (0, _i18n.useEuiI18n)('euiDataGridPagination.detailedPaginationLabel', 'Pagination for preceding grid: {label}', {
    label: ariaLabel !== null && ariaLabel !== void 0 ? ariaLabel : ''
  });
  var paginationLabel = (0, _i18n.useEuiI18n)('euiDataGridPagination.paginationLabel', 'Pagination for preceding grid');

  // Focus the first data cell & scroll back to the top of the grid whenever paginating to a new page
  var _useContext = (0, _react.useContext)(_focus.DataGridFocusContext),
    setFocusedCell = _useContext.setFocusedCell;
  var onChangePage = (0, _react.useCallback)(function (pageIndex) {
    _onChangePage(pageIndex);
    setFocusedCell([0, 0]);
  }, [setFocusedCell, _onChangePage]);
  var pageCount = pageSize ? Math.ceil(rowCount / pageSize) : 1;
  return (0, _react2.jsx)("div", {
    css: styles.euiDataGrid__pagination,
    className: "euiDataGrid__pagination"
  }, (0, _react2.jsx)(_table_pagination.EuiTablePagination, {
    "aria-controls": controls,
    activePage: pageIndex,
    itemsPerPage: pageSize,
    itemsPerPageOptions: pageSizeOptions,
    showPerPageOptions: pageSizeOptions.length > 0,
    pageCount: pageCount,
    onChangePage: onChangePage,
    onChangeItemsPerPage: onChangeItemsPerPage,
    "aria-label": ariaLabel ? detailedPaginationLabel : paginationLabel
  }));
};