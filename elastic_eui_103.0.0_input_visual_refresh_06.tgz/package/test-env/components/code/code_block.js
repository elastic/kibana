"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.PADDING_SIZES = exports.FONT_SIZES = exports.EuiCodeBlock = void 0;
var _react = _interopRequireDefault(require("react"));
var _react2 = require("@emotion/react");
/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */

var EuiCodeBlock = exports.EuiCodeBlock = function EuiCodeBlock(_ref) {
  var children = _ref.children,
    dataTestSubj = _ref['data-test-subj'],
    language = _ref.language;
  return (0, _react2.jsx)("div", null, (0, _react2.jsx)("pre", null, (0, _react2.jsx)("code", {
    "data-test-subj": dataTestSubj,
    "data-code-language": language
  }, children)));
};
var FONT_SIZES = exports.FONT_SIZES = ['s', 'm', 'l'];
var PADDING_SIZES = exports.PADDING_SIZES = ['none', 's', 'm', 'l'];