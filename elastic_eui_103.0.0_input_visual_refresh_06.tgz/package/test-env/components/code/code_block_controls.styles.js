"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.euiCodeBlockControlsStyles = void 0;
var _react = require("@emotion/react");
var _global_styling = require("../../global_styling");
var _code_syntax = require("./code_syntax.styles");
function _EMOTION_STRINGIFIED_CSS_ERROR__() { return "You have tried to stringify object returned from `css` function. It isn't supposed to be used directly (e.g. as value of the `className` prop), but rather handed to emotion so it can handle it (e.g. as value of `css` prop)."; } /*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */ /*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */
var _ref = process.env.NODE_ENV === "production" ? {
  name: "to86kv-none",
  styles: "inset-block-start:0;inset-inline-end:0;label:none;"
} : {
  name: "to86kv-none",
  styles: "inset-block-start:0;inset-inline-end:0;label:none;",
  toString: _EMOTION_STRINGIFIED_CSS_ERROR__
};
var euiCodeBlockControlsStyles = exports.euiCodeBlockControlsStyles = function euiCodeBlockControlsStyles(euiThemeContext) {
  var euiTheme = euiThemeContext.euiTheme;
  var codeSyntaxVariables = (0, _code_syntax.euiCodeSyntaxVariables)(euiThemeContext);
  return {
    euiCodeBlock__controls: /*#__PURE__*/(0, _react.css)("position:absolute;display:flex;flex-direction:column;gap:", euiTheme.size.xs, ";background:", codeSyntaxVariables.backgroundColor, ";;label:euiCodeBlock__controls;"),
    offset: {
      none: _ref,
      s: /*#__PURE__*/(0, _react.css)("inset-block-start:", (0, _global_styling.euiPaddingSize)(euiThemeContext, 's'), ";inset-inline-end:", (0, _global_styling.euiPaddingSize)(euiThemeContext, 's'), ";;label:s;"),
      m: /*#__PURE__*/(0, _react.css)("inset-block-start:", (0, _global_styling.euiPaddingSize)(euiThemeContext, 'm'), ";inset-inline-end:", (0, _global_styling.euiPaddingSize)(euiThemeContext, 'm'), ";;label:m;"),
      l: /*#__PURE__*/(0, _react.css)("inset-block-start:", (0, _global_styling.euiPaddingSize)(euiThemeContext, 'l'), ";inset-inline-end:", (0, _global_styling.euiPaddingSize)(euiThemeContext, 'l'), ";;label:l;")
    }
  };
};