"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.CustomComponentFilter = void 0;
var _react = _interopRequireDefault(require("react"));
var _react2 = require("@emotion/react");
/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */

/**
 * The props that are passed down to the custom component
 */

var CustomComponentFilter = exports.CustomComponentFilter = function CustomComponentFilter(props) {
  var CustomComponent = props.config.component;
  return (0, _react2.jsx)(CustomComponent, {
    query: props.query,
    onChange: props.onChange
  });
};