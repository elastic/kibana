"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.euiCollapsedNavPopoverStyles = void 0;
var _react = require("@emotion/react");
var _global_styling = require("../../../../global_styling");
/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */

var euiCollapsedNavPopoverStyles = exports.euiCollapsedNavPopoverStyles = function euiCollapsedNavPopoverStyles(euiThemeContext) {
  var euiTheme = euiThemeContext.euiTheme;
  return {
    euiCollapsedNavPopover__panel: /*#__PURE__*/(0, _react.css)((0, _global_styling.logicalCSS)('width', (0, _global_styling.mathWithUnits)(euiTheme.size.base, function (x) {
      return x * 15;
    })), ";;label:euiCollapsedNavPopover__panel;"),
    euiCollapsedNavPopover__title: /*#__PURE__*/(0, _react.css)("display:block;padding:", euiTheme.size.m, ";font-weight:", euiTheme.font.weight.bold, ";;label:euiCollapsedNavPopover__title;"),
    euiCollapsedNavPopover__items: /*#__PURE__*/(0, _react.css)((0, _global_styling.euiYScrollWithShadows)(euiThemeContext), " padding-block:", euiTheme.size.s, ";padding-inline:", euiTheme.size.xs, ";", (0, _global_styling.logicalCSS)('max-height', '50vh'), "@media (max-height: ", euiTheme.breakpoint.s, "px){", (0, _global_styling.logicalCSS)('max-height', '75vh'), ";};label:euiCollapsedNavPopover__items;")
  };
};