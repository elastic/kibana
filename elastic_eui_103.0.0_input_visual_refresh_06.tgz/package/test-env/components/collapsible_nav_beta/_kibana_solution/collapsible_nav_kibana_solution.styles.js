"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.euiCollapsibleNavKibanaSolutionStyles = void 0;
var _react = require("@emotion/react");
var _global_styling = require("../../../global_styling");
var _collapsible_nav_item = require("../collapsible_nav_item/collapsible_nav_item.styles");
function _EMOTION_STRINGIFIED_CSS_ERROR__() { return "You have tried to stringify object returned from `css` function. It isn't supposed to be used directly (e.g. as value of the `className` prop), but rather handed to emotion so it can handle it (e.g. as value of `css` prop)."; } /*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */
var _ref = process.env.NODE_ENV === "production" ? {
  name: "kimavp-euiCollapsibleNavKibanaSolution__secondaryItems",
  styles: "padding-block-end:0;label:euiCollapsibleNavKibanaSolution__secondaryItems;"
} : {
  name: "kimavp-euiCollapsibleNavKibanaSolution__secondaryItems",
  styles: "padding-block-end:0;label:euiCollapsibleNavKibanaSolution__secondaryItems;",
  toString: _EMOTION_STRINGIFIED_CSS_ERROR__
};
var _ref2 = process.env.NODE_ENV === "production" ? {
  name: "1fhy01q-euiCollapsibleNavKibanaSolution__switcherIcon",
  styles: "margin-inline-start:auto;label:euiCollapsibleNavKibanaSolution__switcherIcon;"
} : {
  name: "1fhy01q-euiCollapsibleNavKibanaSolution__switcherIcon",
  styles: "margin-inline-start:auto;label:euiCollapsibleNavKibanaSolution__switcherIcon;",
  toString: _EMOTION_STRINGIFIED_CSS_ERROR__
};
var _ref3 = process.env.NODE_ENV === "production" ? {
  name: "332r3i-euiCollapsibleNavKibanaSolution__logo",
  styles: "transform:scale(1.25);label:euiCollapsibleNavKibanaSolution__logo;"
} : {
  name: "332r3i-euiCollapsibleNavKibanaSolution__logo",
  styles: "transform:scale(1.25);label:euiCollapsibleNavKibanaSolution__logo;",
  toString: _EMOTION_STRINGIFIED_CSS_ERROR__
};
var euiCollapsibleNavKibanaSolutionStyles = exports.euiCollapsibleNavKibanaSolutionStyles = function euiCollapsibleNavKibanaSolutionStyles(euiThemeContext) {
  var euiTheme = euiThemeContext.euiTheme;
  var sharedStyles = (0, _collapsible_nav_item.euiCollapsibleNavItemVariables)(euiThemeContext);
  return {
    euiCollapsibleNavKibanaSolution: /*#__PURE__*/(0, _react.css)(";label:euiCollapsibleNavKibanaSolution;"),
    collapsed: /*#__PURE__*/(0, _react.css)("margin-block-start:", euiTheme.size.base, ";;label:collapsed;"),
    uncollapsed: /*#__PURE__*/(0, _react.css)("margin:", sharedStyles.padding, ";;label:uncollapsed;"),
    // Solution switcher title (popover toggle)
    euiCollapsibleNavKibanaSolution__title: /*#__PURE__*/(0, _react.css)("margin-block-start:", euiTheme.size.base, ";margin-block-end:", euiTheme.size.s, ";&:is(button){inline-size:100%;};label:euiCollapsibleNavKibanaSolution__title;"),
    // Make the solution logo slightly larger
    euiCollapsibleNavKibanaSolution__logo: _ref3,
    // Align the layer icon to the accordion arrows
    euiCollapsibleNavKibanaSolution__switcherIcon: _ref2,
    // Solution switcher popover
    euiCollapsibleNavKibanaSolution__switcherPopover: /*#__PURE__*/(0, _react.css)(".euiPopoverTitle{padding:", (0, _global_styling.mathWithUnits)([euiTheme.size.s, euiTheme.size.xxs], function (x, y) {
      return x + y;
    }), ";margin-block-end:0;border-block-end:none;}[class*='euiCollapsedNavPopover__title']{padding:0;}[class*='euiCollapsedNavPopover__items']{padding:0;mask-image:none;};label:euiCollapsibleNavKibanaSolution__switcherPopover;"),
    euiCollapsibleNavKibanaSolution__secondaryItems: _ref
  };
};