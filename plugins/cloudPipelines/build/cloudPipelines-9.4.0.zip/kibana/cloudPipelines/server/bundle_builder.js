"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.serialiseBundle = exports.buildBundle = void 0;
/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0; you may not use this file except in compliance with the Elastic License
 * 2.0.
 */

/**
 * Build a bundle envelope from a set of wired streams for a tenant.
 *
 * The runtime does its own flattening; we just serialise the tree.
 * Streams are ordered ancestors-first (shortest dotted-name first), so
 * when the runtime cascades routing → child processing within one pass,
 * parents route before children execute.
 */
const buildBundle = (streams, tenant) => {
  const ordered = [...streams].sort((a, b) => a.name.length - b.name.length || a.name.localeCompare(b.name));
  return {
    version: 1,
    tenant: {
      target_type: tenant.targetType,
      target_id: tenant.targetId
    },
    exported_at: new Date().toISOString(),
    streams: ordered.map(s => {
      var _s$processing$steps, _s$processing, _s$routing;
      return {
        name: s.name,
        processing: {
          steps: (_s$processing$steps = (_s$processing = s.processing) === null || _s$processing === void 0 ? void 0 : _s$processing.steps) !== null && _s$processing$steps !== void 0 ? _s$processing$steps : []
        },
        routing: ((_s$routing = s.routing) !== null && _s$routing !== void 0 ? _s$routing : []).map(r => {
          var _r$status;
          return {
            destination: r.destination,
            where: r.where,
            status: (_r$status = r.status) !== null && _r$status !== void 0 ? _r$status : 'enabled'
          };
        })
      };
    })
  };
};

/**
 * Serialise the bundle for storage in pipelines-config. The service stores
 * the config as an opaque string; we JSON-stringify the envelope.
 */
exports.buildBundle = buildBundle;
const serialiseBundle = bundle => JSON.stringify(bundle);
exports.serialiseBundle = serialiseBundle;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJidWlsZEJ1bmRsZSIsInN0cmVhbXMiLCJ0ZW5hbnQiLCJvcmRlcmVkIiwic29ydCIsImEiLCJiIiwibmFtZSIsImxlbmd0aCIsImxvY2FsZUNvbXBhcmUiLCJ2ZXJzaW9uIiwidGFyZ2V0X3R5cGUiLCJ0YXJnZXRUeXBlIiwidGFyZ2V0X2lkIiwidGFyZ2V0SWQiLCJleHBvcnRlZF9hdCIsIkRhdGUiLCJ0b0lTT1N0cmluZyIsIm1hcCIsInMiLCJfcyRwcm9jZXNzaW5nJHN0ZXBzIiwiX3MkcHJvY2Vzc2luZyIsIl9zJHJvdXRpbmciLCJwcm9jZXNzaW5nIiwic3RlcHMiLCJyb3V0aW5nIiwiciIsIl9yJHN0YXR1cyIsImRlc3RpbmF0aW9uIiwid2hlcmUiLCJzdGF0dXMiLCJleHBvcnRzIiwic2VyaWFsaXNlQnVuZGxlIiwiYnVuZGxlIiwiSlNPTiIsInN0cmluZ2lmeSJdLCJzb3VyY2VzIjpbImJ1bmRsZV9idWlsZGVyLnRzIl0sInNvdXJjZXNDb250ZW50IjpbIi8qXG4gKiBDb3B5cmlnaHQgRWxhc3RpY3NlYXJjaCBCLlYuIGFuZC9vciBsaWNlbnNlZCB0byBFbGFzdGljc2VhcmNoIEIuVi4gdW5kZXIgb25lXG4gKiBvciBtb3JlIGNvbnRyaWJ1dG9yIGxpY2Vuc2UgYWdyZWVtZW50cy4gTGljZW5zZWQgdW5kZXIgdGhlIEVsYXN0aWMgTGljZW5zZVxuICogMi4wOyB5b3UgbWF5IG5vdCB1c2UgdGhpcyBmaWxlIGV4Y2VwdCBpbiBjb21wbGlhbmNlIHdpdGggdGhlIEVsYXN0aWMgTGljZW5zZVxuICogMi4wLlxuICovXG5cbmV4cG9ydCBpbnRlcmZhY2UgU3RyZWFtTm9kZSB7XG4gIG5hbWU6IHN0cmluZztcbiAgcHJvY2Vzc2luZz86IHsgc3RlcHM/OiB1bmtub3duW10gfTtcbiAgcm91dGluZz86IEFycmF5PHtcbiAgICBkZXN0aW5hdGlvbjogc3RyaW5nO1xuICAgIHdoZXJlOiB1bmtub3duO1xuICAgIHN0YXR1cz86IHN0cmluZztcbiAgfT47XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgVGVuYW50SWRlbnRpdHkge1xuICB0YXJnZXRUeXBlOiBzdHJpbmc7XG4gIHRhcmdldElkOiBzdHJpbmc7XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgQnVuZGxlIHtcbiAgdmVyc2lvbjogMTtcbiAgdGVuYW50OiB7IHRhcmdldF90eXBlOiBzdHJpbmc7IHRhcmdldF9pZDogc3RyaW5nIH07XG4gIGV4cG9ydGVkX2F0OiBzdHJpbmc7XG4gIHN0cmVhbXM6IEFycmF5PHtcbiAgICBuYW1lOiBzdHJpbmc7XG4gICAgcHJvY2Vzc2luZzogeyBzdGVwczogdW5rbm93bltdIH07XG4gICAgcm91dGluZzogQXJyYXk8eyBkZXN0aW5hdGlvbjogc3RyaW5nOyB3aGVyZTogdW5rbm93bjsgc3RhdHVzOiBzdHJpbmcgfT47XG4gIH0+O1xufVxuXG4vKipcbiAqIEJ1aWxkIGEgYnVuZGxlIGVudmVsb3BlIGZyb20gYSBzZXQgb2Ygd2lyZWQgc3RyZWFtcyBmb3IgYSB0ZW5hbnQuXG4gKlxuICogVGhlIHJ1bnRpbWUgZG9lcyBpdHMgb3duIGZsYXR0ZW5pbmc7IHdlIGp1c3Qgc2VyaWFsaXNlIHRoZSB0cmVlLlxuICogU3RyZWFtcyBhcmUgb3JkZXJlZCBhbmNlc3RvcnMtZmlyc3QgKHNob3J0ZXN0IGRvdHRlZC1uYW1lIGZpcnN0KSwgc29cbiAqIHdoZW4gdGhlIHJ1bnRpbWUgY2FzY2FkZXMgcm91dGluZyDihpIgY2hpbGQgcHJvY2Vzc2luZyB3aXRoaW4gb25lIHBhc3MsXG4gKiBwYXJlbnRzIHJvdXRlIGJlZm9yZSBjaGlsZHJlbiBleGVjdXRlLlxuICovXG5leHBvcnQgY29uc3QgYnVpbGRCdW5kbGUgPSAoc3RyZWFtczogU3RyZWFtTm9kZVtdLCB0ZW5hbnQ6IFRlbmFudElkZW50aXR5KTogQnVuZGxlID0+IHtcbiAgY29uc3Qgb3JkZXJlZCA9IFsuLi5zdHJlYW1zXS5zb3J0KChhLCBiKSA9PiBhLm5hbWUubGVuZ3RoIC0gYi5uYW1lLmxlbmd0aCB8fCBhLm5hbWUubG9jYWxlQ29tcGFyZShiLm5hbWUpKTtcblxuICByZXR1cm4ge1xuICAgIHZlcnNpb246IDEsXG4gICAgdGVuYW50OiB7IHRhcmdldF90eXBlOiB0ZW5hbnQudGFyZ2V0VHlwZSwgdGFyZ2V0X2lkOiB0ZW5hbnQudGFyZ2V0SWQgfSxcbiAgICBleHBvcnRlZF9hdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxuICAgIHN0cmVhbXM6IG9yZGVyZWQubWFwKChzKSA9PiAoe1xuICAgICAgbmFtZTogcy5uYW1lLFxuICAgICAgcHJvY2Vzc2luZzogeyBzdGVwczogcy5wcm9jZXNzaW5nPy5zdGVwcyA/PyBbXSB9LFxuICAgICAgcm91dGluZzogKHMucm91dGluZyA/PyBbXSkubWFwKChyKSA9PiAoe1xuICAgICAgICBkZXN0aW5hdGlvbjogci5kZXN0aW5hdGlvbixcbiAgICAgICAgd2hlcmU6IHIud2hlcmUsXG4gICAgICAgIHN0YXR1czogci5zdGF0dXMgPz8gJ2VuYWJsZWQnLFxuICAgICAgfSkpLFxuICAgIH0pKSxcbiAgfTtcbn07XG5cbi8qKlxuICogU2VyaWFsaXNlIHRoZSBidW5kbGUgZm9yIHN0b3JhZ2UgaW4gcGlwZWxpbmVzLWNvbmZpZy4gVGhlIHNlcnZpY2Ugc3RvcmVzXG4gKiB0aGUgY29uZmlnIGFzIGFuIG9wYXF1ZSBzdHJpbmc7IHdlIEpTT04tc3RyaW5naWZ5IHRoZSBlbnZlbG9wZS5cbiAqL1xuZXhwb3J0IGNvbnN0IHNlcmlhbGlzZUJ1bmRsZSA9IChidW5kbGU6IEJ1bmRsZSk6IHN0cmluZyA9PiBKU09OLnN0cmluZ2lmeShidW5kbGUpO1xuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBNEJBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDTyxNQUFNQSxXQUFXLEdBQUdBLENBQUNDLE9BQXFCLEVBQUVDLE1BQXNCLEtBQWE7RUFDcEYsTUFBTUMsT0FBTyxHQUFHLENBQUMsR0FBR0YsT0FBTyxDQUFDLENBQUNHLElBQUksQ0FBQyxDQUFDQyxDQUFDLEVBQUVDLENBQUMsS0FBS0QsQ0FBQyxDQUFDRSxJQUFJLENBQUNDLE1BQU0sR0FBR0YsQ0FBQyxDQUFDQyxJQUFJLENBQUNDLE1BQU0sSUFBSUgsQ0FBQyxDQUFDRSxJQUFJLENBQUNFLGFBQWEsQ0FBQ0gsQ0FBQyxDQUFDQyxJQUFJLENBQUMsQ0FBQztFQUUxRyxPQUFPO0lBQ0xHLE9BQU8sRUFBRSxDQUFDO0lBQ1ZSLE1BQU0sRUFBRTtNQUFFUyxXQUFXLEVBQUVULE1BQU0sQ0FBQ1UsVUFBVTtNQUFFQyxTQUFTLEVBQUVYLE1BQU0sQ0FBQ1k7SUFBUyxDQUFDO0lBQ3RFQyxXQUFXLEVBQUUsSUFBSUMsSUFBSSxDQUFDLENBQUMsQ0FBQ0MsV0FBVyxDQUFDLENBQUM7SUFDckNoQixPQUFPLEVBQUVFLE9BQU8sQ0FBQ2UsR0FBRyxDQUFFQyxDQUFDO01BQUEsSUFBQUMsbUJBQUEsRUFBQUMsYUFBQSxFQUFBQyxVQUFBO01BQUEsT0FBTTtRQUMzQmYsSUFBSSxFQUFFWSxDQUFDLENBQUNaLElBQUk7UUFDWmdCLFVBQVUsRUFBRTtVQUFFQyxLQUFLLEdBQUFKLG1CQUFBLElBQUFDLGFBQUEsR0FBRUYsQ0FBQyxDQUFDSSxVQUFVLGNBQUFGLGFBQUEsdUJBQVpBLGFBQUEsQ0FBY0csS0FBSyxjQUFBSixtQkFBQSxjQUFBQSxtQkFBQSxHQUFJO1FBQUcsQ0FBQztRQUNoREssT0FBTyxFQUFFLEVBQUFILFVBQUEsR0FBQ0gsQ0FBQyxDQUFDTSxPQUFPLGNBQUFILFVBQUEsY0FBQUEsVUFBQSxHQUFJLEVBQUUsRUFBRUosR0FBRyxDQUFFUSxDQUFDO1VBQUEsSUFBQUMsU0FBQTtVQUFBLE9BQU07WUFDckNDLFdBQVcsRUFBRUYsQ0FBQyxDQUFDRSxXQUFXO1lBQzFCQyxLQUFLLEVBQUVILENBQUMsQ0FBQ0csS0FBSztZQUNkQyxNQUFNLEdBQUFILFNBQUEsR0FBRUQsQ0FBQyxDQUFDSSxNQUFNLGNBQUFILFNBQUEsY0FBQUEsU0FBQSxHQUFJO1VBQ3RCLENBQUM7UUFBQSxDQUFDO01BQ0osQ0FBQztJQUFBLENBQUM7RUFDSixDQUFDO0FBQ0gsQ0FBQzs7QUFFRDtBQUNBO0FBQ0E7QUFDQTtBQUhBSSxPQUFBLENBQUEvQixXQUFBLEdBQUFBLFdBQUE7QUFJTyxNQUFNZ0MsZUFBZSxHQUFJQyxNQUFjLElBQWFDLElBQUksQ0FBQ0MsU0FBUyxDQUFDRixNQUFNLENBQUM7QUFBQ0YsT0FBQSxDQUFBQyxlQUFBLEdBQUFBLGVBQUEiLCJpZ25vcmVMaXN0IjpbXX0=