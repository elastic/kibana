"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.registerBundleRoutes = void 0;
var _configSchema = require("@kbn/config-schema");
var _common = require("../../common");
/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0; you may not use this file except in compliance with the Elastic License
 * 2.0.
 */

const STREAMS_INDEX = '.kibana_streams';
const registerBundleRoutes = (router, logger) => {
  router.get({
    path: `${_common.API_BASE}/streams/{name}/bundle`,
    validate: {
      params: _configSchema.schema.object({
        name: _configSchema.schema.string()
      })
    },
    access: 'public',
    security: {
      authz: {
        enabled: false,
        reason: 'Exports stream definitions from .kibana_streams'
      }
    }
  }, async (context, request, response) => {
    const {
      name
    } = request.params;
    const coreContext = await context.core;
    const esClient = coreContext.elasticsearch.client.asInternalUser;
    try {
      const searchResponse = await esClient.search({
        index: STREAMS_INDEX,
        size: 10000,
        sort: [{
          name: 'asc'
        }],
        track_total_hits: false,
        query: {
          bool: {
            filter: [{
              bool: {
                should: [{
                  term: {
                    name
                  }
                }, {
                  prefix: {
                    name: `${name}.`
                  }
                }]
              }
            }, {
              term: {
                type: 'wired'
              }
            }]
          }
        }
      });
      const streams = searchResponse.hits.hits.map(hit => hit._source).filter(doc => doc != null).map(doc => {
        var _doc$ingest$processin, _doc$ingest, _doc$ingest$processin2, _doc$ingest$wired$rou, _doc$ingest2, _doc$ingest2$wired;
        return {
          name: doc.name,
          processing: {
            steps: (_doc$ingest$processin = (_doc$ingest = doc.ingest) === null || _doc$ingest === void 0 ? void 0 : (_doc$ingest$processin2 = _doc$ingest.processing) === null || _doc$ingest$processin2 === void 0 ? void 0 : _doc$ingest$processin2.steps) !== null && _doc$ingest$processin !== void 0 ? _doc$ingest$processin : []
          },
          routing: ((_doc$ingest$wired$rou = (_doc$ingest2 = doc.ingest) === null || _doc$ingest2 === void 0 ? void 0 : (_doc$ingest2$wired = _doc$ingest2.wired) === null || _doc$ingest2$wired === void 0 ? void 0 : _doc$ingest2$wired.routing) !== null && _doc$ingest$wired$rou !== void 0 ? _doc$ingest$wired$rou : []).map(r => {
            var _r$status;
            return {
              destination: r.destination,
              where: r.where,
              status: (_r$status = r.status) !== null && _r$status !== void 0 ? _r$status : 'enabled'
            };
          })
        };
      });
      if (streams.length === 0) {
        return response.notFound({
          body: `Stream '${name}' not found`
        });
      }
      const bundle = {
        version: 1,
        root: name,
        exported_at: new Date().toISOString(),
        streams
      };
      return response.ok({
        body: bundle
      });
    } catch (err) {
      var _err$meta;
      if ((err === null || err === void 0 ? void 0 : (_err$meta = err.meta) === null || _err$meta === void 0 ? void 0 : _err$meta.statusCode) === 404) {
        return response.notFound({
          body: 'Streams index does not exist. Enable Streams first.'
        });
      }
      logger.error(`Failed to export bundle for stream '${name}': ${err}`);
      return response.customError({
        statusCode: 500,
        body: 'Failed to export bundle'
      });
    }
  });
};
exports.registerBundleRoutes = registerBundleRoutes;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfY29uZmlnU2NoZW1hIiwicmVxdWlyZSIsIl9jb21tb24iLCJTVFJFQU1TX0lOREVYIiwicmVnaXN0ZXJCdW5kbGVSb3V0ZXMiLCJyb3V0ZXIiLCJsb2dnZXIiLCJnZXQiLCJwYXRoIiwiQVBJX0JBU0UiLCJ2YWxpZGF0ZSIsInBhcmFtcyIsInNjaGVtYSIsIm9iamVjdCIsIm5hbWUiLCJzdHJpbmciLCJhY2Nlc3MiLCJzZWN1cml0eSIsImF1dGh6IiwiZW5hYmxlZCIsInJlYXNvbiIsImNvbnRleHQiLCJyZXF1ZXN0IiwicmVzcG9uc2UiLCJjb3JlQ29udGV4dCIsImNvcmUiLCJlc0NsaWVudCIsImVsYXN0aWNzZWFyY2giLCJjbGllbnQiLCJhc0ludGVybmFsVXNlciIsInNlYXJjaFJlc3BvbnNlIiwic2VhcmNoIiwiaW5kZXgiLCJzaXplIiwic29ydCIsInRyYWNrX3RvdGFsX2hpdHMiLCJxdWVyeSIsImJvb2wiLCJmaWx0ZXIiLCJzaG91bGQiLCJ0ZXJtIiwicHJlZml4IiwidHlwZSIsInN0cmVhbXMiLCJoaXRzIiwibWFwIiwiaGl0IiwiX3NvdXJjZSIsImRvYyIsIl9kb2MkaW5nZXN0JHByb2Nlc3NpbiIsIl9kb2MkaW5nZXN0IiwiX2RvYyRpbmdlc3QkcHJvY2Vzc2luMiIsIl9kb2MkaW5nZXN0JHdpcmVkJHJvdSIsIl9kb2MkaW5nZXN0MiIsIl9kb2MkaW5nZXN0MiR3aXJlZCIsInByb2Nlc3NpbmciLCJzdGVwcyIsImluZ2VzdCIsInJvdXRpbmciLCJ3aXJlZCIsInIiLCJfciRzdGF0dXMiLCJkZXN0aW5hdGlvbiIsIndoZXJlIiwic3RhdHVzIiwibGVuZ3RoIiwibm90Rm91bmQiLCJib2R5IiwiYnVuZGxlIiwidmVyc2lvbiIsInJvb3QiLCJleHBvcnRlZF9hdCIsIkRhdGUiLCJ0b0lTT1N0cmluZyIsIm9rIiwiZXJyIiwiX2VyciRtZXRhIiwibWV0YSIsInN0YXR1c0NvZGUiLCJlcnJvciIsImN1c3RvbUVycm9yIiwiZXhwb3J0cyJdLCJzb3VyY2VzIjpbImJ1bmRsZS50cyJdLCJzb3VyY2VzQ29udGVudCI6WyIvKlxuICogQ29weXJpZ2h0IEVsYXN0aWNzZWFyY2ggQi5WLiBhbmQvb3IgbGljZW5zZWQgdG8gRWxhc3RpY3NlYXJjaCBCLlYuIHVuZGVyIG9uZVxuICogb3IgbW9yZSBjb250cmlidXRvciBsaWNlbnNlIGFncmVlbWVudHMuIExpY2Vuc2VkIHVuZGVyIHRoZSBFbGFzdGljIExpY2Vuc2VcbiAqIDIuMDsgeW91IG1heSBub3QgdXNlIHRoaXMgZmlsZSBleGNlcHQgaW4gY29tcGxpYW5jZSB3aXRoIHRoZSBFbGFzdGljIExpY2Vuc2VcbiAqIDIuMC5cbiAqL1xuXG5pbXBvcnQgeyBzY2hlbWEgfSBmcm9tICdAa2JuL2NvbmZpZy1zY2hlbWEnO1xuaW1wb3J0IHR5cGUgeyBJUm91dGVyLCBMb2dnZXIgfSBmcm9tICdAa2JuL2NvcmUvc2VydmVyJztcbmltcG9ydCB7IEFQSV9CQVNFIH0gZnJvbSAnLi4vLi4vY29tbW9uJztcblxuY29uc3QgU1RSRUFNU19JTkRFWCA9ICcua2liYW5hX3N0cmVhbXMnO1xuXG5pbnRlcmZhY2UgV2lyZWRTdHJlYW1Eb2Mge1xuICB0eXBlOiBzdHJpbmc7XG4gIG5hbWU6IHN0cmluZztcbiAgaW5nZXN0Pzoge1xuICAgIHByb2Nlc3Npbmc/OiB7XG4gICAgICBzdGVwczogYW55W107XG4gICAgfTtcbiAgICB3aXJlZD86IHtcbiAgICAgIHJvdXRpbmc6IEFycmF5PHtcbiAgICAgICAgZGVzdGluYXRpb246IHN0cmluZztcbiAgICAgICAgd2hlcmU6IGFueTtcbiAgICAgICAgc3RhdHVzPzogc3RyaW5nO1xuICAgICAgfT47XG4gICAgfTtcbiAgfTtcbn1cblxuZXhwb3J0IGNvbnN0IHJlZ2lzdGVyQnVuZGxlUm91dGVzID0gKHJvdXRlcjogSVJvdXRlciwgbG9nZ2VyOiBMb2dnZXIpID0+IHtcbiAgcm91dGVyLmdldChcbiAgICB7XG4gICAgICBwYXRoOiBgJHtBUElfQkFTRX0vc3RyZWFtcy97bmFtZX0vYnVuZGxlYCxcbiAgICAgIHZhbGlkYXRlOiB7XG4gICAgICAgIHBhcmFtczogc2NoZW1hLm9iamVjdCh7XG4gICAgICAgICAgbmFtZTogc2NoZW1hLnN0cmluZygpLFxuICAgICAgICB9KSxcbiAgICAgIH0sXG4gICAgICBhY2Nlc3M6ICdwdWJsaWMnLFxuICAgICAgc2VjdXJpdHk6IHtcbiAgICAgICAgYXV0aHo6IHsgZW5hYmxlZDogZmFsc2UsIHJlYXNvbjogJ0V4cG9ydHMgc3RyZWFtIGRlZmluaXRpb25zIGZyb20gLmtpYmFuYV9zdHJlYW1zJyB9LFxuICAgICAgfSxcbiAgICB9LFxuICAgIGFzeW5jIChjb250ZXh0LCByZXF1ZXN0LCByZXNwb25zZSkgPT4ge1xuICAgICAgY29uc3QgeyBuYW1lIH0gPSByZXF1ZXN0LnBhcmFtcztcbiAgICAgIGNvbnN0IGNvcmVDb250ZXh0ID0gYXdhaXQgY29udGV4dC5jb3JlO1xuICAgICAgY29uc3QgZXNDbGllbnQgPSBjb3JlQ29udGV4dC5lbGFzdGljc2VhcmNoLmNsaWVudC5hc0ludGVybmFsVXNlcjtcblxuICAgICAgdHJ5IHtcbiAgICAgICAgY29uc3Qgc2VhcmNoUmVzcG9uc2UgPSBhd2FpdCBlc0NsaWVudC5zZWFyY2g8V2lyZWRTdHJlYW1Eb2M+KHtcbiAgICAgICAgICBpbmRleDogU1RSRUFNU19JTkRFWCxcbiAgICAgICAgICBzaXplOiAxMDAwMCxcbiAgICAgICAgICBzb3J0OiBbeyBuYW1lOiAnYXNjJyB9XSxcbiAgICAgICAgICB0cmFja190b3RhbF9oaXRzOiBmYWxzZSxcbiAgICAgICAgICBxdWVyeToge1xuICAgICAgICAgICAgYm9vbDoge1xuICAgICAgICAgICAgICBmaWx0ZXI6IFtcbiAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICBib29sOiB7XG4gICAgICAgICAgICAgICAgICAgIHNob3VsZDogW1xuICAgICAgICAgICAgICAgICAgICAgIHsgdGVybTogeyBuYW1lIH0gfSxcbiAgICAgICAgICAgICAgICAgICAgICB7IHByZWZpeDogeyBuYW1lOiBgJHtuYW1lfS5gIH0gfSxcbiAgICAgICAgICAgICAgICAgICAgXSxcbiAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICB7IHRlcm06IHsgdHlwZTogJ3dpcmVkJyB9IH0sXG4gICAgICAgICAgICAgIF0sXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIH0sXG4gICAgICAgIH0pO1xuXG4gICAgICAgIGNvbnN0IHN0cmVhbXMgPSBzZWFyY2hSZXNwb25zZS5oaXRzLmhpdHNcbiAgICAgICAgICAubWFwKChoaXQpID0+IGhpdC5fc291cmNlKVxuICAgICAgICAgIC5maWx0ZXIoKGRvYyk6IGRvYyBpcyBXaXJlZFN0cmVhbURvYyA9PiBkb2MgIT0gbnVsbClcbiAgICAgICAgICAubWFwKChkb2MpID0+ICh7XG4gICAgICAgICAgICBuYW1lOiBkb2MubmFtZSxcbiAgICAgICAgICAgIHByb2Nlc3Npbmc6IHtcbiAgICAgICAgICAgICAgc3RlcHM6IGRvYy5pbmdlc3Q/LnByb2Nlc3Npbmc/LnN0ZXBzID8/IFtdLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHJvdXRpbmc6IChkb2MuaW5nZXN0Py53aXJlZD8ucm91dGluZyA/PyBbXSkubWFwKChyKSA9PiAoe1xuICAgICAgICAgICAgICBkZXN0aW5hdGlvbjogci5kZXN0aW5hdGlvbixcbiAgICAgICAgICAgICAgd2hlcmU6IHIud2hlcmUsXG4gICAgICAgICAgICAgIHN0YXR1czogci5zdGF0dXMgPz8gJ2VuYWJsZWQnLFxuICAgICAgICAgICAgfSkpLFxuICAgICAgICAgIH0pKTtcblxuICAgICAgICBpZiAoc3RyZWFtcy5sZW5ndGggPT09IDApIHtcbiAgICAgICAgICByZXR1cm4gcmVzcG9uc2Uubm90Rm91bmQoeyBib2R5OiBgU3RyZWFtICcke25hbWV9JyBub3QgZm91bmRgIH0pO1xuICAgICAgICB9XG5cbiAgICAgICAgY29uc3QgYnVuZGxlID0ge1xuICAgICAgICAgIHZlcnNpb246IDEsXG4gICAgICAgICAgcm9vdDogbmFtZSxcbiAgICAgICAgICBleHBvcnRlZF9hdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxuICAgICAgICAgIHN0cmVhbXMsXG4gICAgICAgIH07XG5cbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlLm9rKHsgYm9keTogYnVuZGxlIH0pO1xuICAgICAgfSBjYXRjaCAoZXJyOiBhbnkpIHtcbiAgICAgICAgaWYgKGVycj8ubWV0YT8uc3RhdHVzQ29kZSA9PT0gNDA0KSB7XG4gICAgICAgICAgcmV0dXJuIHJlc3BvbnNlLm5vdEZvdW5kKHtcbiAgICAgICAgICAgIGJvZHk6ICdTdHJlYW1zIGluZGV4IGRvZXMgbm90IGV4aXN0LiBFbmFibGUgU3RyZWFtcyBmaXJzdC4nLFxuICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgICAgIGxvZ2dlci5lcnJvcihgRmFpbGVkIHRvIGV4cG9ydCBidW5kbGUgZm9yIHN0cmVhbSAnJHtuYW1lfSc6ICR7ZXJyfWApO1xuICAgICAgICByZXR1cm4gcmVzcG9uc2UuY3VzdG9tRXJyb3IoeyBzdGF0dXNDb2RlOiA1MDAsIGJvZHk6ICdGYWlsZWQgdG8gZXhwb3J0IGJ1bmRsZScgfSk7XG4gICAgICB9XG4gICAgfVxuICApO1xufTtcbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBT0EsSUFBQUEsYUFBQSxHQUFBQyxPQUFBO0FBRUEsSUFBQUMsT0FBQSxHQUFBRCxPQUFBO0FBVEE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQU1BLE1BQU1FLGFBQWEsR0FBRyxpQkFBaUI7QUFtQmhDLE1BQU1DLG9CQUFvQixHQUFHQSxDQUFDQyxNQUFlLEVBQUVDLE1BQWMsS0FBSztFQUN2RUQsTUFBTSxDQUFDRSxHQUFHLENBQ1I7SUFDRUMsSUFBSSxFQUFFLEdBQUdDLGdCQUFRLHdCQUF3QjtJQUN6Q0MsUUFBUSxFQUFFO01BQ1JDLE1BQU0sRUFBRUMsb0JBQU0sQ0FBQ0MsTUFBTSxDQUFDO1FBQ3BCQyxJQUFJLEVBQUVGLG9CQUFNLENBQUNHLE1BQU0sQ0FBQztNQUN0QixDQUFDO0lBQ0gsQ0FBQztJQUNEQyxNQUFNLEVBQUUsUUFBUTtJQUNoQkMsUUFBUSxFQUFFO01BQ1JDLEtBQUssRUFBRTtRQUFFQyxPQUFPLEVBQUUsS0FBSztRQUFFQyxNQUFNLEVBQUU7TUFBa0Q7SUFDckY7RUFDRixDQUFDLEVBQ0QsT0FBT0MsT0FBTyxFQUFFQyxPQUFPLEVBQUVDLFFBQVEsS0FBSztJQUNwQyxNQUFNO01BQUVUO0lBQUssQ0FBQyxHQUFHUSxPQUFPLENBQUNYLE1BQU07SUFDL0IsTUFBTWEsV0FBVyxHQUFHLE1BQU1ILE9BQU8sQ0FBQ0ksSUFBSTtJQUN0QyxNQUFNQyxRQUFRLEdBQUdGLFdBQVcsQ0FBQ0csYUFBYSxDQUFDQyxNQUFNLENBQUNDLGNBQWM7SUFFaEUsSUFBSTtNQUNGLE1BQU1DLGNBQWMsR0FBRyxNQUFNSixRQUFRLENBQUNLLE1BQU0sQ0FBaUI7UUFDM0RDLEtBQUssRUFBRTdCLGFBQWE7UUFDcEI4QixJQUFJLEVBQUUsS0FBSztRQUNYQyxJQUFJLEVBQUUsQ0FBQztVQUFFcEIsSUFBSSxFQUFFO1FBQU0sQ0FBQyxDQUFDO1FBQ3ZCcUIsZ0JBQWdCLEVBQUUsS0FBSztRQUN2QkMsS0FBSyxFQUFFO1VBQ0xDLElBQUksRUFBRTtZQUNKQyxNQUFNLEVBQUUsQ0FDTjtjQUNFRCxJQUFJLEVBQUU7Z0JBQ0pFLE1BQU0sRUFBRSxDQUNOO2tCQUFFQyxJQUFJLEVBQUU7b0JBQUUxQjtrQkFBSztnQkFBRSxDQUFDLEVBQ2xCO2tCQUFFMkIsTUFBTSxFQUFFO29CQUFFM0IsSUFBSSxFQUFFLEdBQUdBLElBQUk7a0JBQUk7Z0JBQUUsQ0FBQztjQUVwQztZQUNGLENBQUMsRUFDRDtjQUFFMEIsSUFBSSxFQUFFO2dCQUFFRSxJQUFJLEVBQUU7Y0FBUTtZQUFFLENBQUM7VUFFL0I7UUFDRjtNQUNGLENBQUMsQ0FBQztNQUVGLE1BQU1DLE9BQU8sR0FBR2IsY0FBYyxDQUFDYyxJQUFJLENBQUNBLElBQUksQ0FDckNDLEdBQUcsQ0FBRUMsR0FBRyxJQUFLQSxHQUFHLENBQUNDLE9BQU8sQ0FBQyxDQUN6QlQsTUFBTSxDQUFFVSxHQUFHLElBQTRCQSxHQUFHLElBQUksSUFBSSxDQUFDLENBQ25ESCxHQUFHLENBQUVHLEdBQUc7UUFBQSxJQUFBQyxxQkFBQSxFQUFBQyxXQUFBLEVBQUFDLHNCQUFBLEVBQUFDLHFCQUFBLEVBQUFDLFlBQUEsRUFBQUMsa0JBQUE7UUFBQSxPQUFNO1VBQ2J4QyxJQUFJLEVBQUVrQyxHQUFHLENBQUNsQyxJQUFJO1VBQ2R5QyxVQUFVLEVBQUU7WUFDVkMsS0FBSyxHQUFBUCxxQkFBQSxJQUFBQyxXQUFBLEdBQUVGLEdBQUcsQ0FBQ1MsTUFBTSxjQUFBUCxXQUFBLHdCQUFBQyxzQkFBQSxHQUFWRCxXQUFBLENBQVlLLFVBQVUsY0FBQUosc0JBQUEsdUJBQXRCQSxzQkFBQSxDQUF3QkssS0FBSyxjQUFBUCxxQkFBQSxjQUFBQSxxQkFBQSxHQUFJO1VBQzFDLENBQUM7VUFDRFMsT0FBTyxFQUFFLEVBQUFOLHFCQUFBLElBQUFDLFlBQUEsR0FBQ0wsR0FBRyxDQUFDUyxNQUFNLGNBQUFKLFlBQUEsd0JBQUFDLGtCQUFBLEdBQVZELFlBQUEsQ0FBWU0sS0FBSyxjQUFBTCxrQkFBQSx1QkFBakJBLGtCQUFBLENBQW1CSSxPQUFPLGNBQUFOLHFCQUFBLGNBQUFBLHFCQUFBLEdBQUksRUFBRSxFQUFFUCxHQUFHLENBQUVlLENBQUM7WUFBQSxJQUFBQyxTQUFBO1lBQUEsT0FBTTtjQUN0REMsV0FBVyxFQUFFRixDQUFDLENBQUNFLFdBQVc7Y0FDMUJDLEtBQUssRUFBRUgsQ0FBQyxDQUFDRyxLQUFLO2NBQ2RDLE1BQU0sR0FBQUgsU0FBQSxHQUFFRCxDQUFDLENBQUNJLE1BQU0sY0FBQUgsU0FBQSxjQUFBQSxTQUFBLEdBQUk7WUFDdEIsQ0FBQztVQUFBLENBQUM7UUFDSixDQUFDO01BQUEsQ0FBQyxDQUFDO01BRUwsSUFBSWxCLE9BQU8sQ0FBQ3NCLE1BQU0sS0FBSyxDQUFDLEVBQUU7UUFDeEIsT0FBTzFDLFFBQVEsQ0FBQzJDLFFBQVEsQ0FBQztVQUFFQyxJQUFJLEVBQUUsV0FBV3JELElBQUk7UUFBYyxDQUFDLENBQUM7TUFDbEU7TUFFQSxNQUFNc0QsTUFBTSxHQUFHO1FBQ2JDLE9BQU8sRUFBRSxDQUFDO1FBQ1ZDLElBQUksRUFBRXhELElBQUk7UUFDVnlELFdBQVcsRUFBRSxJQUFJQyxJQUFJLENBQUMsQ0FBQyxDQUFDQyxXQUFXLENBQUMsQ0FBQztRQUNyQzlCO01BQ0YsQ0FBQztNQUVELE9BQU9wQixRQUFRLENBQUNtRCxFQUFFLENBQUM7UUFBRVAsSUFBSSxFQUFFQztNQUFPLENBQUMsQ0FBQztJQUN0QyxDQUFDLENBQUMsT0FBT08sR0FBUSxFQUFFO01BQUEsSUFBQUMsU0FBQTtNQUNqQixJQUFJLENBQUFELEdBQUcsYUFBSEEsR0FBRyx3QkFBQUMsU0FBQSxHQUFIRCxHQUFHLENBQUVFLElBQUksY0FBQUQsU0FBQSx1QkFBVEEsU0FBQSxDQUFXRSxVQUFVLE1BQUssR0FBRyxFQUFFO1FBQ2pDLE9BQU92RCxRQUFRLENBQUMyQyxRQUFRLENBQUM7VUFDdkJDLElBQUksRUFBRTtRQUNSLENBQUMsQ0FBQztNQUNKO01BQ0E3RCxNQUFNLENBQUN5RSxLQUFLLENBQUMsdUNBQXVDakUsSUFBSSxNQUFNNkQsR0FBRyxFQUFFLENBQUM7TUFDcEUsT0FBT3BELFFBQVEsQ0FBQ3lELFdBQVcsQ0FBQztRQUFFRixVQUFVLEVBQUUsR0FBRztRQUFFWCxJQUFJLEVBQUU7TUFBMEIsQ0FBQyxDQUFDO0lBQ25GO0VBQ0YsQ0FDRixDQUFDO0FBQ0gsQ0FBQztBQUFDYyxPQUFBLENBQUE3RSxvQkFBQSxHQUFBQSxvQkFBQSIsImlnbm9yZUxpc3QiOltdfQ==