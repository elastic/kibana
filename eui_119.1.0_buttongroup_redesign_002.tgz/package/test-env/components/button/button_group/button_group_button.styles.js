"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.euiButtonGroupButtonStyles = exports._compressedButtonFocusColors = void 0;
var _defineProperty2 = _interopRequireDefault(require("@babel/runtime/helpers/defineProperty"));
var _toConsumableArray2 = _interopRequireDefault(require("@babel/runtime/helpers/toConsumableArray"));
var _react = require("@emotion/react");
var _global_styling = require("../../../global_styling");
var _button = require("../../../global_styling/mixins/_button");
var _accessibility = require("../../accessibility");
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { (0, _defineProperty2.default)(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
function _EMOTION_STRINGIFIED_CSS_ERROR__() { return "You have tried to stringify object returned from `css` function. It isn't supposed to be used directly (e.g. as value of the `className` prop), but rather handed to emotion so it can handle it (e.g. as value of `css` prop)."; } /*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */
var _ref = process.env.NODE_ENV === "production" ? {
  name: "1ockoqy-tooltipWrapper",
  styles: "min-inline-size:0;&:has(:focus-visible){z-index:1;};label:tooltipWrapper;"
} : {
  name: "1ockoqy-tooltipWrapper",
  styles: "min-inline-size:0;&:has(:focus-visible){z-index:1;};label:tooltipWrapper;",
  toString: _EMOTION_STRINGIFIED_CSS_ERROR__
};
var euiButtonGroupButtonStyles = exports.euiButtonGroupButtonStyles = function euiButtonGroupButtonStyles(euiThemeContext) {
  var euiTheme = euiThemeContext.euiTheme,
    highContrastMode = euiThemeContext.highContrastMode;
  var buttonSizeMap = (0, _button.euiButtonSizeMap)(euiThemeContext);
  var buttonSizes = {
    s: {
      height: buttonSizeMap.s.getInsetHeight(buttonSizeMap.s.height, euiTheme.size.xs),
      radius: buttonSizeMap.s.radiusInset
    },
    m: {
      height: buttonSizeMap.m.getInsetHeight(buttonSizeMap.m.height, euiTheme.size.xs),
      radius: buttonSizeMap.m.radiusInset
    }
  };
  var compressedButtonHeight = (0, _global_styling.mathWithUnits)([buttonSizes.s.height, euiTheme.border.width.thin], function (x, y) {
    return x - y * 6;
  });
  var selectedSelectors = '.euiButtonGroupButton-isSelected, .euiButtonGroup__tooltipWrapper-isSelected';
  return {
    // Base
    euiButtonGroupButton: /*#__PURE__*/(0, _react.css)((0, _global_styling.logicalCSS)('min-width', 0), " flex-shrink:1;flex-grow:0;border:none;border-radius:", buttonSizes.s.radius, ";font-weight:", euiTheme.font.weight.medium, ";&:is(", selectedSelectors, "):not(", _global_styling.euiDisabledSelector, "){", (0, _global_styling.highContrastModeStyles)(euiThemeContext, {
      forced: "\n            --highContrastHoverIndicatorColor: ".concat(euiTheme.colors.textInverse, ";\n            border: none;\n\n            /* styles the content manually instead of the button itself to preserve the system\n            focus style, as otherwise preventForcedColors() would require manual styling */\n            > [class*=\"euiButtonDisplayContent\"] {\n              ").concat((0, _global_styling.preventForcedColors)(euiThemeContext), "\n              color: ").concat(euiTheme.colors.emptyShade, ";\n              border: none;\n            }\n          ")
    }), ";}&:is(", selectedSelectors, ":where(", _global_styling.euiDisabledSelector, ")){border:none;}&:focus-visible{outline-offset:0;};label:euiButtonGroupButton;"),
    iconOnly: {
      // used only as classname, sizes are added separately
      iconOnly: /*#__PURE__*/(0, _react.css)(";label:iconOnly;"),
      s: "\n        ".concat((0, _global_styling.logicalCSS)('width', buttonSizes.s.height), "\n      "),
      m: "\n        ".concat((0, _global_styling.logicalCSS)('width', buttonSizes.m.height), "\n      "),
      compressed: "\n        ".concat((0, _global_styling.logicalCSS)('width', compressedButtonHeight), "\n      ")
    },
    s: /*#__PURE__*/(0, _react.css)((0, _global_styling.logicalCSS)('height', buttonSizes.s.height), " line-height:", buttonSizes.s.height, ";;label:s;"),
    m: /*#__PURE__*/(0, _react.css)((0, _global_styling.logicalCSS)('height', buttonSizes.m.height), " line-height:", buttonSizes.m.height, ";;label:m;"),
    // States
    isSelected: /*#__PURE__*/(0, _react.css)("background-color:", euiTheme.colors.backgroundLightText, ";&:is(", selectedSelectors, "):not(", _global_styling.euiDisabledSelector, "){", (0, _global_styling.highContrastModeStyles)(euiThemeContext, {
      preferred: "\n            border: ".concat(euiTheme.border.width.thin, " solid currentColor;\n          "),
      forced: "\n            border: none;\n          "
    }), ";}&:is(", selectedSelectors, ":where(", _global_styling.euiDisabledSelector, ")){", (0, _global_styling.highContrastModeStyles)(euiThemeContext, {
      preferred: "\n            border: ".concat(euiTheme.border.thin, ";\n          ")
    }), ";};label:isSelected;"),
    disabledAndSelected: /*#__PURE__*/(0, _react.css)("color:", euiTheme.colors.textDisabled, ";background-color:", euiTheme.components.buttonGroupBackgroundDisabledSelected, ";border:", highContrastMode ? "".concat(euiTheme.border.width.thin, " solid ").concat(euiTheme.components.buttonGroupBackgroundDisabledSelected) : "".concat(euiTheme.border.width.thin, " solid ").concat(euiTheme.colors.borderBasePlain), ";;label:disabledAndSelected;"),
    // Tooltip anchor wrapper
    tooltipWrapper: _ref,
    // Text wrapper
    text: {
      euiButtonGroupButton__text: /*#__PURE__*/(0, _react.css)((0, _global_styling.euiTextShift)('bold', 'data-text', euiTheme), ";;label:euiButtonGroupButton__text;"),
      euiButtonGroupButton__iconOnly: /*#__PURE__*/(0, _react.css)((0, _accessibility.euiScreenReaderOnly)(), ";;label:euiButtonGroupButton__iconOnly;")
    }
  };
};
var _compressedButtonFocusColors = exports._compressedButtonFocusColors = function _compressedButtonFocusColors(euiThemeContext) {
  var euiTheme = euiThemeContext.euiTheme;
  var colors = [].concat((0, _toConsumableArray2.default)(_button.BUTTON_COLORS), ['disabled']);
  return colors.reduce(function (acc, color) {
    return _objectSpread(_objectSpread({}, acc), {}, (0, _defineProperty2.default)({}, color, /*#__PURE__*/(0, _react.css)("&:focus-visible{", (0, _global_styling.euiOutline)(euiThemeContext, 'outset', euiTheme.focus.color), ";}")));
  }, {});
};