import { EuiThemeShape } from '@elastic/eui-theme-common';
import { colorVisLight } from './variables/colors/_colors_vis_light';
import { colorVisDark } from './variables/colors/_colors_vis_dark';
export { colorVisLight as colorVis, colorVisLight, colorVisDark };
export declare const EUI_THEME_BOREALIS_KEY = "EUI_THEME_BOREALIS";
export declare const euiThemeBorealis: EuiThemeShape;
export declare const EuiThemeBorealis: {
    model: EuiThemeShape;
    root: EuiThemeShape;
    key: string;
};
