export declare const severityColorsLightHighContrast: {
    unknown: string;
    neutral: string;
    success: string;
    warning: string;
    risk: string;
    danger: string;
};
