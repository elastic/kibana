import { _EuiThemeVisColors } from '@elastic/eui-theme-common';
export declare const colorVisLight: _EuiThemeVisColors;
