"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.euiFilterButtonWrapperStyles = exports.euiFilterButtonStyles = exports.euiFilterButtonDisplay = exports.euiFilterButtonChildStyles = void 0;
var _react = require("@emotion/react");
var _global_styling = require("../../global_styling");
var _form = require("../form/form.styles");
function _EMOTION_STRINGIFIED_CSS_ERROR__() { return "You have tried to stringify object returned from `css` function. It isn't supposed to be used directly (e.g. as value of the `className` prop), but rather handed to emotion so it can handle it (e.g. as value of `css` prop)."; } /*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */
var euiFilterButtonDisplay = exports.euiFilterButtonDisplay = function euiFilterButtonDisplay(euiThemeContext) {
  var euiTheme = euiThemeContext.euiTheme;
  return {
    flex: '1 1 auto',
    minInlineSize: (0, _global_styling.mathWithUnits)(euiTheme.size.base, function (x) {
      return x * 2.75;
    })
  };
};
var _ref4 = process.env.NODE_ENV === "production" ? {
  name: "jkp921-noGrow",
  styles: "flex-grow:0;label:noGrow;"
} : {
  name: "jkp921-noGrow",
  styles: "flex-grow:0;label:noGrow;",
  toString: _EMOTION_STRINGIFIED_CSS_ERROR__
};
var euiFilterButtonStyles = exports.euiFilterButtonStyles = function euiFilterButtonStyles(euiThemeContext) {
  var euiTheme = euiThemeContext.euiTheme;
  var buttonSizeMap = (0, _global_styling.euiButtonSizeMap)(euiThemeContext);
  var selectedSelector = '.euiFilterButton-isSelected';
  var withNextSelector = '& + .euiFilterButton__wrapper';
  var containerPadding = euiTheme.size.xs;
  return {
    euiFilterButton: /*#__PURE__*/(0, _react.css)("--euiFilterButtonInsetSize:", buttonSizeMap.m.getInsetHeight(buttonSizeMap.m.height, containerPadding), ";--euiFilterButtonRadius:", buttonSizeMap.m.radiusInset, ";position:relative;block-size:var(--euiFilterButtonInsetSize);", (0, _global_styling.logicalCSS)('width', '100%'), " border:none;border-radius:var(\n        --euiFilterButtonRadius,\n        ", euiTheme.border.radius.small, "\n      );&:not(", selectedSelector, "){&:hover,&:active{.euiFilterButton__notification[class*='subdued']{background-color:", euiTheme.components.filterButtonBadgeBackgroundHover, ";}}}&&:focus-visible{outline-style:auto;outline-offset:0;};label:euiFilterButton;"),
    buttonType: {
      toggle: /*#__PURE__*/(0, _react.css)(euiFilterButtonDisplay(euiThemeContext), " ", (0, _global_styling.highContrastModeStyles)(euiThemeContext, {
        forced: "\n            &:is(".concat(selectedSelector, ") {\n              ").concat((0, _global_styling.preventForcedColors)(euiThemeContext), "\n                color: ").concat(euiTheme.colors.emptyShade, ";\n                background-color: ").concat(euiTheme.colors.fullShade, ";\n            }\n          ")
      }), ";;label:toggle;")
    },
    compressed: /*#__PURE__*/(0, _react.css)("--euiFilterButtonInsetSize:", buttonSizeMap.s.getInsetHeight(buttonSizeMap.s.height, containerPadding), ";--euiFilterButtonRadius:", buttonSizeMap.s.radiusInset, ";;label:compressed;"),
    withNext: /*#__PURE__*/(0, _react.css)(withNextSelector, "{margin-inline-start:-", containerPadding, ";&:where(.euiFilterGroup[data-dividers='true'] &){margin-inline-start:-", (0, _global_styling.mathWithUnits)([containerPadding, euiTheme.border.width.thin], function (x, y) {
      return x + y;
    }), ";}&::before{border:none;}};label:withNext;"),
    noGrow: _ref4,
    hasNotification: /*#__PURE__*/(0, _react.css)((0, _global_styling.logicalCSS)('min-width', (0, _global_styling.mathWithUnits)(euiTheme.size.base, function (x) {
      return x * 6;
    })), ";;label:hasNotification;"),
    hasActiveFilters: /*#__PURE__*/(0, _react.css)("font-weight:", euiTheme.font.weight.medium, ";;label:hasActiveFilters;"),
    isSelected: /*#__PURE__*/(0, _react.css)("&", selectedSelector, "{background-color:", euiTheme.colors.backgroundLightText, ";", (0, _global_styling.highContrastModeStyles)(euiThemeContext, {
      preferred: "\n            border: ".concat(euiTheme.border.thin, ";\n          ")
    }), ";};label:isSelected;")
  };
};
var euiFilterButtonWrapperStyles = exports.euiFilterButtonWrapperStyles = function euiFilterButtonWrapperStyles(euiThemeContext) {
  var euiTheme = euiThemeContext.euiTheme;
  var buttonSizeMap = (0, _global_styling.euiButtonSizeMap)(euiThemeContext);
  var _euiFormVariables = (0, _form.euiFormVariables)(euiThemeContext),
    borderColor = _euiFormVariables.borderColor;
  var border = "".concat(euiTheme.border.width.thin, " solid ").concat(borderColor);
  var containerPadding = euiTheme.size.xs;

  // Pseudo elements create borders without affecting width. We also prefer them
  // over box-shadow for Windows high contrast theme compatibility
  var leftBorder = "\n    &::before {\n      content: '';\n      position: absolute;\n      inset-inline-start: -".concat(euiTheme.border.width.thin, ";\n      block-size: calc(\n        var(--euiFilterButtonSize, ").concat(euiTheme.size.xl, ") - ").concat(euiTheme.size.base, "\n      );\n      inline-size: ").concat(euiTheme.border.width.thin, ";\n      border-inline-start: ").concat(border, ";\n      pointer-events: none;\n    }\n  ");
  // Bottom borders are needed for responsive flex-wrap behavior
  var bottomBorder = "\n    &::after {\n      content: '';\n      position: absolute;\n      inset-block-start: -".concat(euiTheme.border.width.thin, ";\n      inset-inline-start: 0;\n      inline-size: calc(100% + ").concat(euiTheme.border.width.thin, ");\n      ").concat((0, _global_styling.logicalCSS)('border-bottom', border), "\n      pointer-events: none;\n    }\n  ");
  return {
    wrapper: /*#__PURE__*/(0, _react.css)("--euiFilterButtonSize:", buttonSizeMap.m.height, ";", euiFilterButtonDisplay(euiThemeContext), " position:relative;display:flex;align-items:center;block-size:var(--euiFilterButtonSize, ", euiTheme.size.xl, ");padding:", containerPadding, ";&+:where(:has(.euiFilterButton)){margin-inline-start:-", containerPadding, ";};label:wrapper;"),
    compressed: /*#__PURE__*/(0, _react.css)("--euiFilterButtonSize:", buttonSizeMap.s.height, ";;label:compressed;"),
    hasDividers: /*#__PURE__*/(0, _react.css)(leftBorder, " ", bottomBorder, " &+:where(:has(.euiFilterButton)){margin-inline-start:0;};label:hasDividers;")
  };
};
var _ref = process.env.NODE_ENV === "production" ? {
  name: "1w3amc7-disabled",
  styles: "opacity:0.5;label:disabled;"
} : {
  name: "1w3amc7-disabled",
  styles: "opacity:0.5;label:disabled;",
  toString: _EMOTION_STRINGIFIED_CSS_ERROR__
};
var _ref2 = process.env.NODE_ENV === "production" ? {
  name: "zxesfz-euiFilterButton__notification",
  styles: "cursor:inherit;forced-color-adjust:auto;&{transition:none;};label:euiFilterButton__notification;"
} : {
  name: "zxesfz-euiFilterButton__notification",
  styles: "cursor:inherit;forced-color-adjust:auto;&{transition:none;};label:euiFilterButton__notification;",
  toString: _EMOTION_STRINGIFIED_CSS_ERROR__
};
var _ref3 = process.env.NODE_ENV === "production" ? {
  name: "kc7mgj-euiFilterButton__content",
  styles: ".euiThemeProvider{display:inline-flex;};label:euiFilterButton__content;"
} : {
  name: "kc7mgj-euiFilterButton__content",
  styles: ".euiThemeProvider{display:inline-flex;};label:euiFilterButton__content;",
  toString: _EMOTION_STRINGIFIED_CSS_ERROR__
};
var euiFilterButtonChildStyles = exports.euiFilterButtonChildStyles = function euiFilterButtonChildStyles(euiThemeContext) {
  var euiTheme = euiThemeContext.euiTheme;
  return {
    content: {
      euiFilterButton__content: _ref3,
      hasIcon: /*#__PURE__*/(0, _react.css)("&>.euiIcon:last-child{", (0, _global_styling.logicalCSS)('margin-left', 'auto'), ";};label:hasIcon;")
    },
    text: {
      euiFilterButton__text: /*#__PURE__*/(0, _react.css)((0, _global_styling.euiTextShift)('bold', 'data-text', euiTheme), " ", (0, _global_styling.euiTextTruncate)(), " ", (0, _global_styling.logicalCSS)('padding-horizontal', euiTheme.size.xs), ";;label:euiFilterButton__text;"),
      hasNotification: /*#__PURE__*/(0, _react.css)((0, _global_styling.logicalCSS)('min-width', (0, _global_styling.mathWithUnits)(euiTheme.size.base, function (x) {
        return x * 2;
      })), ";;label:hasNotification;")
    },
    notification: {
      euiFilterButton__notification: _ref2,
      disabled: _ref
    }
  };
};