"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.euiButtonGroupStyles = exports.euiButtonGroupButtonsStyles = void 0;
var _react = require("@emotion/react");
var _global_styling = require("../../../global_styling");
var _high_contrast = require("../../../global_styling/functions/high_contrast");
function _EMOTION_STRINGIFIED_CSS_ERROR__() { return "You have tried to stringify object returned from `css` function. It isn't supposed to be used directly (e.g. as value of the `className` prop), but rather handed to emotion so it can handle it (e.g. as value of `css` prop)."; } /*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */
var hasButtonOnlySelector = ':not(:has(.euiButtonIcon))';
var hasButtonIconOnlySelector = ':not(:has(.euiButton, .euiButtonEmpty))';
var buttonItemSelector = '.euiButtonGroup__item, .euiToolTipAnchor, .euiPopover, .euiButton';
var buttonOnlyItemSelector = "*:is(".concat(buttonItemSelector, "):not(:has(.euiButtonIcon))");
var segmentedStyledSelector = "*:is([data-variant='segmented'], [data-variant='selection'])";
var euiButtonGroupStyles = exports.euiButtonGroupStyles = {
  euiButtonGroup: /*#__PURE__*/(0, _react.css)("display:inline-block;", (0, _global_styling.logicalCSS)('max-width', '100%'), " position:relative;&:where(", segmentedStyledSelector, "){&", hasButtonIconOnlySelector, "{display:flex;}};label:euiButtonGroup;"),
  fullWidth: process.env.NODE_ENV === "production" ? {
    name: "jl0hie-fullWidth",
    styles: "display:block;label:fullWidth;"
  } : {
    name: "jl0hie-fullWidth",
    styles: "display:block;label:fullWidth;",
    toString: _EMOTION_STRINGIFIED_CSS_ERROR__
  }
};
var euiButtonGroupButtonsStyles = exports.euiButtonGroupButtonsStyles = function euiButtonGroupButtonsStyles(euiThemeContext) {
  var euiTheme = euiThemeContext.euiTheme;
  var buttonSizeMap = (0, _global_styling.euiButtonSizeMap)(euiThemeContext);
  var containerPadding = euiTheme.size.xs;
  var splitPadding = (0, _global_styling.mathWithUnits)([containerPadding], function (x) {
    return x / 2;
  });
  var buttonGroupVariables = {
    gap: {
      regular: euiTheme.size.xs,
      dividers: (0, _global_styling.mathWithUnits)([euiTheme.size.xs, euiTheme.border.width.thin], function (x, y) {
        return x + y;
      })
    },
    radius: {
      outer: euiTheme.border.radius.medium,
      inner: buttonSizeMap.s.radiusInset
    },
    size: {
      s: buttonSizeMap.s.getInsetHeight(buttonSizeMap.s.height, containerPadding),
      m: buttonSizeMap.m.getInsetHeight(buttonSizeMap.m.height, containerPadding)
    },
    backgroundColor: euiTheme.colors.backgroundBasePlain
  };
  var dividerOffset = (0, _global_styling.mathWithUnits)([buttonGroupVariables.gap.dividers, euiTheme.border.width.thin], function (x, y) {
    return (x + y) / 2;
  });
  var containerBorderStyles = "\n    &::after {\n      content: '';\n      position: absolute;\n      inset: 0;\n      /* keep the border under any related content */\n      z-index: -1;\n      border: ".concat(euiTheme.border.width.thin, " solid\n        ").concat(euiTheme.colors.borderBasePlain, ";\n      border-radius: inherit;\n      pointer-events: none;\n    }\n  ");
  var containerCommonStyles = "\n    position: relative;\n    display: inline-flex;\n    align-items: center;\n    gap: ".concat(buttonGroupVariables.gap.regular, ";\n    max-inline-size: 100%;\n    padding: ").concat(splitPadding, ";\n    overflow: hidden;\n  ");
  var dividerStyles = "\n    gap: ".concat(buttonGroupVariables.gap.dividers, ";\n\n    .euiButtonGroup__item {\n      position: relative;\n\n      /* block border */\n      &::before {\n        content: '';\n        position: absolute;\n        inset-block-start: -").concat(dividerOffset, ";\n        inset-inline-start: -").concat((0, _global_styling.mathWithUnits)(containerPadding, function (x) {
    return x / 2;
  }), ";\n        inline-size: calc(\n          100% + ").concat((0, _global_styling.mathWithUnits)(containerPadding, function (x) {
    return x * 2;
  }), "\n        );\n        block-size: ").concat(euiTheme.border.width.thin, ";\n        border-block-start: ").concat(euiTheme.border.width.thin, " solid\n          ").concat(euiTheme.colors.borderBasePlain, ";\n        pointer-events: none;\n      }\n\n      /* inline border */\n      &::after {\n        content: '';\n        position: absolute;\n        inset-inline-start: -").concat(dividerOffset, ";\n        block-size: calc(\n          var(--euiButtonGroupButtonInsetSize) - ").concat(euiTheme.size.s, "\n        );\n        inline-size: ").concat(euiTheme.border.width.thin, ";\n        border-inline-start: ").concat(euiTheme.border.width.thin, " solid\n          ").concat(euiTheme.colors.borderBasePlain, ";\n        pointer-events: none;\n      }\n    }\n\n    &:where([data-layout='horizontal'] &) {\n      &:where(:is(").concat(hasButtonIconOnlySelector, ") &) {\n        .euiButtonGroup__item::before {\n          inset-inline-start: 0;\n          inline-size: 100%;\n        }\n      }\n    }\n\n    &:where([data-layout='vertical'] &) {\n      &:where(:is(").concat(hasButtonIconOnlySelector, ") &) {\n        .euiButtonGroup__item::before {\n          inset-inline-start: auto;\n          inline-size: calc(\n            var(--euiButtonGroupButtonInsetSize) - ").concat(euiTheme.size.s, "\n          );\n        }\n      }\n    }\n  ");

  // Shared inset styles for both segmented and selection variants.
  var segmentedChildrenStyles = "\n    /* Buttons are used inset and shouldn't have their own borders */\n    .euiButton,\n    .euiButtonIcon {\n      border: none;\n      pointer-events: auto; /* Ensure buttons are still clickable in jsdom */\n\n      &::before {\n        border-radius: inherit;\n      }\n\n      &:focus-visible {\n        outline-offset: 0;\n      }\n    }\n\n    /* Adjust children for inset behavior */\n    ".concat(buttonItemSelector, ",\n    .euiButtonIcon {\n      display: inline-flex;\n      align-items: center;\n      block-size: var(--euiButtonGroupButtonInsetSize);\n      border-radius: ").concat(buttonGroupVariables.radius.inner, ";\n    }\n\n    .euiButtonIcon {\n      inline-size: var(--euiButtonGroupButtonInsetSize);\n    }\n\n    /* Only non-icon buttons auto-grow/shrink */\n    .euiButton,\n    ").concat(buttonOnlyItemSelector, " {\n      flex: 1;\n      min-inline-size: auto;\n    }\n  ");
  return {
    // Base
    euiButtonGroup__container: /*#__PURE__*/(0, _react.css)("&:where(", segmentedStyledSelector, " &){position:relative;display:inline-flex;align-items:center;max-inline-size:100%;z-index:", euiTheme.levels.content, ";padding:", splitPadding, ";border-radius:", buttonGroupVariables.radius.outer, ";background-color:", euiTheme.colors.backgroundBasePlain, ";", containerBorderStyles, ";&:where([data-size='s'] &){--euiButtonGroupButtonInsetSize:", buttonGroupVariables.size.s, ";min-block-size:", buttonSizeMap.s.height, ";}&:where([data-size='m'] &){--euiButtonGroupButtonInsetSize:", buttonGroupVariables.size.m, ";min-block-size:", buttonSizeMap.m.height, ";}}&:where([data-variant='selection'][data-display='inverse'] &){background-color:", euiTheme.colors.backgroundBaseSubdued, ";};label:euiButtonGroup__container;"),
    euiButtonGroup__buttons: /*#__PURE__*/(0, _react.css)((0, _global_styling.logicalCSS)('max-width', '100%'), " display:flex;align-items:center;z-index:", euiTheme.levels.content, ";&:where(.euiButtonGroup:not([data-variant]) &){", containerCommonStyles, " padding:", containerPadding, ";border-radius:", buttonGroupVariables.radius.outer, ";background-color:", euiTheme.colors.backgroundBasePlain, ";", containerBorderStyles, ";}&:where([data-variant='default'] &){flex-wrap:wrap;}&:where(", segmentedStyledSelector, " &){flex-wrap:wrap;", containerCommonStyles, " ", segmentedChildrenStyles, " *:where(.euiButton, .euiButtonIcon){&:where(:is(", _global_styling.euiDisabledSelector, "):not([aria-pressed='true'])){background-color:transparent;}}&:where([data-dividers='true'] &){", dividerStyles, ";}&:where([data-layout='vertical'] &){flex-direction:column;.euiButtonGroup__item{justify-content:center;}}}&:where([data-variant='segmented'] &){*:where(.euiButton, .euiButtonIcon):is(", _global_styling.euiDisabledSelector, "){background-color:transparent;}}&:where([data-variant='selection'] &){*:where(.euiButton, .euiButtonIcon){&:is(", _global_styling.euiDisabledSelector, "){", (0, _high_contrast.highContrastModeStyles)(euiThemeContext, {
      forced: "\n              opacity: 0.5;\n            "
    }), ";}&:is([aria-pressed='true']){", (0, _high_contrast.highContrastModeStyles)(euiThemeContext, {
      forced: "\n              --highContrastHoverIndicatorColor: ".concat(euiTheme.colors.textInverse, ";\n              ").concat((0, _high_contrast.preventForcedColors)(euiThemeContext), "\n              background-color: ").concat(euiTheme.colors.fullShade, ";\n              color: ").concat(euiTheme.colors.emptyShade, ";\n            ")
    }), ";}&:is([aria-pressed='false']){background-color:transparent;}}}&:where([data-variant='selection'][data-display='regular'] &){*:where(.euiButton, .euiButtonIcon):is([aria-pressed='true']){&:not(:is(", _global_styling.euiDisabledSelector, ")){background-color:", euiTheme.colors.backgroundLightText, ";", (0, _high_contrast.highContrastModeStyles)(euiThemeContext, {
      none: "\n                background-color: ".concat(euiTheme.colors.backgroundLightText, ";\n              "),
      preferred: "\n                border: ".concat(euiTheme.border.thin, ";\n              "),
      forced: "\n                background-color: ".concat(euiTheme.colors.fullShade, ";\n                border: none;\n              ")
    }), ";}}}&:where([data-variant='selection'][data-display='inverse'] &){*:where(.euiButton, .euiButtonIcon):is([aria-pressed='true']){", (0, _global_styling.euiShadowXSmall)(euiThemeContext), " ", (0, _high_contrast.highContrastModeStyles)(euiThemeContext, {
      forced: "\n              border: none;\n            "
    }), ";}*:where(.euiButton, .euiButtonIcon):is(", _global_styling.euiDisabledSelector, "){background-color:transparent;}};label:euiButtonGroup__buttons;"),
    noWrap: /*#__PURE__*/(0, _react.css)("&:where(", segmentedStyledSelector, " &){flex-wrap:nowrap;", buttonOnlyItemSelector, "{flex:0 1 auto;min-inline-size:0;.euiButton .eui-textTruncate{min-inline-size:0;}}&", hasButtonIconOnlySelector, "{overflow-inline:auto;}};label:noWrap;"),
    fullWidth: /*#__PURE__*/(0, _react.css)((0, _global_styling.logicalCSS)('width', '100%'), " .euiButtonGroupButton,.euiButtonGroup__tooltipWrapper{flex:1;", (0, _global_styling.logicalCSS)('width', '100%'), ";}&:where([data-variant='default'] &){.euiButton{flex-grow:1;inline-size:auto;}.euiButtonEmpty{flex-shrink:0;}}&:where(", segmentedStyledSelector, " &){&", hasButtonIconOnlySelector, "{inline-size:auto;}&", hasButtonOnlySelector, "{.euiButtonGroup__buttons{inline-size:100%;}", buttonOnlyItemSelector, "{flex-grow:1;}}};label:fullWidth;"),
    // Options API sizes
    size: {
      m: /*#__PURE__*/(0, _react.css)((0, _global_styling.logicalCSS)('height', buttonSizeMap.m.height), " --euiButtonGroupButtonInsetSize:", buttonGroupVariables.size.m, ";background-color:", buttonGroupVariables.backgroundColor, ";border-radius:", buttonGroupVariables.radius.outer, ";", _highContrastStyles(euiThemeContext), ";;label:m;"),
      s: /*#__PURE__*/(0, _react.css)((0, _global_styling.logicalCSS)('height', buttonSizeMap.s.height), " --euiButtonGroupButtonInsetSize:", buttonGroupVariables.size.s, ";background-color:", buttonGroupVariables.backgroundColor, ";border-radius:", buttonGroupVariables.radius.outer, ";", _highContrastStyles(euiThemeContext), ";;label:s;")
    },
    gutterSize: {
      xs: /*#__PURE__*/(0, _react.css)("gap:", euiTheme.size.xs, ";;label:xs;"),
      s: /*#__PURE__*/(0, _react.css)("gap:", euiTheme.size.s, ";;label:s;"),
      m: /*#__PURE__*/(0, _react.css)("gap:", euiTheme.size.base, ";;label:m;"),
      l: /*#__PURE__*/(0, _react.css)("gap:", euiTheme.size.l, ";;label:l;"),
      xl: /*#__PURE__*/(0, _react.css)("gap:", euiTheme.size.xl, ";;label:xl;")
    }
  };
};
var _highContrastStyles = function _highContrastStyles(euiThemeContext) {
  var euiTheme = euiThemeContext.euiTheme;
  return (0, _high_contrast.highContrastModeStyles)(euiThemeContext, {
    preferred: "\n      .euiButtonGroupButton {\n        border: none;\n      }\n    ",
    forced: "\n      .euiButtonGroupButton-isSelected {\n        ".concat((0, _high_contrast.preventForcedColors)(euiThemeContext), "\n        color: ").concat(euiTheme.colors.emptyShade, ";\n        background-color: ").concat(euiTheme.colors.fullShade, ";\n\n        &:is(:hover, :focus):not(:is(").concat(_global_styling.euiDisabledSelector, ")) {\n          &::before {\n            border-color: ").concat(euiTheme.colors.textInverse, ";\n          }\n        }\n      }\n\n      .euiButtonGroupButton:is(").concat(_global_styling.euiDisabledSelector, ") {\n        opacity: 0.5;\n      }\n    ")
  });
};