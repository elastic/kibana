"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.useEuiButtonCommonProps = useEuiButtonCommonProps;
var _react = require("react");
var _button_context = require("./button_context");
var _button_display = require("./button_display/_button_display");
/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */

/**
 * Resolves inherited button props from EuiButtonContext,
 * popover boundary isolation and isDisabled computation.
 */
function useEuiButtonCommonProps(_ref) {
  var _groupContext$isDisab, _groupContext$getSele, _groupContext$size, _groupContext$color, _groupContext$hasAria, _groupContext$fullWid, _ref2, _groupContext$display, _selectionProps$isSel;
  var size = _ref.size,
    color = _ref.color,
    _isDisabled = _ref.isDisabled,
    hasAriaDisabled = _ref.hasAriaDisabled,
    fullWidth = _ref.fullWidth,
    fill = _ref.fill,
    _display = _ref.display,
    href = _ref.href,
    disabled = _ref.disabled,
    isLoading = _ref.isLoading,
    id = _ref.id,
    _isSelected = _ref.isSelected,
    _onClick = _ref.onClick;
  var groupContext = (0, _react.useContext)(_button_context.EuiButtonContext);
  var isDisabled = (0, _button_display.isButtonDisabled)({
    href: href,
    isDisabled: ((_groupContext$isDisab = groupContext.isDisabled) !== null && _groupContext$isDisab !== void 0 ? _groupContext$isDisab : _isDisabled) || disabled,
    isLoading: isLoading
  });
  var selectionProps = id != null ? (_groupContext$getSele = groupContext.getSelectionProps) === null || _groupContext$getSele === void 0 ? void 0 : _groupContext$getSele.call(groupContext, id, isDisabled) : undefined;
  var onClick = selectionProps ? function (event) {
    selectionProps.onSelect();
    _onClick === null || _onClick === void 0 || _onClick(event);
  } : _onClick;
  return {
    size: (_groupContext$size = groupContext.size) !== null && _groupContext$size !== void 0 ? _groupContext$size : size,
    color: (_groupContext$color = groupContext.color) !== null && _groupContext$color !== void 0 ? _groupContext$color : color,
    isDisabled: isDisabled,
    hasAriaDisabled: (_groupContext$hasAria = groupContext.hasAriaDisabled) !== null && _groupContext$hasAria !== void 0 ? _groupContext$hasAria : hasAriaDisabled,
    fullWidth: (_groupContext$fullWid = groupContext.fullWidth) !== null && _groupContext$fullWid !== void 0 ? _groupContext$fullWid : fullWidth,
    display: (_ref2 = (_groupContext$display = groupContext.display) !== null && _groupContext$display !== void 0 ? _groupContext$display : selectionProps === null || selectionProps === void 0 ? void 0 : selectionProps.display) !== null && _ref2 !== void 0 ? _ref2 : _display,
    fill: (selectionProps === null || selectionProps === void 0 ? void 0 : selectionProps.fill) !== undefined ? selectionProps.fill : groupContext.fill !== undefined ? groupContext.fill : fill,
    isSelected: (_selectionProps$isSel = selectionProps === null || selectionProps === void 0 ? void 0 : selectionProps.isSelected) !== null && _selectionProps$isSel !== void 0 ? _selectionProps$isSel : _isSelected,
    onClick: onClick
  };
}