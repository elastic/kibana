"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
var _typeof = require("@babel/runtime/helpers/typeof");
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.EuiFilterGroup = void 0;
var _extends2 = _interopRequireDefault(require("@babel/runtime/helpers/extends"));
var _objectWithoutProperties2 = _interopRequireDefault(require("@babel/runtime/helpers/objectWithoutProperties"));
var _react = _interopRequireWildcard(require("react"));
var _propTypes = _interopRequireDefault(require("prop-types"));
var _classnames = _interopRequireDefault(require("classnames"));
var _services = require("../../services");
var _filter_group = require("./filter_group.styles");
var _filter_group_context = require("./filter_group_context");
var _react2 = require("@emotion/react");
var _excluded = ["children", "className", "fullWidth", "compressed", "display", "showDividers"];
/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */
function _getRequireWildcardCache(e) { if ("function" != typeof WeakMap) return null; var r = new WeakMap(), t = new WeakMap(); return (_getRequireWildcardCache = function _getRequireWildcardCache(e) { return e ? t : r; })(e); }
function _interopRequireWildcard(e, r) { if (!r && e && e.__esModule) return e; if (null === e || "object" != _typeof(e) && "function" != typeof e) return { default: e }; var t = _getRequireWildcardCache(r); if (t && t.has(e)) return t.get(e); var n = { __proto__: null }, a = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var u in e) if ("default" !== u && {}.hasOwnProperty.call(e, u)) { var i = a ? Object.getOwnPropertyDescriptor(e, u) : null; i && (i.get || i.set) ? Object.defineProperty(n, u, i) : n[u] = e[u]; } return n.default = e, t && t.set(e, n), n; }
/**
 * @see {@link https://eui.elastic.co/docs/components/navigation/buttons/filter-group/|EuiFilterGroup documentation}
 */
var EuiFilterGroup = exports.EuiFilterGroup = function EuiFilterGroup(_ref) {
  var children = _ref.children,
    className = _ref.className,
    _ref$fullWidth = _ref.fullWidth,
    fullWidth = _ref$fullWidth === void 0 ? false : _ref$fullWidth,
    compressed = _ref.compressed,
    _ref$display = _ref.display,
    display = _ref$display === void 0 ? 'regular' : _ref$display,
    _ref$showDividers = _ref.showDividers,
    showDividers = _ref$showDividers === void 0 ? true : _ref$showDividers,
    rest = (0, _objectWithoutProperties2.default)(_ref, _excluded);
  var styles = (0, _services.useEuiMemoizedStyles)(_filter_group.euiFilterGroupStyles);
  var cssStyles = [styles.euiFilterGroup, fullWidth && styles.fullWidth, compressed ? styles.compressed : styles.uncompressed];
  var classes = (0, _classnames.default)('euiFilterGroup', className);
  var contextValue = (0, _react.useMemo)(function () {
    return {
      compressed: compressed,
      display: display,
      showDividers: showDividers
    };
  }, [compressed, display, showDividers]);
  return (0, _react2.jsx)(_filter_group_context.EuiFilterGroupContext.Provider, {
    value: contextValue
  }, (0, _react2.jsx)("div", (0, _extends2.default)({
    className: classes,
    css: cssStyles
  }, rest, {
    "data-display": display,
    "data-dividers": showDividers || undefined
  }), children));
};
EuiFilterGroup.propTypes = {
  className: _propTypes.default.string,
  "aria-label": _propTypes.default.string,
  "data-test-subj": _propTypes.default.string,
  css: _propTypes.default.any,
  children: _propTypes.default.node,
  /**
       * Expand the whole bar to fill its parent's width
       */
  fullWidth: _propTypes.default.bool,
  /**
       *  When `true`, creates a shorter height filter group matching that of `compressed` form controls
       */
  compressed: _propTypes.default.bool,
  /**
       * Visual display variant:
       * - `'regular'`: subdued toggle state
       * - `'highlighted'`: highlighted toggle state
       * @default 'regular'
       */
  display: _propTypes.default.oneOf(["regular", "highlighted"]),
  /**
       * Shows dividers between buttons.
       * @default true
       */
  showDividers: _propTypes.default.bool
};