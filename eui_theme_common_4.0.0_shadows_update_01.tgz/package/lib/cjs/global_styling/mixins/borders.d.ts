import { UseEuiTheme } from '../../services/theme/types';
export declare const getBorderSide: (side: BorderSides) => string;
export declare type BorderSides = 'left' | 'right' | 'top' | 'bottom' | 'horizontal' | 'vertical' | 'all';
export declare const euiBorderStyles: (euiThemeContext: UseEuiTheme, options: {
    side?: BorderSides;
    borderColor?: string;
    borderWidth?: string;
    borderStyle?: string;
}) => string;
