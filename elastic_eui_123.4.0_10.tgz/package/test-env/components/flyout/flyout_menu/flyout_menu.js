"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.EuiFlyoutMenu = void 0;
var _extends2 = _interopRequireDefault(require("@babel/runtime/helpers/extends"));
var _toConsumableArray2 = _interopRequireDefault(require("@babel/runtime/helpers/toConsumableArray"));
var _objectWithoutProperties2 = _interopRequireDefault(require("@babel/runtime/helpers/objectWithoutProperties"));
var _classnames = _interopRequireDefault(require("classnames"));
var _propTypes = _interopRequireDefault(require("prop-types"));
var _react = _interopRequireWildcard(require("react"));
var _services = require("../../../services");
var _flex = require("../../flex");
var _i18n = require("../../i18n");
var _title = require("../../title");
var _tool_tip = require("../../tool_tip");
var _flyout_close_button = require("../_flyout_close_button");
var _const = require("../const");
var _flyout_menu_context = require("../flyout_menu_context");
var _flyout_menu = require("./flyout_menu.styles");
var _back_button = require("./back_button");
var _close_spacer = require("./close_spacer");
var _history_popover = require("./history_popover");
var _action_button = require("./action_button");
var _divider = require("./divider");
var _pagination = require("./pagination");
var _react2 = require("@emotion/react");
var _excluded = ["className", "title", "titleId", "hideTitle", "hideCloseButton", "historyItems", "showBackButton", "backButtonProps", "leadingActions", "trailingActions", "customActions", "iconType", "pagination", "showMaximizeButton", "onMaximizeChange", "isMaximized", "canMaximize", "onToggleMaximize"];
/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */
var cache;
function _interopRequireWildcard(e, t) { if (!t && e && e.__esModule) return e; var r, c, a = Object.defineProperty, n = { __proto__: null, default: e }; if (Object(e) !== e) return n; if (cache || "function" != typeof WeakMap || (cache = new WeakMap()), cache) { if (cache.has(e)) return cache.get(e); cache.set(e, n); } for (c in e) "default" !== c && {}.hasOwnProperty.call(e, c) && ((r = a && Object.getOwnPropertyDescriptor(e, c)) && (r.get || r.set) ? a(n, c, r) : n[c] = e[c]); return n; }
/**
 * The component for the top menu bar inside a flyout. Since this is a private
 * component, rendering is controlled using the `flyoutMenuProps` prop on
 * `EuiFlyout`. In managed session flyouts, the Flyout Manager controls a back
 * button and history popover for navigating to different flyout sessions
 * within the managed context.
 *
 * @private
 */
var EuiFlyoutMenu = exports.EuiFlyoutMenu = function EuiFlyoutMenu(_ref) {
  var _historyItems$0$title, _historyItems$, _pagination$currentIn, _pagination$total;
  var className = _ref.className,
    title = _ref.title,
    titleId = _ref.titleId,
    _ref$hideTitle = _ref.hideTitle,
    hideTitle = _ref$hideTitle === void 0 ? true : _ref$hideTitle,
    hideCloseButton = _ref.hideCloseButton,
    _ref$historyItems = _ref.historyItems,
    historyItems = _ref$historyItems === void 0 ? [] : _ref$historyItems,
    showBackButton = _ref.showBackButton,
    backButtonProps = _ref.backButtonProps,
    _ref$leadingActions = _ref.leadingActions,
    leadingActions = _ref$leadingActions === void 0 ? [] : _ref$leadingActions,
    trailingActions = _ref.trailingActions,
    customActions = _ref.customActions,
    _iconType = _ref.iconType,
    pagination = _ref.pagination,
    showMaximizeButton = _ref.showMaximizeButton,
    _onMaximizeChange = _ref.onMaximizeChange,
    isMaximized = _ref.isMaximized,
    canMaximize = _ref.canMaximize,
    onToggleMaximize = _ref.onToggleMaximize,
    rest = (0, _objectWithoutProperties2.default)(_ref, _excluded);
  var _useContext = (0, _react.useContext)(_flyout_menu_context.EuiFlyoutMenuContext),
    onClose = _useContext.onClose;
  var styles = (0, _services.useEuiMemoizedStyles)(_flyout_menu.euiFlyoutMenuStyles);
  var classes = (0, _classnames.default)('euiFlyoutMenu', className);
  var showPaginationControls = pagination != null && pagination.total >= 1;
  var hasBackButton = !showPaginationControls && !!showBackButton;
  var hasHistory = !showPaginationControls && historyItems.length >= _const.MIN_HISTORY_ITEMS;
  var maximizeLabel = (0, _i18n.useEuiI18n)('euiFlyoutMenu.maximize', 'Maximize');
  var restoreLabel = (0, _i18n.useEuiI18n)('euiFlyoutMenu.restore', 'Restore');
  var maximizeAction = showMaximizeButton && canMaximize ? {
    iconType: isMaximized ? 'minimize' : 'maximize',
    'aria-label': isMaximized ? restoreLabel : maximizeLabel,
    toolTipContent: isMaximized ? restoreLabel : maximizeLabel,
    onClick: function onClick() {
      return onToggleMaximize === null || onToggleMaximize === void 0 ? void 0 : onToggleMaximize();
    },
    'data-test-subj': 'euiFlyoutMenuMaximizeButton'
  } : undefined;

  // `trailingActions` takes precedence over the deprecated `customActions` alias
  var consumerTrailingActions = trailingActions !== undefined ? trailingActions : customActions !== null && customActions !== void 0 ? customActions : [];
  var effectiveTrailingActions = maximizeAction ? [].concat((0, _toConsumableArray2.default)(consumerTrailingActions), [maximizeAction]) : consumerTrailingActions;
  var hasBuiltInLeadingContent = showPaginationControls || hasBackButton || hasHistory;
  var showBackHistoryDivider = hasBackButton && hasHistory;
  var showLeadingBoundaryDivider = hasBuiltInLeadingContent && leadingActions.length > 0;
  var showTrailingCloseDivider = effectiveTrailingActions.length > 0 && !hideCloseButton;

  // Sub-components are presentational, so all `euiFlyoutMenu.*` tokens are
  // resolved here, in the file that owns the namespace
  var backButtonLabel = (0, _i18n.useEuiI18n)('euiFlyoutMenu.back', 'Back');
  // `historyItems` is ordered most-recent-first, so index 0 is the entry the
  // back button navigates to
  var previousPageTitle = (_historyItems$0$title = (_historyItems$ = historyItems[0]) === null || _historyItems$ === void 0 ? void 0 : _historyItems$.title) !== null && _historyItems$0$title !== void 0 ? _historyItems$0$title : '';
  var backTooltipLabel = (0, _i18n.useEuiI18n)('euiFlyoutMenu.back.tooltip', 'Back to {previousPage}', {
    previousPage: previousPageTitle
  });
  var historyLabel = (0, _i18n.useEuiI18n)('euiFlyoutMenu.history', 'History');
  var recentlyVisitedLabel = (0, _i18n.useEuiI18n)('euiFlyoutMenu.history.tooltip', 'Recently visited');
  var paginationLabels = {
    first: (0, _i18n.useEuiI18n)('euiFlyoutMenu.pagination.first', 'First'),
    previous: (0, _i18n.useEuiI18n)('euiFlyoutMenu.pagination.previous', 'Previous'),
    next: (0, _i18n.useEuiI18n)('euiFlyoutMenu.pagination.next', 'Next'),
    last: (0, _i18n.useEuiI18n)('euiFlyoutMenu.pagination.last', 'Last'),
    counter: (0, _i18n.useEuiI18n)('euiFlyoutMenu.pagination.counter', '{position} of {total}', {
      position: ((_pagination$currentIn = pagination === null || pagination === void 0 ? void 0 : pagination.currentIndex) !== null && _pagination$currentIn !== void 0 ? _pagination$currentIn : 0) + 1,
      total: (_pagination$total = pagination === null || pagination === void 0 ? void 0 : pagination.total) !== null && _pagination$total !== void 0 ? _pagination$total : 0
    })
  };
  var titleNode;
  if (title) {
    titleNode = (0, _react2.jsx)(_title.EuiTitle, {
      size: "xxs",
      id: titleId
    }, (0, _react2.jsx)("h3", {
      css: hideTitle && styles.euiFlyoutMenu__hiddenTitle
    }, title));
  }
  var handleClose = function handleClose(event) {
    onClose === null || onClose === void 0 || onClose(event, {
      reason: 'close-button'
    });
  };
  return (0, _react2.jsx)("div", (0, _extends2.default)({
    className: classes,
    css: styles.euiFlyoutMenu__container,
    "data-test-subj": "euiFlyoutMenu"
  }, rest), (0, _react2.jsx)(_flex.EuiFlexGroup, {
    alignItems: "center",
    justifyContent: "spaceBetween",
    gutterSize: "none",
    responsive: false,
    css: styles.euiFlyoutMenu__controls
  }, showPaginationControls ? (0, _react2.jsx)(_pagination.PaginationControls, {
    pagination: pagination,
    labels: paginationLabels
  }) : (0, _react2.jsx)(_react.default.Fragment, null, hasBackButton && (0, _react2.jsx)(_flex.EuiFlexItem, {
    grow: false
  }, previousPageTitle ? (0, _react2.jsx)(_tool_tip.EuiToolTip, {
    content: backTooltipLabel
  }, (0, _react2.jsx)(_back_button.BackButton, (0, _extends2.default)({
    label: backButtonLabel
  }, backButtonProps))) : (0, _react2.jsx)(_back_button.BackButton, (0, _extends2.default)({
    label: backButtonLabel
  }, backButtonProps))), showBackHistoryDivider && (0, _react2.jsx)(_divider.MenuDivider, null), hasHistory && (0, _react2.jsx)(_flex.EuiFlexItem, {
    grow: false
  }, (0, _react2.jsx)(_history_popover.HistoryPopover, {
    items: historyItems,
    historyLabel: historyLabel,
    recentlyVisitedLabel: recentlyVisitedLabel
  }))), showLeadingBoundaryDivider && (0, _react2.jsx)(_divider.MenuDivider, null), leadingActions.length > 0 && (0, _react2.jsx)(_flex.EuiFlexItem, {
    grow: false,
    css: styles.euiFlyoutMenu__actions
  }, (0, _react2.jsx)(_flex.EuiFlexGroup, {
    gutterSize: "s",
    alignItems: "center",
    responsive: false
  }, leadingActions.map(function (action, actionIndex) {
    return (0, _react2.jsx)(_flex.EuiFlexItem, {
      key: "leading-action-".concat(actionIndex),
      grow: false
    }, (0, _react2.jsx)(_action_button.MenuActionButton, {
      action: action
    }));
  }))), titleNode && (0, _react2.jsx)(_flex.EuiFlexItem, {
    grow: false
  }, titleNode), (0, _react2.jsx)(_flex.EuiFlexItem, {
    grow: true
  }), effectiveTrailingActions.length > 0 && (0, _react2.jsx)(_flex.EuiFlexItem, {
    grow: false,
    css: styles.euiFlyoutMenu__actions
  }, (0, _react2.jsx)(_flex.EuiFlexGroup, {
    gutterSize: "s",
    alignItems: "center",
    responsive: false
  }, effectiveTrailingActions.map(function (action, actionIndex) {
    return (0, _react2.jsx)(_flex.EuiFlexItem, {
      key: "trailing-action-".concat(actionIndex),
      grow: false
    }, (0, _react2.jsx)(_action_button.MenuActionButton, {
      action: action
    }));
  }))), !hideCloseButton && (0, _react2.jsx)(_close_spacer.CloseButtonSpacer, {
    showDivider: showTrailingCloseDivider
  })), !hideCloseButton && (0, _react2.jsx)(_flyout_close_button.EuiFlyoutCloseButton, {
    onClose: handleClose,
    side: "right",
    closeButtonPosition: "inside"
  }));
};
EuiFlyoutMenu.propTypes = {
  className: _propTypes.default.string,
  "aria-label": _propTypes.default.string,
  "data-test-subj": _propTypes.default.string,
  css: _propTypes.default.any,
  /**
       * An id to use for the title element. Useful for setting aria-labelledby on the flyout.
       * Example:
       * ```jsx
       * <EuiFlyout
       *   aria-labelledby="myMenuTitleId"
       *   flyoutMenuProps={{ title: 'Menu title', titleId: 'myMenuTitleId' }
       * >
       *  ...
       * </EuiFlyout>
       * ```
       */
  titleId: _propTypes.default.string,
  /**
       * Title for the menu component. In a managed flyout context, the title is used to indicate the flyout session for history navigation.
       */
  title: _propTypes.default.node,
  /**
       * An optional icon to display next to the session title in the history menu
       */
  iconType: _propTypes.default.oneOfType([_propTypes.default.oneOf(["accessibility", "addDataApp", "addToChat", "addToDashboard", "advancedSettingsApp", "agentApp", "aggregate", "alignBottom", "alignBottomLeft", "alignBottomRight", "alignCenterHorizontal", "alignCenterVertical", "alignLeft", "alignRight", "alignTop", "alignTopLeft", "alignTopRight", "analyzeEvent", "annotation", "chartAnomaly", "anomalySwimLane", "apmApp", "chartWaterfall", "appSearchApp", "apps", "chevronSingleDown", "chevronSingleLeft", "chevronSingleRight", "chevronSingleUp", "chevronLimitLeft", "chevronLimitRight", "asterisk", "at", "archive", "article", "axisX", "axisYLeft", "axisYRight", "auditbeatApp", "backgroundTask", "bell", "bellSlash", "beta", "bolt", "boxesVertical", "branch", "briefcase", "broom", "brush", "bug", "bulb", "bullseye", "calendar", "canvasApp", "casesApp", "chartChangePoint", "chartArea", "visArea", "chartAreaStack", "chartBarHorizontal", "chartBarHorizontalStack", "chartBarVertical", "visBarVertical", "chartBarVerticalStack", "chartGauge", "visGauge", "chartHeatmap", "chartLine", "visLine", "chartMix", "chartPie", "visPie", "chartTagCloud", "chartThreshold", "chartWaffle", "check", "checkCircle", "checkCircleFill", "popper", "classificationJob", "clickLeft", "clickRight", "clipboardWarning", "clock", "clockControl", "clockCounter", "clockUp", "cloud", "cloudBolt", "cloudDrizzle", "cloudRain", "cloudStormy", "cloudSun", "cloudSunny", "cluster", "code", "codeApp", "paintBucket", "commandLine", "comment", "editorComment", "compare", "processor", "compute", "consoleApp", "container", "continuityAbove", "continuityWithin", "contrast", "contrastFill", "controls", "copy", "crossProjectSearch", "createAdvancedJob", "createGenericJob", "createGeoJob", "createMultiMetricJob", "createPopulationJob", "createSingleMetricJob", "cross", "crossClusterReplicationApp", "crossCircle", "crosshair", "cursorDefault", "money", "scissors", "dashboardApp", "dashedCircle", "dataVisualizer", "database", "display", "devToolsApp", "discoverApp", "distributeHorizontal", "distributeVertical", "download", "drag", "dragHorizontal", "dragVertical", "document", "documentation", "documents", "dot", "dotInCircle", "chevronDoubleLeft", "chevronDoubleRight", "ellipsis", "textAlignCenter", "textAlignLeft", "textAlignRight", "textBold", "listCheck", "textHeading", "textItalic", "listNumber", "redo", "textStrike", "table", "visTable", "textUnderline", "undo", "listBullet", "list", "mail", "emergencyLight", "empty", "emsApp", "endpoint", "query", "eraser", "error", "errorFill", "esqlVis", "logIn", "logOut", "maximize", "export", "upload", "external", "eye", "eyeSlash", "faceHappy", "faceNeutral", "faceSad", "tableInfo", "filebeatApp", "filter", "filterExclude", "filterIgnore", "filterInclude", "flask", "flag", "fleetApp", "fold", "folder", "folderClosed", "folderClose", "folderCheck", "folderExclamation", "folderOpen", "folderOpened", "frameNext", "framePrevious", "fullScreen", "fullScreenExit", "gear", "gisApp", "globe", "gradient", "graphApp", "grid", "grokApp", "heart", "heartbeatApp", "help", "home", "hourglass", "if", "info", "image", "index", "indexClose", "tableCross", "tableSparkles", "indexEdit", "tablePencil", "indexManagementApp", "mapping", "indexOpen", "tablePlus", "indexPatternApp", "indexRollupApp", "indexRuntime", "tablePlay", "indexSettings", "tableGear", "tableTime", "infinity", "inputOutput", "inspect", "ip", "key", "keyboard", "queryField", "kqlFunction", "queryOperand", "querySelector", "queryValue", "kubernetesNamespace", "kubernetesNode", "kubernetesPod", "cube", "rocket", "layers", "lensApp", "text", "lineBreak", "lineBreakSlash", "lineDash", "lineDot", "lineSolid", "link", "linkSlash", "lock", "lockOpen", "pattern", "logRateAnalysis", "logoAWS", "logoAWSMono", "logoAerospike", "logoApache", "logoAppSearch", "logoAzure", "logoAzureMono", "logoBeats", "logoBusinessAnalytics", "logoCeph", "logoCloud", "logoCloudEnterprise", "logoCode", "logoCodesandbox", "logoCouchbase", "logoDocker", "logoDropwizard", "logoElastic", "logoElasticStack", "logoElasticsearch", "logoEnterpriseSearch", "logoEtcd", "logoGCP", "logoGCPMono", "logoGithub", "logoGmail", "logoGolang", "logoGoogleG", "logoHAproxy", "logoIBM", "logoIBMMono", "logoKafka", "logoKibana", "logoKubernetes", "logoLogging", "logoLogstash", "logoMaps", "logoMemcached", "logoMetrics", "logoMongodb", "logoMySQL", "logoNginx", "logoObservability", "logoOsquery", "logoPhp", "logoPostgres", "logoPrometheus", "logoRabbitmq", "logoRedis", "logoSecurity", "logoSiteSearch", "logoSketch", "logoSlack", "logoUptime", "logoVectorDB", "logoVulnerabilityManagement", "logoWebhook", "logoWindows", "logoWorkplaceSearch", "logsApp", "logstashFilter", "logstashInput", "logstashOutput", "queue", "machineLearningApp", "magnify", "search", "magnifyExclamation", "magnifyMinus", "magnifyPlus", "managementApp", "map", "mapMarker", "waypoint", "megaphone", "memory", "menu", "menuDown", "menuLeft", "menuRight", "menuUp", "merge", "metricbeatApp", "metricsApp", "minimize", "minus", "minusCircle", "minusSquare", "mobile", "monitoringApp", "moon", "move", "namespace", "nested", "vectorTriangle", "notebookApp", "number", "wifiSlash", "wifi", "outlierDetectionJob", "package", "packetbeatApp", "pagesSelect", "documentsCheck", "palette", "paperClip", "partial", "pause", "payment", "pencil", "percent", "pin", "pinFill", "pinFilled", "pipelineApp", "pivot", "play", "plugs", "plus", "plusCircle", "plusSquare", "presentation", "productAgent", "productAlertZero", "productCanvas", "productCloudInfra", "productDashboard", "productDiscover", "productElasticAgent", "productFleet", "productLens", "productML", "productNightshift", "productStreamsClassic", "productStreamsWired", "productTimelion", "productTSVB", "push", "send", "puzzlePiece", "question", "quote", "radar", "readOnly", "recentlyViewedApp", "refresh", "regressionJob", "reporter", "reportingApp", "return", "routeSplit", "ruler", "save", "scale", "savedObjectsApp", "searchProfilerApp", "section", "securityAnalyticsApp", "securityApp", "securitySignalDetected", "server", "sessionViewer", "shard", "share", "shield", "significantEvents", "singleMetricViewer", "snowflake", "sortAscending", "sortDescending", "sortDown", "sortLeft", "sortRight", "sortUp", "sortable", "spaces", "spacesApp", "sparkles", "sqlApp", "star", "starEmpty", "starEmptySpace", "starFill", "starFilled", "starFillSpace", "starMinusEmpty", "starMinusFill", "starPlusEmpty", "starPlusFill", "stats", "stop", "stopFill", "stopSlash", "storage", "string", "sun", "swatchInput", "symlink", "tableDensityHigh", "tableDensityLow", "tableOfContents", "tag", "thermometer", "temperature", "thumbDown", "thumbUp", "timeline", "timelineWithArrow", "timelinePointer", "timelionApp", "refreshTime", "transitionBottomIn", "transitionBottomOut", "transitionLeftIn", "transitionLeftOut", "transitionRightIn", "transitionRightOut", "transitionTopIn", "transitionTopOut", "translate", "trash", "unfold", "upgradeAssistantApp", "uptimeApp", "user", "users", "usersRolesApp", "unarchive", "vectorSquare", "videoPlayer", "visGoal", "chartMetric", "visTimelion", "visVisualBuilder", "visualizeApp", "vulnerabilityManagementApp", "warning", "alert", "warningFill", "watchesApp", "web", "wordWrap", "wordWrapDisabled", "workflowsApp", "workflow", "workplaceSearchApp", "wrench", "tokenAlias", "tokenAnnotation", "tokenArray", "tokenBinary", "tokenBoolean", "tokenClass", "tokenCompletionSuggester", "tokenConstant", "tokenDate", "tokenDimension", "tokenElement", "tokenEnum", "tokenEnumMember", "tokenEvent", "tokenException", "tokenField", "tokenFile", "tokenFlattened", "tokenFunction", "tokenGeo", "tokenHistogram", "tokenInterface", "tokenIP", "tokenJoin", "tokenKey", "tokenKeyword", "tokenMethod", "tokenMetricCounter", "tokenMetricGauge", "tokenModule", "tokenNamespace", "tokenNested", "tokenNull", "tokenNumber", "tokenObject", "tokenOperator", "tokenPackage", "tokenParameter", "tokenPercolator", "tokenProperty", "tokenRange", "tokenRankFeature", "tokenRankFeatures", "tokenRepo", "tokenSearchType", "tokenSemanticText", "tokenShape", "tokenString", "tokenStruct", "tokenSymbol", "tokenTag", "tokenText", "tokenTokenCount", "tokenVariable", "tokenVectorDense", "tokenVectorSparse"]).isRequired, _propTypes.default.string.isRequired, _propTypes.default.elementType.isRequired]),
  /**
       * Hides the title in the `EuiFlyoutMenu`.
       * @default true
       * @deprecated Use `EuiFlyoutHeader` for visible titles instead.
       * `hideTitle` is still honored but may be removed in a future major version.
       */
  hideTitle: _propTypes.default.bool,
  /**
       * Hides the close button in the menu component
       * @default false
       */
  hideCloseButton: _propTypes.default.bool,
  /**
       * Shows a back button in the menu component
       * @default false
       */
  showBackButton: _propTypes.default.bool,
  /**
       * Shows a maximize/restore button in the trailing actions. A maximized
       * flyout fills the width of its container, leaving room for an open child
       * flyout. Child flyouts never show the button.
       * @default false
       */
  showMaximizeButton: _propTypes.default.bool,
  /**
       * Called with the new state each time the flyout is maximized or restored.
       */
  onMaximizeChange: _propTypes.default.func,
  /**
       * Props to pass to the back button, such as `onClick` handler
       */
  backButtonProps: _propTypes.default.any,
  /**
       * List of history items for the history popover, ordered most-recent-first.
       * Index 0 is the page the back button navigates to. Not shown if there is
       * just a single item.
       */
  historyItems: _propTypes.default.arrayOf(_propTypes.default.shape({
    /**
       * Title for the history item
       */
    title: _propTypes.default.string.isRequired,
    /**
       * An optional icon to display next to the session title in the history menu
       */
    iconType: _propTypes.default.oneOfType([_propTypes.default.oneOf(["accessibility", "addDataApp", "addToChat", "addToDashboard", "advancedSettingsApp", "agentApp", "aggregate", "alignBottom", "alignBottomLeft", "alignBottomRight", "alignCenterHorizontal", "alignCenterVertical", "alignLeft", "alignRight", "alignTop", "alignTopLeft", "alignTopRight", "analyzeEvent", "annotation", "chartAnomaly", "anomalySwimLane", "apmApp", "chartWaterfall", "appSearchApp", "apps", "chevronSingleDown", "chevronSingleLeft", "chevronSingleRight", "chevronSingleUp", "chevronLimitLeft", "chevronLimitRight", "asterisk", "at", "archive", "article", "axisX", "axisYLeft", "axisYRight", "auditbeatApp", "backgroundTask", "bell", "bellSlash", "beta", "bolt", "boxesVertical", "branch", "briefcase", "broom", "brush", "bug", "bulb", "bullseye", "calendar", "canvasApp", "casesApp", "chartChangePoint", "chartArea", "visArea", "chartAreaStack", "chartBarHorizontal", "chartBarHorizontalStack", "chartBarVertical", "visBarVertical", "chartBarVerticalStack", "chartGauge", "visGauge", "chartHeatmap", "chartLine", "visLine", "chartMix", "chartPie", "visPie", "chartTagCloud", "chartThreshold", "chartWaffle", "check", "checkCircle", "checkCircleFill", "popper", "classificationJob", "clickLeft", "clickRight", "clipboardWarning", "clock", "clockControl", "clockCounter", "clockUp", "cloud", "cloudBolt", "cloudDrizzle", "cloudRain", "cloudStormy", "cloudSun", "cloudSunny", "cluster", "code", "codeApp", "paintBucket", "commandLine", "comment", "editorComment", "compare", "processor", "compute", "consoleApp", "container", "continuityAbove", "continuityWithin", "contrast", "contrastFill", "controls", "copy", "crossProjectSearch", "createAdvancedJob", "createGenericJob", "createGeoJob", "createMultiMetricJob", "createPopulationJob", "createSingleMetricJob", "cross", "crossClusterReplicationApp", "crossCircle", "crosshair", "cursorDefault", "money", "scissors", "dashboardApp", "dashedCircle", "dataVisualizer", "database", "display", "devToolsApp", "discoverApp", "distributeHorizontal", "distributeVertical", "download", "drag", "dragHorizontal", "dragVertical", "document", "documentation", "documents", "dot", "dotInCircle", "chevronDoubleLeft", "chevronDoubleRight", "ellipsis", "textAlignCenter", "textAlignLeft", "textAlignRight", "textBold", "listCheck", "textHeading", "textItalic", "listNumber", "redo", "textStrike", "table", "visTable", "textUnderline", "undo", "listBullet", "list", "mail", "emergencyLight", "empty", "emsApp", "endpoint", "query", "eraser", "error", "errorFill", "esqlVis", "logIn", "logOut", "maximize", "export", "upload", "external", "eye", "eyeSlash", "faceHappy", "faceNeutral", "faceSad", "tableInfo", "filebeatApp", "filter", "filterExclude", "filterIgnore", "filterInclude", "flask", "flag", "fleetApp", "fold", "folder", "folderClosed", "folderClose", "folderCheck", "folderExclamation", "folderOpen", "folderOpened", "frameNext", "framePrevious", "fullScreen", "fullScreenExit", "gear", "gisApp", "globe", "gradient", "graphApp", "grid", "grokApp", "heart", "heartbeatApp", "help", "home", "hourglass", "if", "info", "image", "index", "indexClose", "tableCross", "tableSparkles", "indexEdit", "tablePencil", "indexManagementApp", "mapping", "indexOpen", "tablePlus", "indexPatternApp", "indexRollupApp", "indexRuntime", "tablePlay", "indexSettings", "tableGear", "tableTime", "infinity", "inputOutput", "inspect", "ip", "key", "keyboard", "queryField", "kqlFunction", "queryOperand", "querySelector", "queryValue", "kubernetesNamespace", "kubernetesNode", "kubernetesPod", "cube", "rocket", "layers", "lensApp", "text", "lineBreak", "lineBreakSlash", "lineDash", "lineDot", "lineSolid", "link", "linkSlash", "lock", "lockOpen", "pattern", "logRateAnalysis", "logoAWS", "logoAWSMono", "logoAerospike", "logoApache", "logoAppSearch", "logoAzure", "logoAzureMono", "logoBeats", "logoBusinessAnalytics", "logoCeph", "logoCloud", "logoCloudEnterprise", "logoCode", "logoCodesandbox", "logoCouchbase", "logoDocker", "logoDropwizard", "logoElastic", "logoElasticStack", "logoElasticsearch", "logoEnterpriseSearch", "logoEtcd", "logoGCP", "logoGCPMono", "logoGithub", "logoGmail", "logoGolang", "logoGoogleG", "logoHAproxy", "logoIBM", "logoIBMMono", "logoKafka", "logoKibana", "logoKubernetes", "logoLogging", "logoLogstash", "logoMaps", "logoMemcached", "logoMetrics", "logoMongodb", "logoMySQL", "logoNginx", "logoObservability", "logoOsquery", "logoPhp", "logoPostgres", "logoPrometheus", "logoRabbitmq", "logoRedis", "logoSecurity", "logoSiteSearch", "logoSketch", "logoSlack", "logoUptime", "logoVectorDB", "logoVulnerabilityManagement", "logoWebhook", "logoWindows", "logoWorkplaceSearch", "logsApp", "logstashFilter", "logstashInput", "logstashOutput", "queue", "machineLearningApp", "magnify", "search", "magnifyExclamation", "magnifyMinus", "magnifyPlus", "managementApp", "map", "mapMarker", "waypoint", "megaphone", "memory", "menu", "menuDown", "menuLeft", "menuRight", "menuUp", "merge", "metricbeatApp", "metricsApp", "minimize", "minus", "minusCircle", "minusSquare", "mobile", "monitoringApp", "moon", "move", "namespace", "nested", "vectorTriangle", "notebookApp", "number", "wifiSlash", "wifi", "outlierDetectionJob", "package", "packetbeatApp", "pagesSelect", "documentsCheck", "palette", "paperClip", "partial", "pause", "payment", "pencil", "percent", "pin", "pinFill", "pinFilled", "pipelineApp", "pivot", "play", "plugs", "plus", "plusCircle", "plusSquare", "presentation", "productAgent", "productAlertZero", "productCanvas", "productCloudInfra", "productDashboard", "productDiscover", "productElasticAgent", "productFleet", "productLens", "productML", "productNightshift", "productStreamsClassic", "productStreamsWired", "productTimelion", "productTSVB", "push", "send", "puzzlePiece", "question", "quote", "radar", "readOnly", "recentlyViewedApp", "refresh", "regressionJob", "reporter", "reportingApp", "return", "routeSplit", "ruler", "save", "scale", "savedObjectsApp", "searchProfilerApp", "section", "securityAnalyticsApp", "securityApp", "securitySignalDetected", "server", "sessionViewer", "shard", "share", "shield", "significantEvents", "singleMetricViewer", "snowflake", "sortAscending", "sortDescending", "sortDown", "sortLeft", "sortRight", "sortUp", "sortable", "spaces", "spacesApp", "sparkles", "sqlApp", "star", "starEmpty", "starEmptySpace", "starFill", "starFilled", "starFillSpace", "starMinusEmpty", "starMinusFill", "starPlusEmpty", "starPlusFill", "stats", "stop", "stopFill", "stopSlash", "storage", "string", "sun", "swatchInput", "symlink", "tableDensityHigh", "tableDensityLow", "tableOfContents", "tag", "thermometer", "temperature", "thumbDown", "thumbUp", "timeline", "timelineWithArrow", "timelinePointer", "timelionApp", "refreshTime", "transitionBottomIn", "transitionBottomOut", "transitionLeftIn", "transitionLeftOut", "transitionRightIn", "transitionRightOut", "transitionTopIn", "transitionTopOut", "translate", "trash", "unfold", "upgradeAssistantApp", "uptimeApp", "user", "users", "usersRolesApp", "unarchive", "vectorSquare", "videoPlayer", "visGoal", "chartMetric", "visTimelion", "visVisualBuilder", "visualizeApp", "vulnerabilityManagementApp", "warning", "alert", "warningFill", "watchesApp", "web", "wordWrap", "wordWrapDisabled", "workflowsApp", "workflow", "workplaceSearchApp", "wrench", "tokenAlias", "tokenAnnotation", "tokenArray", "tokenBinary", "tokenBoolean", "tokenClass", "tokenCompletionSuggester", "tokenConstant", "tokenDate", "tokenDimension", "tokenElement", "tokenEnum", "tokenEnumMember", "tokenEvent", "tokenException", "tokenField", "tokenFile", "tokenFlattened", "tokenFunction", "tokenGeo", "tokenHistogram", "tokenInterface", "tokenIP", "tokenJoin", "tokenKey", "tokenKeyword", "tokenMethod", "tokenMetricCounter", "tokenMetricGauge", "tokenModule", "tokenNamespace", "tokenNested", "tokenNull", "tokenNumber", "tokenObject", "tokenOperator", "tokenPackage", "tokenParameter", "tokenPercolator", "tokenProperty", "tokenRange", "tokenRankFeature", "tokenRankFeatures", "tokenRepo", "tokenSearchType", "tokenSemanticText", "tokenShape", "tokenString", "tokenStruct", "tokenSymbol", "tokenTag", "tokenText", "tokenTokenCount", "tokenVariable", "tokenVectorDense", "tokenVectorSparse"]).isRequired, _propTypes.default.string.isRequired, _propTypes.default.elementType.isRequired]),
    /**
       * onClick handler for the history item
       */
    onClick: _propTypes.default.func.isRequired
  }).isRequired),
  /**
       * List of action items rendered at the start (inline-start) of the menu bar.
       */
  leadingActions: _propTypes.default.arrayOf(_propTypes.default.oneOfType([_propTypes.default.shape({
    /**
       * Aria label for the action button
       */
    "aria-label": _propTypes.default.string.isRequired,
    /**
       * onClick handler for the action button
       */
    onClick: _propTypes.default.func,
    /**
       * Tooltip text shown on hover or focus.
       * When the action is disabled, also set `hasAriaDisabled`. This keeps
       * the button focusable so the tooltip remains reachable.
       */
    toolTipContent: _propTypes.default.node,
    /**
       * Optional props to pass to the underlying {@link EuiToolTip}.
       * Only used when `toolTipContent` is also provided.
       */
    toolTipProps: _propTypes.default.any
  }).isRequired, _propTypes.default.shape({
    /**
       * Aria label for the action button
       */
    "aria-label": _propTypes.default.string.isRequired,
    /**
       * onClick handler for the action button
       */
    onClick: _propTypes.default.func,
    /**
       * Tooltip text shown on hover or focus.
       * When the action is disabled, also set `hasAriaDisabled`. This keeps
       * the button focusable so the tooltip remains reachable.
       */
    toolTipContent: _propTypes.default.node,
    /**
       * Optional props to pass to the underlying {@link EuiToolTip}.
       * Only used when `toolTipContent` is also provided.
       */
    toolTipProps: _propTypes.default.any
  }).isRequired]).isRequired),
  /**
       * List of action items rendered at the end (inline-end) of the menu bar.
       */
  trailingActions: _propTypes.default.arrayOf(_propTypes.default.oneOfType([_propTypes.default.shape({
    /**
       * Aria label for the action button
       */
    "aria-label": _propTypes.default.string.isRequired,
    /**
       * onClick handler for the action button
       */
    onClick: _propTypes.default.func,
    /**
       * Tooltip text shown on hover or focus.
       * When the action is disabled, also set `hasAriaDisabled`. This keeps
       * the button focusable so the tooltip remains reachable.
       */
    toolTipContent: _propTypes.default.node,
    /**
       * Optional props to pass to the underlying {@link EuiToolTip}.
       * Only used when `toolTipContent` is also provided.
       */
    toolTipProps: _propTypes.default.any
  }).isRequired, _propTypes.default.shape({
    /**
       * Aria label for the action button
       */
    "aria-label": _propTypes.default.string.isRequired,
    /**
       * onClick handler for the action button
       */
    onClick: _propTypes.default.func,
    /**
       * Tooltip text shown on hover or focus.
       * When the action is disabled, also set `hasAriaDisabled`. This keeps
       * the button focusable so the tooltip remains reachable.
       */
    toolTipContent: _propTypes.default.node,
    /**
       * Optional props to pass to the underlying {@link EuiToolTip}.
       * Only used when `toolTipContent` is also provided.
       */
    toolTipProps: _propTypes.default.any
  }).isRequired]).isRequired),
  /**
       * List of custom action items for the menu component
       * @deprecated Use `trailingActions` instead. If both are supplied, `trailingActions` takes precedence.
       */
  customActions: _propTypes.default.arrayOf(_propTypes.default.shape({
    iconType: _propTypes.default.string.isRequired,
    onClick: _propTypes.default.func.isRequired,
    "aria-label": _propTypes.default.string.isRequired
  }).isRequired),
  /**
       * Enables Prev/Next navigation controls and a position counter in the menu bar.
       * Pagination replaces back/history navigation in the left menu slot.
       */
  pagination: _propTypes.default.shape({
    /**
       * Zero-based index of the currently displayed item
       */
    currentIndex: _propTypes.default.number.isRequired,
    /**
       * Total number of items
       */
    total: _propTypes.default.number.isRequired,
    /**
       * Called when the user clicks the Previous button
       */
    onPrevious: _propTypes.default.func.isRequired,
    /**
       * Called when the user clicks the Next button
       */
    onNext: _propTypes.default.func.isRequired,
    /**
       * Called when the user clicks the First button, to jump to the beginning.
       */
    onFirst: _propTypes.default.func,
    /**
       * Called when the user clicks the Last button, which jumps to the end.
       */
    onLast: _propTypes.default.func
  }),
  isMaximized: _propTypes.default.bool,
  canMaximize: _propTypes.default.bool,
  onToggleMaximize: _propTypes.default.func
};