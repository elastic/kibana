"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.euiFlyoutBodyStyles = void 0;
var _react = require("@emotion/react");
var _global_styling = require("../../global_styling");
var _high_contrast = require("../../global_styling/functions/high_contrast");
/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */

var euiFlyoutBodyStyles = exports.euiFlyoutBodyStyles = function euiFlyoutBodyStyles(euiThemeContext) {
  var euiTheme = euiThemeContext.euiTheme;
  return {
    euiFlyoutBody: /*#__PURE__*/(0, _react.css)((0, _global_styling.logicalCSSWithFallback)('overflow-y', 'hidden'), " ", (0, _global_styling.logicalCSS)('height', '100%'), ";;label:euiFlyoutBody;"),
    overflow: {
      euiFlyoutBody__overflow: /*#__PURE__*/(0, _react.css)(";label:euiFlyoutBody__overflow;"),
      noBanner: /*#__PURE__*/(0, _react.css)((0, _global_styling.euiYScrollWithShadows)(euiThemeContext), ";;label:noBanner;"),
      hasBanner: /*#__PURE__*/(0, _react.css)((0, _global_styling.euiYScrollWithShadows)(euiThemeContext, {
        side: 'end'
      }), ";;label:hasBanner;")
    },
    euiFlyoutBody__banner: /*#__PURE__*/(0, _react.css)((0, _global_styling.logicalCSSWithFallback)('overflow-x', 'hidden'), " ", (0, _high_contrast.highContrastModeStyles)(euiThemeContext, {
      preferred: (0, _global_styling.logicalCSS)('border-bottom', euiTheme.border.thin)
    }), ";;label:euiFlyoutBody__banner;")
  };
};