"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.euiFlyoutResizeButtonStyles = void 0;
var _react = require("@emotion/react");
var _global_styling = require("../../global_styling");
function _EMOTION_STRINGIFIED_CSS_ERROR__() { return "You have tried to stringify object returned from `css` function. It isn't supposed to be used directly (e.g. as value of the `className` prop), but rather handed to emotion so it can handle it (e.g. as value of `css` prop)."; } /*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */
var _ref = process.env.NODE_ENV === "production" ? {
  name: "1vfos8p-right",
  styles: "justify-content:flex-start;label:right;"
} : {
  name: "1vfos8p-right",
  styles: "justify-content:flex-start;label:right;",
  toString: _EMOTION_STRINGIFIED_CSS_ERROR__
};
var _ref2 = process.env.NODE_ENV === "production" ? {
  name: "1ydooaf-left",
  styles: "justify-content:flex-end;label:left;"
} : {
  name: "1ydooaf-left",
  styles: "justify-content:flex-end;label:left;",
  toString: _EMOTION_STRINGIFIED_CSS_ERROR__
};
var _ref3 = process.env.NODE_ENV === "production" ? {
  name: "10l1ho9-root",
  styles: "margin-inline:0;label:root;"
} : {
  name: "10l1ho9-root",
  styles: "margin-inline:0;label:root;",
  toString: _EMOTION_STRINGIFIED_CSS_ERROR__
};
var _ref4 = process.env.NODE_ENV === "production" ? {
  name: "1yicr0l-root",
  styles: "position:absolute;label:root;"
} : {
  name: "1yicr0l-root",
  styles: "position:absolute;label:root;",
  toString: _EMOTION_STRINGIFIED_CSS_ERROR__
};
var euiFlyoutResizeButtonStyles = exports.euiFlyoutResizeButtonStyles = function euiFlyoutResizeButtonStyles(_ref5) {
  var euiTheme = _ref5.euiTheme;
  return {
    root: _ref4,
    overlay: {
      left: /*#__PURE__*/(0, _react.css)((0, _global_styling.logicalCSS)('right', 0), ";;label:left;"),
      right: /*#__PURE__*/(0, _react.css)((0, _global_styling.logicalCSS)('left', 0), ";;label:right;")
    },
    push: {
      left: /*#__PURE__*/(0, _react.css)((0, _global_styling.logicalCSS)('right', "-".concat(euiTheme.border.width.thick)), ";;label:left;"),
      right: /*#__PURE__*/(0, _react.css)((0, _global_styling.logicalCSS)('left', "-".concat(euiTheme.border.width.thick)), ";;label:right;")
    },
    noOverlay: {
      root: _ref3,
      left: _ref2,
      right: _ref
    }
  };
};