"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "KibanaCollapsibleNavSolution", {
  enumerable: true,
  get: function get() {
    return _collapsible_nav_kibana_solution.KibanaCollapsibleNavSolution;
  }
});
var _collapsible_nav_kibana_solution = require("./collapsible_nav_kibana_solution");