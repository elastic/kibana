import type { UseEuiTheme } from '../../services/theme/types';
import { _EuiThemeShadowSize } from '../variables/shadow';
export interface EuiShadowOptions {
    color?: string;
    /**
     * Note: not supported by all shadow utilities.
     */
    property?: 'box-shadow' | 'filter';
    borderAllInHighContrastMode?: boolean;
}
/**
 * euiSlightShadow
 */
export declare const euiShadowXSmall: ({ euiTheme, colorMode, highContrastMode }: UseEuiTheme, options?: EuiShadowOptions | undefined) => string;
/**
 * bottomShadowSmall
 */
export declare const euiShadowSmall: ({ euiTheme, colorMode, highContrastMode }: UseEuiTheme, options?: EuiShadowOptions | undefined) => string;
/**
 * bottomShadowMedium
 */
export declare const euiShadowMedium: ({ euiTheme, colorMode, highContrastMode }: UseEuiTheme, options?: EuiShadowOptions | undefined) => string;
/**
 * bottomShadow
 */
export declare const euiShadowLarge: ({ euiTheme, colorMode, highContrastMode }: UseEuiTheme, options?: EuiShadowOptions | undefined) => string;
/**
 * bottomShadowLarge
 */
export interface EuiShadowXLarge extends EuiShadowOptions {
    reverse?: boolean;
}
export declare const euiShadowXLarge: ({ euiTheme, colorMode, highContrastMode }: UseEuiTheme, options?: EuiShadowXLarge | undefined) => string;
/**
 * slightShadowHover
 */
export declare const euiSlightShadowHover: ({ euiTheme, colorMode, highContrastMode }: UseEuiTheme, options?: EuiShadowOptions | undefined) => string;
/**
 * bottomShadowFlat
 *
 * Similar to shadow medium but without the bottom depth.
 * Useful for popovers that drop UP rather than DOWN.
 */
export declare const euiShadowFlat: ({ euiTheme, colorMode, highContrastMode }: UseEuiTheme, options?: EuiShadowOptions | undefined) => string;
export declare const euiShadow: (euiThemeContext: UseEuiTheme, size?: _EuiThemeShadowSize, options?: EuiShadowOptions | undefined) => string;
