/**
 * Theme variant flags
 *
 * Note: Currently empty as placeholder for potential future use
 */
export declare type EuiThemeVariantFlags = {};
/**
 * Theme specific setting flags
 */
export declare type _EuiThemeFlags = EuiThemeVariantFlags;
