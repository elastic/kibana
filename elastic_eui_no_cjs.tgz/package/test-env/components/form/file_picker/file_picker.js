"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.EuiFilePicker = void 0;
var _extends2 = _interopRequireDefault(require("@babel/runtime/helpers/extends"));
var _toConsumableArray2 = _interopRequireDefault(require("@babel/runtime/helpers/toConsumableArray"));
var _slicedToArray2 = _interopRequireDefault(require("@babel/runtime/helpers/slicedToArray"));
var _objectWithoutProperties2 = _interopRequireDefault(require("@babel/runtime/helpers/objectWithoutProperties"));
var _react = _interopRequireWildcard(require("react"));
var _propTypes = _interopRequireDefault(require("prop-types"));
var _classnames = _interopRequireDefault(require("classnames"));
var _services = require("../../../services");
var _button = require("../../button");
var _progress = require("../../progress");
var _icon = require("../../icon");
var _i18n = require("../../i18n");
var _loading = require("../../loading");
var _eui_form_context = require("../eui_form_context");
var _validatable_control = require("../validatable_control");
var _form_control_layout_clear_button = require("../form_control_layout/form_control_layout_clear_button");
var _file_picker = require("./file_picker.styles");
var _react2 = require("@emotion/react");
var _excluded = ["id", "name", "initialPromptText", "className", "disabled", "compressed", "onChange", "isInvalid", "fullWidth", "isLoading", "display", "files"];
/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */
var cache;
function _interopRequireWildcard(e, t) { if (!t && e && e.__esModule) return e; var r, c, a = Object.defineProperty, n = { __proto__: null, default: e }; if (Object(e) !== e) return n; if (cache || "function" != typeof WeakMap || (cache = new WeakMap()), cache) { if (cache.has(e)) return cache.get(e); cache.set(e, n); } for (c in e) "default" !== c && {}.hasOwnProperty.call(e, c) && ((r = a && Object.getOwnPropertyDescriptor(e, c)) && (r.get || r.set) ? a(n, c, r) : n[c] = e[c]); return n; }
var getPromptTextFromFileList = function getPromptTextFromFileList(files) {
  if (!files || files.length === 0) {
    return null;
  }
  if (files.length > 1) {
    return (0, _react2.jsx)(_i18n.EuiI18n, {
      token: "euiFilePicker.filesSelected",
      default: "{fileCount} files selected",
      values: {
        fileCount: files.length
      }
    });
  }
  return files[0].name;
};

/**
 * @see {@link https://eui.elastic.co/docs/components/forms/other/file-picker/|EuiFilePicker documentation}
 */
var EuiFilePicker = exports.EuiFilePicker = /*#__PURE__*/(0, _react.forwardRef)(function (props, ref) {
  var _useFormContext = (0, _eui_form_context.useFormContext)(),
    defaultFullWidth = _useFormContext.defaultFullWidth;
  var id = props.id,
    name = props.name,
    _props$initialPromptT = props.initialPromptText,
    initialPromptText = _props$initialPromptT === void 0 ? (0, _react2.jsx)(_i18n.EuiI18n, {
      token: "euiFilePicker.promptText",
      default: "Select or drag and drop a file"
    }) : _props$initialPromptT,
    className = props.className,
    disabled = props.disabled,
    _props$compressed = props.compressed,
    compressed = _props$compressed === void 0 ? false : _props$compressed,
    onChange = props.onChange,
    isInvalid = props.isInvalid,
    _props$fullWidth = props.fullWidth,
    fullWidth = _props$fullWidth === void 0 ? defaultFullWidth : _props$fullWidth,
    isLoading = props.isLoading,
    _props$display = props.display,
    display = _props$display === void 0 ? 'large' : _props$display,
    files = props.files,
    rest = (0, _objectWithoutProperties2.default)(props, _excluded);
  var removeSelectedAriaLabel = (0, _i18n.useEuiI18n)('euiFilePicker.removeSelectedAriaLabel', 'Remove selected files');
  var fileInput = (0, _react.useRef)(null);
  var _useState = (0, _react.useState)(function () {
      return files ? getPromptTextFromFileList(files) : null;
    }),
    _useState2 = (0, _slicedToArray2.default)(_useState, 2),
    promptText = _useState2[0],
    setPromptText = _useState2[1];
  var _useState3 = (0, _react.useState)(false),
    _useState4 = (0, _slicedToArray2.default)(_useState3, 2),
    isHoveringDrop = _useState4[0],
    setIsHoveringDrop = _useState4[1];

  // Update prompt text when the `files` prop changes. The ref guard keeps this
  // from re-running on mount, where the initial state is already derived above.
  var prevFiles = (0, _react.useRef)(files);
  (0, _react.useEffect)(function () {
    if (prevFiles.current !== files) {
      prevFiles.current = files;
      setPromptText(getPromptTextFromFileList(files !== null && files !== void 0 ? files : null));
    }
  }, [files]);
  var handleChange = (0, _react.useCallback)(function () {
    if (!fileInput.current) return;
    if (fileInput.current.files && fileInput.current.files.length === 1) {
      setPromptText(fileInput.current.value.split('\\').pop());
    } else {
      setPromptText(getPromptTextFromFileList(fileInput.current.files ? Array.from(fileInput.current.files) : null));
    }
    if (onChange) {
      onChange(fileInput.current.files && fileInput.current.files.length > 0 ? fileInput.current.files : null);
    }
  }, [onChange]);
  var removeFiles = (0, _react.useCallback)(function (e) {
    if (e) {
      e.stopPropagation();
      e.preventDefault();
    }
    if (!fileInput.current) return;
    fileInput.current.value = '';
    handleChange();
  }, [handleChange]);
  (0, _react.useImperativeHandle)(ref, function () {
    return {
      removeFiles: removeFiles,
      input: fileInput.current
    };
  }, [removeFiles]);
  var showDrop = function showDrop() {
    return !disabled && setIsHoveringDrop(true);
  };
  var hideDrop = function hideDrop() {
    return setIsHoveringDrop(false);
  };
  var generatedId = (0, _services.useGeneratedHtmlId)();
  var promptId = "".concat(id || generatedId, "-filePicker__prompt");
  var isOverridingInitialPrompt = promptText != null;
  var normalFormControl = display === 'default';
  var classes = (0, _classnames.default)('euiFilePicker', {
    'euiFilePicker-isDroppingFile': isHoveringDrop,
    'euiFilePicker-isInvalid': isInvalid,
    'euiFilePicker-isLoading': isLoading,
    'euiFilePicker-hasFiles': isOverridingInitialPrompt
  }, className);
  var styles = (0, _services.useEuiMemoizedStyles)(_file_picker.euiFilePickerStyles);
  var cssStyles = [styles.euiFilePicker, fullWidth ? styles.fullWidth : styles.formWidth, isHoveringDrop && styles.isDroppingFile, isInvalid && !disabled && styles.invalid, isOverridingInitialPrompt && !disabled && styles.hasFiles, isLoading && styles.loading];
  var inputStyles = [styles.input.euiFilePicker__input, !normalFormControl && !disabled && styles.input.largeInteractive];
  var promptStyles = [styles.euiFilePicker__prompt, disabled && styles.disabled].concat((0, _toConsumableArray2.default)(normalFormControl ? [compressed ? styles.compressed : styles.uncompressed] : [styles.large.large, compressed ? styles.large.compressed : styles.large.uncompressed]));
  var iconStyles = [styles.icon.euiFilePicker__icon].concat((0, _toConsumableArray2.default)(normalFormControl ? [styles.icon.normal, compressed ? styles.icon.compressed : styles.icon.uncompressed] : [styles.icon.large]));
  var rightIconStyles = normalFormControl ? [styles.rightIcon.euiFilePicker__rightIcon, compressed ? styles.rightIcon.compressed : styles.rightIcon.uncompressed] : undefined;
  var clearButton;
  if (isLoading && normalFormControl) {
    // Override clear button with loading spinner if it is in loading state
    clearButton = (0, _react2.jsx)(_loading.EuiLoadingSpinner, {
      css: rightIconStyles,
      className: "euiFilePicker__loadingSpinner",
      size: compressed ? 's' : 'm'
    });
  } else if (isOverridingInitialPrompt && !disabled) {
    if (normalFormControl) {
      clearButton = (0, _react2.jsx)(_form_control_layout_clear_button.EuiFormControlLayoutClearButton, {
        "aria-label": removeSelectedAriaLabel,
        css: [styles.euiFilePicker__clearButton, rightIconStyles, ";label:clearButton;"],
        className: "euiFilePicker__clearButton",
        onClick: removeFiles,
        size: compressed ? 's' : 'm'
      });
    } else {
      clearButton = (0, _react2.jsx)(_button.EuiButtonEmpty, {
        "aria-label": removeSelectedAriaLabel,
        css: styles.euiFilePicker__clearButton,
        className: "euiFilePicker__clearButton",
        size: "xs",
        onClick: removeFiles
      }, (0, _react2.jsx)(_i18n.EuiI18n, {
        token: "euiFilePicker.removeSelected",
        default: "Remove"
      }));
    }
  } else {
    clearButton = null;
  }
  var loader = !normalFormControl && isLoading && (0, _react2.jsx)(_progress.EuiProgress, {
    size: "xs",
    color: "accent",
    position: "absolute"
  });
  var iconColor = isInvalid ? 'danger' : disabled ? 'disabled' : 'text';
  return (0, _react2.jsx)("div", {
    css: cssStyles,
    className: classes
  }, (0, _react2.jsx)(_validatable_control.EuiValidatableControl, {
    isInvalid: isInvalid
  }, (0, _react2.jsx)("input", (0, _extends2.default)({
    type: "file",
    id: id,
    name: name,
    css: inputStyles,
    className: "euiFilePicker__input",
    onChange: handleChange,
    ref: fileInput,
    onDragOver: showDrop,
    onDragLeave: hideDrop,
    onDrop: hideDrop,
    disabled: disabled,
    "aria-describedby": promptId
  }, rest))), (0, _react2.jsx)("div", {
    css: promptStyles,
    className: "euiFilePicker__prompt",
    id: promptId
  }, (0, _react2.jsx)(_icon.EuiIcon, {
    css: iconStyles,
    className: "euiFilePicker__icon",
    color: iconColor,
    type: isInvalid ? 'warning' : disabled ? 'minusCircle' : 'upload',
    size: normalFormControl ? 'm' : 'l',
    "aria-hidden": "true"
  }), (0, _react2.jsx)("span", {
    className: "euiFilePicker__promptText"
  }, promptText || initialPromptText), clearButton, loader));
});
EuiFilePicker.propTypes = {
  id: _propTypes.default.string,
  name: _propTypes.default.string,
  className: _propTypes.default.string,
  /**
     * The content that appears in the dropzone if no file is attached
     * @default 'Select or drag and drop a file'
     */
  initialPromptText: _propTypes.default.node,
  /**
     * Use as a callback to access the HTML FileList API
     */
  onChange: _propTypes.default.func,
  /**
     * Optionally pass a `File[]` array to maintain the file picker's displayed
     * state between re-renders. Useful for multi-step forms where the component
     * may unmount and remount while the file data is still stored in context.
     *
     * Note: Due to browser security restrictions, the actual file input
     * cannot be programmatically set with files. This prop only controls
     * the displayed state (file names in the prompt). The actual file data
     * should be stored and managed separately in your application state.
     */
  files: _propTypes.default.oneOfType([_propTypes.default.arrayOf(_propTypes.default.any.isRequired).isRequired, _propTypes.default.oneOf([null])]),
  /**
     * Reduces the size to a typical (compressed) input
     * @default false
     */
  compressed: _propTypes.default.bool,
  /**
     * Size or type of display;
     * `default` for normal height, similar to other controls;
     * `large` for taller size
     * @default large
     */
  display: _propTypes.default.oneOf(["default", "large"]),
  /**
     * Expand to fill 100% of the parent.
     * Defaults to `fullWidth` prop of `<EuiForm>`.
     * @default false
     */
  fullWidth: _propTypes.default.bool,
  isInvalid: _propTypes.default.bool,
  isLoading: _propTypes.default.bool,
  disabled: _propTypes.default.bool,
  "aria-label": _propTypes.default.string,
  "data-test-subj": _propTypes.default.string,
  css: _propTypes.default.any
};
EuiFilePicker.displayName = 'EuiFilePicker';