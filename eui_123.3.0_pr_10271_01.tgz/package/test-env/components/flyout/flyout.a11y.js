"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
var _extends2 = _interopRequireDefault(require("@babel/runtime/helpers/extends"));
var _slicedToArray2 = _interopRequireDefault(require("@babel/runtime/helpers/slicedToArray"));
var _objectWithoutProperties2 = _interopRequireDefault(require("@babel/runtime/helpers/objectWithoutProperties"));
var _react = _interopRequireWildcard(require("react"));
var _flyout = require("./flyout");
var _button = require("../button");
var _react2 = require("@emotion/react");
var _excluded = ["children"];
/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */
/// <reference types="cypress" />
/// <reference types="cypress-real-events" />
/// <reference types="../../../cypress/support" />
var cache;
function _interopRequireWildcard(e, t) { if (!t && e && e.__esModule) return e; var r, c, a = Object.defineProperty, n = { __proto__: null, default: e }; if (Object(e) !== e) return n; if (cache || "function" != typeof WeakMap || (cache = new WeakMap()), cache) { if (cache.has(e)) return cache.get(e); cache.set(e, n); } for (c in e) "default" !== c && {}.hasOwnProperty.call(e, c) && ((r = a && Object.getOwnPropertyDescriptor(e, c)) && (r.get || r.set) ? a(n, c, r) : n[c] = e[c]); return n; }
var childrenDefault = (0, _react2.jsx)(_react.default.Fragment, null, (0, _react2.jsx)("button", {
  "data-test-subj": "itemA"
}, "Item A"), (0, _react2.jsx)("button", {
  "data-test-subj": "itemB"
}, "Item B"), (0, _react2.jsx)("button", {
  "data-test-subj": "itemC"
}, "Item C"), (0, _react2.jsx)("input", {
  "data-test-subj": "itemD"
}));
var Flyout = function Flyout(_ref) {
  var _ref$children = _ref.children,
    children = _ref$children === void 0 ? childrenDefault : _ref$children,
    rest = (0, _objectWithoutProperties2.default)(_ref, _excluded);
  var _useState = (0, _react.useState)(false),
    _useState2 = (0, _slicedToArray2.default)(_useState, 2),
    isOpen = _useState2[0],
    setIsOpen = _useState2[1];
  var onButtonClick = function onButtonClick() {
    return setIsOpen(!isOpen);
  };
  var button = (0, _react2.jsx)(_button.EuiButtonEmpty, {
    onClick: onButtonClick
  }, "Toggle flyout");
  return (0, _react2.jsx)("div", null, button, isOpen ? (0, _react2.jsx)(_flyout.EuiFlyout, (0, _extends2.default)({
    "data-test-subj": "flyoutSpec",
    onClose: function onClose() {
      return setIsOpen(false);
    }
  }, rest), children) : null);
};
beforeEach(function () {
  cy.mount((0, _react2.jsx)(Flyout, null));
  cy.get('div.euiFlyout').should('not.exist');
});
describe('EuiFlyout', function () {
  describe('Automated accessibility check', function () {
    it('has zero violations on render', function () {
      cy.checkAxe();
    });
    it('has zero violations when flyout is opened', function () {
      cy.get('button.euiButtonEmpty').click();
      cy.get('div.euiFlyout').should('exist');
      cy.checkAxe();
    });
    it('has zero violations when flyout is closed', function () {
      cy.get('button.euiButtonEmpty').click();
      cy.get('div.euiFlyout').should('exist');
      cy.get('button.euiFlyout__closeButton').click();
      cy.get('div.euiFlyout').should('not.exist');
      cy.checkAxe();
    });
  });
});