"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.useIsInsideParentFlyout = exports.EuiFlyoutParentProvider = void 0;
var _react = _interopRequireWildcard(require("react"));
var _react2 = require("@emotion/react");
var cache;
function _interopRequireWildcard(e, t) { if (!t && e && e.__esModule) return e; var r, c, a = Object.defineProperty, n = { __proto__: null, default: e }; if (Object(e) !== e) return n; if (cache || "function" != typeof WeakMap || (cache = new WeakMap()), cache) { if (cache.has(e)) return cache.get(e); cache.set(e, n); } for (c in e) "default" !== c && {}.hasOwnProperty.call(e, c) && ((r = a && Object.getOwnPropertyDescriptor(e, c)) && (r.get || r.set) ? a(n, c, r) : n[c] = e[c]); return n; }
/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */

/**
 * Context to track if we're inside a parent flyout's children.
 * This allows nested flyouts to automatically inherit the session
 * without requiring explicit `session="inherit"` prop.
 */var EuiFlyoutParentContext = /*#__PURE__*/(0, _react.createContext)(false);

/**
 * Provider that wraps a flyout's children to indicate they're inside a parent flyout.
 * Nested flyouts can use this to automatically default to session inheritance.
 */
var EuiFlyoutParentProvider = exports.EuiFlyoutParentProvider = function EuiFlyoutParentProvider(_ref) {
  var children = _ref.children;
  return (0, _react2.jsx)(EuiFlyoutParentContext.Provider, {
    value: true
  }, children);
};

/**
 * Hook that returns `true` when called within a parent flyout's children.
 * Used to automatically determine if a nested flyout should inherit the session.
 */
var useIsInsideParentFlyout = exports.useIsInsideParentFlyout = function useIsInsideParentFlyout() {
  return (0, _react.useContext)(EuiFlyoutParentContext);
};