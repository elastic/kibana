"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.EuiFlyoutOverlay = void 0;
var _extends2 = _interopRequireDefault(require("@babel/runtime/helpers/extends"));
var _react = _interopRequireWildcard(require("react"));
var _css = require("@emotion/css");
var _services = require("../../services");
var _overlay_mask = require("../overlay_mask");
var _portal = require("../portal");
var _react2 = require("@emotion/react");
var cache;
function _interopRequireWildcard(e, t) { if (!t && e && e.__esModule) return e; var r, c, a = Object.defineProperty, n = { __proto__: null, default: e }; if (Object(e) !== e) return n; if (cache || "function" != typeof WeakMap || (cache = new WeakMap()), cache) { if (cache.has(e)) return cache.get(e); cache.set(e, n); } for (c in e) "default" !== c && {}.hasOwnProperty.call(e, c) && ((r = a && Object.getOwnPropertyDescriptor(e, c)) && (r.get || r.set) ? a(n, c, r) : n[c] = e[c]); return n; }
/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */

var getEuiFlyoutOverlayStyles = function getEuiFlyoutOverlayStyles(zIndex) {
  /*
  This needs to have !important to override the default EuiOverlayMask
  z-index based on the headerZindexLocation prop. Using the style attribute
  doesn't work since EuiOverlayMask requires the styles to be provided via className
  */
  return /*#__PURE__*/(0, _css.css)("z-index:", zIndex, "!important;;label:getEuiFlyoutOverlayStyles;");
};

/**
 * Light wrapper for conditionally rendering portals or overlay masks:
 *  - If ownFocus is set, wrap with an overlay and allow the user to click it to close it.
 *  - Otherwise still wrap within an EuiPortal so it appends to the bottom of the window.
 * Push flyouts have no overlay OR portal behavior.
 *
 * @internal
 */
var EuiFlyoutOverlay = exports.EuiFlyoutOverlay = function EuiFlyoutOverlay(_ref) {
  var _maskProps$headerZind;
  var children = _ref.children,
    isPushed = _ref.isPushed,
    maskProps = _ref.maskProps,
    hasOverlayMask = _ref.hasOverlayMask,
    maskZIndex = _ref.maskZIndex,
    _ref$headerZindexLoca = _ref.headerZindexLocation,
    headerZindexLocation = _ref$headerZindexLoca === void 0 ? 'below' : _ref$headerZindexLoca,
    containerRect = _ref.containerRect;
  var styles = (0, _react.useMemo)(function () {
    return getEuiFlyoutOverlayStyles(maskZIndex);
  }, [maskZIndex]);

  // Internal ref so we can apply containerRect positioning directly on the DOM
  // node, avoiding new Emotion CSS class generation on every scroll/resize.
  var internalMaskRef = (0, _react.useRef)(null);
  var combinedMaskRef = (0, _services.useCombinedRefs)([internalMaskRef, maskProps === null || maskProps === void 0 ? void 0 : maskProps.maskRef]);
  (0, _react.useEffect)(function () {
    var node = internalMaskRef.current;
    if (!node) return;

    //  containerRect positioning must be applied via node.style.setProperty rather than
    //  through the style prop - EuiOverlayMask requires styles to be passed via className
    if (containerRect) {
      node.style.setProperty('inset-block-start', "".concat(containerRect.top, "px"));
      node.style.setProperty('inset-inline-start', "".concat(containerRect.left, "px"));
      node.style.setProperty('inline-size', "".concat(containerRect.width, "px"));
      node.style.setProperty('block-size', "".concat(containerRect.height, "px"));
      node.style.setProperty('inset-inline-end', 'auto');
      node.style.setProperty('inset-block-end', 'auto');
    } else {
      node.style.removeProperty('inset-block-start');
      node.style.removeProperty('inset-inline-start');
      node.style.removeProperty('inline-size');
      node.style.removeProperty('block-size');
      node.style.removeProperty('inset-inline-end');
      node.style.removeProperty('inset-block-end');
    }
  }, [containerRect, hasOverlayMask]); // toggling ownFocus while the flyout is already open should cause re-render

  var content = children;
  if (!isPushed || hasOverlayMask) {
    content = (0, _react2.jsx)(_portal.EuiPortal, null, content);
  }
  var classes = (0, _css.cx)(maskProps === null || maskProps === void 0 ? void 0 : maskProps.className, styles);
  return (0, _react2.jsx)(_react.default.Fragment, null, hasOverlayMask && (0, _react2.jsx)(_overlay_mask.EuiOverlayMask, (0, _extends2.default)({
    headerZindexLocation: (_maskProps$headerZind = maskProps === null || maskProps === void 0 ? void 0 : maskProps.headerZindexLocation) !== null && _maskProps$headerZind !== void 0 ? _maskProps$headerZind : headerZindexLocation
  }, maskProps, {
    maskRef: combinedMaskRef,
    className: classes
  })), content);
};