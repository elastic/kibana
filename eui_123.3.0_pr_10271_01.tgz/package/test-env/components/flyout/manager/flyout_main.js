"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.EuiFlyoutMain = void 0;
var _extends2 = _interopRequireDefault(require("@babel/runtime/helpers/extends"));
var _defineProperty2 = _interopRequireDefault(require("@babel/runtime/helpers/defineProperty"));
var _objectWithoutProperties2 = _interopRequireDefault(require("@babel/runtime/helpers/objectWithoutProperties"));
var _react = _interopRequireWildcard(require("react"));
var _flyout_managed = require("./flyout_managed");
var _hooks = require("./hooks");
var _flyout_main = require("./flyout_main.styles");
var _services = require("../../../services");
var _const = require("../const");
var _hooks2 = require("../hooks");
var _const2 = require("./const");
var _react2 = require("@emotion/react");
var _excluded = ["id", "pushMinBreakpoint", "type", "side"];
/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */
/**
 * Props for `EuiFlyoutMain`, the primary managed flyout component.
 * The `level` prop is fixed internally to `main` and is therefore omitted.
 */
var cache;
function _interopRequireWildcard(e, t) { if (!t && e && e.__esModule) return e; var r, c, a = Object.defineProperty, n = { __proto__: null, default: e }; if (Object(e) !== e) return n; if (cache || "function" != typeof WeakMap || (cache = new WeakMap()), cache) { if (cache.has(e)) return cache.get(e); cache.set(e, n); } for (c in e) "default" !== c && {}.hasOwnProperty.call(e, c) && ((r = a && Object.getOwnPropertyDescriptor(e, c)) && (r.get || r.set) ? a(n, c, r) : n[c] = e[c]); return n; }
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { (0, _defineProperty2.default)(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
/**
 * Managed main flyout. Handles ID management, child-flyout styling,
 * and push/overlay behavior based on provided props.
 */
var EuiFlyoutMain = exports.EuiFlyoutMain = /*#__PURE__*/(0, _react.forwardRef)(function (_ref, ref) {
  var id = _ref.id,
    _ref$pushMinBreakpoin = _ref.pushMinBreakpoint,
    pushMinBreakpoint = _ref$pushMinBreakpoin === void 0 ? _const.DEFAULT_PUSH_MIN_BREAKPOINT : _ref$pushMinBreakpoin,
    _ref$type = _ref.type,
    type = _ref$type === void 0 ? _const.DEFAULT_TYPE : _ref$type,
    _ref$side = _ref.side,
    side = _ref$side === void 0 ? _const.DEFAULT_SIDE : _ref$side,
    props = (0, _objectWithoutProperties2.default)(_ref, _excluded);
  var flyoutId = (0, _hooks.useFlyoutId)(id);
  var hasChildFlyout = (0, _hooks.useHasChildFlyout)(flyoutId);
  var styles = (0, _services.useEuiMemoizedStyles)(_flyout_main.euiMainFlyoutStyles);
  var context = (0, _hooks.useFlyoutManager)();
  var isPushed = (0, _hooks2.useIsPushed)({
    type: type,
    pushMinBreakpoint: pushMinBreakpoint,
    containerWidth: context === null || context === void 0 ? void 0 : context.state.referenceWidth
  });
  var cssStyles = [hasChildFlyout && !isPushed && styles.hasChildFlyout[side]];
  var style = {};
  return (0, _react2.jsx)(_flyout_managed.EuiManagedFlyout, (0, _extends2.default)({
    ref: ref,
    id: flyoutId,
    level: _const2.LEVEL_MAIN,
    style: style,
    css: cssStyles
  }, _objectSpread(_objectSpread({}, props), {}, {
    pushMinBreakpoint: pushMinBreakpoint,
    type: type,
    side: side
  })));
});
EuiFlyoutMain.displayName = 'EuiFlyoutMain';