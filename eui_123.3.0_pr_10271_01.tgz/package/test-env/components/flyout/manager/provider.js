"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.useFlyoutManager = exports.EuiFlyoutManagerContext = exports.EuiFlyoutManager = void 0;
var _defineProperty2 = _interopRequireDefault(require("@babel/runtime/helpers/defineProperty"));
var _objectWithoutProperties2 = _interopRequireDefault(require("@babel/runtime/helpers/objectWithoutProperties"));
var _react = _interopRequireWildcard(require("react"));
var _shim = require("use-sync-external-store/shim");
var _layout_mode = require("./layout_mode");
var _store = require("./store");
var _react2 = require("@emotion/react");
var _excluded = ["getState", "subscribe"];
/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */
/**
 * React context that exposes the Flyout Manager API (state + actions).
 */
var cache;
function _interopRequireWildcard(e, t) { if (!t && e && e.__esModule) return e; var r, c, a = Object.defineProperty, n = { __proto__: null, default: e }; if (Object(e) !== e) return n; if (cache || "function" != typeof WeakMap || (cache = new WeakMap()), cache) { if (cache.has(e)) return cache.get(e); cache.set(e, n); } for (c in e) "default" !== c && {}.hasOwnProperty.call(e, c) && ((r = a && Object.getOwnPropertyDescriptor(e, c)) && (r.get || r.set) ? a(n, c, r) : n[c] = e[c]); return n; }
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { (0, _defineProperty2.default)(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
var EuiFlyoutManagerContext = exports.EuiFlyoutManagerContext = /*#__PURE__*/(0, _react.createContext)(null);

/**
 * Provides the Flyout Manager API via context and runs layout-mode logic.
 */
var EuiFlyoutManager = exports.EuiFlyoutManager = function EuiFlyoutManager(_ref) {
  var children = _ref.children;
  var _getFlyoutManagerStor = (0, _store.getFlyoutManagerStore)(),
    getState = _getFlyoutManagerStor.getState,
    subscribe = _getFlyoutManagerStor.subscribe,
    rest = (0, _objectWithoutProperties2.default)(_getFlyoutManagerStor, _excluded);
  var state = (0, _shim.useSyncExternalStore)(subscribe, getState, getState);
  var api = (0, _react.useMemo)(function () {
    return _objectSpread({
      state: state
    }, rest);
  }, [state, rest]);
  return (0, _react2.jsx)(EuiFlyoutManagerContext.Provider, {
    value: api
  }, (0, _react2.jsx)(EuiFlyoutManagerContainer, null, children));
};
var EuiFlyoutManagerContainer = function EuiFlyoutManagerContainer(_ref2) {
  var children = _ref2.children;
  (0, _layout_mode.useApplyFlyoutLayoutMode)();
  return (0, _react2.jsx)(_react.default.Fragment, null, children);
};

/** Hook to access the Flyout Manager API from context. */
var useFlyoutManager = exports.useFlyoutManager = function useFlyoutManager() {
  return (0, _react.useContext)(EuiFlyoutManagerContext);
};