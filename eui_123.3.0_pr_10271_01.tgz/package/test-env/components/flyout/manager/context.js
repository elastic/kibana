"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.useIsInManagedFlyout = exports.EuiFlyoutIsManagedProvider = void 0;
var _react = _interopRequireWildcard(require("react"));
var _react2 = require("@emotion/react");
var cache;
function _interopRequireWildcard(e, t) { if (!t && e && e.__esModule) return e; var r, c, a = Object.defineProperty, n = { __proto__: null, default: e }; if (Object(e) !== e) return n; if (cache || "function" != typeof WeakMap || (cache = new WeakMap()), cache) { if (cache.has(e)) return cache.get(e); cache.set(e, n); } for (c in e) "default" !== c && {}.hasOwnProperty.call(e, c) && ((r = a && Object.getOwnPropertyDescriptor(e, c)) && (r.get || r.set) ? a(n, c, r) : n[c] = e[c]); return n; }
/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */

// Context to track if we're within a managed flyout
var EuiFlyoutIsManagedContext = /*#__PURE__*/(0, _react.createContext)(false);

/**
 * React provider that marks descendants as being rendered inside
 * an EUI managed flyout. Used by hooks/components to alter behavior
 * (e.g., focus handling) when inside a managed flyout tree.
 */
var EuiFlyoutIsManagedProvider = exports.EuiFlyoutIsManagedProvider = function EuiFlyoutIsManagedProvider(_ref) {
  var isManaged = _ref.isManaged,
    children = _ref.children;
  return (0, _react2.jsx)(EuiFlyoutIsManagedContext.Provider, {
    value: isManaged
  }, children);
};

/**
 * Hook that returns `true` when called within an EUI managed flyout subtree.
 */
var useIsInManagedFlyout = exports.useIsInManagedFlyout = function useIsInManagedFlyout() {
  return (0, _react.useContext)(EuiFlyoutIsManagedContext);
};