"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.EuiBanner = void 0;
var _extends2 = _interopRequireDefault(require("@babel/runtime/helpers/extends"));
var _slicedToArray2 = _interopRequireDefault(require("@babel/runtime/helpers/slicedToArray"));
var _objectWithoutProperties2 = _interopRequireDefault(require("@babel/runtime/helpers/objectWithoutProperties"));
var _react = _interopRequireWildcard(require("react"));
var _propTypes = _interopRequireDefault(require("prop-types"));
var _classnames = _interopRequireDefault(require("classnames"));
var _services = require("../../services");
var _global_styling = require("../../global_styling");
var _i18n = require("../i18n");
var _title = require("../title");
var _button = require("../button");
var _text = require("../text");
var _accessibility = require("../accessibility");
var _banner = require("./banner.styles");
var _react2 = require("@emotion/react");
var _excluded = ["title", "headingElement", "text", "size", "color", "actionProps", "media", "onDismiss", "dismissButtonProps", "children", "className", "announceOnMount", "data-test-subj"];
/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */
var cache;
function _interopRequireWildcard(e, t) { if (!t && e && e.__esModule) return e; var r, c, a = Object.defineProperty, n = { __proto__: null, default: e }; if (Object(e) !== e) return n; if (cache || "function" != typeof WeakMap || (cache = new WeakMap()), cache) { if (cache.has(e)) return cache.get(e); cache.set(e, n); } for (c in e) "default" !== c && {}.hasOwnProperty.call(e, c) && ((r = a && Object.getOwnPropertyDescriptor(e, c)) && (r.get || r.set) ? a(n, c, r) : n[c] = e[c]); return n; }
/**
 * @see {@link https://eui.elastic.co/docs/components/display/banner/|EuiBanner documentation}
 */
var EuiBanner = exports.EuiBanner = /*#__PURE__*/(0, _react.forwardRef)(function (_ref, ref) {
  var title = _ref.title,
    _ref$headingElement = _ref.headingElement,
    headingElement = _ref$headingElement === void 0 ? 'h2' : _ref$headingElement,
    text = _ref.text,
    _ref$size = _ref.size,
    size = _ref$size === void 0 ? 'm' : _ref$size,
    _ref$color = _ref.color,
    color = _ref$color === void 0 ? 'highlighted' : _ref$color,
    actionProps = _ref.actionProps,
    media = _ref.media,
    onDismiss = _ref.onDismiss,
    dismissButtonProps = _ref.dismissButtonProps,
    children = _ref.children,
    className = _ref.className,
    _ref$announceOnMount = _ref.announceOnMount,
    announceOnMount = _ref$announceOnMount === void 0 ? false : _ref$announceOnMount,
    _ref$dataTestSubj = _ref['data-test-subj'],
    dataTestSubj = _ref$dataTestSubj === void 0 ? 'euiBanner' : _ref$dataTestSubj,
    rest = (0, _objectWithoutProperties2.default)(_ref, _excluded);
  var styles = (0, _services.useEuiMemoizedStyles)(_banner.euiBannerStyles);
  var dismissAriaLabel = (0, _i18n.useEuiI18n)('euiBanner.dismissAriaLabel', 'Dismiss "{title}" announcement', {
    title: title
  });
  var Heading = headingElement;
  var headingSize = size === 's' ? 'xxs' : 'xs';
  var primaryActionProps = actionProps === null || actionProps === void 0 ? void 0 : actionProps.primary;
  var secondaryActionProps = actionProps === null || actionProps === void 0 ? void 0 : actionProps.secondary;
  var hasActions = Boolean(primaryActionProps) || Boolean(secondaryActionProps);
  var titleRef = (0, _react.useRef)(null);
  var contentRef = (0, _react.useRef)(null);
  var _useState = (0, _react.useState)(''),
    _useState2 = (0, _slicedToArray2.default)(_useState, 2),
    announcement = _useState2[0],
    setAnnouncement = _useState2[1];
  (0, _react.useEffect)(function () {
    var content = contentRef.current;
    if (!announceOnMount || !content) {
      setAnnouncement('');
      return;
    }

    // `EuiText` does not forward refs. The text slot is the first direct
    // `.euiText` child, since `children` render after it.
    var textNode = text ? Array.from(content.children).find(function (node) {
      return node.classList.contains('euiText');
    }) : undefined;
    var childrenText = Array.from(content.childNodes).filter(function (node) {
      return node !== titleRef.current && node !== textNode;
    }).map(readText).filter(Boolean).join(' ');
    setAnnouncement([readText(titleRef.current), readText(textNode), childrenText].filter(Boolean).join(",\xA0"));
  }, [announceOnMount, title, text, children]);
  var componentClass = 'euiBanner';
  var classes = (0, _classnames.default)(componentClass, className);
  var backgroundColorStyles = (0, _global_styling.useEuiBackgroundColorCSS)()[color];
  var cssStyles = [styles.euiBanner, backgroundColorStyles];
  var containerCssStyles = [styles.container, onDismiss && styles.hasDismiss];
  return (0, _react2.jsx)("div", (0, _extends2.default)({
    ref: ref,
    className: classes,
    css: cssStyles,
    "data-size": size,
    "data-color": color,
    "data-test-subj": dataTestSubj
  }, rest), (0, _react2.jsx)("div", {
    className: "".concat(componentClass, "__container"),
    css: containerCssStyles
  }, media ? (0, _react2.jsx)("div", {
    className: "".concat(componentClass, "__media"),
    css: styles.media,
    "data-test-subj": "".concat(dataTestSubj, "-media")
  }, media) : null, (0, _react2.jsx)("div", {
    className: "".concat(componentClass, "__body"),
    css: styles.body
  }, (0, _react2.jsx)("div", {
    ref: contentRef,
    className: "".concat(componentClass, "__content"),
    css: styles.content
  }, (0, _react2.jsx)(_title.EuiTitle, {
    size: headingSize
  }, (0, _react2.jsx)(Heading, {
    ref: titleRef,
    css: styles.title,
    "data-test-subj": "".concat(dataTestSubj, "-title")
  }, title)), onDismiss ? (0, _react2.jsx)(_button.EuiButtonIcon, (0, _extends2.default)({
    iconType: "cross",
    color: "text",
    "aria-label": dismissAriaLabel,
    "data-test-subj": "".concat(dataTestSubj, "-dismiss")
  }, dismissButtonProps, {
    css: [styles.dismiss, dismissButtonProps === null || dismissButtonProps === void 0 ? void 0 : dismissButtonProps.css, ";label:EuiBanner;"],
    onClick: onDismiss
  })) : null, text ? (0, _react2.jsx)(_text.EuiText, {
    css: styles.text,
    size: "s",
    color: "subdued",
    "data-test-subj": "".concat(dataTestSubj, "-text")
  }, text) : null, children && children), hasActions ? (0, _react2.jsx)("div", {
    className: "".concat(componentClass, "__actions"),
    css: styles.actions,
    "data-test-subj": "".concat(dataTestSubj, "-actions")
  }, primaryActionProps ? (0, _react2.jsx)(_button.EuiButton, (0, _extends2.default)({
    "data-test-subj": "".concat(dataTestSubj, "-primaryAction")
  }, primaryActionProps, {
    color: "primary",
    size: "s"
  })) : null, secondaryActionProps ? (0, _react2.jsx)(_button.EuiButtonEmpty, (0, _extends2.default)({
    "data-test-subj": "".concat(dataTestSubj, "-secondaryAction")
  }, secondaryActionProps, {
    color: "primary",
    size: "s"
  })) : null) : null)), announcement ? (0, _react2.jsx)(_accessibility.EuiLiveAnnouncer, null, announcement) : null);
});
EuiBanner.propTypes = {
  className: _propTypes.default.string,
  "aria-label": _propTypes.default.string,
  "data-test-subj": _propTypes.default.string,
  css: _propTypes.default.any,
  /** Heading shown at the top. */title: _propTypes.default.string.isRequired,
  /**
     * HTML element used to render the title.
     * @default 'h2'
     */
  headingElement: _propTypes.default.oneOf(["h2", "h3", "h4", "h5", "h6"]),
  /** Supporting copy rendered below the title. */text: _propTypes.default.node,
  /** Extra content rendered directly below `text`. */children: _propTypes.default.node,
  /** Illustration slot. Wrapped in a square (1:1) container. */media: _propTypes.default.node.isRequired,
  /**
     * Visual size variant.
     * @default 'm'
     */
  size: _propTypes.default.any,
  /**
     * Defines the announcement background color.
     * @default 'highlighted'
     */
  color: _propTypes.default.oneOf(["highlighted", "plain"]),
  /** Optional action buttons. */actionProps: _propTypes.default.shape({
    /** Primary call-to-action, rendered as an `EuiButton`. */primary: _propTypes.default.any,
    /** Secondary action, rendered as an `EuiButtonEmpty`. Is only rendered when a primary action is available. */secondary: _propTypes.default.any
  }),
  /**
     * When provided, a dismiss button is rendered in the top-right corner and
     * this callback fires when the user activates it.
     */
  onDismiss: _propTypes.default.func,
  /** Extra props spread onto the dismiss `EuiButtonIcon`. */dismissButtonProps: _propTypes.default.shape({
    "aria-label": _propTypes.default.string,
    "aria-labelledby": _propTypes.default.string,
    /**
       * Overall size of button.
       * Matches the sizes of other EuiButtons
       */
    size: _propTypes.default.any,
    /**
       * Size of the icon only.
       * This will not affect the overall size of the button
       */
    iconSize: _propTypes.default.any,
    /**
       * Applies the boolean state as the `aria-pressed` property to create a toggle button.
       * *Only use when the readable text does not change between states.*
       */
    isSelected: _propTypes.default.bool,
    /**
       * Sets the display style for matching other EuiButton types.
       * `base` is equivalent to a typical EuiButton
       * `fill` is equivalent to a filled EuiButton
       * `empty` (default) is equivalent to an EuiButtonEmpty
       */
    display: _propTypes.default.any,
    /**
       * Disables the button and changes the icon to a loading spinner
       */
    isLoading: _propTypes.default.bool,
    className: _propTypes.default.string,
    "data-test-subj": _propTypes.default.string,
    css: _propTypes.default.any,
    /**
       * Controls the disabled behavior via the native `disabled` attribute.
       */
    isDisabled: _propTypes.default.bool,
    /**
       * NOTE: Beta feature, may be changed or removed in the future
       *
       * Changes the native `disabled` attribute to `aria-disabled` to preserve focusability.
       * This results in a semantically disabled button without the default browser handling of the disabled state.
       *
       * Use e.g. when a disabled button should have a tooltip.
       */
    hasAriaDisabled: _propTypes.default.bool
  }),
  /**
     * When set to `true`, the content is announced by screen readers on mount.
     * Use only when the announcement is immediately relevant, e.g. as feedback to user actions.
     * Avoid using on initial page load as it may create noise for assistive technology users.
     *
     * @default false
     */
  announceOnMount: _propTypes.default.bool
};
EuiBanner.displayName = 'EuiBanner';

// jsdom has no `innerText`, so tests read `textContent`
var readText = function readText(node) {
  var _ref2, _innerText;
  return (_ref2 = (_innerText = node === null || node === void 0 ? void 0 : node.innerText) !== null && _innerText !== void 0 ? _innerText : node === null || node === void 0 ? void 0 : node.textContent) === null || _ref2 === void 0 ? void 0 : _ref2.trim();
};