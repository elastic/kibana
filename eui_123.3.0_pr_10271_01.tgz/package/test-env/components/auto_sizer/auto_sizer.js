"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.EuiAutoSizer = void 0;
var _react = _interopRequireWildcard(require("react"));
var _react2 = require("@emotion/react");
var cache;
function _interopRequireWildcard(e, t) { if (!t && e && e.__esModule) return e; var r, c, a = Object.defineProperty, n = { __proto__: null, default: e }; if (Object(e) !== e) return n; if (cache || "function" != typeof WeakMap || (cache = new WeakMap()), cache) { if (cache.has(e)) return cache.get(e); cache.set(e, n); } for (c in e) "default" !== c && {}.hasOwnProperty.call(e, c) && ((r = a && Object.getOwnPropertyDescriptor(e, c)) && (r.get || r.set) ? a(n, c, r) : n[c] = e[c]); return n; }
/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */

var EuiAutoSizer = exports.EuiAutoSizer = function EuiAutoSizer(_ref) {
  var children = _ref.children,
    defaultHeight = _ref.defaultHeight,
    defaultWidth = _ref.defaultWidth,
    onResize = _ref.onResize;
  var childrenParams = {
    height: defaultHeight !== null && defaultHeight !== void 0 ? defaultHeight : 600,
    width: defaultWidth !== null && defaultWidth !== void 0 ? defaultWidth : 600
  };
  (0, _react.useEffect)(function () {
    onResize === null || onResize === void 0 || onResize(childrenParams);
  }, [onResize, defaultHeight, defaultWidth]); // eslint-disable-line react-hooks/exhaustive-deps

  return (0, _react2.jsx)("div", {
    "data-eui": "EuiAutoSizer"
  }, children(childrenParams));
};