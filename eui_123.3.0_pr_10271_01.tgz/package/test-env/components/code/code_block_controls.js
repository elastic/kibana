"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.EuiCodeBlockControls = void 0;
var _react = _interopRequireWildcard(require("react"));
var _services = require("../../services");
var _code_block_controls = require("./code_block_controls.styles");
var _react2 = require("@emotion/react");
var cache;
function _interopRequireWildcard(e, t) { if (!t && e && e.__esModule) return e; var r, c, a = Object.defineProperty, n = { __proto__: null, default: e }; if (Object(e) !== e) return n; if (cache || "function" != typeof WeakMap || (cache = new WeakMap()), cache) { if (cache.has(e)) return cache.get(e); cache.set(e, n); } for (c in e) "default" !== c && {}.hasOwnProperty.call(e, c) && ((r = a && Object.getOwnPropertyDescriptor(e, c)) && (r.get || r.set) ? a(n, c, r) : n[c] = e[c]); return n; }
/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */

var EuiCodeBlockControls = exports.EuiCodeBlockControls = function EuiCodeBlockControls(_ref) {
  var paddingSize = _ref.paddingSize,
    controls = _ref.controls;
  var styles = (0, _services.useEuiMemoizedStyles)(_code_block_controls.euiCodeBlockControlsStyles);
  var cssStyles = [styles.euiCodeBlock__controls, styles.offset[paddingSize]];
  var hasControls = controls.some(function (control) {
    return !!control;
  });
  return hasControls ? (0, _react2.jsx)("div", {
    className: "euiCodeBlock__controls",
    css: cssStyles
  }, controls.map(function (control, i) {
    return (0, _react2.jsx)(_react.Fragment, {
      key: i
    }, control);
  })) : null;
};