"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.EuiButtonResetProvider = exports.EuiButtonContext = void 0;
var _react = _interopRequireWildcard(require("react"));
var _react2 = require("@emotion/react");
var cache;
function _interopRequireWildcard(e, t) { if (!t && e && e.__esModule) return e; var r, c, a = Object.defineProperty, n = { __proto__: null, default: e }; if (Object(e) !== e) return n; if (cache || "function" != typeof WeakMap || (cache = new WeakMap()), cache) { if (cache.has(e)) return cache.get(e); cache.set(e, n); } for (c in e) "default" !== c && {}.hasOwnProperty.call(e, c) && ((r = a && Object.getOwnPropertyDescriptor(e, c)) && (r.get || r.set) ? a(n, c, r) : n[c] = e[c]); return n; }
/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */

/**
 * Cascades button props from a parent component (e.g. EuiButtonGroup) down
 * to button children.
 *
 * When set, context values take precedence over the same prop passed directly,
 * except for `isDisabled`/`hasAriaDisabled` which should only ever be populated
 * with `true` (never `false`). Otherwise the parent would enable manually
 * disabled children.
 */
var EuiButtonContext = exports.EuiButtonContext = /*#__PURE__*/(0, _react.createContext)({});

/**
 * Resets inherited EuiButtonContext values for descendant buttons.
 * Used by components like EuiPopover that render buttons in a separate
 * visual context where group cascading should not apply.
 */
var EuiButtonResetProvider = exports.EuiButtonResetProvider = function EuiButtonResetProvider(_ref) {
  var children = _ref.children;
  return (0, _react2.jsx)(EuiButtonContext.Provider, {
    value: {}
  }, children);
};