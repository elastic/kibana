"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.I18nContext = exports.EuiI18nConsumer = exports.EuiContext = void 0;
var _react = _interopRequireWildcard(require("react"));
var _propTypes = _interopRequireDefault(require("prop-types"));
var _react2 = require("@emotion/react");
var cache;
function _interopRequireWildcard(e, t) { if (!t && e && e.__esModule) return e; var r, c, a = Object.defineProperty, n = { __proto__: null, default: e }; if (Object(e) !== e) return n; if (cache || "function" != typeof WeakMap || (cache = new WeakMap()), cache) { if (cache.has(e)) return cache.get(e); cache.set(e, n); } for (c in e) "default" !== c && {}.hasOwnProperty.call(e, c) && ((r = a && Object.getOwnPropertyDescriptor(e, c)) && (r.get || r.set) ? a(n, c, r) : n[c] = e[c]); return n; }
/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */

var I18nContext = exports.I18nContext = /*#__PURE__*/(0, _react.createContext)({});
var EuiI18nProvider = I18nContext.Provider,
  EuiI18nConsumer = exports.EuiI18nConsumer = I18nContext.Consumer;
var EuiContext = exports.EuiContext = function EuiContext(_ref) {
  var _ref$i18n = _ref.i18n,
    i18n = _ref$i18n === void 0 ? {} : _ref$i18n,
    children = _ref.children;
  return (0, _react2.jsx)(EuiI18nProvider, {
    value: i18n
  }, children);
};
EuiContext.propTypes = {
  i18n: _propTypes.default.shape({
    mapping: _propTypes.default.shape({}),
    mappingFunc: _propTypes.default.func,
    /**
       * Some browsers' translation features don't work with a rendered `<Fragment>` component.
       * The `render` function allows you to pass in another component instead, e.g. `<div>`
       */
    render: _propTypes.default.func,
    formatNumber: _propTypes.default.func,
    formatDateTime: _propTypes.default.func,
    locale: _propTypes.default.string
  }).isRequired,
  /**
     * ReactNode to render as this component's content
     */
  children: _propTypes.default.node.isRequired
};