"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
var _slicedToArray2 = _interopRequireDefault(require("@babel/runtime/helpers/slicedToArray"));
var _react = _interopRequireWildcard(require("react"));
var _delay_hide = require("./delay_hide");
var _form = require("../form");
var _flex = require("../flex");
var _loading = require("../loading");
var _react2 = require("@emotion/react");
var cache;
function _interopRequireWildcard(e, t) { if (!t && e && e.__esModule) return e; var r, c, a = Object.defineProperty, n = { __proto__: null, default: e }; if (Object(e) !== e) return n; if (cache || "function" != typeof WeakMap || (cache = new WeakMap()), cache) { if (cache.has(e)) return cache.get(e); cache.set(e, n); } for (c in e) "default" !== c && {}.hasOwnProperty.call(e, c) && ((r = a && Object.getOwnPropertyDescriptor(e, c)) && (r.get || r.set) ? a(n, c, r) : n[c] = e[c]); return n; }
/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */

/// <reference types="cypress" />
/// <reference types="cypress-real-events" />
/// <reference types="../../../cypress/support" />

var DelayHide = function DelayHide() {
  var _useState = (0, _react.useState)(1000),
    _useState2 = (0, _slicedToArray2.default)(_useState, 2),
    minimumDuration = _useState2[0],
    setDuration = _useState2[1];
  var _useState3 = (0, _react.useState)(false),
    _useState4 = (0, _slicedToArray2.default)(_useState3, 2),
    hide = _useState4[0],
    setHide = _useState4[1];
  return (0, _react2.jsx)(_react.default.Fragment, null, (0, _react2.jsx)(_flex.EuiFlexItem, null, (0, _react2.jsx)(_form.EuiFormRow, null, (0, _react2.jsx)(_form.EuiCheckbox, {
    id: "dummy-id",
    checked: hide,
    onChange: function onChange(event) {
      return setHide(event.target.checked);
    },
    label: "Hide child"
  })), (0, _react2.jsx)(_form.EuiFormRow, {
    label: "Minimum duration"
  }, (0, _react2.jsx)(_form.EuiFieldNumber, {
    value: minimumDuration,
    onChange: function onChange(event) {
      return setDuration(parseInt(event.target.value, 10));
    }
  })), (0, _react2.jsx)(_form.EuiFormRow, {
    label: "Child to render"
  }, (0, _react2.jsx)(_delay_hide.EuiDelayHide, {
    hide: hide,
    minimumDuration: minimumDuration,
    render: function render() {
      return (0, _react2.jsx)(_loading.EuiLoadingSpinner, {
        size: "m"
      });
    }
  }))));
};
beforeEach(function () {
  cy.realMount((0, _react2.jsx)(DelayHide, null));
});
describe('EuiHideRender', function () {
  describe('Automated accessibility check', function () {
    it('has zero violations on first render', function () {
      cy.checkAxe();
    });
    it('has zero violations when the hide child input is checked', function () {
      cy.get('input.euiCheckbox__input').realClick();
      cy.get('div.euiFormRow__fieldWrapper').last().find('span[role="progressbar"]', {
        timeout: 5000
      }).should('not.exist');
      cy.checkAxe();
    });
    it('has zero violations when the hide child input is pressed', function () {
      cy.realPress('Tab');
      cy.get('input.euiCheckbox__input').should('have.focus');
      cy.realPress('Space');
      cy.get('div.euiFormRow__fieldWrapper').last().find('span[role="progressbar"]', {
        timeout: 5000
      }).should('not.exist');
      cy.checkAxe();
    });
    it('has zero violations when the hide child input is toggled', function () {
      cy.realPress('Tab');
      cy.get('input.euiCheckbox__input').should('have.focus');
      cy.realPress('Space');
      cy.get('div.euiFormRow__fieldWrapper').last().find('span[role="progressbar"]').should('not.exist');
      cy.realPress('Space');
      cy.get('div.euiFormRow__fieldWrapper').last().find('span[role="progressbar"]', {
        timeout: 5000
      }).should('exist');
      cy.checkAxe();
    });
  });
});