"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.EuiAccordionChildren = void 0;
var _extends2 = _interopRequireDefault(require("@babel/runtime/helpers/extends"));
var _slicedToArray2 = _interopRequireDefault(require("@babel/runtime/helpers/slicedToArray"));
var _objectWithoutProperties2 = _interopRequireDefault(require("@babel/runtime/helpers/objectWithoutProperties"));
var _react = _interopRequireWildcard(require("react"));
var _propTypes = _interopRequireDefault(require("prop-types"));
var _classnames = _interopRequireDefault(require("classnames"));
var _services = require("../../../services");
var _resize_observer = require("../../observer/resize_observer");
var _accordion_children_loading = require("./accordion_children_loading");
var _accordion_children = require("./accordion_children.styles");
var _react2 = require("@emotion/react");
var _excluded = ["role", "children", "paddingSize", "isLoading", "isLoadingMessage", "isOpen", "initialIsOpen"];
/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */
var cache;
function _interopRequireWildcard(e, t) { if (!t && e && e.__esModule) return e; var r, c, a = Object.defineProperty, n = { __proto__: null, default: e }; if (Object(e) !== e) return n; if (cache || "function" != typeof WeakMap || (cache = new WeakMap()), cache) { if (cache.has(e)) return cache.get(e); cache.set(e, n); } for (c in e) "default" !== c && {}.hasOwnProperty.call(e, c) && ((r = a && Object.getOwnPropertyDescriptor(e, c)) && (r.get || r.set) ? a(n, c, r) : n[c] = e[c]); return n; }
var EuiAccordionChildren = exports.EuiAccordionChildren = function EuiAccordionChildren(_ref) {
  var role = _ref.role,
    children = _ref.children,
    paddingSize = _ref.paddingSize,
    isLoading = _ref.isLoading,
    isLoadingMessage = _ref.isLoadingMessage,
    isOpen = _ref.isOpen,
    initialIsOpen = _ref.initialIsOpen,
    rest = (0, _objectWithoutProperties2.default)(_ref, _excluded);
  /**
   * Children
   */
  var classes = (0, _classnames.default)('euiAccordion__children', {
    'euiAccordion__children-isLoading': isLoading
  });
  var styles = (0, _services.useEuiMemoizedStyles)(_accordion_children.euiAccordionChildrenStyles);
  var cssStyles = [styles.euiAccordion__children, isLoading && styles.isLoading, paddingSize && paddingSize !== 'none' && styles[paddingSize]];

  /**
   * Wrapper
   */
  var _useState = (0, _react.useState)(false),
    _useState2 = (0, _slicedToArray2.default)(_useState, 2),
    hasTransition = _useState2[0],
    setHasTransition = _useState2[1];
  var wrapperStyles = (0, _services.useEuiMemoizedStyles)(_accordion_children.euiAccordionChildWrapperStyles);
  var wrapperCssStyles = [wrapperStyles.euiAccordion__childWrapper, isOpen ? wrapperStyles.isOpen : wrapperStyles.isClosed, initialIsOpen && !hasTransition && isOpen && wrapperStyles.noTransition];

  /* Controls enabling opening/closing transitions on first interaction
  when initialIsOpen=true; this only runs once */
  (0, _react.useEffect)(function () {
    if (initialIsOpen && !isOpen && !hasTransition) {
      setHasTransition(true);
    }
  }, [isOpen, initialIsOpen, hasTransition]);

  /**
   * Update the accordion wrapper height whenever the accordion opens, and also
   * whenever the child content updates (which will change the height)
   */
  var _useState3 = (0, _react.useState)(0),
    _useState4 = (0, _slicedToArray2.default)(_useState3, 2),
    contentHeight = _useState4[0],
    setContentHeight = _useState4[1];
  var onResize = (0, _react.useCallback)(function (_ref2) {
    var height = _ref2.height;
    return setContentHeight(Math.round(height));
  }, []);
  var heightInlineStyle = (0, _react.useMemo)(function () {
    return {
      blockSize: isOpen ? contentHeight : 0
    };
  }, [isOpen, contentHeight]);
  return (0, _react2.jsx)("div", (0, _extends2.default)({}, rest, {
    className: "euiAccordion__childWrapper",
    css: wrapperCssStyles,
    style: heightInlineStyle,
    role: role
    // @ts-expect-error - inert property not yet available in React TS defs. TODO: Remove this once https://github.com/DefinitelyTyped/DefinitelyTyped/pull/60822 is merged
    ,
    inert: !isOpen ? '' : undefined // Can't pass a boolean currently, Jest throws errors
  }), (0, _react2.jsx)(_resize_observer.EuiResizeObserver, {
    onResize: onResize
  }, function (resizeRef) {
    return (0, _react2.jsx)("div", {
      ref: resizeRef,
      className: classes,
      css: cssStyles
    }, isLoading && isLoadingMessage ? (0, _react2.jsx)(_accordion_children_loading.EuiAccordionChildrenLoading, {
      isLoadingMessage: isLoadingMessage
    }) : children);
  }));
};
EuiAccordionChildren.propTypes = {
  isOpen: _propTypes.default.bool.isRequired
};