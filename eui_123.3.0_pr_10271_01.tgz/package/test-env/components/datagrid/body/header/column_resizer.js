"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.EuiDataGridColumnResizer = void 0;
var _slicedToArray2 = _interopRequireDefault(require("@babel/runtime/helpers/slicedToArray"));
var _react = _interopRequireWildcard(require("react"));
var _propTypes = _interopRequireDefault(require("prop-types"));
var _services = require("../../../../services");
var _global_styling = require("../../../../global_styling");
var _draggable_columns = require("./draggable_columns");
var _column_resizer = require("./column_resizer.styles");
var _react2 = require("@emotion/react");
var cache;
function _interopRequireWildcard(e, t) { if (!t && e && e.__esModule) return e; var r, c, a = Object.defineProperty, n = { __proto__: null, default: e }; if (Object(e) !== e) return n; if (cache || "function" != typeof WeakMap || (cache = new WeakMap()), cache) { if (cache.has(e)) return cache.get(e); cache.set(e, n); } for (c in e) "default" !== c && {}.hasOwnProperty.call(e, c) && ((r = a && Object.getOwnPropertyDescriptor(e, c)) && (r.get || r.set) ? a(n, c, r) : n[c] = e[c]); return n; }
/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */

var MINIMUM_COLUMN_WIDTH = 40;
var EuiDataGridColumnResizer = exports.EuiDataGridColumnResizer = function EuiDataGridColumnResizer(_ref) {
  var columnId = _ref.columnId,
    columnWidth = _ref.columnWidth,
    setColumnWidth = _ref.setColumnWidth,
    isLastColumn = _ref.isLastColumn;
  var styles = (0, _services.useEuiMemoizedStyles)(_column_resizer.euiDataGridColumnResizerStyles);
  var _useState = (0, _react.useState)(0),
    _useState2 = (0, _slicedToArray2.default)(_useState, 2),
    offset = _useState2[0],
    setOffset = _useState2[1];
  var initialX = (0, _react.useRef)(0);

  // Handlers are bound to `window`, so they must stay stable to be removed
  // and read current values from a ref
  var latest = (0, _services.useLatest)({
    columnId: columnId,
    columnWidth: columnWidth,
    setColumnWidth: setColumnWidth,
    offset: offset
  });
  var onMouseMove = (0, _react.useCallback)(function (e) {
    var _ref2 = latest.current,
      columnWidth = _ref2.columnWidth;
    setOffset(Math.max(e.pageX - initialX.current, -(columnWidth - MINIMUM_COLUMN_WIDTH)));
  }, [latest]);
  var onMouseUp = (0, _react.useCallback)(function () {
    var _ref3 = latest.current,
      columnId = _ref3.columnId,
      columnWidth = _ref3.columnWidth,
      setColumnWidth = _ref3.setColumnWidth,
      offset = _ref3.offset;
    setColumnWidth(columnId, Math.max(MINIMUM_COLUMN_WIDTH, columnWidth + offset));
    setOffset(0);
    window.removeEventListener('mouseup', onMouseUp);
    window.removeEventListener('blur', onMouseUp);
    window.removeEventListener('mousemove', onMouseMove);
  }, [latest, onMouseMove]);
  var onMouseDown = (0, _react.useCallback)(function (e) {
    initialX.current = e.pageX;
    window.addEventListener('mouseup', onMouseUp);
    window.addEventListener('blur', onMouseUp);
    window.addEventListener('mousemove', onMouseMove);

    // don't let this action steal focus
    e.preventDefault();
  }, [onMouseUp, onMouseMove]);

  // Clean up listeners if unmounted mid-drag
  (0, _react.useEffect)(function () {
    return function () {
      window.removeEventListener('mouseup', onMouseUp);
      window.removeEventListener('blur', onMouseUp);
      window.removeEventListener('mousemove', onMouseMove);
    };
  }, [onMouseUp, onMouseMove]);
  var cssStyles = [styles.euiDataGridColumnResizer, isLastColumn && styles.isLastColumn, offset && styles.isDragging];
  return (0, _react2.jsx)("div", {
    css: cssStyles,
    className: "euiDataGridColumnResizer",
    "data-test-subj": "dataGridColumnResizer",
    style: offset ? (0, _global_styling.logicalStyle)('margin-right', "".concat(-offset, "px")) : undefined,
    onMouseDown: onMouseDown
  }, (0, _react2.jsx)(_draggable_columns.DragOverlay, {
    isDragging: !!offset,
    cursor: "ew-resize"
  }));
};
EuiDataGridColumnResizer.propTypes = {
  columnId: _propTypes.default.string.isRequired,
  columnWidth: _propTypes.default.number.isRequired,
  setColumnWidth: _propTypes.default.func.isRequired,
  isLastColumn: _propTypes.default.bool.isRequired
};