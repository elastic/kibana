"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.useDataGridHeader = void 0;
var _extends2 = _interopRequireDefault(require("@babel/runtime/helpers/extends"));
var _slicedToArray2 = _interopRequireDefault(require("@babel/runtime/helpers/slicedToArray"));
var _react = _interopRequireWildcard(require("react"));
var _resize_observer = require("../../../observer/resize_observer");
var _data_grid_header_row = require("./data_grid_header_row");
var _react2 = require("@emotion/react");
var cache;
function _interopRequireWildcard(e, t) { if (!t && e && e.__esModule) return e; var r, c, a = Object.defineProperty, n = { __proto__: null, default: e }; if (Object(e) !== e) return n; if (cache || "function" != typeof WeakMap || (cache = new WeakMap()), cache) { if (cache.has(e)) return cache.get(e); cache.set(e, n); } for (c in e) "default" !== c && {}.hasOwnProperty.call(e, c) && ((r = a && Object.getOwnPropertyDescriptor(e, c)) && (r.get || r.set) ? a(n, c, r) : n[c] = e[c]); return n; }
/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */

/**
 * DRY out setting up the grid header and its refs & observers
 */
var useDataGridHeader = exports.useDataGridHeader = function useDataGridHeader(props) {
  var _useState = (0, _react.useState)(null),
    _useState2 = (0, _slicedToArray2.default)(_useState, 2),
    headerRowRef = _useState2[0],
    setHeaderRowRef = _useState2[1];
  var _useResizeObserver = (0, _resize_observer.useResizeObserver)(headerRowRef, 'height'),
    headerRowHeight = _useResizeObserver.height;
  var headerRow = (0, _react.useMemo)(function () {
    return (0, _react2.jsx)(_data_grid_header_row.EuiDataGridHeaderRow, (0, _extends2.default)({
      ref: setHeaderRowRef
    }, props));
  }, [props]);
  return (0, _react.useMemo)(function () {
    return {
      headerRow: headerRow,
      headerRowHeight: headerRowHeight
    };
  }, [headerRow, headerRowHeight]);
};