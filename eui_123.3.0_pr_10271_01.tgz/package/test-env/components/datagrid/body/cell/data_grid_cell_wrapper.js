"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.CellWrapper = void 0;
var _extends2 = _interopRequireDefault(require("@babel/runtime/helpers/extends"));
var _defineProperty2 = _interopRequireDefault(require("@babel/runtime/helpers/defineProperty"));
var _objectWithoutProperties2 = _interopRequireDefault(require("@babel/runtime/helpers/objectWithoutProperties"));
var _react = _interopRequireWildcard(require("react"));
var _classnames = _interopRequireDefault(require("classnames"));
var _sorting = require("../../utils/sorting");
var _data_grid_cell_popover = require("./data_grid_cell_popover");
var _data_grid_cell = require("./data_grid_cell");
var _react2 = require("@emotion/react");
var _excluded = ["colIndex", "visibleRowIndex", "style", "schema", "schemaDetectors", "pagination", "columns", "leadingControlColumns", "trailingControlColumns", "visibleColCount", "columnWidths", "defaultColumnWidth", "renderCellValue", "cellContext", "renderCellPopover", "interactiveCellId", "setRowHeight", "rowHeightsOptions", "rowHeightUtils", "rowManager"];
/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */
var cache;
function _interopRequireWildcard(e, t) { if (!t && e && e.__esModule) return e; var r, c, a = Object.defineProperty, n = { __proto__: null, default: e }; if (Object(e) !== e) return n; if (cache || "function" != typeof WeakMap || (cache = new WeakMap()), cache) { if (cache.has(e)) return cache.get(e); cache.set(e, n); } for (c in e) "default" !== c && {}.hasOwnProperty.call(e, c) && ((r = a && Object.getOwnPropertyDescriptor(e, c)) && (r.get || r.set) ? a(n, c, r) : n[c] = e[c]); return n; }
/**
 * A DRY wrapper used by both custom and virtualized grid cells.
 * It grabs context,  determines the type of cell being rendered
 * (e.g. control vs data cell), & sets shared props between all cells
 */
var CellWrapper = exports.CellWrapper = /*#__PURE__*/(0, _react.memo)(function (_ref) {
  var colIndex = _ref.colIndex,
    visibleRowIndex = _ref.visibleRowIndex,
    style = _ref.style,
    schema = _ref.schema,
    schemaDetectors = _ref.schemaDetectors,
    pagination = _ref.pagination,
    columns = _ref.columns,
    leadingControlColumns = _ref.leadingControlColumns,
    trailingControlColumns = _ref.trailingControlColumns,
    visibleColCount = _ref.visibleColCount,
    columnWidths = _ref.columnWidths,
    defaultColumnWidth = _ref.defaultColumnWidth,
    renderCellValue = _ref.renderCellValue,
    cellContext = _ref.cellContext,
    renderCellPopover = _ref.renderCellPopover,
    interactiveCellId = _ref.interactiveCellId,
    setRowHeight = _ref.setRowHeight,
    rowHeightsOptions = _ref.rowHeightsOptions,
    rowHeightUtils = _ref.rowHeightUtils,
    rowManager = _ref.rowManager,
    rest = (0, _objectWithoutProperties2.default)(_ref, _excluded);
  var popoverContext = (0, _react.useContext)(_data_grid_cell_popover.DataGridCellPopoverContext);
  var _useContext = (0, _react.useContext)(_sorting.DataGridSortedContext),
    getCorrectRowIndex = _useContext.getCorrectRowIndex;
  var isFirstColumn = colIndex === 0;
  var isLastColumn = colIndex === visibleColCount - 1;
  var isLastCopyColumn = columns.length > 0 && colIndex === leadingControlColumns.length + columns.length - 1;
  var isLeadingControlColumn = colIndex < leadingControlColumns.length;
  var isTrailingControlColumn = colIndex >= leadingControlColumns.length + columns.length;
  var datacolIndex = colIndex - leadingControlColumns.length;
  var column = columns[datacolIndex];
  var columnId = column === null || column === void 0 ? void 0 : column.id;
  var textTransform = (0, _react.useMemo)(function () {
    var _schemaDetectors$filt;
    return (_schemaDetectors$filt = schemaDetectors.filter(function (row) {
      return column !== null && column !== void 0 && column.schema ? (column === null || column === void 0 ? void 0 : column.schema) === row.type : columnId === row.type;
    })[0]) === null || _schemaDetectors$filt === void 0 ? void 0 : _schemaDetectors$filt.textTransform;
  }, [columnId, column === null || column === void 0 ? void 0 : column.schema, schemaDetectors]);
  var sharedCellProps = (0, _react.useMemo)(function () {
    var classes = (0, _classnames.default)((0, _defineProperty2.default)({
      'euiDataGridRowCell--firstColumn': isFirstColumn,
      'euiDataGridRowCell--lastColumn': isLastColumn,
      'euiDataGridRowCell--controlColumn': isLeadingControlColumn || isTrailingControlColumn
    }, "euiDataGridRowCell--".concat(textTransform), textTransform));
    return {
      rowIndex: getCorrectRowIndex(visibleRowIndex),
      visibleRowIndex: visibleRowIndex,
      colIndex: colIndex,
      interactiveCellId: interactiveCellId,
      className: classes,
      style: style,
      rowHeightsOptions: rowHeightsOptions,
      rowHeightUtils: rowHeightUtils,
      setRowHeight: isFirstColumn ? setRowHeight : undefined,
      rowManager: rowManager,
      popoverContext: popoverContext,
      pagination: pagination,
      cellContext: cellContext,
      isLastCopyColumn: isLastCopyColumn
    };
  }, [colIndex, setRowHeight, visibleRowIndex, getCorrectRowIndex, interactiveCellId, style, rowHeightsOptions, rowHeightUtils, rowManager, popoverContext, pagination, cellContext, isFirstColumn, isLastColumn, isLastCopyColumn, isLeadingControlColumn, isTrailingControlColumn, textTransform]);
  if (isLeadingControlColumn) {
    var leadingColumn = leadingControlColumns[colIndex];
    var id = leadingColumn.id,
      rowCellRender = leadingColumn.rowCellRender;
    return (0, _react2.jsx)(_data_grid_cell.EuiDataGridCell, (0, _extends2.default)({}, sharedCellProps, {
      columnId: id,
      width: leadingColumn.width,
      renderCellValue: rowCellRender,
      isExpandable: false
    }, rest));
  } else if (isTrailingControlColumn) {
    var columnOffset = columns.length + leadingControlColumns.length;
    var trailingcolIndex = colIndex - columnOffset;
    var trailingColumn = trailingControlColumns[trailingcolIndex];
    var _id = trailingColumn.id,
      _rowCellRender = trailingColumn.rowCellRender;
    return (0, _react2.jsx)(_data_grid_cell.EuiDataGridCell, (0, _extends2.default)({}, sharedCellProps, {
      columnId: _id,
      width: trailingColumn.width,
      renderCellValue: _rowCellRender,
      isExpandable: false
    }, rest));
  } else {
    // this is a normal data cell
    var columnType = schema[columnId] ? schema[columnId].columnType : null;
    var isExpandable = (column === null || column === void 0 ? void 0 : column.isExpandable) !== undefined ? column === null || column === void 0 ? void 0 : column.isExpandable : true;
    var width = columnWidths[columnId] || defaultColumnWidth;
    return (0, _react2.jsx)(_data_grid_cell.EuiDataGridCell, (0, _extends2.default)({}, sharedCellProps, {
      columnId: columnId,
      column: column,
      columnType: columnType,
      width: width || undefined,
      renderCellValue: renderCellValue,
      renderCellPopover: renderCellPopover,
      interactiveCellId: interactiveCellId,
      isExpandable: isExpandable
    }, rest));
  }
});
CellWrapper.displayName = 'CellWrapper';