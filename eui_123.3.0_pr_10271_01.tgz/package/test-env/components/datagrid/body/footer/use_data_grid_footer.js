"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.useDataGridFooter = void 0;
var _extends2 = _interopRequireDefault(require("@babel/runtime/helpers/extends"));
var _objectWithoutProperties2 = _interopRequireDefault(require("@babel/runtime/helpers/objectWithoutProperties"));
var _slicedToArray2 = _interopRequireDefault(require("@babel/runtime/helpers/slicedToArray"));
var _react = _interopRequireWildcard(require("react"));
var _resize_observer = require("../../../observer/resize_observer");
var _data_grid_footer_row = require("./data_grid_footer_row");
var _react2 = require("@emotion/react");
var _excluded = ["renderFooterCellValue"];
/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */
var cache;
function _interopRequireWildcard(e, t) { if (!t && e && e.__esModule) return e; var r, c, a = Object.defineProperty, n = { __proto__: null, default: e }; if (Object(e) !== e) return n; if (cache || "function" != typeof WeakMap || (cache = new WeakMap()), cache) { if (cache.has(e)) return cache.get(e); cache.set(e, n); } for (c in e) "default" !== c && {}.hasOwnProperty.call(e, c) && ((r = a && Object.getOwnPropertyDescriptor(e, c)) && (r.get || r.set) ? a(n, c, r) : n[c] = e[c]); return n; }
/**
 * DRY out setting up the grid footer and its refs & observers
 */
var useDataGridFooter = exports.useDataGridFooter = function useDataGridFooter(props) {
  var _useState = (0, _react.useState)(null),
    _useState2 = (0, _slicedToArray2.default)(_useState, 2),
    footerRowRef = _useState2[0],
    setFooterRowRef = _useState2[1];
  var _useResizeObserver = (0, _resize_observer.useResizeObserver)(footerRowRef, 'height'),
    footerRowHeight = _useResizeObserver.height;
  var footerRow = (0, _react.useMemo)(function () {
    var renderFooterCellValue = props.renderFooterCellValue,
      footerProps = (0, _objectWithoutProperties2.default)(props, _excluded);
    if (renderFooterCellValue == null) return null;
    return (0, _react2.jsx)(_data_grid_footer_row.EuiDataGridFooterRow, (0, _extends2.default)({
      ref: setFooterRowRef,
      renderCellValue: renderFooterCellValue
    }, footerProps));
  }, [props]);
  return {
    footerRow: footerRow,
    footerRowHeight: footerRowHeight
  };
};