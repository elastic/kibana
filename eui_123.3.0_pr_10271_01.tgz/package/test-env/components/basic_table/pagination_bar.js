"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.PaginationBar = void 0;
var _react = _interopRequireWildcard(require("react"));
var _services = require("../../services");
var _table_pagination = require("../table/table_pagination");
var _responsive_context = require("../table/mobile/responsive_context");
var _pagination_bar = require("./pagination_bar.styles");
var _react2 = require("@emotion/react");
var cache;
function _interopRequireWildcard(e, t) { if (!t && e && e.__esModule) return e; var r, c, a = Object.defineProperty, n = { __proto__: null, default: e }; if (Object(e) !== e) return n; if (cache || "function" != typeof WeakMap || (cache = new WeakMap()), cache) { if (cache.has(e)) return cache.get(e); cache.set(e, n); } for (c in e) "default" !== c && {}.hasOwnProperty.call(e, c) && ((r = a && Object.getOwnPropertyDescriptor(e, c)) && (r.get || r.set) ? a(n, c, r) : n[c] = e[c]); return n; }
/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */

/**
 * @internal
 */

/**
 * An internal utility component that renders EuiTablePagination with
 * proper configuration and handles the `panelled` styles.
 * @internal
 */
var PaginationBar = exports.PaginationBar = function PaginationBar(_ref) {
  var pagination = _ref.pagination,
    panelled = _ref.panelled,
    responsiveBreakpoint = _ref.responsiveBreakpoint,
    onPageSizeChange = _ref.onPageSizeChange,
    onPageChange = _ref.onPageChange,
    ariaControls = _ref['aria-controls'],
    ariaLabel = _ref['aria-label'];
  var defaults = (0, _table_pagination.useEuiTablePaginationDefaults)();
  var pageIndex = pagination.pageIndex,
    totalItemCount = pagination.totalItemCount,
    _pagination$pageSize = pagination.pageSize,
    pageSize = _pagination$pageSize === void 0 ? defaults.itemsPerPage : _pagination$pageSize,
    _pagination$pageSizeO = pagination.pageSizeOptions,
    pageSizeOptions = _pagination$pageSizeO === void 0 ? defaults.itemsPerPageOptions : _pagination$pageSizeO,
    _pagination$showPerPa = pagination.showPerPageOptions,
    showPerPageOptions = _pagination$showPerPa === void 0 ? defaults.showPerPageOptions : _pagination$showPerPa;
  var pageCount = pageSize ? Math.ceil(totalItemCount / pageSize) : 1;
  var styles = (0, _services.useEuiMemoizedStyles)(_pagination_bar.euiBasicTablePaginationBarStyles);
  var isResponsive = (0, _responsive_context.useIsEuiTableResponsive)(responsiveBreakpoint);
  (0, _react.useEffect)(function () {
    if (pageCount < pageIndex + 1) {
      onPageChange === null || onPageChange === void 0 || onPageChange(pageCount - 1);
    }
  }, [pageCount, onPageChange, pageIndex]);
  return (0, _react2.jsx)("div", {
    css: [styles.root, !isResponsive && panelled && styles.panelled, ";label:PaginationBar;"]
  }, (0, _react2.jsx)(_table_pagination.EuiTablePagination, {
    activePage: pageIndex,
    showPerPageOptions: showPerPageOptions,
    itemsPerPage: pageSize,
    itemsPerPageOptions: pageSizeOptions,
    pageCount: pageCount,
    onChangeItemsPerPage: onPageSizeChange,
    onChangePage: onPageChange,
    "aria-controls": ariaControls,
    "aria-label": ariaLabel
  }));
};