"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.DefaultItemAction = void 0;
var _react = _interopRequireWildcard(require("react"));
var _button = require("../button");
var _tool_tip = require("../tool_tip");
var _accessibility = require("../../services/accessibility");
var _accessibility2 = require("../accessibility");
var _action_types = require("./action_types");
var _react2 = require("@emotion/react");
var cache;
function _interopRequireWildcard(e, t) { if (!t && e && e.__esModule) return e; var r, c, a = Object.defineProperty, n = { __proto__: null, default: e }; if (Object(e) !== e) return n; if (cache || "function" != typeof WeakMap || (cache = new WeakMap()), cache) { if (cache.has(e)) return cache.get(e); cache.set(e, n); } for (c in e) "default" !== c && {}.hasOwnProperty.call(e, c) && ((r = a && Object.getOwnPropertyDescriptor(e, c)) && (r.get || r.set) ? a(n, c, r) : n[c] = e[c]); return n; }
/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */

var DefaultItemAction = exports.DefaultItemAction = function DefaultItemAction(_ref) {
  var action = _ref.action,
    enabled = _ref.enabled,
    item = _ref.item,
    className = _ref.className;
  if (!action.onClick && !action.href) {
    throw new Error("Cannot render item action [".concat(action.name, "]. Missing required 'onClick' callback\n      or 'href' string. If you want to provide a custom action control, make sure to define the 'render' callback"));
  }
  var onClick = (0, _react.useCallback)(function (event) {
    if (!action.onClick) return;
    event.persist(); // TODO: Remove once React 16 support is dropped
    action.onClick(item, event);
  }, [action.onClick, item]);
  var color = action.color ? (0, _action_types.callWithItemIfFunction)(item)(action.color) : 'text';
  var icon = action.icon ? (0, _action_types.callWithItemIfFunction)(item)(action.icon) : undefined;
  var actionContent = (0, _action_types.callWithItemIfFunction)(item)(action.name);
  var tooltipContent = (0, _action_types.callWithItemIfFunction)(item)(action.description);
  var tooltipProps = {
    content: tooltipContent,
    // Avoid screen-readers announcing the same text twice
    disableScreenReaderOutput: typeof actionContent === 'string' && actionContent === tooltipContent
  };
  var href = (0, _action_types.callWithItemIfFunction)(item)(action.href);
  var dataTestSubj = (0, _action_types.callWithItemIfFunction)(item)(action['data-test-subj']);
  var ariaLabelId = (0, _accessibility.useGeneratedHtmlId)();
  var ariaLabelledBy;
  var button;
  if (action.type === 'icon') {
    if (!icon) {
      throw new Error("Cannot render item action [".concat(action.name, "]. It is configured to render as an icon but no\n      icon is provided. Make sure to set the 'icon' property of the action"));
    }
    button = (0, _react2.jsx)(_button.EuiButtonIcon, {
      className: className,
      "aria-labelledby": ariaLabelId,
      isDisabled: !enabled,
      hasAriaDisabled: !enabled,
      color: color,
      iconType: icon,
      onClick: onClick,
      href: href,
      target: action.target,
      "data-test-subj": dataTestSubj
    });
    // actionContent (action.name) is a ReactNode and must be rendered
    // to an element and referenced by ID for screen readers
    ariaLabelledBy = (0, _react2.jsx)(_accessibility2.EuiScreenReaderOnly, null, (0, _react2.jsx)("span", {
      id: ariaLabelId
    }, actionContent));
  } else {
    button = (0, _react2.jsx)(_button.EuiButtonEmpty, {
      className: className,
      size: "s",
      isDisabled: !enabled,
      hasAriaDisabled: !enabled,
      color: color,
      iconType: icon,
      onClick: onClick,
      href: href,
      target: action.target,
      "data-test-subj": dataTestSubj,
      flush: "right"
    }, actionContent);
  }
  return (0, _react2.jsx)(_react.default.Fragment, null, (0, _react2.jsx)(_tool_tip.EuiToolTip, tooltipProps, button), ariaLabelledBy);
};