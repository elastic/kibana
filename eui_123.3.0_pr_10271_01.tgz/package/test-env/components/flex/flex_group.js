"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.JUSTIFY_CONTENTS = exports.GUTTER_SIZES = exports.EuiFlexGroup = exports.DIRECTIONS = exports.ALIGN_ITEMS = void 0;
var _extends2 = _interopRequireDefault(require("@babel/runtime/helpers/extends"));
var _objectWithoutProperties2 = _interopRequireDefault(require("@babel/runtime/helpers/objectWithoutProperties"));
var _react = _interopRequireWildcard(require("react"));
var _classnames = _interopRequireDefault(require("classnames"));
var _services = require("../../services");
var _flex_group = require("./flex_group.styles");
var _react2 = require("@emotion/react");
var _excluded = ["className", "component", "gutterSize", "alignItems", "responsive", "justifyContent", "direction", "wrap"];
/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */
var cache;
function _interopRequireWildcard(e, t) { if (!t && e && e.__esModule) return e; var r, c, a = Object.defineProperty, n = { __proto__: null, default: e }; if (Object(e) !== e) return n; if (cache || "function" != typeof WeakMap || (cache = new WeakMap()), cache) { if (cache.has(e)) return cache.get(e); cache.set(e, n); } for (c in e) "default" !== c && {}.hasOwnProperty.call(e, c) && ((r = a && Object.getOwnPropertyDescriptor(e, c)) && (r.get || r.set) ? a(n, c, r) : n[c] = e[c]); return n; }
var GUTTER_SIZES = exports.GUTTER_SIZES = ['none', 'xs', 's', 'm', 'l', 'xl'];
var ALIGN_ITEMS = exports.ALIGN_ITEMS = ['stretch', 'flexStart', 'flexEnd', 'center', 'baseline'];
var JUSTIFY_CONTENTS = exports.JUSTIFY_CONTENTS = ['flexStart', 'flexEnd', 'center', 'spaceBetween', 'spaceAround', 'spaceEvenly'];
var DIRECTIONS = exports.DIRECTIONS = ['row', 'rowReverse', 'column', 'columnReverse'];
var EuiFlexGroupInternal = function EuiFlexGroupInternal(_ref, ref) {
  var className = _ref.className,
    _ref$component = _ref.component,
    component = _ref$component === void 0 ? 'div' : _ref$component,
    _ref$gutterSize = _ref.gutterSize,
    gutterSize = _ref$gutterSize === void 0 ? 'm' : _ref$gutterSize,
    _ref$alignItems = _ref.alignItems,
    alignItems = _ref$alignItems === void 0 ? 'stretch' : _ref$alignItems,
    _ref$responsive = _ref.responsive,
    responsive = _ref$responsive === void 0 ? true : _ref$responsive,
    _ref$justifyContent = _ref.justifyContent,
    justifyContent = _ref$justifyContent === void 0 ? 'flexStart' : _ref$justifyContent,
    _ref$direction = _ref.direction,
    direction = _ref$direction === void 0 ? 'row' : _ref$direction,
    _ref$wrap = _ref.wrap,
    wrap = _ref$wrap === void 0 ? false : _ref$wrap,
    rest = (0, _objectWithoutProperties2.default)(_ref, _excluded);
  var styles = (0, _services.useEuiMemoizedStyles)(_flex_group.euiFlexGroupStyles);
  var cssStyles = [styles.euiFlexGroup, responsive && !direction.includes('column') && styles.responsive, wrap && styles.wrap, styles.gutterSizes[gutterSize], styles.justifyContent[justifyContent], styles.alignItems[alignItems], styles.direction[direction]];
  var classes = (0, _classnames.default)('euiFlexGroup', className);

  // Cast `component` to FunctionComponent to simplify its type.
  // Note that FunctionComponent type is used here for purely typing
  // convenience since we specify the return type above, and function
  // components don't support `ref`s, but that doesn't matter in this case.
  var Component = component;
  return (0, _react2.jsx)(Component, (0, _extends2.default)({}, rest, {
    ref: ref,
    className: classes,
    css: cssStyles
  }));
};

// Cast forwardRef return type to work with the generic TComponent type
// and not fallback to implicit any typing
/**
 * @see {@link https://eui.elastic.co/docs/components/layout/flex/|EuiFlexGroup documentation}
 */
var EuiFlexGroup = exports.EuiFlexGroup = /*#__PURE__*/(0, _react.forwardRef)(EuiFlexGroupInternal);
EuiFlexGroup.displayName = 'EuiFlexGroup';