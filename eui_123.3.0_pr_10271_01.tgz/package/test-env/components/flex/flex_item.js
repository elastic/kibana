"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.EuiFlexItem = void 0;
var _extends2 = _interopRequireDefault(require("@babel/runtime/helpers/extends"));
var _objectWithoutProperties2 = _interopRequireDefault(require("@babel/runtime/helpers/objectWithoutProperties"));
var _react = _interopRequireWildcard(require("react"));
var _classnames = _interopRequireDefault(require("classnames"));
var _flex_item = require("./flex_item.styles");
var _react2 = require("@emotion/react");
var _excluded = ["children", "className", "grow", "component"];
/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */
var cache;
function _interopRequireWildcard(e, t) { if (!t && e && e.__esModule) return e; var r, c, a = Object.defineProperty, n = { __proto__: null, default: e }; if (Object(e) !== e) return n; if (cache || "function" != typeof WeakMap || (cache = new WeakMap()), cache) { if (cache.has(e)) return cache.get(e); cache.set(e, n); } for (c in e) "default" !== c && {}.hasOwnProperty.call(e, c) && ((r = a && Object.getOwnPropertyDescriptor(e, c)) && (r.get || r.set) ? a(n, c, r) : n[c] = e[c]); return n; }
var VALID_GROW_VALUES = [null, undefined, true, false, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
var EuiFlexItemInternal = function EuiFlexItemInternal(_ref, ref) {
  var children = _ref.children,
    className = _ref.className,
    _ref$grow = _ref.grow,
    _grow = _ref$grow === void 0 ? true : _ref$grow,
    _ref$component = _ref.component,
    component = _ref$component === void 0 ? 'div' : _ref$component,
    rest = (0, _objectWithoutProperties2.default)(_ref, _excluded);
  // resets `grow` to the default value when an invalid value is passed
  var grow = VALID_GROW_VALUES.indexOf(_grow) === -1 ? true : _grow;
  (0, _react.useEffect)(function () {
    if (process.env.NODE_ENV === 'development' && VALID_GROW_VALUES.indexOf(_grow) === -1) {
      console.warn("Prop `grow` passed to `EuiFlexItem` must be a boolean or an integer between 0 and 10, received `".concat(_grow, "`. Defaulting to `true`."));
    }
  }, [_grow]);
  var cssStyles = [_flex_item.euiFlexItemStyles.euiFlexItem, !grow ? _flex_item.euiFlexItemStyles.growZero : _flex_item.euiFlexItemStyles.grow, grow && (typeof grow === 'number' ? _flex_item.euiFlexItemStyles.growSizes[grow] : _flex_item.euiFlexItemStyles.growSizes['1'])];
  var classes = (0, _classnames.default)('euiFlexItem', className);

  // Cast `component` to FunctionComponent to simplify its type.
  // Note that FunctionComponent type is used here for purely typing
  // convenience since we specify the return type above, and function
  // components don't support `ref`s, but that doesn't matter in this case.
  var Component = component;
  return (0, _react2.jsx)(Component, (0, _extends2.default)({}, rest, {
    ref: ref,
    css: cssStyles,
    className: classes
  }), children);
};

// Cast forwardRef return type to work with the generic TComponent type
// and not fallback to implicit any typing
/**
 * @see {@link https://eui.elastic.co/docs/components/layout/flex/item/|EuiFlexItem documentation}
 */
var EuiFlexItem = exports.EuiFlexItem = /*#__PURE__*/(0, _react.forwardRef)(EuiFlexItemInternal);
EuiFlexItem.displayName = 'EuiFlexItem';