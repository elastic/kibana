"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.EuiCheckableCard = void 0;
var _extends2 = _interopRequireDefault(require("@babel/runtime/helpers/extends"));
var _slicedToArray2 = _interopRequireDefault(require("@babel/runtime/helpers/slicedToArray"));
var _objectWithoutProperties2 = _interopRequireDefault(require("@babel/runtime/helpers/objectWithoutProperties"));
var _react = _interopRequireWildcard(require("react"));
var _propTypes = _interopRequireDefault(require("prop-types"));
var _classnames = _interopRequireDefault(require("classnames"));
var _tabbable = require("tabbable");
var _form = require("../../form");
var _panel = require("../../panel");
var _services = require("../../../services");
var _checkable_card = require("./checkable_card.styles");
var _react2 = require("@emotion/react");
var _excluded = ["children", "className", "css", "checkableType", "label", "labelProps", "name", "checked", "disabled", "hasShadow", "hasBorder"];
/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */
// if `checkableType` is left out or set to 'radio', use EuiRadioProps
// if `checkableType` is set to 'checkbox', use EuiCheckboxProps
var cache;
function _interopRequireWildcard(e, t) { if (!t && e && e.__esModule) return e; var r, c, a = Object.defineProperty, n = { __proto__: null, default: e }; if (Object(e) !== e) return n; if (cache || "function" != typeof WeakMap || (cache = new WeakMap()), cache) { if (cache.has(e)) return cache.get(e); cache.set(e, n); } for (c in e) "default" !== c && {}.hasOwnProperty.call(e, c) && ((r = a && Object.getOwnPropertyDescriptor(e, c)) && (r.get || r.set) ? a(n, c, r) : n[c] = e[c]); return n; }
var EuiCheckableCard = exports.EuiCheckableCard = function EuiCheckableCard(_ref) {
  var children = _ref.children,
    className = _ref.className,
    css = _ref.css,
    _ref$checkableType = _ref.checkableType,
    checkableType = _ref$checkableType === void 0 ? 'radio' : _ref$checkableType,
    label = _ref.label,
    labelProps = _ref.labelProps,
    name = _ref.name,
    checked = _ref.checked,
    disabled = _ref.disabled,
    hasShadow = _ref.hasShadow,
    _ref$hasBorder = _ref.hasBorder,
    hasBorder = _ref$hasBorder === void 0 ? true : _ref$hasBorder,
    rest = (0, _objectWithoutProperties2.default)(_ref, _excluded);
  var euiThemeContext = (0, _services.useEuiTheme)();
  var styles = (0, _checkable_card.euiCheckableCardStyles)(euiThemeContext);
  var baseStyles = [styles.euiCheckableCard, checked && !disabled && styles.isChecked, css];
  var labelStyles = [styles.label.euiCheckableCard__label, disabled && styles.label.isDisabled];
  var childStyles = [styles.euiCheckableCard__children];
  var id = rest.id;
  var labelEl = (0, _react.useRef)(null);
  var inputEl = (0, _react.useRef)(null);
  var childrenWrapperEl = (0, _react.useRef)(null);
  var classes = (0, _classnames.default)('euiCheckableCard', className);
  var _useState = (0, _react.useState)(false),
    _useState2 = (0, _slicedToArray2.default)(_useState, 2),
    hasInteractiveChildren = _useState2[0],
    setHasInteractiveChildren = _useState2[1];
  (0, _react.useEffect)(function () {
    var interactiveElements = childrenWrapperEl.current ? (0, _tabbable.tabbable)(childrenWrapperEl.current) : [];
    setHasInteractiveChildren(interactiveElements.length > 0);
  }, [children, childrenWrapperEl]);
  var checkableElement;
  if (checkableType === 'radio') {
    checkableElement = (0, _react2.jsx)(_form.EuiRadio, (0, _extends2.default)({
      name: name,
      checked: checked,
      disabled: disabled
    }, rest));
  } else {
    checkableElement = (0, _react2.jsx)(_form.EuiCheckbox, (0, _extends2.default)({
      inputRef: inputEl,
      name: name,
      checked: checked,
      disabled: disabled
    }, rest));
  }
  var labelClasses = (0, _classnames.default)('euiCheckableCard__label');
  var onChangeAffordance = function onChangeAffordance(e) {
    if (!labelEl.current || e.target === inputEl.current) return;
    labelEl.current.click();
  };
  var onChildrenClick = function onChildrenClick() {
    var _labelEl$current;
    if (hasInteractiveChildren) return;
    (_labelEl$current = labelEl.current) === null || _labelEl$current === void 0 || _labelEl$current.click();
  };
  return (0, _react2.jsx)(_panel.EuiSplitPanel.Outer, {
    responsive: false,
    hasShadow: hasShadow,
    hasBorder: hasBorder,
    direction: "row",
    className: classes,
    css: baseStyles
  }, (0, _react2.jsx)(_panel.EuiSplitPanel.Inner, {
    // Bubbles up the change event when clicking on the whole div for extra affordance
    onClick: disabled ? undefined : onChangeAffordance,
    color: checked ? 'primary' : 'subdued',
    grow: false
  }, checkableElement), (0, _react2.jsx)(_panel.EuiSplitPanel.Inner, null, (0, _react2.jsx)("label", (0, _extends2.default)({}, labelProps, {
    ref: labelEl,
    className: labelClasses,
    css: labelStyles,
    htmlFor: id,
    "aria-describedby": children ? "".concat(id, "-details") : undefined
  }), label), children && (0, _react2.jsx)("div", {
    ref: childrenWrapperEl,
    id: "".concat(id, "-details"),
    className: "euiCheckableCard__children",
    css: childStyles,
    onClick: disabled ? undefined : onChildrenClick,
    style: {
      cursor: !disabled && !hasInteractiveChildren ? 'pointer' : undefined
    }
  }, children)));
};
EuiCheckableCard.propTypes = {
  id: _propTypes.default.string.isRequired,
  label: _propTypes.default.node.isRequired,
  hasShadow: _propTypes.default.any,
  hasBorder: _propTypes.default.any
};