"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.EuiDelayRender = void 0;
var _slicedToArray2 = _interopRequireDefault(require("@babel/runtime/helpers/slicedToArray"));
var _react = require("react");
var _propTypes = _interopRequireDefault(require("prop-types"));
/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */

var EuiDelayRender = exports.EuiDelayRender = function EuiDelayRender(_ref) {
  var _ref$delay = _ref.delay,
    delay = _ref$delay === void 0 ? 500 : _ref$delay,
    children = _ref.children;
  var _useState = (0, _react.useState)(false),
    _useState2 = (0, _slicedToArray2.default)(_useState, 2),
    shouldRender = _useState2[0],
    setShouldRender = _useState2[1];
  var _useState3 = (0, _react.useState)({
      children: children,
      delay: delay
    }),
    _useState4 = (0, _slicedToArray2.default)(_useState3, 2),
    prevProps = _useState4[0],
    setPrevProps = _useState4[1];

  // Hiding must happen during the render phase: waiting for an effect would
  // briefly commit updated children before hiding them again, flashing the
  // content and triggering any aria-live announcements it may contain
  if (children !== prevProps.children || delay !== prevProps.delay) {
    setPrevProps({
      children: children,
      delay: delay
    });
    setShouldRender(false);
  }
  (0, _react.useEffect)(function () {
    var timeoutId = window.setTimeout(function () {
      return setShouldRender(true);
    }, delay);
    return function () {
      return window.clearTimeout(timeoutId);
    };
  }, [children, delay]);
  return shouldRender ? children : null;
};
EuiDelayRender.propTypes = {
  delay: _propTypes.default.number
};