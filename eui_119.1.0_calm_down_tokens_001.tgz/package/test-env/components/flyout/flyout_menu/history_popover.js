"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
var _typeof = require("@babel/runtime/helpers/typeof");
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.HistoryPopover = void 0;
var _slicedToArray2 = _interopRequireDefault(require("@babel/runtime/helpers/slicedToArray"));
var _react = _interopRequireWildcard(require("react"));
var _button = require("../../button");
var _list_group = require("../../list_group");
var _popover = require("../../popover");
var _tool_tip = require("../../tool_tip");
var _react2 = require("@emotion/react");
function _getRequireWildcardCache(e) { if ("function" != typeof WeakMap) return null; var r = new WeakMap(), t = new WeakMap(); return (_getRequireWildcardCache = function _getRequireWildcardCache(e) { return e ? t : r; })(e); }
function _interopRequireWildcard(e, r) { if (!r && e && e.__esModule) return e; if (null === e || "object" != _typeof(e) && "function" != typeof e) return { default: e }; var t = _getRequireWildcardCache(r); if (t && t.has(e)) return t.get(e); var n = { __proto__: null }, a = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var u in e) if ("default" !== u && {}.hasOwnProperty.call(e, u)) { var i = a ? Object.getOwnPropertyDescriptor(e, u) : null; i && (i.get || i.set) ? Object.defineProperty(n, u, i) : n[u] = e[u]; } return n.default = e, t && t.set(e, n), n; }
/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */

/**
 * Labels are resolved by `EuiFlyoutMenu`, which owns the `euiFlyoutMenu.*`
 * i18n token namespace.
 */
var HistoryPopover = exports.HistoryPopover = function HistoryPopover(_ref) {
  var items = _ref.items,
    historyLabel = _ref.historyLabel,
    recentlyVisitedLabel = _ref.recentlyVisitedLabel;
  var _useState = (0, _react.useState)(false),
    _useState2 = (0, _slicedToArray2.default)(_useState, 2),
    isPopoverOpen = _useState2[0],
    setIsPopoverOpen = _useState2[1];
  return (0, _react2.jsx)(_popover.EuiPopover, {
    "aria-label": historyLabel,
    button: (0, _react2.jsx)(_tool_tip.EuiToolTip, {
      content: recentlyVisitedLabel,
      disableScreenReaderOutput: true
    }, (0, _react2.jsx)(_button.EuiButtonIcon, {
      iconType: "clockCounter",
      color: "text",
      "aria-label": historyLabel,
      "data-test-subj": "euiFlyoutMenuHistoryButton"
    })),
    isOpen: isPopoverOpen,
    onClick: function onClick() {
      return setIsPopoverOpen(!isPopoverOpen);
    },
    closePopover: function closePopover() {
      return setIsPopoverOpen(false);
    },
    panelPaddingSize: "xs",
    anchorPosition: "downLeft"
  }, (0, _react2.jsx)(_list_group.EuiListGroup, null, items.map(function (item, index) {
    return (0, _react2.jsx)(_list_group.EuiListGroupItem, {
      key: "history-item-".concat(index),
      label: item.title,
      iconType: item.iconType,
      onClick: function onClick() {
        item.onClick();
        setIsPopoverOpen(false);
      },
      "data-test-subj": "euiFlyoutMenuHistoryItem-".concat(index)
    }, item.title);
  })));
};