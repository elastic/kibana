"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.CloseButtonSpacer = void 0;
var _react = _interopRequireDefault(require("react"));
var _services = require("../../../services");
var _flex = require("../../flex");
var _flyout_menu = require("./flyout_menu.styles");
var _react2 = require("@emotion/react");
/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */

/**
 * Spacer that gives trailing actions room around the absolutely-positioned
 * close button. When `showDivider` is true, it doubles as the visual divider
 * between trailing actions and the close button.
 */
var CloseButtonSpacer = exports.CloseButtonSpacer = function CloseButtonSpacer(_ref) {
  var showDivider = _ref.showDivider;
  var styles = (0, _services.useEuiMemoizedStyles)(_flyout_menu.euiFlyoutMenuStyles);
  return (0, _react2.jsx)(_flex.EuiFlexItem, {
    grow: false,
    css: [styles.euiFlyoutMenu__spacer, showDivider && styles.euiFlyoutMenu__divider, ";label:CloseButtonSpacer;"],
    className: showDivider ? 'euiFlyoutMenu__divider' : undefined,
    "aria-hidden": showDivider ? 'true' : undefined
  });
};