"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "EuiFlyoutMenu", {
  enumerable: true,
  get: function get() {
    return _flyout_menu.EuiFlyoutMenu;
  }
});
var _flyout_menu = require("./flyout_menu");