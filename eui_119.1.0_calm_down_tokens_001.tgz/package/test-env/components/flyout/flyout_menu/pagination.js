"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.PaginationControls = void 0;
var _extends2 = _interopRequireDefault(require("@babel/runtime/helpers/extends"));
var _react = _interopRequireDefault(require("react"));
var _services = require("../../../services");
var _button = require("../../button");
var _flex = require("../../flex");
var _accessibility = require("../../accessibility");
var _text = require("../../text");
var _tool_tip = require("../../tool_tip");
var _flyout_menu = require("./flyout_menu.styles");
var _react2 = require("@emotion/react");
/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */

var PaginationButton = function PaginationButton(_ref) {
  var iconType = _ref.iconType,
    label = _ref.label,
    onClick = _ref.onClick,
    isDisabled = _ref.isDisabled,
    dataTestSubj = _ref.dataTestSubj;
  var sharedProps = {
    iconType: iconType,
    color: 'text',
    size: 'xs',
    'aria-label': label,
    onClick: onClick,
    'data-test-subj': dataTestSubj
  };
  return isDisabled ? (0, _react2.jsx)(_button.EuiButtonIcon, (0, _extends2.default)({}, sharedProps, {
    isDisabled: true
  })) : (0, _react2.jsx)(_tool_tip.EuiToolTip, {
    content: label,
    disableScreenReaderOutput: true
  }, (0, _react2.jsx)(_button.EuiButtonIcon, sharedProps));
};
/**
 * `labels` are resolved by `EuiFlyoutMenu`, which owns the `euiFlyoutMenu.*`
 * i18n token namespace.
 */
var PaginationControls = exports.PaginationControls = function PaginationControls(_ref2) {
  var pagination = _ref2.pagination,
    labels = _ref2.labels;
  var styles = (0, _services.useEuiMemoizedStyles)(_flyout_menu.euiFlyoutMenuStyles);
  var currentIndex = pagination.currentIndex,
    total = pagination.total,
    onPrevious = pagination.onPrevious,
    onNext = pagination.onNext,
    onFirst = pagination.onFirst,
    onLast = pagination.onLast;

  // Jump-to-first/last controls read as a horizontal track, so the Prev/Next
  // chevrons follow that axis unless the consumer overrides them.
  var hasJumpControls = onFirst != null || onLast != null;
  var previousIconType = hasJumpControls ? 'chevronSingleLeft' : 'chevronSingleUp';
  var nextIconType = hasJumpControls ? 'chevronSingleRight' : 'chevronSingleDown';
  var firstLabel = labels.first,
    prevLabel = labels.previous,
    nextLabel = labels.next,
    lastLabel = labels.last,
    counterLabel = labels.counter;
  var isAtStart = currentIndex === 0;
  var isAtEnd = currentIndex === total - 1;
  return (0, _react2.jsx)(_flex.EuiFlexItem, {
    grow: false
  }, (0, _react2.jsx)(_flex.EuiFlexGroup, {
    gutterSize: "xs",
    alignItems: "center",
    responsive: false
  }, onFirst && (0, _react2.jsx)(_flex.EuiFlexItem, {
    grow: false
  }, (0, _react2.jsx)(PaginationButton, {
    iconType: "chevronLimitLeft",
    label: firstLabel,
    onClick: onFirst,
    isDisabled: isAtStart,
    dataTestSubj: "euiFlyoutMenuPaginationFirst"
  })), (0, _react2.jsx)(_flex.EuiFlexItem, {
    grow: false
  }, (0, _react2.jsx)(PaginationButton, {
    iconType: previousIconType,
    label: prevLabel,
    onClick: onPrevious,
    isDisabled: isAtStart,
    dataTestSubj: "euiFlyoutMenuPaginationPrev"
  })), (0, _react2.jsx)(_flex.EuiFlexItem, {
    grow: false
  }, (0, _react2.jsx)(_text.EuiText, {
    size: "s",
    css: styles.euiFlyoutMenu__paginationCounter,
    "aria-hidden": "true"
  }, counterLabel), (0, _react2.jsx)(_accessibility.EuiScreenReaderLive, null, counterLabel)), (0, _react2.jsx)(_flex.EuiFlexItem, {
    grow: false
  }, (0, _react2.jsx)(PaginationButton, {
    iconType: nextIconType,
    label: nextLabel,
    onClick: onNext,
    isDisabled: isAtEnd,
    dataTestSubj: "euiFlyoutMenuPaginationNext"
  })), onLast && (0, _react2.jsx)(_flex.EuiFlexItem, {
    grow: false
  }, (0, _react2.jsx)(PaginationButton, {
    iconType: "chevronLimitRight",
    label: lastLabel,
    onClick: onLast,
    isDisabled: isAtEnd,
    dataTestSubj: "euiFlyoutMenuPaginationLast"
  }))));
};