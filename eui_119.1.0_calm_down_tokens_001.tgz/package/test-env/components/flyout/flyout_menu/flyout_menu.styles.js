"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.euiFlyoutMenuStyles = void 0;
var _react = require("@emotion/react");
var _global_styling = require("../../../global_styling");
var _accessibility = require("../../accessibility");
function _EMOTION_STRINGIFIED_CSS_ERROR__() { return "You have tried to stringify object returned from `css` function. It isn't supposed to be used directly (e.g. as value of the `className` prop), but rather handed to emotion so it can handle it (e.g. as value of `css` prop)."; } /*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */
var _ref = process.env.NODE_ENV === "production" ? {
  name: "1kqtial-euiFlyoutMenu__actions",
  styles: "align-self:center;label:euiFlyoutMenu__actions;"
} : {
  name: "1kqtial-euiFlyoutMenu__actions",
  styles: "align-self:center;label:euiFlyoutMenu__actions;",
  toString: _EMOTION_STRINGIFIED_CSS_ERROR__
};
var euiFlyoutMenuStyles = exports.euiFlyoutMenuStyles = function euiFlyoutMenuStyles(euiThemeContext) {
  var euiTheme = euiThemeContext.euiTheme;
  return {
    euiFlyoutMenu__container: /*#__PURE__*/(0, _react.css)("block-size:calc(", euiTheme.size.m, " * 3.5);flex-shrink:0;padding-block:", euiTheme.size.s, ";padding-inline:", euiTheme.size.s, ";border-block-end:", euiTheme.border.width.thin, " solid ", euiTheme.border.color, ";.euiTitle{padding-inline:", euiTheme.size.s, ";};label:euiFlyoutMenu__container;"),
    // Full height in high contrast mode so dividers can bleed to the container edges.
    euiFlyoutMenu__controls: /*#__PURE__*/(0, _react.css)((0, _global_styling.highContrastModeStyles)(euiThemeContext, {
      preferred: 'block-size: 100%;'
    }), ";;label:euiFlyoutMenu__controls;"),
    euiFlyoutMenu__spacer: /*#__PURE__*/(0, _react.css)("padding-inline:", euiTheme.size.m, ";;label:euiFlyoutMenu__spacer;"),
    euiFlyoutMenu__actions: _ref,
    euiFlyoutMenu__hiddenTitle: /*#__PURE__*/(0, _react.css)((0, _accessibility.euiScreenReaderOnly)(), ";;label:euiFlyoutMenu__hiddenTitle;"),
    euiFlyoutMenu__paginationCounter: /*#__PURE__*/(0, _react.css)("color:", euiTheme.colors.textSubdued, ";white-space:nowrap;;label:euiFlyoutMenu__paginationCounter;"),
    // Border (not background) keeps the line visible in Windows high contrast themes.
    euiFlyoutMenu__divider: /*#__PURE__*/(0, _react.css)("align-self:center;inline-size:0;block-size:", euiTheme.size.l, ";margin-inline:", euiTheme.size.s, ";border-inline-start:", euiTheme.border.thin, ";pointer-events:none;", (0, _global_styling.highContrastModeStyles)(euiThemeContext, {
      preferred: "\n          align-self: stretch;\n          block-size: auto;\n          margin-block: -".concat(euiTheme.size.s, ";\n        ")
    }), ";;label:euiFlyoutMenu__divider;")
  };
};