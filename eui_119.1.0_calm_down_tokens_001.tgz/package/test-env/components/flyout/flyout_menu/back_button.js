"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.BackButton = void 0;
var _extends2 = _interopRequireDefault(require("@babel/runtime/helpers/extends"));
var _objectWithoutProperties2 = _interopRequireDefault(require("@babel/runtime/helpers/objectWithoutProperties"));
var _react = _interopRequireDefault(require("react"));
var _button = require("../../button");
var _react2 = require("@emotion/react");
var _excluded = ["label"];
/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */
/**
 * `label` is resolved by `EuiFlyoutMenu`, which owns the `euiFlyoutMenu.*`
 * i18n token namespace.
 */
var BackButton = exports.BackButton = function BackButton(_ref) {
  var label = _ref.label,
    rest = (0, _objectWithoutProperties2.default)(_ref, _excluded);
  return (0, _react2.jsx)(_button.EuiButtonEmpty, (0, _extends2.default)({
    size: "xs",
    color: "text",
    iconType: "undo",
    "data-test-subj": "euiFlyoutMenuBackButton"
  }, rest), label);
};