"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.MenuDivider = void 0;
var _react = _interopRequireDefault(require("react"));
var _services = require("../../../services");
var _flex = require("../../flex");
var _flyout_menu = require("./flyout_menu.styles");
var _react2 = require("@emotion/react");
/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */

var MenuDivider = exports.MenuDivider = function MenuDivider() {
  var styles = (0, _services.useEuiMemoizedStyles)(_flyout_menu.euiFlyoutMenuStyles);
  return (0, _react2.jsx)(_flex.EuiFlexItem, {
    grow: false,
    css: styles.euiFlyoutMenu__divider,
    "aria-hidden": "true",
    className: "euiFlyoutMenu__divider"
  });
};