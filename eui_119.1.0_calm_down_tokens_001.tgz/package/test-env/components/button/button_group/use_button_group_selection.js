"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.useEuiButtonGroupSelection = useEuiButtonGroupSelection;
var _react = require("react");
/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */

/**
 * Purely controlled selection state for `EuiButtonGroup` with `variant="selection"`.
 * The consumer owns state via `idSelected` (single) or `idToSelectedMap` (multi)
 * and updates it through `onChange`.
 */
function useEuiButtonGroupSelection(_ref) {
  var type = _ref.type,
    idSelected = _ref.idSelected,
    idToSelectedMap = _ref.idToSelectedMap,
    onChange = _ref.onChange;
  var isSelected = (0, _react.useCallback)(function (id) {
    return type === 'multi' ? !!(idToSelectedMap !== null && idToSelectedMap !== void 0 && idToSelectedMap[id]) : id === idSelected;
  }, [type, idSelected, idToSelectedMap]);
  var onSelect = (0, _react.useCallback)(function (id) {
    return onChange === null || onChange === void 0 ? void 0 : onChange(id);
  }, [onChange]);
  return {
    isSelected: isSelected,
    onSelect: onSelect
  };
}