"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
var _typeof = require("@babel/runtime/helpers/typeof");
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.PADDING_SIZES = exports.EuiAccordion = void 0;
var _extends2 = _interopRequireDefault(require("@babel/runtime/helpers/extends"));
var _slicedToArray2 = _interopRequireDefault(require("@babel/runtime/helpers/slicedToArray"));
var _objectWithoutProperties2 = _interopRequireDefault(require("@babel/runtime/helpers/objectWithoutProperties"));
var _react = _interopRequireWildcard(require("react"));
var _propTypes = _interopRequireDefault(require("prop-types"));
var _classnames = _interopRequireDefault(require("classnames"));
var _services = require("../../services");
var _loading = require("../loading");
var _accordion_trigger = require("./accordion_trigger");
var _accordion_children = require("./accordion_children");
var _accordion = require("./accordion.styles");
var _react2 = require("@emotion/react");
var _excluded = ["children", "className", "id", "role", "element", "buttonElement", "buttonProps", "buttonClassName", "buttonContentClassName", "buttonContent", "arrowDisplay", "arrowProps", "extraAction", "paddingSize", "borders", "initialIsOpen", "forceState", "isLoading", "isLoadingMessage", "isDisabled", "onToggle"];
/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */
function _getRequireWildcardCache(e) { if ("function" != typeof WeakMap) return null; var r = new WeakMap(), t = new WeakMap(); return (_getRequireWildcardCache = function _getRequireWildcardCache(e) { return e ? t : r; })(e); }
function _interopRequireWildcard(e, r) { if (!r && e && e.__esModule) return e; if (null === e || "object" != _typeof(e) && "function" != typeof e) return { default: e }; var t = _getRequireWildcardCache(r); if (t && t.has(e)) return t.get(e); var n = { __proto__: null }, a = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var u in e) if ("default" !== u && {}.hasOwnProperty.call(e, u)) { var i = a ? Object.getOwnPropertyDescriptor(e, u) : null; i && (i.get || i.set) ? Object.defineProperty(n, u, i) : n[u] = e[u]; } return n.default = e, t && t.set(e, n), n; }
var PADDING_SIZES = exports.PADDING_SIZES = ['none', 'xs', 's', 'm', 'l', 'xl'];
/**
 * @see {@link https://eui.elastic.co/docs/components/containers/accordion/|EuiAccordion documentation}
 */
var EuiAccordion = exports.EuiAccordion = function EuiAccordion(_ref) {
  var _buttonProps$id;
  var children = _ref.children,
    className = _ref.className,
    id = _ref.id,
    _ref$role = _ref.role,
    role = _ref$role === void 0 ? 'group' : _ref$role,
    _ref$element = _ref.element,
    Element = _ref$element === void 0 ? 'div' : _ref$element,
    _ref$buttonElement = _ref.buttonElement,
    buttonElement = _ref$buttonElement === void 0 ? 'button' : _ref$buttonElement,
    buttonProps = _ref.buttonProps,
    buttonClassName = _ref.buttonClassName,
    buttonContentClassName = _ref.buttonContentClassName,
    buttonContent = _ref.buttonContent,
    _ref$arrowDisplay = _ref.arrowDisplay,
    arrowDisplay = _ref$arrowDisplay === void 0 ? 'left' : _ref$arrowDisplay,
    arrowProps = _ref.arrowProps,
    extraAction = _ref.extraAction,
    _ref$paddingSize = _ref.paddingSize,
    paddingSize = _ref$paddingSize === void 0 ? 'none' : _ref$paddingSize,
    _ref$borders = _ref.borders,
    borders = _ref$borders === void 0 ? 'none' : _ref$borders,
    _ref$initialIsOpen = _ref.initialIsOpen,
    initialIsOpen = _ref$initialIsOpen === void 0 ? false : _ref$initialIsOpen,
    forceState = _ref.forceState,
    _ref$isLoading = _ref.isLoading,
    isLoading = _ref$isLoading === void 0 ? false : _ref$isLoading,
    _ref$isLoadingMessage = _ref.isLoadingMessage,
    isLoadingMessage = _ref$isLoadingMessage === void 0 ? false : _ref$isLoadingMessage,
    _ref$isDisabled = _ref.isDisabled,
    isDisabled = _ref$isDisabled === void 0 ? false : _ref$isDisabled,
    onToggle = _ref.onToggle,
    rest = (0, _objectWithoutProperties2.default)(_ref, _excluded);
  var _useState = (0, _react.useState)(forceState ? forceState === 'open' : initialIsOpen),
    _useState2 = (0, _slicedToArray2.default)(_useState, 2),
    isOpenState = _useState2[0],
    setIsOpenState = _useState2[1];
  var isOpen = forceState ? forceState === 'open' : isOpenState;
  var onAccordionToggle = function onAccordionToggle() {
    if (forceState) {
      onToggle === null || onToggle === void 0 || onToggle(!isOpen);
    } else {
      var nextState = !isOpenState;
      setIsOpenState(nextState);
      onToggle === null || onToggle === void 0 || onToggle(nextState);
    }
  };
  var generatedId = (0, _services.useGeneratedHtmlId)();
  var buttonId = (_buttonProps$id = buttonProps === null || buttonProps === void 0 ? void 0 : buttonProps.id) !== null && _buttonProps$id !== void 0 ? _buttonProps$id : generatedId;
  var classes = (0, _classnames.default)('euiAccordion', {
    'euiAccordion-isOpen': isOpen
  }, className);
  var styles = (0, _services.useEuiMemoizedStyles)(_accordion.euiAccordionStyles);
  var cssStyles = [styles.euiAccordion, borders !== 'none' && styles.borders.borders, borders !== 'none' && styles.borders[borders]];
  return (0, _react2.jsx)(Element, (0, _extends2.default)({
    className: classes,
    css: cssStyles
  }, rest), (0, _react2.jsx)(_accordion_trigger.EuiAccordionTrigger, {
    ariaControlsId: id,
    buttonId: buttonId
    // Force button element to be a legend if the element is a fieldset
    ,
    buttonElement: Element === 'fieldset' ? 'legend' : buttonElement,
    buttonClassName: buttonClassName,
    buttonContent: buttonContent,
    buttonContentClassName: buttonContentClassName,
    buttonProps: buttonProps,
    arrowProps: arrowProps,
    arrowDisplay: arrowDisplay,
    isDisabled: isDisabled,
    isOpen: isOpen,
    onToggle: onAccordionToggle,
    extraAction: isLoading ? (0, _react2.jsx)(_loading.EuiLoadingSpinner, null) : extraAction
  }), (0, _react2.jsx)(_accordion_children.EuiAccordionChildren, {
    role: role,
    id: id,
    "aria-labelledby": buttonId,
    paddingSize: paddingSize,
    isLoading: isLoading,
    isLoadingMessage: isLoadingMessage,
    isOpen: isOpen,
    initialIsOpen: initialIsOpen
  }, children));
};
EuiAccordion.propTypes = {
  className: _propTypes.default.string,
  "aria-label": _propTypes.default.string,
  "data-test-subj": _propTypes.default.string,
  css: _propTypes.default.any,
  id: _propTypes.default.string.isRequired,
  /**
       * Applied to the entire .euiAccordion wrapper.
       * When using `fieldset`, it will enforce `buttonElement = legend` as well.
       */
  element: _propTypes.default.oneOf(["div", "fieldset"]),
  /**
       * Defaults to the [group role](https://developer.mozilla.org/en-US/docs/Web/Accessibility/ARIA/Roles/group_role).
       *
       * If your accordion contains significant enough content to be a document
       * [landmark role](https://developer.mozilla.org/en-US/docs/Web/Accessibility/ARIA/Roles/region_role#accessibility_concerns), consider using the `region` role instead.
       * @default group
       */
  role: _propTypes.default.any,
  /**
       * Class that will apply to the trigger for the accordion.
       */
  buttonClassName: _propTypes.default.string,
  /**
       * Apply more props to the triggering button.
       *
       * Includes optional `paddingSize` prop which allows sizes of `s`, `m`, or `l`.
       * Note: Padding will not be present on the side closest to the accordion arrow.
       */
  buttonProps: _propTypes.default.shape({
    className: _propTypes.default.string,
    "aria-label": _propTypes.default.string,
    "data-test-subj": _propTypes.default.string,
    css: _propTypes.default.any,
    paddingSize: _propTypes.default.oneOf(["s", "m", "l"])
  }),
  /**
       * Class that will apply to the trigger content for the accordion.
       */
  buttonContentClassName: _propTypes.default.string,
  /**
       * The content of the clickable trigger
       */
  buttonContent: _propTypes.default.node,
  /**
       * Applied to the main button receiving the `onToggle` event.
       * Anything other than the default `button` does not support removing the arrow display (for accessibility of focus).
       */
  buttonElement: _propTypes.default.oneOf(["div", "legend", "button"]),
  /**
       * Extra props to pass to the EuiButtonIcon containing the arrow.
       */
  arrowProps: _propTypes.default.any,
  /**
       * Will appear right aligned against the button. Useful for separate actions like deletions.
       */
  extraAction: _propTypes.default.node,
  /**
       * The accordion will start in the open state.
       */
  initialIsOpen: _propTypes.default.bool,
  /**
       * Optional callback method called on open and close with a single `isOpen` parameter
       */
  onToggle: _propTypes.default.func,
  /**
       * The padding around the exposed accordion content.
       */
  paddingSize: _propTypes.default.any,
  /**
       * Placement of the arrow indicator, or 'none' to hide it.
       */
  arrowDisplay: _propTypes.default.oneOf(["left", "right", "none"]),
  /**
       * Optional border styling. Defaults to 'none'.
       */
  borders: _propTypes.default.oneOf(["horizontal", "all", "none"]),
  /**
       * Control the opening of accordion via prop
       */
  forceState: _propTypes.default.oneOf(["closed", "open"]),
  /**
       * Change `extraAction` and children into a loading spinner
       */
  isLoading: _propTypes.default.bool,
  /**
       * Choose whether the loading message replaces the content. Customize the message by passing a node
       */
  isLoadingMessage: _propTypes.default.oneOfType([_propTypes.default.bool.isRequired, _propTypes.default.node.isRequired]),
  /**
       * Disable the open/close interaction and visually subdues the trigger
       */
  isDisabled: _propTypes.default.bool
};