"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
var _typeof = require("@babel/runtime/helpers/typeof");
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.EuiCopy = void 0;
var _extends2 = _interopRequireDefault(require("@babel/runtime/helpers/extends"));
var _slicedToArray2 = _interopRequireDefault(require("@babel/runtime/helpers/slicedToArray"));
var _react = _interopRequireWildcard(require("react"));
var _propTypes = _interopRequireDefault(require("prop-types"));
var _services = require("../../services");
var _accessibility = require("../accessibility");
var _tool_tip = require("../tool_tip");
var _react2 = require("@emotion/react");
function _getRequireWildcardCache(e) { if ("function" != typeof WeakMap) return null; var r = new WeakMap(), t = new WeakMap(); return (_getRequireWildcardCache = function _getRequireWildcardCache(e) { return e ? t : r; })(e); }
function _interopRequireWildcard(e, r) { if (!r && e && e.__esModule) return e; if (null === e || "object" != _typeof(e) && "function" != typeof e) return { default: e }; var t = _getRequireWildcardCache(r); if (t && t.has(e)) return t.get(e); var n = { __proto__: null }, a = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var u in e) if ("default" !== u && {}.hasOwnProperty.call(e, u)) { var i = a ? Object.getOwnPropertyDescriptor(e, u) : null; i && (i.get || i.set) ? Object.defineProperty(n, u, i) : n[u] = e[u]; } return n.default = e, t && t.set(e, n), n; }
/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */

var EuiCopy = exports.EuiCopy = function EuiCopy(_ref) {
  var textToCopy = _ref.textToCopy,
    beforeMessage = _ref.beforeMessage,
    _ref$afterMessage = _ref.afterMessage,
    afterMessage = _ref$afterMessage === void 0 ? 'Copied' : _ref$afterMessage,
    children = _ref.children,
    tooltipProps = _ref.tooltipProps;
  var tooltipRef = (0, _react.useRef)(null);

  // Consumers can hold onto the render prop `copy` callback and invoke it after
  // this component has unmounted (e.g. from a debounced handler). Setting state
  // then is a no-op that React 17 additionally warns about, so skip it.
  var isMountedRef = (0, _react.useRef)(true);
  (0, _react.useEffect)(function () {
    return function () {
      isMountedRef.current = false;
    };
  }, []);

  // Counts successful copies instead of storing a boolean, so that every copy
  // re-runs the effect below - the tooltip may have been hidden in between
  // copies (e.g. by another tooltip being shown) and needs showing again.
  var _useState = (0, _react.useState)(0),
    _useState2 = (0, _slicedToArray2.default)(_useState, 2),
    copyCount = _useState2[0],
    setCopyCount = _useState2[1];
  var isCopied = copyCount > 0;
  var tooltipText = isCopied ? afterMessage : beforeMessage;
  var copy = (0, _react.useCallback)(function () {
    var copied = (0, _services.copyToClipboard)(textToCopy);
    if (copied && isMountedRef.current) {
      setCopyCount(function (count) {
        return count + 1;
      });
    }
  }, [textToCopy]);
  var resetTooltipText = (0, _react.useCallback)(function () {
    if (isMountedRef.current) {
      setCopyCount(0);
    }
  }, []);

  // `EuiToolTip` suppresses showing when content is empty, so `EuiCopy`
  // imperatively shows the tooltip after the post-copy state update.
  (0, _react.useEffect)(function () {
    if (copyCount > 0) {
      var _tooltipRef$current;
      (_tooltipRef$current = tooltipRef.current) === null || _tooltipRef$current === void 0 || _tooltipRef$current.showToolTip();
    }
  }, [copyCount]);
  return (0, _react2.jsx)(_react.default.Fragment, null, (0, _react2.jsx)(_tool_tip.EuiToolTip, (0, _extends2.default)({
    ref: tooltipRef,
    content: tooltipText,
    onMouseOut: resetTooltipText
  }, tooltipProps, {
    onBlur: function onBlur() {
      var _tooltipProps$onBlur;
      tooltipProps === null || tooltipProps === void 0 || (_tooltipProps$onBlur = tooltipProps.onBlur) === null || _tooltipProps$onBlur === void 0 || _tooltipProps$onBlur.call(tooltipProps);
      if (isCopied) resetTooltipText();
    },
    disableScreenReaderOutput: isCopied || !!(tooltipProps !== null && tooltipProps !== void 0 && tooltipProps.disableScreenReaderOutput)
  }), children(copy)), (0, _react2.jsx)(_accessibility.EuiScreenReaderOnly, null, (0, _react2.jsx)("div", {
    "aria-live": "assertive",
    "aria-atomic": "true"
  }, isCopied ? afterMessage : '')));
};
EuiCopy.propTypes = {
  /**
     * Text that will be copied to clipboard when copy function is executed.
     */
  textToCopy: _propTypes.default.string.isRequired,
  /**
     * Tooltip message displayed before copy function is called.
     */
  beforeMessage: _propTypes.default.node,
  /**
     * Tooltip message displayed after copy function is called that lets the user know that
     * 'textToCopy' has been copied to the clipboard.
     */
  afterMessage: _propTypes.default.node,
  /**
     * Function that must return a component. First argument is 'copy' function.
     * Use your own logic to create the component that users interact with when triggering copy.
     */
  children: _propTypes.default.func.isRequired,
  /**
     * Optional props to pass to the EuiToolTip component.
     */
  tooltipProps: _propTypes.default.any,
  className: _propTypes.default.string,
  "aria-label": _propTypes.default.string,
  "data-test-subj": _propTypes.default.string,
  css: _propTypes.default.any
};