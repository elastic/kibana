"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
var _typeof = require("@babel/runtime/helpers/typeof");
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.EuiQuickSelect = void 0;
var _defineProperty2 = _interopRequireDefault(require("@babel/runtime/helpers/defineProperty"));
var _slicedToArray2 = _interopRequireDefault(require("@babel/runtime/helpers/slicedToArray"));
var _react = _interopRequireWildcard(require("react"));
var _moment = _interopRequireDefault(require("moment"));
var _datemath = _interopRequireDefault(require("@elastic/datemath"));
var _services = require("../../../../services");
var _i18n = require("../../../i18n");
var _accessibility = require("../../../accessibility");
var _button = require("../../../button");
var _flex = require("../../../flex");
var _form = require("../../../form");
var _tool_tip = require("../../../tool_tip");
var _time_options = require("../time_options");
var _quick_select_utils = require("./quick_select_utils");
var _quick_select_panel = require("./quick_select_panel");
var _react2 = require("@emotion/react");
function _getRequireWildcardCache(e) { if ("function" != typeof WeakMap) return null; var r = new WeakMap(), t = new WeakMap(); return (_getRequireWildcardCache = function _getRequireWildcardCache(e) { return e ? t : r; })(e); }
function _interopRequireWildcard(e, r) { if (!r && e && e.__esModule) return e; if (null === e || "object" != _typeof(e) && "function" != typeof e) return { default: e }; var t = _getRequireWildcardCache(r); if (t && t.has(e)) return t.get(e); var n = { __proto__: null }, a = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var u in e) if ("default" !== u && {}.hasOwnProperty.call(e, u)) { var i = a ? Object.getOwnPropertyDescriptor(e, u) : null; i && (i.get || i.set) ? Object.defineProperty(n, u, i) : n[u] = e[u]; } return n.default = e, t && t.set(e, n), n; }
function _EMOTION_STRINGIFIED_CSS_ERROR__() { return "You have tried to stringify object returned from `css` function. It isn't supposed to be used directly (e.g. as value of the `className` prop), but rather handed to emotion so it can handle it (e.g. as value of `css` prop)."; }
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { (0, _defineProperty2.default)(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; } /*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */
var _ref4 = process.env.NODE_ENV === "production" ? {
  name: "7yqi2-EuiQuickSelect",
  styles: "> div{position:relative;overflow:visible;};label:EuiQuickSelect;"
} : {
  name: "7yqi2-EuiQuickSelect",
  styles: "> div{position:relative;overflow:visible;};label:EuiQuickSelect;",
  toString: _EMOTION_STRINGIFIED_CSS_ERROR__
};
var _ref5 = process.env.NODE_ENV === "production" ? {
  name: "qbrd7j-EuiQuickSelect",
  styles: "position:absolute;right:0;bottom:100%;transform:translateY(-33%);label:EuiQuickSelect;"
} : {
  name: "qbrd7j-EuiQuickSelect",
  styles: "position:absolute;right:0;bottom:100%;transform:translateY(-33%);label:EuiQuickSelect;",
  toString: _EMOTION_STRINGIFIED_CSS_ERROR__
};
var EuiQuickSelect = exports.EuiQuickSelect = function EuiQuickSelect(_ref) {
  var applyTime = _ref.applyTime,
    start = _ref.start,
    end = _ref.end,
    prevQuickSelect = _ref.prevQuickSelect,
    timeOptions = _ref.timeOptions;
  var _useState = (0, _react.useState)(function () {
      var _parseTimeParts = (0, _quick_select_utils.parseTimeParts)(start, end),
        timeTenseDefault = _parseTimeParts.timeTense,
        timeUnitsDefault = _parseTimeParts.timeUnits,
        timeValueDefault = _parseTimeParts.timeValue;
      return {
        timeTense: prevQuickSelect && prevQuickSelect.timeTense ? prevQuickSelect.timeTense : timeTenseDefault,
        timeValue: prevQuickSelect && prevQuickSelect.timeValue ? prevQuickSelect.timeValue : timeValueDefault,
        timeUnits: prevQuickSelect && prevQuickSelect.timeUnits ? prevQuickSelect.timeUnits : timeUnitsDefault
      };
    }),
    _useState2 = (0, _slicedToArray2.default)(_useState, 2),
    state = _useState2[0],
    setState = _useState2[1];
  var timeSelectionId = (0, _services.useGeneratedHtmlId)();
  var legendId = (0, _services.useGeneratedHtmlId)();
  var onTimeTenseChange = function onTimeTenseChange(event) {
    var timeTense = event.target.value;
    setState(function (state) {
      return _objectSpread(_objectSpread({}, state), {}, {
        timeTense: timeTense
      });
    });
  };
  var onTimeValueChange = function onTimeValueChange(event) {
    var sanitizedValue = parseInt(event.target.value, 10);
    setState(function (state) {
      return _objectSpread(_objectSpread({}, state), {}, {
        timeValue: isNaN(sanitizedValue) ? 0 : sanitizedValue
      });
    });
  };
  var onTimeUnitsChange = function onTimeUnitsChange(event) {
    var timeUnits = event.target.value;
    setState(function (state) {
      return _objectSpread(_objectSpread({}, state), {}, {
        timeUnits: timeUnits
      });
    });
  };
  var applyQuickSelect = function applyQuickSelect() {
    var timeTense = state.timeTense,
      timeValue = state.timeValue,
      timeUnits = state.timeUnits;
    if (timeTense === _time_options.NEXT) {
      applyTime({
        start: 'now',
        end: "now+".concat(timeValue).concat(timeUnits),
        quickSelect: _objectSpread({}, state)
      });
      return;
    }
    applyTime({
      start: "now-".concat(timeValue).concat(timeUnits),
      end: 'now',
      quickSelect: _objectSpread({}, state)
    });
  };
  var handleKeyDown = function handleKeyDown(_ref2) {
    var key = _ref2.key;
    if (key === 'Enter') {
      applyQuickSelect();
    }
  };
  var getBounds = function getBounds() {
    var startMoment = _datemath.default.parse(start);
    var endMoment = _datemath.default.parse(end, {
      roundUp: true
    });
    return {
      min: startMoment && startMoment.isValid() ? startMoment : (0, _moment.default)().subtract(15, 'minute'),
      max: endMoment && endMoment.isValid() ? endMoment : (0, _moment.default)()
    };
  };
  var stepForward = function stepForward() {
    var _getBounds = getBounds(),
      min = _getBounds.min,
      max = _getBounds.max;
    var diff = max.diff(min);
    applyTime({
      start: (0, _moment.default)(max).toISOString(),
      end: (0, _moment.default)(max).add(diff, 'ms').toISOString(),
      keepPopoverOpen: true
    });
  };
  var stepBackward = function stepBackward() {
    var _getBounds2 = getBounds(),
      min = _getBounds2.min,
      max = _getBounds2.max;
    var diff = max.diff(min);
    applyTime({
      start: (0, _moment.default)(min).subtract(diff, 'ms').toISOString(),
      end: (0, _moment.default)(min).toISOString(),
      keepPopoverOpen: true
    });
  };
  var timeTense = state.timeTense,
    timeValue = state.timeValue,
    timeUnits = state.timeUnits;
  var timeTenseOptions = timeOptions.timeTenseOptions,
    timeUnitsOptions = timeOptions.timeUnitsOptions;
  var matchedTimeUnit = timeUnitsOptions.find(function (_ref3) {
    var value = _ref3.value;
    return value === timeUnits;
  });
  var timeUnit = matchedTimeUnit ? matchedTimeUnit.text : '';
  return (0, _react2.jsx)(_quick_select_panel.EuiQuickSelectPanel, {
    component: "fieldset",
    title: (0, _react2.jsx)(_i18n.EuiI18n, {
      token: "euiQuickSelect.quickSelectTitle",
      default: "Quick select"
    }),
    titleId: legendId,
    "aria-describedby": timeSelectionId,
    css: _ref4
  }, (0, _react2.jsx)(_flex.EuiFlexGroup, {
    css: _ref5,
    alignItems: "center",
    gutterSize: "s",
    responsive: false
  }, (0, _react2.jsx)(_flex.EuiFlexItem, {
    grow: false
  }, (0, _react2.jsx)(_i18n.EuiI18n, {
    token: "euiQuickSelect.previousLabel",
    default: "Previous time window"
  }, function (previousLabel) {
    return (0, _react2.jsx)(_tool_tip.EuiToolTip, {
      content: previousLabel,
      disableScreenReaderOutput: true
    }, (0, _react2.jsx)(_button.EuiButtonIcon, {
      "aria-label": previousLabel,
      iconType: "chevronSingleLeft",
      onClick: stepBackward
    }));
  })), (0, _react2.jsx)(_flex.EuiFlexItem, {
    grow: false
  }, (0, _react2.jsx)(_i18n.EuiI18n, {
    token: "euiQuickSelect.nextLabel",
    default: "Next time window"
  }, function (nextLabel) {
    return (0, _react2.jsx)(_tool_tip.EuiToolTip, {
      content: nextLabel,
      disableScreenReaderOutput: true
    }, (0, _react2.jsx)(_button.EuiButtonIcon, {
      "aria-label": nextLabel,
      iconType: "chevronSingleRight",
      onClick: stepForward
    }));
  }))), (0, _react2.jsx)(_flex.EuiFlexGroup, {
    gutterSize: "s",
    responsive: false
  }, (0, _react2.jsx)(_flex.EuiFlexItem, null, (0, _react2.jsx)(_i18n.EuiI18n, {
    token: "euiQuickSelect.tenseLabel",
    default: "Time tense"
  }, function (tenseLabel) {
    return (0, _react2.jsx)(_form.EuiSelect, {
      compressed: true,
      onKeyDown: handleKeyDown,
      "aria-label": tenseLabel,
      "aria-describedby": "".concat(timeSelectionId, " ").concat(legendId),
      value: timeTense,
      options: timeTenseOptions,
      onChange: onTimeTenseChange
    });
  })), (0, _react2.jsx)(_flex.EuiFlexItem, null, (0, _react2.jsx)(_i18n.EuiI18n, {
    token: "euiQuickSelect.valueLabel",
    default: "Time value"
  }, function (valueLabel) {
    return (0, _react2.jsx)(_form.EuiFieldNumber, {
      compressed: true,
      onKeyDown: handleKeyDown,
      "aria-describedby": "".concat(timeSelectionId, " ").concat(legendId),
      "aria-label": valueLabel,
      value: timeValue,
      onChange: onTimeValueChange
    });
  })), (0, _react2.jsx)(_flex.EuiFlexItem, null, (0, _react2.jsx)(_i18n.EuiI18n, {
    token: "euiQuickSelect.unitLabel",
    default: "Time unit"
  }, function (unitLabel) {
    return (0, _react2.jsx)(_form.EuiSelect, {
      compressed: true,
      onKeyDown: handleKeyDown,
      "aria-label": unitLabel,
      "aria-describedby": "".concat(timeSelectionId, " ").concat(legendId),
      value: timeUnits,
      options: timeUnitsOptions,
      onChange: onTimeUnitsChange
    });
  })), (0, _react2.jsx)(_flex.EuiFlexItem, {
    grow: false
  }, (0, _react2.jsx)(_button.EuiButton, {
    "aria-describedby": "".concat(timeSelectionId, " ").concat(legendId),
    "data-test-subj": "superDatePickerQuickSelectApplyButton",
    minWidth: 0 // Allow the button to shrink
    ,
    size: "s",
    onClick: applyQuickSelect,
    disabled: timeValue <= 0
  }, (0, _react2.jsx)(_i18n.EuiI18n, {
    token: "euiQuickSelect.applyButton",
    default: "Apply"
  })))), (0, _react2.jsx)(_accessibility.EuiScreenReaderOnly, null, (0, _react2.jsx)("p", {
    id: timeSelectionId
  }, (0, _react2.jsx)(_i18n.EuiI18n, {
    token: "euiQuickSelect.fullDescription",
    default: "Currently set to {timeTense} {timeValue} {timeUnit}.",
    values: {
      timeTense: timeTense,
      timeValue: timeValue,
      timeUnit: timeUnit
    }
  }))));
};