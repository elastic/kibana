"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ZodLiteral = exports.ZodEnum = exports.ZodSet = exports.ZodMap = exports.ZodRecord = exports.ZodTuple = exports.ZodIntersection = exports.ZodDiscriminatedUnion = exports.ZodXor = exports.ZodUnion = exports.ZodObject = exports.ZodArray = exports.ZodDate = exports.ZodVoid = exports.ZodNever = exports.ZodUnknown = exports.ZodAny = exports.ZodNull = exports.ZodUndefined = exports.ZodSymbol = exports.ZodBigIntFormat = exports.ZodBigInt = exports.ZodBoolean = exports.ZodNumberFormat = exports.ZodNumber = exports.ZodCustomStringFormat = exports.ZodJWT = exports.ZodE164 = exports.ZodBase64URL = exports.ZodBase64 = exports.ZodCIDRv6 = exports.ZodCIDRv4 = exports.ZodIPv6 = exports.ZodMAC = exports.ZodIPv4 = exports.ZodKSUID = exports.ZodXID = exports.ZodULID = exports.ZodCUID2 = exports.ZodCUID = exports.ZodNanoID = exports.ZodEmoji = exports.ZodURL = exports.ZodUUID = exports.ZodGUID = exports.ZodEmail = exports.ZodStringFormat = exports.ZodString = exports._ZodString = exports.ZodType = void 0;
exports.stringbool = exports.meta = exports.describe = exports.ZodCustom = exports.ZodFunction = exports.ZodPromise = exports.ZodLazy = exports.ZodTemplateLiteral = exports.ZodReadonly = exports.ZodCodec = exports.ZodPipe = exports.ZodNaN = exports.ZodCatch = exports.ZodSuccess = exports.ZodNonOptional = exports.ZodPrefault = exports.ZodDefault = exports.ZodNullable = exports.ZodExactOptional = exports.ZodOptional = exports.ZodTransform = exports.ZodFile = void 0;
exports.string = string;
exports.email = email;
exports.guid = guid;
exports.uuid = uuid;
exports.uuidv4 = uuidv4;
exports.uuidv6 = uuidv6;
exports.uuidv7 = uuidv7;
exports.url = url;
exports.httpUrl = httpUrl;
exports.emoji = emoji;
exports.nanoid = nanoid;
exports.cuid = cuid;
exports.cuid2 = cuid2;
exports.ulid = ulid;
exports.xid = xid;
exports.ksuid = ksuid;
exports.ipv4 = ipv4;
exports.mac = mac;
exports.ipv6 = ipv6;
exports.cidrv4 = cidrv4;
exports.cidrv6 = cidrv6;
exports.base64 = base64;
exports.base64url = base64url;
exports.e164 = e164;
exports.jwt = jwt;
exports.stringFormat = stringFormat;
exports.hostname = hostname;
exports.hex = hex;
exports.hash = hash;
exports.number = number;
exports.int = int;
exports.float32 = float32;
exports.float64 = float64;
exports.int32 = int32;
exports.uint32 = uint32;
exports.boolean = boolean;
exports.bigint = bigint;
exports.int64 = int64;
exports.uint64 = uint64;
exports.symbol = symbol;
exports.undefined = _undefined;
exports.null = _null;
exports.any = any;
exports.unknown = unknown;
exports.never = never;
exports.void = _void;
exports.date = date;
exports.array = array;
exports.keyof = keyof;
exports.object = object;
exports.strictObject = strictObject;
exports.looseObject = looseObject;
exports.union = union;
exports.xor = xor;
exports.discriminatedUnion = discriminatedUnion;
exports.intersection = intersection;
exports.tuple = tuple;
exports.record = record;
exports.partialRecord = partialRecord;
exports.looseRecord = looseRecord;
exports.map = map;
exports.set = set;
exports.enum = _enum;
exports.nativeEnum = nativeEnum;
exports.literal = literal;
exports.file = file;
exports.transform = transform;
exports.optional = optional;
exports.exactOptional = exactOptional;
exports.nullable = nullable;
exports.nullish = nullish;
exports._default = _default;
exports.prefault = prefault;
exports.nonoptional = nonoptional;
exports.success = success;
exports.catch = _catch;
exports.nan = nan;
exports.pipe = pipe;
exports.codec = codec;
exports.readonly = readonly;
exports.templateLiteral = templateLiteral;
exports.lazy = lazy;
exports.promise = promise;
exports._function = _function;
exports.function = _function;
exports._function = _function;
exports.function = _function;
exports.check = check;
exports.custom = custom;
exports.refine = refine;
exports.superRefine = superRefine;
exports.instanceof = _instanceof;
exports.json = json;
exports.preprocess = preprocess;
const core = __importStar(require("../core/index.cjs"));
const index_js_1 = require("../core/index.cjs");
const processors = __importStar(require("../core/json-schema-processors.cjs"));
const to_json_schema_js_1 = require("../core/to-json-schema.cjs");
const checks = __importStar(require("./checks.cjs"));
const iso = __importStar(require("./iso.cjs"));
const parse = __importStar(require("./parse.cjs"));
// Maps (prototype, key) pairs already initialized — avoids repeated prototype setup
const _protoInitMap = new WeakMap();
/**
 * Sets shared methods on the prototype of inst's constructor (once per concrete type).
 * Each initializer uses a unique key so multiple call sites don't interfere.
 */
function _initProto(inst, key, methods, defineProps) {
    const proto = Object.getPrototypeOf(inst);
    let keys = _protoInitMap.get(proto);
    if (!keys) {
        keys = new Set();
        _protoInitMap.set(proto, keys);
    }
    if (keys.has(key))
        return;
    keys.add(key);
    Object.assign(proto, methods);
    if (defineProps) {
        for (const [k, desc] of defineProps) {
            Object.defineProperty(proto, k, { ...desc, configurable: true });
        }
    }
}
// ─────────────────────────────────────────────────────────────────────────────
// Shared method references (memory optimization)
//
// Zod v4 originally assigned every schema method as a per-instance arrow
// function closure, capturing `inst`. With many schemas this causes significant
// heap pressure (~50 extra function objects per schema instance). Instead, we
// define each method once as a named function that uses `this` for context.
// All instances then share the same function objects while retaining the same
// own-property API surface and full runtime correctness.
//
// The return-type casts (`as any`) are required because TypeScript cannot
// statically verify that a shared `this: ZodType` matches the polymorphic
// `this` in the interface declaration. The declared interface types remain
// authoritative; these casts are implementation-only.
// ─────────────────────────────────────────────────────────────────────────────
// ZodType – base methods
function _sharedCheck(...chks) {
    const def = this.def;
    return this.clone(index_js_1.util.mergeDefs(def, {
        checks: [
            ...(def.checks ?? []),
            ...chks.map((ch) => typeof ch === "function" ? { _zod: { check: ch, def: { check: "custom" }, onattach: [] } } : ch),
        ],
    }), { parent: true });
}
function _sharedClone(def, params) {
    return core.clone(this, def, params);
}
function _sharedBrand() {
    return this;
}
function _sharedRegister(reg, meta) {
    reg.add(this, meta);
    return this;
}
// NOTE: parse/safeParse/parseAsync/safeParseAsync/encode/decode (and their variants)
// are intentionally kept as per-instance closures in the ZodType initializer below.
// These methods are commonly called in a detached manner (e.g. `arr.map(schema.parse)`
// or `const p = schema.parse; p(v)`), so they must capture `inst` rather than rely
// on `this` binding.
function _sharedRefine(check, params) {
    return this.check(refine(check, params));
}
function _sharedSuperRefine(refinement) {
    return this.check(superRefine(refinement));
}
function _sharedOverwrite(fn) {
    return this.check(checks.overwrite(fn));
}
function _sharedOptional() {
    return optional(this);
}
function _sharedExactOptional() {
    return exactOptional(this);
}
function _sharedNullable() {
    return nullable(this);
}
function _sharedNullish() {
    return optional(nullable(this));
}
function _sharedNonoptional(params) {
    return nonoptional(this, params);
}
function _sharedArray() {
    return array(this);
}
function _sharedOr(arg) {
    return union([this, arg]);
}
function _sharedAnd(arg) {
    return intersection(this, arg);
}
function _sharedTransform(tx) {
    return pipe(this, transform(tx));
}
function _sharedDefault(d) {
    return _default(this, d);
}
function _sharedPrefault(d) {
    return prefault(this, d);
}
function _sharedCatch(params) {
    return _catch(this, params);
}
function _sharedPipe(target) {
    return pipe(this, target);
}
function _sharedReadonly() {
    return readonly(this);
}
function _sharedDescribe(description) {
    const cl = this.clone();
    core.globalRegistry.add(cl, { description });
    return cl;
}
function _sharedMeta(...args) {
    if (args.length === 0)
        return core.globalRegistry.get(this);
    const cl = this.clone();
    core.globalRegistry.add(cl, args[0]);
    return cl;
}
function _sharedIsOptional() {
    return this.safeParse(undefined).success;
}
function _sharedIsNullable() {
    return this.safeParse(null).success;
}
function _sharedApply(fn) {
    return fn(this);
}
// _ZodString – string validation methods
function _sharedRegex(...args) {
    return this.check(checks.regex(...args));
}
function _sharedIncludes(...args) {
    return this.check(checks.includes(...args));
}
function _sharedStartsWith(...args) {
    return this.check(checks.startsWith(...args));
}
function _sharedEndsWith(...args) {
    return this.check(checks.endsWith(...args));
}
function _sharedStrMin(...args) {
    return this.check(checks.minLength(...args));
}
function _sharedStrMax(...args) {
    return this.check(checks.maxLength(...args));
}
function _sharedStrLength(...args) {
    return this.check(checks.length(...args));
}
function _sharedStrNonempty(...args) {
    return this.check(checks.minLength(1, ...args));
}
function _sharedLowercase(params) {
    return this.check(checks.lowercase(params));
}
function _sharedUppercase(params) {
    return this.check(checks.uppercase(params));
}
function _sharedTrim() {
    return this.check(checks.trim());
}
function _sharedNormalize(...args) {
    return this.check(checks.normalize(...args));
}
function _sharedToLowerCase() {
    return this.check(checks.toLowerCase());
}
function _sharedToUpperCase() {
    return this.check(checks.toUpperCase());
}
function _sharedSlugify() {
    return this.check(checks.slugify());
}
// ZodString – format methods
function _sharedEmail(params) {
    return this.check(core._email(exports.ZodEmail, params));
}
function _sharedUrl(params) {
    return this.check(core._url(exports.ZodURL, params));
}
function _sharedJwt(params) {
    return this.check(core._jwt(exports.ZodJWT, params));
}
function _sharedEmoji(params) {
    return this.check(core._emoji(exports.ZodEmoji, params));
}
function _sharedGuid(params) {
    return this.check(core._guid(exports.ZodGUID, params));
}
function _sharedUuid(params) {
    return this.check(core._uuid(exports.ZodUUID, params));
}
function _sharedUuidv4(params) {
    return this.check(core._uuidv4(exports.ZodUUID, params));
}
function _sharedUuidv6(params) {
    return this.check(core._uuidv6(exports.ZodUUID, params));
}
function _sharedUuidv7(params) {
    return this.check(core._uuidv7(exports.ZodUUID, params));
}
function _sharedNanoid(params) {
    return this.check(core._nanoid(exports.ZodNanoID, params));
}
function _sharedCuid(params) {
    return this.check(core._cuid(exports.ZodCUID, params));
}
function _sharedCuid2(params) {
    return this.check(core._cuid2(exports.ZodCUID2, params));
}
function _sharedUlid(params) {
    return this.check(core._ulid(exports.ZodULID, params));
}
function _sharedBase64(params) {
    return this.check(core._base64(exports.ZodBase64, params));
}
function _sharedBase64url(params) {
    return this.check(core._base64url(exports.ZodBase64URL, params));
}
function _sharedXid(params) {
    return this.check(core._xid(exports.ZodXID, params));
}
function _sharedKsuid(params) {
    return this.check(core._ksuid(exports.ZodKSUID, params));
}
function _sharedIpv4(params) {
    return this.check(core._ipv4(exports.ZodIPv4, params));
}
function _sharedIpv6(params) {
    return this.check(core._ipv6(exports.ZodIPv6, params));
}
function _sharedCidrv4(params) {
    return this.check(core._cidrv4(exports.ZodCIDRv4, params));
}
function _sharedCidrv6(params) {
    return this.check(core._cidrv6(exports.ZodCIDRv6, params));
}
function _sharedE164(params) {
    return this.check(core._e164(exports.ZodE164, params));
}
function _sharedDatetime(params) {
    return this.check(iso.datetime(params));
}
function _sharedDate(params) {
    return this.check(iso.date(params));
}
function _sharedTime(params) {
    return this.check(iso.time(params));
}
function _sharedDuration(params) {
    return this.check(iso.duration(params));
}
// ZodNumber – numeric methods
function _sharedNumGt(value, params) {
    return this.check(checks.gt(value, params));
}
function _sharedNumGte(value, params) {
    return this.check(checks.gte(value, params));
}
function _sharedNumLt(value, params) {
    return this.check(checks.lt(value, params));
}
function _sharedNumLte(value, params) {
    return this.check(checks.lte(value, params));
}
function _sharedNumInt(params) {
    return this.check(int(params));
}
function _sharedNumPositive(params) {
    return this.check(checks.gt(0, params));
}
function _sharedNumNonnegative(params) {
    return this.check(checks.gte(0, params));
}
function _sharedNumNegative(params) {
    return this.check(checks.lt(0, params));
}
function _sharedNumNonpositive(params) {
    return this.check(checks.lte(0, params));
}
function _sharedNumMultipleOf(value, params) {
    return this.check(checks.multipleOf(value, params));
}
function _sharedNumFinite() {
    return this;
}
// ZodBigInt – bigint methods
function _sharedBigIntGt(value, params) {
    return this.check(checks.gt(value, params));
}
function _sharedBigIntGte(value, params) {
    return this.check(checks.gte(value, params));
}
function _sharedBigIntLt(value, params) {
    return this.check(checks.lt(value, params));
}
function _sharedBigIntLte(value, params) {
    return this.check(checks.lte(value, params));
}
function _sharedBigIntPositive(params) {
    return this.check(checks.gt(BigInt(0), params));
}
function _sharedBigIntNegative(params) {
    return this.check(checks.lt(BigInt(0), params));
}
function _sharedBigIntNonpositive(params) {
    return this.check(checks.lte(BigInt(0), params));
}
function _sharedBigIntNonnegative(params) {
    return this.check(checks.gte(BigInt(0), params));
}
function _sharedBigIntMultipleOf(value, params) {
    return this.check(checks.multipleOf(value, params));
}
// ZodDate – date validation methods
function _sharedDateMin(value, params) {
    return this.check(checks.gte(value, params));
}
function _sharedDateMax(value, params) {
    return this.check(checks.lte(value, params));
}
// ZodArray – array methods
function _sharedArrMin(minLength, params) {
    return this.check(checks.minLength(minLength, params));
}
function _sharedArrNonempty(params) {
    return this.check(checks.minLength(1, params));
}
function _sharedArrMax(maxLength, params) {
    return this.check(checks.maxLength(maxLength, params));
}
function _sharedArrLength(len, params) {
    return this.check(checks.length(len, params));
}
function _sharedArrUnwrap() {
    return this.element;
}
// ZodObject – object methods
function _sharedObjKeyof() {
    return _enum(Object.keys(this._zod.def.shape));
}
function _sharedObjCatchall(catchall) {
    return this.clone({ ...this._zod.def, catchall });
}
function _sharedObjPassthrough() {
    return this.clone({ ...this._zod.def, catchall: unknown() });
}
function _sharedObjLoose() {
    return this.clone({ ...this._zod.def, catchall: unknown() });
}
function _sharedObjStrict() {
    return this.clone({ ...this._zod.def, catchall: never() });
}
function _sharedObjStrip() {
    return this.clone({ ...this._zod.def, catchall: undefined });
}
function _sharedObjExtend(incoming) {
    return index_js_1.util.extend(this, incoming);
}
function _sharedObjSafeExtend(incoming) {
    return index_js_1.util.safeExtend(this, incoming);
}
function _sharedObjMerge(other) {
    return index_js_1.util.merge(this, other);
}
function _sharedObjPick(mask) {
    return index_js_1.util.pick(this, mask);
}
function _sharedObjOmit(mask) {
    return index_js_1.util.omit(this, mask);
}
function _sharedObjPartial(...args) {
    return index_js_1.util.partial(exports.ZodOptional, this, args[0]);
}
function _sharedObjRequired(...args) {
    return index_js_1.util.required(exports.ZodNonOptional, this, args[0]);
}
// ZodTuple
function _sharedTupleRest(rest) {
    return this.clone({ ...this._zod.def, rest });
}
// ZodMap / ZodSet – size methods
function _sharedSizeMin(...args) {
    return this.check(core._minSize(...args));
}
function _sharedSizeNonempty(params) {
    return this.check(core._minSize(1, params));
}
function _sharedSizeMax(...args) {
    return this.check(core._maxSize(...args));
}
function _sharedSize(...args) {
    return this.check(core._size(...args));
}
// ZodFile – file methods
function _sharedFileMin(size, params) {
    return this.check(core._minSize(size, params));
}
function _sharedFileMax(size, params) {
    return this.check(core._maxSize(size, params));
}
function _sharedFileMime(types, params) {
    return this.check(core._mime(Array.isArray(types) ? types : [types], params));
}
// ZodEnum – extract/exclude
function _sharedEnumExtract(values, params) {
    const def = this._zod.def;
    const keys = new Set(Object.keys(def.entries));
    const newEntries = {};
    for (const value of values) {
        if (keys.has(value))
            newEntries[value] = def.entries[value];
        else
            throw new Error(`Key ${value} not found in enum`);
    }
    return new exports.ZodEnum({ ...def, checks: [], ...index_js_1.util.normalizeParams(params), entries: newEntries });
}
function _sharedEnumExclude(values, params) {
    const def = this._zod.def;
    const keys = new Set(Object.keys(def.entries));
    const newEntries = { ...def.entries };
    for (const value of values) {
        if (keys.has(value))
            delete newEntries[value];
        else
            throw new Error(`Key ${value} not found in enum`);
    }
    return new exports.ZodEnum({ ...def, checks: [], ...index_js_1.util.normalizeParams(params), entries: newEntries });
}
// Wrapper types – shared unwrap
function _sharedUnwrap() {
    return this._zod.def.innerType;
}
function _sharedLazyUnwrap() {
    return this._zod.def.getter();
}
exports.ZodType = core.$constructor("ZodType", (inst, def) => {
    core.$ZodType.init(inst, def);
    Object.assign(inst["~standard"], {
        jsonSchema: {
            input: (0, to_json_schema_js_1.createStandardJSONSchemaMethod)(inst, "input"),
            output: (0, to_json_schema_js_1.createStandardJSONSchemaMethod)(inst, "output"),
        },
    });
    inst.toJSONSchema = (0, to_json_schema_js_1.createToJSONSchemaMethod)(inst, {});
    inst.def = def;
    inst.type = def.type;
    Object.defineProperty(inst, "_def", { value: def });
    // base methods
    // parsing
    // parsing — kept as per-instance closures so that detached usage works:
    //   const parse = schema.parse; parse("hello"); // must work
    inst.parse = (data, params) => parse.parse(inst, data, params, { callee: inst.parse });
    inst.safeParse = (data, params) => parse.safeParse(inst, data, params);
    inst.parseAsync = async (data, params) => parse.parseAsync(inst, data, params, { callee: inst.parseAsync });
    inst.safeParseAsync = async (data, params) => parse.safeParseAsync(inst, data, params);
    inst.spa = inst.safeParseAsync;
    // encoding/decoding — same reason
    inst.encode = (data, params) => parse.encode(inst, data, params);
    inst.decode = (data, params) => parse.decode(inst, data, params);
    inst.encodeAsync = async (data, params) => parse.encodeAsync(inst, data, params);
    inst.decodeAsync = async (data, params) => parse.decodeAsync(inst, data, params);
    inst.safeEncode = (data, params) => parse.safeEncode(inst, data, params);
    inst.safeDecode = (data, params) => parse.safeDecode(inst, data, params);
    inst.safeEncodeAsync = async (data, params) => parse.safeEncodeAsync(inst, data, params);
    inst.safeDecodeAsync = async (data, params) => parse.safeDecodeAsync(inst, data, params);
    // refinements
    // wrappers
    // inst.coalesce = (def, params) => coalesce(inst, def, params);
    // meta
    // helpers
    _initProto(inst, "ZodType", {
        check: _sharedCheck,
        with: _sharedCheck,
        clone: _sharedClone,
        brand: _sharedBrand,
        register: _sharedRegister,
        refine: _sharedRefine,
        superRefine: _sharedSuperRefine,
        overwrite: _sharedOverwrite,
        optional: _sharedOptional,
        exactOptional: _sharedExactOptional,
        nullable: _sharedNullable,
        nullish: _sharedNullish,
        nonoptional: _sharedNonoptional,
        array: _sharedArray,
        or: _sharedOr,
        and: _sharedAnd,
        transform: _sharedTransform,
        default: _sharedDefault,
        prefault: _sharedPrefault,
        catch: _sharedCatch,
        pipe: _sharedPipe,
        readonly: _sharedReadonly,
        describe: _sharedDescribe,
        meta: _sharedMeta,
        isOptional: _sharedIsOptional,
        isNullable: _sharedIsNullable,
        apply: _sharedApply,
    }, [
        [
            "description",
            {
                get() {
                    return core.globalRegistry.get(this)?.description;
                },
                configurable: true,
            },
        ],
    ]);
    return inst;
});
/** @internal */
exports._ZodString = core.$constructor("_ZodString", (inst, def) => {
    core.$ZodString.init(inst, def);
    exports.ZodType.init(inst, def);
    inst._zod.processJSONSchema = (ctx, json, params) => processors.stringProcessor(inst, ctx, json, params);
    const bag = inst._zod.bag;
    inst.format = bag.format ?? null;
    inst.minLength = bag.minimum ?? null;
    inst.maxLength = bag.maximum ?? null;
    // validations
    // transforms
    _initProto(inst, "_ZodString", {
        regex: _sharedRegex,
        includes: _sharedIncludes,
        startsWith: _sharedStartsWith,
        endsWith: _sharedEndsWith,
        min: _sharedStrMin,
        max: _sharedStrMax,
        length: _sharedStrLength,
        nonempty: _sharedStrNonempty,
        lowercase: _sharedLowercase,
        uppercase: _sharedUppercase,
        trim: _sharedTrim,
        normalize: _sharedNormalize,
        toLowerCase: _sharedToLowerCase,
        toUpperCase: _sharedToUpperCase,
        slugify: _sharedSlugify,
    });
});
exports.ZodString = core.$constructor("ZodString", (inst, def) => {
    core.$ZodString.init(inst, def);
    exports._ZodString.init(inst, def);
    // iso
    _initProto(inst, "ZodString", {
        email: _sharedEmail,
        url: _sharedUrl,
        jwt: _sharedJwt,
        emoji: _sharedEmoji,
        guid: _sharedGuid,
        uuid: _sharedUuid,
        uuidv4: _sharedUuidv4,
        uuidv6: _sharedUuidv6,
        uuidv7: _sharedUuidv7,
        nanoid: _sharedNanoid,
        cuid: _sharedCuid,
        cuid2: _sharedCuid2,
        ulid: _sharedUlid,
        base64: _sharedBase64,
        base64url: _sharedBase64url,
        xid: _sharedXid,
        ksuid: _sharedKsuid,
        ipv4: _sharedIpv4,
        ipv6: _sharedIpv6,
        cidrv4: _sharedCidrv4,
        cidrv6: _sharedCidrv6,
        e164: _sharedE164,
        datetime: _sharedDatetime,
        date: _sharedDate,
        time: _sharedTime,
        duration: _sharedDuration,
    });
});
function string(params) {
    return core._string(exports.ZodString, params);
}
exports.ZodStringFormat = core.$constructor("ZodStringFormat", (inst, def) => {
    core.$ZodStringFormat.init(inst, def);
    exports._ZodString.init(inst, def);
});
exports.ZodEmail = core.$constructor("ZodEmail", (inst, def) => {
    // ZodStringFormat.init(inst, def);
    core.$ZodEmail.init(inst, def);
    exports.ZodStringFormat.init(inst, def);
});
function email(params) {
    return core._email(exports.ZodEmail, params);
}
exports.ZodGUID = core.$constructor("ZodGUID", (inst, def) => {
    // ZodStringFormat.init(inst, def);
    core.$ZodGUID.init(inst, def);
    exports.ZodStringFormat.init(inst, def);
});
function guid(params) {
    return core._guid(exports.ZodGUID, params);
}
exports.ZodUUID = core.$constructor("ZodUUID", (inst, def) => {
    // ZodStringFormat.init(inst, def);
    core.$ZodUUID.init(inst, def);
    exports.ZodStringFormat.init(inst, def);
});
function uuid(params) {
    return core._uuid(exports.ZodUUID, params);
}
function uuidv4(params) {
    return core._uuidv4(exports.ZodUUID, params);
}
// ZodUUIDv6
function uuidv6(params) {
    return core._uuidv6(exports.ZodUUID, params);
}
// ZodUUIDv7
function uuidv7(params) {
    return core._uuidv7(exports.ZodUUID, params);
}
exports.ZodURL = core.$constructor("ZodURL", (inst, def) => {
    // ZodStringFormat.init(inst, def);
    core.$ZodURL.init(inst, def);
    exports.ZodStringFormat.init(inst, def);
});
function url(params) {
    return core._url(exports.ZodURL, params);
}
function httpUrl(params) {
    return core._url(exports.ZodURL, {
        protocol: core.regexes.httpProtocol,
        hostname: core.regexes.domain,
        ...index_js_1.util.normalizeParams(params),
    });
}
exports.ZodEmoji = core.$constructor("ZodEmoji", (inst, def) => {
    // ZodStringFormat.init(inst, def);
    core.$ZodEmoji.init(inst, def);
    exports.ZodStringFormat.init(inst, def);
});
function emoji(params) {
    return core._emoji(exports.ZodEmoji, params);
}
exports.ZodNanoID = core.$constructor("ZodNanoID", (inst, def) => {
    // ZodStringFormat.init(inst, def);
    core.$ZodNanoID.init(inst, def);
    exports.ZodStringFormat.init(inst, def);
});
function nanoid(params) {
    return core._nanoid(exports.ZodNanoID, params);
}
exports.ZodCUID = core.$constructor("ZodCUID", (inst, def) => {
    // ZodStringFormat.init(inst, def);
    core.$ZodCUID.init(inst, def);
    exports.ZodStringFormat.init(inst, def);
});
function cuid(params) {
    return core._cuid(exports.ZodCUID, params);
}
exports.ZodCUID2 = core.$constructor("ZodCUID2", (inst, def) => {
    // ZodStringFormat.init(inst, def);
    core.$ZodCUID2.init(inst, def);
    exports.ZodStringFormat.init(inst, def);
});
function cuid2(params) {
    return core._cuid2(exports.ZodCUID2, params);
}
exports.ZodULID = core.$constructor("ZodULID", (inst, def) => {
    // ZodStringFormat.init(inst, def);
    core.$ZodULID.init(inst, def);
    exports.ZodStringFormat.init(inst, def);
});
function ulid(params) {
    return core._ulid(exports.ZodULID, params);
}
exports.ZodXID = core.$constructor("ZodXID", (inst, def) => {
    // ZodStringFormat.init(inst, def);
    core.$ZodXID.init(inst, def);
    exports.ZodStringFormat.init(inst, def);
});
function xid(params) {
    return core._xid(exports.ZodXID, params);
}
exports.ZodKSUID = core.$constructor("ZodKSUID", (inst, def) => {
    // ZodStringFormat.init(inst, def);
    core.$ZodKSUID.init(inst, def);
    exports.ZodStringFormat.init(inst, def);
});
function ksuid(params) {
    return core._ksuid(exports.ZodKSUID, params);
}
exports.ZodIPv4 = core.$constructor("ZodIPv4", (inst, def) => {
    // ZodStringFormat.init(inst, def);
    core.$ZodIPv4.init(inst, def);
    exports.ZodStringFormat.init(inst, def);
});
function ipv4(params) {
    return core._ipv4(exports.ZodIPv4, params);
}
exports.ZodMAC = core.$constructor("ZodMAC", (inst, def) => {
    // ZodStringFormat.init(inst, def);
    core.$ZodMAC.init(inst, def);
    exports.ZodStringFormat.init(inst, def);
});
function mac(params) {
    return core._mac(exports.ZodMAC, params);
}
exports.ZodIPv6 = core.$constructor("ZodIPv6", (inst, def) => {
    // ZodStringFormat.init(inst, def);
    core.$ZodIPv6.init(inst, def);
    exports.ZodStringFormat.init(inst, def);
});
function ipv6(params) {
    return core._ipv6(exports.ZodIPv6, params);
}
exports.ZodCIDRv4 = core.$constructor("ZodCIDRv4", (inst, def) => {
    core.$ZodCIDRv4.init(inst, def);
    exports.ZodStringFormat.init(inst, def);
});
function cidrv4(params) {
    return core._cidrv4(exports.ZodCIDRv4, params);
}
exports.ZodCIDRv6 = core.$constructor("ZodCIDRv6", (inst, def) => {
    core.$ZodCIDRv6.init(inst, def);
    exports.ZodStringFormat.init(inst, def);
});
function cidrv6(params) {
    return core._cidrv6(exports.ZodCIDRv6, params);
}
exports.ZodBase64 = core.$constructor("ZodBase64", (inst, def) => {
    // ZodStringFormat.init(inst, def);
    core.$ZodBase64.init(inst, def);
    exports.ZodStringFormat.init(inst, def);
});
function base64(params) {
    return core._base64(exports.ZodBase64, params);
}
exports.ZodBase64URL = core.$constructor("ZodBase64URL", (inst, def) => {
    // ZodStringFormat.init(inst, def);
    core.$ZodBase64URL.init(inst, def);
    exports.ZodStringFormat.init(inst, def);
});
function base64url(params) {
    return core._base64url(exports.ZodBase64URL, params);
}
exports.ZodE164 = core.$constructor("ZodE164", (inst, def) => {
    // ZodStringFormat.init(inst, def);
    core.$ZodE164.init(inst, def);
    exports.ZodStringFormat.init(inst, def);
});
function e164(params) {
    return core._e164(exports.ZodE164, params);
}
exports.ZodJWT = core.$constructor("ZodJWT", (inst, def) => {
    // ZodStringFormat.init(inst, def);
    core.$ZodJWT.init(inst, def);
    exports.ZodStringFormat.init(inst, def);
});
function jwt(params) {
    return core._jwt(exports.ZodJWT, params);
}
exports.ZodCustomStringFormat = core.$constructor("ZodCustomStringFormat", (inst, def) => {
    // ZodStringFormat.init(inst, def);
    core.$ZodCustomStringFormat.init(inst, def);
    exports.ZodStringFormat.init(inst, def);
});
function stringFormat(format, fnOrRegex, _params = {}) {
    return core._stringFormat(exports.ZodCustomStringFormat, format, fnOrRegex, _params);
}
function hostname(_params) {
    return core._stringFormat(exports.ZodCustomStringFormat, "hostname", core.regexes.hostname, _params);
}
function hex(_params) {
    return core._stringFormat(exports.ZodCustomStringFormat, "hex", core.regexes.hex, _params);
}
function hash(alg, params) {
    const enc = params?.enc ?? "hex";
    const format = `${alg}_${enc}`;
    const regex = core.regexes[format];
    if (!regex)
        throw new Error(`Unrecognized hash format: ${format}`);
    return core._stringFormat(exports.ZodCustomStringFormat, format, regex, params);
}
exports.ZodNumber = core.$constructor("ZodNumber", (inst, def) => {
    core.$ZodNumber.init(inst, def);
    exports.ZodType.init(inst, def);
    inst._zod.processJSONSchema = (ctx, json, params) => processors.numberProcessor(inst, ctx, json, params);
    // inst.finite = (params) => inst.check(core.finite(params));
    const bag = inst._zod.bag;
    inst.minValue =
        Math.max(bag.minimum ?? Number.NEGATIVE_INFINITY, bag.exclusiveMinimum ?? Number.NEGATIVE_INFINITY) ?? null;
    inst.maxValue =
        Math.min(bag.maximum ?? Number.POSITIVE_INFINITY, bag.exclusiveMaximum ?? Number.POSITIVE_INFINITY) ?? null;
    inst.isInt = (bag.format ?? "").includes("int") || Number.isSafeInteger(bag.multipleOf ?? 0.5);
    inst.isFinite = true;
    inst.format = bag.format ?? null;
    _initProto(inst, "ZodNumber", {
        gt: _sharedNumGt,
        gte: _sharedNumGte,
        min: _sharedNumGte,
        lt: _sharedNumLt,
        lte: _sharedNumLte,
        max: _sharedNumLte,
        int: _sharedNumInt,
        safe: _sharedNumInt,
        positive: _sharedNumPositive,
        nonnegative: _sharedNumNonnegative,
        negative: _sharedNumNegative,
        nonpositive: _sharedNumNonpositive,
        multipleOf: _sharedNumMultipleOf,
        step: _sharedNumMultipleOf,
        finite: _sharedNumFinite,
    });
});
function number(params) {
    return core._number(exports.ZodNumber, params);
}
exports.ZodNumberFormat = core.$constructor("ZodNumberFormat", (inst, def) => {
    core.$ZodNumberFormat.init(inst, def);
    exports.ZodNumber.init(inst, def);
});
function int(params) {
    return core._int(exports.ZodNumberFormat, params);
}
function float32(params) {
    return core._float32(exports.ZodNumberFormat, params);
}
function float64(params) {
    return core._float64(exports.ZodNumberFormat, params);
}
function int32(params) {
    return core._int32(exports.ZodNumberFormat, params);
}
function uint32(params) {
    return core._uint32(exports.ZodNumberFormat, params);
}
exports.ZodBoolean = core.$constructor("ZodBoolean", (inst, def) => {
    core.$ZodBoolean.init(inst, def);
    exports.ZodType.init(inst, def);
    inst._zod.processJSONSchema = (ctx, json, params) => processors.booleanProcessor(inst, ctx, json, params);
});
function boolean(params) {
    return core._boolean(exports.ZodBoolean, params);
}
exports.ZodBigInt = core.$constructor("ZodBigInt", (inst, def) => {
    core.$ZodBigInt.init(inst, def);
    exports.ZodType.init(inst, def);
    inst._zod.processJSONSchema = (ctx, json, params) => processors.bigintProcessor(inst, ctx, json, params);
    const bag = inst._zod.bag;
    inst.minValue = bag.minimum ?? null;
    inst.maxValue = bag.maximum ?? null;
    inst.format = bag.format ?? null;
    _initProto(inst, "ZodBigInt", {
        gte: _sharedBigIntGte,
        min: _sharedBigIntGte,
        gt: _sharedBigIntGt,
        lt: _sharedBigIntLt,
        lte: _sharedBigIntLte,
        max: _sharedBigIntLte,
        positive: _sharedBigIntPositive,
        negative: _sharedBigIntNegative,
        nonpositive: _sharedBigIntNonpositive,
        nonnegative: _sharedBigIntNonnegative,
        multipleOf: _sharedBigIntMultipleOf,
    });
});
function bigint(params) {
    return core._bigint(exports.ZodBigInt, params);
}
exports.ZodBigIntFormat = core.$constructor("ZodBigIntFormat", (inst, def) => {
    core.$ZodBigIntFormat.init(inst, def);
    exports.ZodBigInt.init(inst, def);
});
// int64
function int64(params) {
    return core._int64(exports.ZodBigIntFormat, params);
}
// uint64
function uint64(params) {
    return core._uint64(exports.ZodBigIntFormat, params);
}
exports.ZodSymbol = core.$constructor("ZodSymbol", (inst, def) => {
    core.$ZodSymbol.init(inst, def);
    exports.ZodType.init(inst, def);
    inst._zod.processJSONSchema = (ctx, json, params) => processors.symbolProcessor(inst, ctx, json, params);
});
function symbol(params) {
    return core._symbol(exports.ZodSymbol, params);
}
exports.ZodUndefined = core.$constructor("ZodUndefined", (inst, def) => {
    core.$ZodUndefined.init(inst, def);
    exports.ZodType.init(inst, def);
    inst._zod.processJSONSchema = (ctx, json, params) => processors.undefinedProcessor(inst, ctx, json, params);
});
function _undefined(params) {
    return core._undefined(exports.ZodUndefined, params);
}
exports.ZodNull = core.$constructor("ZodNull", (inst, def) => {
    core.$ZodNull.init(inst, def);
    exports.ZodType.init(inst, def);
    inst._zod.processJSONSchema = (ctx, json, params) => processors.nullProcessor(inst, ctx, json, params);
});
function _null(params) {
    return core._null(exports.ZodNull, params);
}
exports.ZodAny = core.$constructor("ZodAny", (inst, def) => {
    core.$ZodAny.init(inst, def);
    exports.ZodType.init(inst, def);
    inst._zod.processJSONSchema = (ctx, json, params) => processors.anyProcessor(inst, ctx, json, params);
});
function any() {
    return core._any(exports.ZodAny);
}
exports.ZodUnknown = core.$constructor("ZodUnknown", (inst, def) => {
    core.$ZodUnknown.init(inst, def);
    exports.ZodType.init(inst, def);
    inst._zod.processJSONSchema = (ctx, json, params) => processors.unknownProcessor(inst, ctx, json, params);
});
function unknown() {
    return core._unknown(exports.ZodUnknown);
}
exports.ZodNever = core.$constructor("ZodNever", (inst, def) => {
    core.$ZodNever.init(inst, def);
    exports.ZodType.init(inst, def);
    inst._zod.processJSONSchema = (ctx, json, params) => processors.neverProcessor(inst, ctx, json, params);
});
function never(params) {
    return core._never(exports.ZodNever, params);
}
exports.ZodVoid = core.$constructor("ZodVoid", (inst, def) => {
    core.$ZodVoid.init(inst, def);
    exports.ZodType.init(inst, def);
    inst._zod.processJSONSchema = (ctx, json, params) => processors.voidProcessor(inst, ctx, json, params);
});
function _void(params) {
    return core._void(exports.ZodVoid, params);
}
exports.ZodDate = core.$constructor("ZodDate", (inst, def) => {
    core.$ZodDate.init(inst, def);
    exports.ZodType.init(inst, def);
    inst._zod.processJSONSchema = (ctx, json, params) => processors.dateProcessor(inst, ctx, json, params);
    _initProto(inst, "__min__", { min: _sharedDateMin });
    _initProto(inst, "__max__", { max: _sharedDateMax });
    const c = inst._zod.bag;
    inst.minDate = c.minimum ? new Date(c.minimum) : null;
    inst.maxDate = c.maximum ? new Date(c.maximum) : null;
});
function date(params) {
    return core._date(exports.ZodDate, params);
}
exports.ZodArray = core.$constructor("ZodArray", (inst, def) => {
    core.$ZodArray.init(inst, def);
    exports.ZodType.init(inst, def);
    inst._zod.processJSONSchema = (ctx, json, params) => processors.arrayProcessor(inst, ctx, json, params);
    inst.element = def.element;
    _initProto(inst, "__min__", { min: _sharedArrMin });
    _initProto(inst, "__nonempty__", { nonempty: _sharedArrNonempty });
    _initProto(inst, "__max__", { max: _sharedArrMax });
    _initProto(inst, "__length__", { length: _sharedArrLength });
    _initProto(inst, "__unwrap__", { unwrap: _sharedArrUnwrap });
});
function array(element, params) {
    return core._array(exports.ZodArray, element, params);
}
// .keyof
function keyof(schema) {
    const shape = schema._zod.def.shape;
    return _enum(Object.keys(shape));
}
exports.ZodObject = core.$constructor("ZodObject", (inst, def) => {
    core.$ZodObjectJIT.init(inst, def);
    exports.ZodType.init(inst, def);
    inst._zod.processJSONSchema = (ctx, json, params) => processors.objectProcessor(inst, ctx, json, params);
    index_js_1.util.defineLazy(inst, "shape", () => {
        return def.shape;
    });
    _initProto(inst, "__keyof__", { keyof: _sharedObjKeyof });
    _initProto(inst, "__catchall__", { catchall: _sharedObjCatchall });
    _initProto(inst, "__passthrough__", { passthrough: _sharedObjPassthrough });
    _initProto(inst, "__loose__", { loose: _sharedObjLoose });
    _initProto(inst, "__strict__", { strict: _sharedObjStrict });
    _initProto(inst, "__strip__", { strip: _sharedObjStrip });
    _initProto(inst, "__extend__", { extend: _sharedObjExtend });
    _initProto(inst, "__safeExtend__", { safeExtend: _sharedObjSafeExtend });
    _initProto(inst, "__merge__", { merge: _sharedObjMerge });
    _initProto(inst, "__pick__", { pick: _sharedObjPick });
    _initProto(inst, "__omit__", { omit: _sharedObjOmit });
    _initProto(inst, "__partial__", { partial: _sharedObjPartial });
    _initProto(inst, "__required__", { required: _sharedObjRequired });
});
function object(shape, params) {
    const def = {
        type: "object",
        shape: shape ?? {},
        ...index_js_1.util.normalizeParams(params),
    };
    return new exports.ZodObject(def);
}
// strictObject
function strictObject(shape, params) {
    return new exports.ZodObject({
        type: "object",
        shape,
        catchall: never(),
        ...index_js_1.util.normalizeParams(params),
    });
}
// looseObject
function looseObject(shape, params) {
    return new exports.ZodObject({
        type: "object",
        shape,
        catchall: unknown(),
        ...index_js_1.util.normalizeParams(params),
    });
}
exports.ZodUnion = core.$constructor("ZodUnion", (inst, def) => {
    core.$ZodUnion.init(inst, def);
    exports.ZodType.init(inst, def);
    inst._zod.processJSONSchema = (ctx, json, params) => processors.unionProcessor(inst, ctx, json, params);
    inst.options = def.options;
});
function union(options, params) {
    return new exports.ZodUnion({
        type: "union",
        options: options,
        ...index_js_1.util.normalizeParams(params),
    });
}
exports.ZodXor = core.$constructor("ZodXor", (inst, def) => {
    exports.ZodUnion.init(inst, def);
    core.$ZodXor.init(inst, def);
    inst._zod.processJSONSchema = (ctx, json, params) => processors.unionProcessor(inst, ctx, json, params);
    inst.options = def.options;
});
/** Creates an exclusive union (XOR) where exactly one option must match.
 * Unlike regular unions that succeed when any option matches, xor fails if
 * zero or more than one option matches the input. */
function xor(options, params) {
    return new exports.ZodXor({
        type: "union",
        options: options,
        inclusive: false,
        ...index_js_1.util.normalizeParams(params),
    });
}
exports.ZodDiscriminatedUnion = core.$constructor("ZodDiscriminatedUnion", (inst, def) => {
    exports.ZodUnion.init(inst, def);
    core.$ZodDiscriminatedUnion.init(inst, def);
});
function discriminatedUnion(discriminator, options, params) {
    // const [options, params] = args;
    return new exports.ZodDiscriminatedUnion({
        type: "union",
        options,
        discriminator,
        ...index_js_1.util.normalizeParams(params),
    });
}
exports.ZodIntersection = core.$constructor("ZodIntersection", (inst, def) => {
    core.$ZodIntersection.init(inst, def);
    exports.ZodType.init(inst, def);
    inst._zod.processJSONSchema = (ctx, json, params) => processors.intersectionProcessor(inst, ctx, json, params);
});
function intersection(left, right) {
    return new exports.ZodIntersection({
        type: "intersection",
        left: left,
        right: right,
    });
}
exports.ZodTuple = core.$constructor("ZodTuple", (inst, def) => {
    core.$ZodTuple.init(inst, def);
    exports.ZodType.init(inst, def);
    inst._zod.processJSONSchema = (ctx, json, params) => processors.tupleProcessor(inst, ctx, json, params);
    _initProto(inst, "__rest__", { rest: _sharedTupleRest });
});
function tuple(items, _paramsOrRest, _params) {
    const hasRest = _paramsOrRest instanceof core.$ZodType;
    const params = hasRest ? _params : _paramsOrRest;
    const rest = hasRest ? _paramsOrRest : null;
    return new exports.ZodTuple({
        type: "tuple",
        items: items,
        rest,
        ...index_js_1.util.normalizeParams(params),
    });
}
exports.ZodRecord = core.$constructor("ZodRecord", (inst, def) => {
    core.$ZodRecord.init(inst, def);
    exports.ZodType.init(inst, def);
    inst._zod.processJSONSchema = (ctx, json, params) => processors.recordProcessor(inst, ctx, json, params);
    inst.keyType = def.keyType;
    inst.valueType = def.valueType;
});
function record(keyType, valueType, params) {
    return new exports.ZodRecord({
        type: "record",
        keyType,
        valueType: valueType,
        ...index_js_1.util.normalizeParams(params),
    });
}
// type alksjf = core.output<core.$ZodRecordKey>;
function partialRecord(keyType, valueType, params) {
    const k = core.clone(keyType);
    k._zod.values = undefined;
    return new exports.ZodRecord({
        type: "record",
        keyType: k,
        valueType: valueType,
        ...index_js_1.util.normalizeParams(params),
    });
}
function looseRecord(keyType, valueType, params) {
    return new exports.ZodRecord({
        type: "record",
        keyType,
        valueType: valueType,
        mode: "loose",
        ...index_js_1.util.normalizeParams(params),
    });
}
exports.ZodMap = core.$constructor("ZodMap", (inst, def) => {
    core.$ZodMap.init(inst, def);
    exports.ZodType.init(inst, def);
    inst._zod.processJSONSchema = (ctx, json, params) => processors.mapProcessor(inst, ctx, json, params);
    inst.keyType = def.keyType;
    inst.valueType = def.valueType;
    _initProto(inst, "__min__", { min: _sharedSizeMin });
    _initProto(inst, "__nonempty__", { nonempty: _sharedSizeNonempty });
    _initProto(inst, "__max__", { max: _sharedSizeMax });
    _initProto(inst, "__size__", { size: _sharedSize });
});
function map(keyType, valueType, params) {
    return new exports.ZodMap({
        type: "map",
        keyType: keyType,
        valueType: valueType,
        ...index_js_1.util.normalizeParams(params),
    });
}
exports.ZodSet = core.$constructor("ZodSet", (inst, def) => {
    core.$ZodSet.init(inst, def);
    exports.ZodType.init(inst, def);
    inst._zod.processJSONSchema = (ctx, json, params) => processors.setProcessor(inst, ctx, json, params);
    _initProto(inst, "__min__", { min: _sharedSizeMin });
    _initProto(inst, "__nonempty__", { nonempty: _sharedSizeNonempty });
    _initProto(inst, "__max__", { max: _sharedSizeMax });
    _initProto(inst, "__size__", { size: _sharedSize });
});
function set(valueType, params) {
    return new exports.ZodSet({
        type: "set",
        valueType: valueType,
        ...index_js_1.util.normalizeParams(params),
    });
}
exports.ZodEnum = core.$constructor("ZodEnum", (inst, def) => {
    core.$ZodEnum.init(inst, def);
    exports.ZodType.init(inst, def);
    inst._zod.processJSONSchema = (ctx, json, params) => processors.enumProcessor(inst, ctx, json, params);
    inst.enum = def.entries;
    inst.options = Object.values(def.entries);
    _initProto(inst, "__extract__", { extract: _sharedEnumExtract });
    _initProto(inst, "__exclude__", { exclude: _sharedEnumExclude });
});
function _enum(values, params) {
    const entries = Array.isArray(values) ? Object.fromEntries(values.map((v) => [v, v])) : values;
    return new exports.ZodEnum({
        type: "enum",
        entries,
        ...index_js_1.util.normalizeParams(params),
    });
}
/** @deprecated This API has been merged into `z.enum()`. Use `z.enum()` instead.
 *
 * ```ts
 * enum Colors { red, green, blue }
 * z.enum(Colors);
 * ```
 */
function nativeEnum(entries, params) {
    return new exports.ZodEnum({
        type: "enum",
        entries,
        ...index_js_1.util.normalizeParams(params),
    });
}
exports.ZodLiteral = core.$constructor("ZodLiteral", (inst, def) => {
    core.$ZodLiteral.init(inst, def);
    exports.ZodType.init(inst, def);
    inst._zod.processJSONSchema = (ctx, json, params) => processors.literalProcessor(inst, ctx, json, params);
    inst.values = new Set(def.values);
    Object.defineProperty(inst, "value", {
        get() {
            if (def.values.length > 1) {
                throw new Error("This schema contains multiple valid literal values. Use `.values` instead.");
            }
            return def.values[0];
        },
    });
});
function literal(value, params) {
    return new exports.ZodLiteral({
        type: "literal",
        values: Array.isArray(value) ? value : [value],
        ...index_js_1.util.normalizeParams(params),
    });
}
exports.ZodFile = core.$constructor("ZodFile", (inst, def) => {
    core.$ZodFile.init(inst, def);
    exports.ZodType.init(inst, def);
    inst._zod.processJSONSchema = (ctx, json, params) => processors.fileProcessor(inst, ctx, json, params);
    _initProto(inst, "__min__", { min: _sharedFileMin });
    _initProto(inst, "__max__", { max: _sharedFileMax });
    _initProto(inst, "__mime__", { mime: _sharedFileMime });
});
function file(params) {
    return core._file(exports.ZodFile, params);
}
exports.ZodTransform = core.$constructor("ZodTransform", (inst, def) => {
    core.$ZodTransform.init(inst, def);
    exports.ZodType.init(inst, def);
    inst._zod.processJSONSchema = (ctx, json, params) => processors.transformProcessor(inst, ctx, json, params);
    inst._zod.parse = (payload, _ctx) => {
        if (_ctx.direction === "backward") {
            throw new core.$ZodEncodeError(inst.constructor.name);
        }
        payload.addIssue = (issue) => {
            if (typeof issue === "string") {
                payload.issues.push(index_js_1.util.issue(issue, payload.value, def));
            }
            else {
                // for Zod 3 backwards compatibility
                const _issue = issue;
                if (_issue.fatal)
                    _issue.continue = false;
                _issue.code ?? (_issue.code = "custom");
                _issue.input ?? (_issue.input = payload.value);
                _issue.inst ?? (_issue.inst = inst);
                // _issue.continue ??= true;
                payload.issues.push(index_js_1.util.issue(_issue));
            }
        };
        const output = def.transform(payload.value, payload);
        if (output instanceof Promise) {
            return output.then((output) => {
                payload.value = output;
                return payload;
            });
        }
        payload.value = output;
        return payload;
    };
});
function transform(fn) {
    return new exports.ZodTransform({
        type: "transform",
        transform: fn,
    });
}
exports.ZodOptional = core.$constructor("ZodOptional", (inst, def) => {
    core.$ZodOptional.init(inst, def);
    exports.ZodType.init(inst, def);
    inst._zod.processJSONSchema = (ctx, json, params) => processors.optionalProcessor(inst, ctx, json, params);
    _initProto(inst, "__unwrap__", { unwrap: _sharedUnwrap });
});
function optional(innerType) {
    return new exports.ZodOptional({
        type: "optional",
        innerType: innerType,
    });
}
exports.ZodExactOptional = core.$constructor("ZodExactOptional", (inst, def) => {
    core.$ZodExactOptional.init(inst, def);
    exports.ZodType.init(inst, def);
    inst._zod.processJSONSchema = (ctx, json, params) => processors.optionalProcessor(inst, ctx, json, params);
    _initProto(inst, "__unwrap__", { unwrap: _sharedUnwrap });
});
function exactOptional(innerType) {
    return new exports.ZodExactOptional({
        type: "optional",
        innerType: innerType,
    });
}
exports.ZodNullable = core.$constructor("ZodNullable", (inst, def) => {
    core.$ZodNullable.init(inst, def);
    exports.ZodType.init(inst, def);
    inst._zod.processJSONSchema = (ctx, json, params) => processors.nullableProcessor(inst, ctx, json, params);
    _initProto(inst, "__unwrap__", { unwrap: _sharedUnwrap });
});
function nullable(innerType) {
    return new exports.ZodNullable({
        type: "nullable",
        innerType: innerType,
    });
}
// nullish
function nullish(innerType) {
    return optional(nullable(innerType));
}
exports.ZodDefault = core.$constructor("ZodDefault", (inst, def) => {
    core.$ZodDefault.init(inst, def);
    exports.ZodType.init(inst, def);
    inst._zod.processJSONSchema = (ctx, json, params) => processors.defaultProcessor(inst, ctx, json, params);
    _initProto(inst, "__unwrap__", { unwrap: _sharedUnwrap });
    _initProto(inst, "__removeDefault__", { removeDefault: _sharedUnwrap });
});
function _default(innerType, defaultValue) {
    return new exports.ZodDefault({
        type: "default",
        innerType: innerType,
        get defaultValue() {
            return typeof defaultValue === "function" ? defaultValue() : index_js_1.util.shallowClone(defaultValue);
        },
    });
}
exports.ZodPrefault = core.$constructor("ZodPrefault", (inst, def) => {
    core.$ZodPrefault.init(inst, def);
    exports.ZodType.init(inst, def);
    inst._zod.processJSONSchema = (ctx, json, params) => processors.prefaultProcessor(inst, ctx, json, params);
    _initProto(inst, "__unwrap__", { unwrap: _sharedUnwrap });
});
function prefault(innerType, defaultValue) {
    return new exports.ZodPrefault({
        type: "prefault",
        innerType: innerType,
        get defaultValue() {
            return typeof defaultValue === "function" ? defaultValue() : index_js_1.util.shallowClone(defaultValue);
        },
    });
}
exports.ZodNonOptional = core.$constructor("ZodNonOptional", (inst, def) => {
    core.$ZodNonOptional.init(inst, def);
    exports.ZodType.init(inst, def);
    inst._zod.processJSONSchema = (ctx, json, params) => processors.nonoptionalProcessor(inst, ctx, json, params);
    _initProto(inst, "__unwrap__", { unwrap: _sharedUnwrap });
});
function nonoptional(innerType, params) {
    return new exports.ZodNonOptional({
        type: "nonoptional",
        innerType: innerType,
        ...index_js_1.util.normalizeParams(params),
    });
}
exports.ZodSuccess = core.$constructor("ZodSuccess", (inst, def) => {
    core.$ZodSuccess.init(inst, def);
    exports.ZodType.init(inst, def);
    inst._zod.processJSONSchema = (ctx, json, params) => processors.successProcessor(inst, ctx, json, params);
    _initProto(inst, "__unwrap__", { unwrap: _sharedUnwrap });
});
function success(innerType) {
    return new exports.ZodSuccess({
        type: "success",
        innerType: innerType,
    });
}
exports.ZodCatch = core.$constructor("ZodCatch", (inst, def) => {
    core.$ZodCatch.init(inst, def);
    exports.ZodType.init(inst, def);
    inst._zod.processJSONSchema = (ctx, json, params) => processors.catchProcessor(inst, ctx, json, params);
    _initProto(inst, "__unwrap__", { unwrap: _sharedUnwrap });
    _initProto(inst, "__removeCatch__", { removeCatch: _sharedUnwrap });
});
function _catch(innerType, catchValue) {
    return new exports.ZodCatch({
        type: "catch",
        innerType: innerType,
        catchValue: (typeof catchValue === "function" ? catchValue : () => catchValue),
    });
}
exports.ZodNaN = core.$constructor("ZodNaN", (inst, def) => {
    core.$ZodNaN.init(inst, def);
    exports.ZodType.init(inst, def);
    inst._zod.processJSONSchema = (ctx, json, params) => processors.nanProcessor(inst, ctx, json, params);
});
function nan(params) {
    return core._nan(exports.ZodNaN, params);
}
exports.ZodPipe = core.$constructor("ZodPipe", (inst, def) => {
    core.$ZodPipe.init(inst, def);
    exports.ZodType.init(inst, def);
    inst._zod.processJSONSchema = (ctx, json, params) => processors.pipeProcessor(inst, ctx, json, params);
    inst.in = def.in;
    inst.out = def.out;
});
function pipe(in_, out) {
    return new exports.ZodPipe({
        type: "pipe",
        in: in_,
        out: out,
        // ...util.normalizeParams(params),
    });
}
exports.ZodCodec = core.$constructor("ZodCodec", (inst, def) => {
    exports.ZodPipe.init(inst, def);
    core.$ZodCodec.init(inst, def);
});
function codec(in_, out, params) {
    return new exports.ZodCodec({
        type: "pipe",
        in: in_,
        out: out,
        transform: params.decode,
        reverseTransform: params.encode,
    });
}
exports.ZodReadonly = core.$constructor("ZodReadonly", (inst, def) => {
    core.$ZodReadonly.init(inst, def);
    exports.ZodType.init(inst, def);
    inst._zod.processJSONSchema = (ctx, json, params) => processors.readonlyProcessor(inst, ctx, json, params);
    _initProto(inst, "__unwrap__", { unwrap: _sharedUnwrap });
});
function readonly(innerType) {
    return new exports.ZodReadonly({
        type: "readonly",
        innerType: innerType,
    });
}
exports.ZodTemplateLiteral = core.$constructor("ZodTemplateLiteral", (inst, def) => {
    core.$ZodTemplateLiteral.init(inst, def);
    exports.ZodType.init(inst, def);
    inst._zod.processJSONSchema = (ctx, json, params) => processors.templateLiteralProcessor(inst, ctx, json, params);
});
function templateLiteral(parts, params) {
    return new exports.ZodTemplateLiteral({
        type: "template_literal",
        parts,
        ...index_js_1.util.normalizeParams(params),
    });
}
exports.ZodLazy = core.$constructor("ZodLazy", (inst, def) => {
    core.$ZodLazy.init(inst, def);
    exports.ZodType.init(inst, def);
    inst._zod.processJSONSchema = (ctx, json, params) => processors.lazyProcessor(inst, ctx, json, params);
    _initProto(inst, "__unwrap__", { unwrap: _sharedLazyUnwrap });
});
function lazy(getter) {
    return new exports.ZodLazy({
        type: "lazy",
        getter: getter,
    });
}
exports.ZodPromise = core.$constructor("ZodPromise", (inst, def) => {
    core.$ZodPromise.init(inst, def);
    exports.ZodType.init(inst, def);
    inst._zod.processJSONSchema = (ctx, json, params) => processors.promiseProcessor(inst, ctx, json, params);
    _initProto(inst, "__unwrap__", { unwrap: _sharedUnwrap });
});
function promise(innerType) {
    return new exports.ZodPromise({
        type: "promise",
        innerType: innerType,
    });
}
exports.ZodFunction = core.$constructor("ZodFunction", (inst, def) => {
    core.$ZodFunction.init(inst, def);
    exports.ZodType.init(inst, def);
    inst._zod.processJSONSchema = (ctx, json, params) => processors.functionProcessor(inst, ctx, json, params);
});
function _function(params) {
    return new exports.ZodFunction({
        type: "function",
        input: Array.isArray(params?.input) ? tuple(params?.input) : (params?.input ?? array(unknown())),
        output: params?.output ?? unknown(),
    });
}
exports.ZodCustom = core.$constructor("ZodCustom", (inst, def) => {
    core.$ZodCustom.init(inst, def);
    exports.ZodType.init(inst, def);
    inst._zod.processJSONSchema = (ctx, json, params) => processors.customProcessor(inst, ctx, json, params);
});
// custom checks
function check(fn) {
    const ch = new core.$ZodCheck({
        check: "custom",
        // ...util.normalizeParams(params),
    });
    ch._zod.check = fn;
    return ch;
}
function custom(fn, _params) {
    return core._custom(exports.ZodCustom, fn ?? (() => true), _params);
}
function refine(fn, _params = {}) {
    return core._refine(exports.ZodCustom, fn, _params);
}
// superRefine
function superRefine(fn) {
    return core._superRefine(fn);
}
// Re-export describe and meta from core
exports.describe = core.describe;
exports.meta = core.meta;
function _instanceof(cls, params = {}) {
    const inst = new exports.ZodCustom({
        type: "custom",
        check: "custom",
        fn: (data) => data instanceof cls,
        abort: true,
        ...index_js_1.util.normalizeParams(params),
    });
    inst._zod.bag.Class = cls;
    // Override check to emit invalid_type instead of custom
    inst._zod.check = (payload) => {
        if (!(payload.value instanceof cls)) {
            payload.issues.push({
                code: "invalid_type",
                expected: cls.name,
                input: payload.value,
                inst,
                path: [...(inst._zod.def.path ?? [])],
            });
        }
    };
    return inst;
}
// stringbool
const stringbool = (...args) => core._stringbool({
    Codec: exports.ZodCodec,
    Boolean: exports.ZodBoolean,
    String: exports.ZodString,
}, ...args);
exports.stringbool = stringbool;
function json(params) {
    const jsonSchema = lazy(() => {
        return union([string(params), number(), boolean(), _null(), array(jsonSchema), record(string(), jsonSchema)]);
    });
    return jsonSchema;
}
// preprocess
// /** @deprecated Use `z.pipe()` and `z.transform()` instead. */
function preprocess(fn, schema) {
    return pipe(transform(fn), schema);
}
