import * as core from "../core/index.js";
import { util } from "../core/index.js";
import * as processors from "../core/json-schema-processors.js";
import { createStandardJSONSchemaMethod, createToJSONSchemaMethod } from "../core/to-json-schema.js";
import * as checks from "./checks.js";
import * as iso from "./iso.js";
import * as parse from "./parse.js";
// Maps (prototype, key) pairs already initialized — avoids repeated prototype setup
const _protoInitMap = new WeakMap();
/**
 * Sets shared methods on the prototype of inst's constructor (once per concrete type).
 * Each initializer uses a unique key so multiple call sites don't interfere.
 */
function _initProto(inst, key, methods, defineProps) {
    const proto = Object.getPrototypeOf(inst);
    let keys = _protoInitMap.get(proto);
    if (!keys) {
        keys = new Set();
        _protoInitMap.set(proto, keys);
    }
    if (keys.has(key))
        return;
    keys.add(key);
    Object.assign(proto, methods);
    if (defineProps) {
        for (const [k, desc] of defineProps) {
            Object.defineProperty(proto, k, { ...desc, configurable: true });
        }
    }
}
// ─────────────────────────────────────────────────────────────────────────────
// Shared method references (memory optimization)
//
// Zod v4 originally assigned every schema method as a per-instance arrow
// function closure, capturing `inst`. With many schemas this causes significant
// heap pressure (~50 extra function objects per schema instance). Instead, we
// define each method once as a named function that uses `this` for context.
// All instances then share the same function objects while retaining the same
// own-property API surface and full runtime correctness.
//
// The return-type casts (`as any`) are required because TypeScript cannot
// statically verify that a shared `this: ZodType` matches the polymorphic
// `this` in the interface declaration. The declared interface types remain
// authoritative; these casts are implementation-only.
// ─────────────────────────────────────────────────────────────────────────────
// ZodType – base methods
function _sharedCheck(...chks) {
    const def = this.def;
    return this.clone(util.mergeDefs(def, {
        checks: [
            ...(def.checks ?? []),
            ...chks.map((ch) => typeof ch === "function" ? { _zod: { check: ch, def: { check: "custom" }, onattach: [] } } : ch),
        ],
    }), { parent: true });
}
function _sharedClone(def, params) {
    return core.clone(this, def, params);
}
function _sharedBrand() {
    return this;
}
function _sharedRegister(reg, meta) {
    reg.add(this, meta);
    return this;
}
// NOTE: parse/safeParse/parseAsync/safeParseAsync/encode/decode (and their variants)
// are intentionally kept as per-instance closures in the ZodType initializer below.
// These methods are commonly called in a detached manner (e.g. `arr.map(schema.parse)`
// or `const p = schema.parse; p(v)`), so they must capture `inst` rather than rely
// on `this` binding.
function _sharedRefine(check, params) {
    return this.check(refine(check, params));
}
function _sharedSuperRefine(refinement) {
    return this.check(superRefine(refinement));
}
function _sharedOverwrite(fn) {
    return this.check(checks.overwrite(fn));
}
function _sharedOptional() {
    return optional(this);
}
function _sharedExactOptional() {
    return exactOptional(this);
}
function _sharedNullable() {
    return nullable(this);
}
function _sharedNullish() {
    return optional(nullable(this));
}
function _sharedNonoptional(params) {
    return nonoptional(this, params);
}
function _sharedArray() {
    return array(this);
}
function _sharedOr(arg) {
    return union([this, arg]);
}
function _sharedAnd(arg) {
    return intersection(this, arg);
}
function _sharedTransform(tx) {
    return pipe(this, transform(tx));
}
function _sharedDefault(d) {
    return _default(this, d);
}
function _sharedPrefault(d) {
    return prefault(this, d);
}
function _sharedCatch(params) {
    return _catch(this, params);
}
function _sharedPipe(target) {
    return pipe(this, target);
}
function _sharedReadonly() {
    return readonly(this);
}
function _sharedDescribe(description) {
    const cl = this.clone();
    core.globalRegistry.add(cl, { description });
    return cl;
}
function _sharedMeta(...args) {
    if (args.length === 0)
        return core.globalRegistry.get(this);
    const cl = this.clone();
    core.globalRegistry.add(cl, args[0]);
    return cl;
}
function _sharedIsOptional() {
    return this.safeParse(undefined).success;
}
function _sharedIsNullable() {
    return this.safeParse(null).success;
}
function _sharedApply(fn) {
    return fn(this);
}
// _ZodString – string validation methods
function _sharedRegex(...args) {
    return this.check(checks.regex(...args));
}
function _sharedIncludes(...args) {
    return this.check(checks.includes(...args));
}
function _sharedStartsWith(...args) {
    return this.check(checks.startsWith(...args));
}
function _sharedEndsWith(...args) {
    return this.check(checks.endsWith(...args));
}
function _sharedStrMin(...args) {
    return this.check(checks.minLength(...args));
}
function _sharedStrMax(...args) {
    return this.check(checks.maxLength(...args));
}
function _sharedStrLength(...args) {
    return this.check(checks.length(...args));
}
function _sharedStrNonempty(...args) {
    return this.check(checks.minLength(1, ...args));
}
function _sharedLowercase(params) {
    return this.check(checks.lowercase(params));
}
function _sharedUppercase(params) {
    return this.check(checks.uppercase(params));
}
function _sharedTrim() {
    return this.check(checks.trim());
}
function _sharedNormalize(...args) {
    return this.check(checks.normalize(...args));
}
function _sharedToLowerCase() {
    return this.check(checks.toLowerCase());
}
function _sharedToUpperCase() {
    return this.check(checks.toUpperCase());
}
function _sharedSlugify() {
    return this.check(checks.slugify());
}
// ZodString – format methods
function _sharedEmail(params) {
    return this.check(core._email(ZodEmail, params));
}
function _sharedUrl(params) {
    return this.check(core._url(ZodURL, params));
}
function _sharedJwt(params) {
    return this.check(core._jwt(ZodJWT, params));
}
function _sharedEmoji(params) {
    return this.check(core._emoji(ZodEmoji, params));
}
function _sharedGuid(params) {
    return this.check(core._guid(ZodGUID, params));
}
function _sharedUuid(params) {
    return this.check(core._uuid(ZodUUID, params));
}
function _sharedUuidv4(params) {
    return this.check(core._uuidv4(ZodUUID, params));
}
function _sharedUuidv6(params) {
    return this.check(core._uuidv6(ZodUUID, params));
}
function _sharedUuidv7(params) {
    return this.check(core._uuidv7(ZodUUID, params));
}
function _sharedNanoid(params) {
    return this.check(core._nanoid(ZodNanoID, params));
}
function _sharedCuid(params) {
    return this.check(core._cuid(ZodCUID, params));
}
function _sharedCuid2(params) {
    return this.check(core._cuid2(ZodCUID2, params));
}
function _sharedUlid(params) {
    return this.check(core._ulid(ZodULID, params));
}
function _sharedBase64(params) {
    return this.check(core._base64(ZodBase64, params));
}
function _sharedBase64url(params) {
    return this.check(core._base64url(ZodBase64URL, params));
}
function _sharedXid(params) {
    return this.check(core._xid(ZodXID, params));
}
function _sharedKsuid(params) {
    return this.check(core._ksuid(ZodKSUID, params));
}
function _sharedIpv4(params) {
    return this.check(core._ipv4(ZodIPv4, params));
}
function _sharedIpv6(params) {
    return this.check(core._ipv6(ZodIPv6, params));
}
function _sharedCidrv4(params) {
    return this.check(core._cidrv4(ZodCIDRv4, params));
}
function _sharedCidrv6(params) {
    return this.check(core._cidrv6(ZodCIDRv6, params));
}
function _sharedE164(params) {
    return this.check(core._e164(ZodE164, params));
}
function _sharedDatetime(params) {
    return this.check(iso.datetime(params));
}
function _sharedDate(params) {
    return this.check(iso.date(params));
}
function _sharedTime(params) {
    return this.check(iso.time(params));
}
function _sharedDuration(params) {
    return this.check(iso.duration(params));
}
// ZodNumber – numeric methods
function _sharedNumGt(value, params) {
    return this.check(checks.gt(value, params));
}
function _sharedNumGte(value, params) {
    return this.check(checks.gte(value, params));
}
function _sharedNumLt(value, params) {
    return this.check(checks.lt(value, params));
}
function _sharedNumLte(value, params) {
    return this.check(checks.lte(value, params));
}
function _sharedNumInt(params) {
    return this.check(int(params));
}
function _sharedNumPositive(params) {
    return this.check(checks.gt(0, params));
}
function _sharedNumNonnegative(params) {
    return this.check(checks.gte(0, params));
}
function _sharedNumNegative(params) {
    return this.check(checks.lt(0, params));
}
function _sharedNumNonpositive(params) {
    return this.check(checks.lte(0, params));
}
function _sharedNumMultipleOf(value, params) {
    return this.check(checks.multipleOf(value, params));
}
function _sharedNumFinite() {
    return this;
}
// ZodBigInt – bigint methods
function _sharedBigIntGt(value, params) {
    return this.check(checks.gt(value, params));
}
function _sharedBigIntGte(value, params) {
    return this.check(checks.gte(value, params));
}
function _sharedBigIntLt(value, params) {
    return this.check(checks.lt(value, params));
}
function _sharedBigIntLte(value, params) {
    return this.check(checks.lte(value, params));
}
function _sharedBigIntPositive(params) {
    return this.check(checks.gt(BigInt(0), params));
}
function _sharedBigIntNegative(params) {
    return this.check(checks.lt(BigInt(0), params));
}
function _sharedBigIntNonpositive(params) {
    return this.check(checks.lte(BigInt(0), params));
}
function _sharedBigIntNonnegative(params) {
    return this.check(checks.gte(BigInt(0), params));
}
function _sharedBigIntMultipleOf(value, params) {
    return this.check(checks.multipleOf(value, params));
}
// ZodDate – date validation methods
function _sharedDateMin(value, params) {
    return this.check(checks.gte(value, params));
}
function _sharedDateMax(value, params) {
    return this.check(checks.lte(value, params));
}
// ZodArray – array methods
function _sharedArrMin(minLength, params) {
    return this.check(checks.minLength(minLength, params));
}
function _sharedArrNonempty(params) {
    return this.check(checks.minLength(1, params));
}
function _sharedArrMax(maxLength, params) {
    return this.check(checks.maxLength(maxLength, params));
}
function _sharedArrLength(len, params) {
    return this.check(checks.length(len, params));
}
function _sharedArrUnwrap() {
    return this.element;
}
// ZodObject – object methods
function _sharedObjKeyof() {
    return _enum(Object.keys(this._zod.def.shape));
}
function _sharedObjCatchall(catchall) {
    return this.clone({ ...this._zod.def, catchall });
}
function _sharedObjPassthrough() {
    return this.clone({ ...this._zod.def, catchall: unknown() });
}
function _sharedObjLoose() {
    return this.clone({ ...this._zod.def, catchall: unknown() });
}
function _sharedObjStrict() {
    return this.clone({ ...this._zod.def, catchall: never() });
}
function _sharedObjStrip() {
    return this.clone({ ...this._zod.def, catchall: undefined });
}
function _sharedObjExtend(incoming) {
    return util.extend(this, incoming);
}
function _sharedObjSafeExtend(incoming) {
    return util.safeExtend(this, incoming);
}
function _sharedObjMerge(other) {
    return util.merge(this, other);
}
function _sharedObjPick(mask) {
    return util.pick(this, mask);
}
function _sharedObjOmit(mask) {
    return util.omit(this, mask);
}
function _sharedObjPartial(...args) {
    return util.partial(ZodOptional, this, args[0]);
}
function _sharedObjRequired(...args) {
    return util.required(ZodNonOptional, this, args[0]);
}
// ZodTuple
function _sharedTupleRest(rest) {
    return this.clone({ ...this._zod.def, rest });
}
// ZodMap / ZodSet – size methods
function _sharedSizeMin(...args) {
    return this.check(core._minSize(...args));
}
function _sharedSizeNonempty(params) {
    return this.check(core._minSize(1, params));
}
function _sharedSizeMax(...args) {
    return this.check(core._maxSize(...args));
}
function _sharedSize(...args) {
    return this.check(core._size(...args));
}
// ZodFile – file methods
function _sharedFileMin(size, params) {
    return this.check(core._minSize(size, params));
}
function _sharedFileMax(size, params) {
    return this.check(core._maxSize(size, params));
}
function _sharedFileMime(types, params) {
    return this.check(core._mime(Array.isArray(types) ? types : [types], params));
}
// ZodEnum – extract/exclude
function _sharedEnumExtract(values, params) {
    const def = this._zod.def;
    const keys = new Set(Object.keys(def.entries));
    const newEntries = {};
    for (const value of values) {
        if (keys.has(value))
            newEntries[value] = def.entries[value];
        else
            throw new Error(`Key ${value} not found in enum`);
    }
    return new ZodEnum({ ...def, checks: [], ...util.normalizeParams(params), entries: newEntries });
}
function _sharedEnumExclude(values, params) {
    const def = this._zod.def;
    const keys = new Set(Object.keys(def.entries));
    const newEntries = { ...def.entries };
    for (const value of values) {
        if (keys.has(value))
            delete newEntries[value];
        else
            throw new Error(`Key ${value} not found in enum`);
    }
    return new ZodEnum({ ...def, checks: [], ...util.normalizeParams(params), entries: newEntries });
}
// Wrapper types – shared unwrap
function _sharedUnwrap() {
    return this._zod.def.innerType;
}
function _sharedLazyUnwrap() {
    return this._zod.def.getter();
}
export const ZodType = /*@__PURE__*/ core.$constructor("ZodType", (inst, def) => {
    core.$ZodType.init(inst, def);
    Object.assign(inst["~standard"], {
        jsonSchema: {
            input: createStandardJSONSchemaMethod(inst, "input"),
            output: createStandardJSONSchemaMethod(inst, "output"),
        },
    });
    inst.toJSONSchema = createToJSONSchemaMethod(inst, {});
    inst.def = def;
    inst.type = def.type;
    Object.defineProperty(inst, "_def", { value: def });
    // base methods
    // parsing
    // parsing — kept as per-instance closures so that detached usage works:
    //   const parse = schema.parse; parse("hello"); // must work
    inst.parse = (data, params) => parse.parse(inst, data, params, { callee: inst.parse });
    inst.safeParse = (data, params) => parse.safeParse(inst, data, params);
    inst.parseAsync = async (data, params) => parse.parseAsync(inst, data, params, { callee: inst.parseAsync });
    inst.safeParseAsync = async (data, params) => parse.safeParseAsync(inst, data, params);
    inst.spa = inst.safeParseAsync;
    // encoding/decoding — same reason
    inst.encode = (data, params) => parse.encode(inst, data, params);
    inst.decode = (data, params) => parse.decode(inst, data, params);
    inst.encodeAsync = async (data, params) => parse.encodeAsync(inst, data, params);
    inst.decodeAsync = async (data, params) => parse.decodeAsync(inst, data, params);
    inst.safeEncode = (data, params) => parse.safeEncode(inst, data, params);
    inst.safeDecode = (data, params) => parse.safeDecode(inst, data, params);
    inst.safeEncodeAsync = async (data, params) => parse.safeEncodeAsync(inst, data, params);
    inst.safeDecodeAsync = async (data, params) => parse.safeDecodeAsync(inst, data, params);
    // refinements
    // wrappers
    // inst.coalesce = (def, params) => coalesce(inst, def, params);
    // meta
    // helpers
    _initProto(inst, "ZodType", {
        check: _sharedCheck,
        with: _sharedCheck,
        clone: _sharedClone,
        brand: _sharedBrand,
        register: _sharedRegister,
        refine: _sharedRefine,
        superRefine: _sharedSuperRefine,
        overwrite: _sharedOverwrite,
        optional: _sharedOptional,
        exactOptional: _sharedExactOptional,
        nullable: _sharedNullable,
        nullish: _sharedNullish,
        nonoptional: _sharedNonoptional,
        array: _sharedArray,
        or: _sharedOr,
        and: _sharedAnd,
        transform: _sharedTransform,
        default: _sharedDefault,
        prefault: _sharedPrefault,
        catch: _sharedCatch,
        pipe: _sharedPipe,
        readonly: _sharedReadonly,
        describe: _sharedDescribe,
        meta: _sharedMeta,
        isOptional: _sharedIsOptional,
        isNullable: _sharedIsNullable,
        apply: _sharedApply,
    }, [
        [
            "description",
            {
                get() {
                    return core.globalRegistry.get(this)?.description;
                },
                configurable: true,
            },
        ],
    ]);
    return inst;
});
/** @internal */
export const _ZodString = /*@__PURE__*/ core.$constructor("_ZodString", (inst, def) => {
    core.$ZodString.init(inst, def);
    ZodType.init(inst, def);
    inst._zod.processJSONSchema = (ctx, json, params) => processors.stringProcessor(inst, ctx, json, params);
    const bag = inst._zod.bag;
    inst.format = bag.format ?? null;
    inst.minLength = bag.minimum ?? null;
    inst.maxLength = bag.maximum ?? null;
    // validations
    // transforms
    _initProto(inst, "_ZodString", {
        regex: _sharedRegex,
        includes: _sharedIncludes,
        startsWith: _sharedStartsWith,
        endsWith: _sharedEndsWith,
        min: _sharedStrMin,
        max: _sharedStrMax,
        length: _sharedStrLength,
        nonempty: _sharedStrNonempty,
        lowercase: _sharedLowercase,
        uppercase: _sharedUppercase,
        trim: _sharedTrim,
        normalize: _sharedNormalize,
        toLowerCase: _sharedToLowerCase,
        toUpperCase: _sharedToUpperCase,
        slugify: _sharedSlugify,
    });
});
export const ZodString = /*@__PURE__*/ core.$constructor("ZodString", (inst, def) => {
    core.$ZodString.init(inst, def);
    _ZodString.init(inst, def);
    // iso
    _initProto(inst, "ZodString", {
        email: _sharedEmail,
        url: _sharedUrl,
        jwt: _sharedJwt,
        emoji: _sharedEmoji,
        guid: _sharedGuid,
        uuid: _sharedUuid,
        uuidv4: _sharedUuidv4,
        uuidv6: _sharedUuidv6,
        uuidv7: _sharedUuidv7,
        nanoid: _sharedNanoid,
        cuid: _sharedCuid,
        cuid2: _sharedCuid2,
        ulid: _sharedUlid,
        base64: _sharedBase64,
        base64url: _sharedBase64url,
        xid: _sharedXid,
        ksuid: _sharedKsuid,
        ipv4: _sharedIpv4,
        ipv6: _sharedIpv6,
        cidrv4: _sharedCidrv4,
        cidrv6: _sharedCidrv6,
        e164: _sharedE164,
        datetime: _sharedDatetime,
        date: _sharedDate,
        time: _sharedTime,
        duration: _sharedDuration,
    });
});
export function string(params) {
    return core._string(ZodString, params);
}
export const ZodStringFormat = /*@__PURE__*/ core.$constructor("ZodStringFormat", (inst, def) => {
    core.$ZodStringFormat.init(inst, def);
    _ZodString.init(inst, def);
});
export const ZodEmail = /*@__PURE__*/ core.$constructor("ZodEmail", (inst, def) => {
    // ZodStringFormat.init(inst, def);
    core.$ZodEmail.init(inst, def);
    ZodStringFormat.init(inst, def);
});
export function email(params) {
    return core._email(ZodEmail, params);
}
export const ZodGUID = /*@__PURE__*/ core.$constructor("ZodGUID", (inst, def) => {
    // ZodStringFormat.init(inst, def);
    core.$ZodGUID.init(inst, def);
    ZodStringFormat.init(inst, def);
});
export function guid(params) {
    return core._guid(ZodGUID, params);
}
export const ZodUUID = /*@__PURE__*/ core.$constructor("ZodUUID", (inst, def) => {
    // ZodStringFormat.init(inst, def);
    core.$ZodUUID.init(inst, def);
    ZodStringFormat.init(inst, def);
});
export function uuid(params) {
    return core._uuid(ZodUUID, params);
}
export function uuidv4(params) {
    return core._uuidv4(ZodUUID, params);
}
// ZodUUIDv6
export function uuidv6(params) {
    return core._uuidv6(ZodUUID, params);
}
// ZodUUIDv7
export function uuidv7(params) {
    return core._uuidv7(ZodUUID, params);
}
export const ZodURL = /*@__PURE__*/ core.$constructor("ZodURL", (inst, def) => {
    // ZodStringFormat.init(inst, def);
    core.$ZodURL.init(inst, def);
    ZodStringFormat.init(inst, def);
});
export function url(params) {
    return core._url(ZodURL, params);
}
export function httpUrl(params) {
    return core._url(ZodURL, {
        protocol: core.regexes.httpProtocol,
        hostname: core.regexes.domain,
        ...util.normalizeParams(params),
    });
}
export const ZodEmoji = /*@__PURE__*/ core.$constructor("ZodEmoji", (inst, def) => {
    // ZodStringFormat.init(inst, def);
    core.$ZodEmoji.init(inst, def);
    ZodStringFormat.init(inst, def);
});
export function emoji(params) {
    return core._emoji(ZodEmoji, params);
}
export const ZodNanoID = /*@__PURE__*/ core.$constructor("ZodNanoID", (inst, def) => {
    // ZodStringFormat.init(inst, def);
    core.$ZodNanoID.init(inst, def);
    ZodStringFormat.init(inst, def);
});
export function nanoid(params) {
    return core._nanoid(ZodNanoID, params);
}
export const ZodCUID = /*@__PURE__*/ core.$constructor("ZodCUID", (inst, def) => {
    // ZodStringFormat.init(inst, def);
    core.$ZodCUID.init(inst, def);
    ZodStringFormat.init(inst, def);
});
export function cuid(params) {
    return core._cuid(ZodCUID, params);
}
export const ZodCUID2 = /*@__PURE__*/ core.$constructor("ZodCUID2", (inst, def) => {
    // ZodStringFormat.init(inst, def);
    core.$ZodCUID2.init(inst, def);
    ZodStringFormat.init(inst, def);
});
export function cuid2(params) {
    return core._cuid2(ZodCUID2, params);
}
export const ZodULID = /*@__PURE__*/ core.$constructor("ZodULID", (inst, def) => {
    // ZodStringFormat.init(inst, def);
    core.$ZodULID.init(inst, def);
    ZodStringFormat.init(inst, def);
});
export function ulid(params) {
    return core._ulid(ZodULID, params);
}
export const ZodXID = /*@__PURE__*/ core.$constructor("ZodXID", (inst, def) => {
    // ZodStringFormat.init(inst, def);
    core.$ZodXID.init(inst, def);
    ZodStringFormat.init(inst, def);
});
export function xid(params) {
    return core._xid(ZodXID, params);
}
export const ZodKSUID = /*@__PURE__*/ core.$constructor("ZodKSUID", (inst, def) => {
    // ZodStringFormat.init(inst, def);
    core.$ZodKSUID.init(inst, def);
    ZodStringFormat.init(inst, def);
});
export function ksuid(params) {
    return core._ksuid(ZodKSUID, params);
}
export const ZodIPv4 = /*@__PURE__*/ core.$constructor("ZodIPv4", (inst, def) => {
    // ZodStringFormat.init(inst, def);
    core.$ZodIPv4.init(inst, def);
    ZodStringFormat.init(inst, def);
});
export function ipv4(params) {
    return core._ipv4(ZodIPv4, params);
}
export const ZodMAC = /*@__PURE__*/ core.$constructor("ZodMAC", (inst, def) => {
    // ZodStringFormat.init(inst, def);
    core.$ZodMAC.init(inst, def);
    ZodStringFormat.init(inst, def);
});
export function mac(params) {
    return core._mac(ZodMAC, params);
}
export const ZodIPv6 = /*@__PURE__*/ core.$constructor("ZodIPv6", (inst, def) => {
    // ZodStringFormat.init(inst, def);
    core.$ZodIPv6.init(inst, def);
    ZodStringFormat.init(inst, def);
});
export function ipv6(params) {
    return core._ipv6(ZodIPv6, params);
}
export const ZodCIDRv4 = /*@__PURE__*/ core.$constructor("ZodCIDRv4", (inst, def) => {
    core.$ZodCIDRv4.init(inst, def);
    ZodStringFormat.init(inst, def);
});
export function cidrv4(params) {
    return core._cidrv4(ZodCIDRv4, params);
}
export const ZodCIDRv6 = /*@__PURE__*/ core.$constructor("ZodCIDRv6", (inst, def) => {
    core.$ZodCIDRv6.init(inst, def);
    ZodStringFormat.init(inst, def);
});
export function cidrv6(params) {
    return core._cidrv6(ZodCIDRv6, params);
}
export const ZodBase64 = /*@__PURE__*/ core.$constructor("ZodBase64", (inst, def) => {
    // ZodStringFormat.init(inst, def);
    core.$ZodBase64.init(inst, def);
    ZodStringFormat.init(inst, def);
});
export function base64(params) {
    return core._base64(ZodBase64, params);
}
export const ZodBase64URL = /*@__PURE__*/ core.$constructor("ZodBase64URL", (inst, def) => {
    // ZodStringFormat.init(inst, def);
    core.$ZodBase64URL.init(inst, def);
    ZodStringFormat.init(inst, def);
});
export function base64url(params) {
    return core._base64url(ZodBase64URL, params);
}
export const ZodE164 = /*@__PURE__*/ core.$constructor("ZodE164", (inst, def) => {
    // ZodStringFormat.init(inst, def);
    core.$ZodE164.init(inst, def);
    ZodStringFormat.init(inst, def);
});
export function e164(params) {
    return core._e164(ZodE164, params);
}
export const ZodJWT = /*@__PURE__*/ core.$constructor("ZodJWT", (inst, def) => {
    // ZodStringFormat.init(inst, def);
    core.$ZodJWT.init(inst, def);
    ZodStringFormat.init(inst, def);
});
export function jwt(params) {
    return core._jwt(ZodJWT, params);
}
export const ZodCustomStringFormat = /*@__PURE__*/ core.$constructor("ZodCustomStringFormat", (inst, def) => {
    // ZodStringFormat.init(inst, def);
    core.$ZodCustomStringFormat.init(inst, def);
    ZodStringFormat.init(inst, def);
});
export function stringFormat(format, fnOrRegex, _params = {}) {
    return core._stringFormat(ZodCustomStringFormat, format, fnOrRegex, _params);
}
export function hostname(_params) {
    return core._stringFormat(ZodCustomStringFormat, "hostname", core.regexes.hostname, _params);
}
export function hex(_params) {
    return core._stringFormat(ZodCustomStringFormat, "hex", core.regexes.hex, _params);
}
export function hash(alg, params) {
    const enc = params?.enc ?? "hex";
    const format = `${alg}_${enc}`;
    const regex = core.regexes[format];
    if (!regex)
        throw new Error(`Unrecognized hash format: ${format}`);
    return core._stringFormat(ZodCustomStringFormat, format, regex, params);
}
export const ZodNumber = /*@__PURE__*/ core.$constructor("ZodNumber", (inst, def) => {
    core.$ZodNumber.init(inst, def);
    ZodType.init(inst, def);
    inst._zod.processJSONSchema = (ctx, json, params) => processors.numberProcessor(inst, ctx, json, params);
    // inst.finite = (params) => inst.check(core.finite(params));
    const bag = inst._zod.bag;
    inst.minValue =
        Math.max(bag.minimum ?? Number.NEGATIVE_INFINITY, bag.exclusiveMinimum ?? Number.NEGATIVE_INFINITY) ?? null;
    inst.maxValue =
        Math.min(bag.maximum ?? Number.POSITIVE_INFINITY, bag.exclusiveMaximum ?? Number.POSITIVE_INFINITY) ?? null;
    inst.isInt = (bag.format ?? "").includes("int") || Number.isSafeInteger(bag.multipleOf ?? 0.5);
    inst.isFinite = true;
    inst.format = bag.format ?? null;
    _initProto(inst, "ZodNumber", {
        gt: _sharedNumGt,
        gte: _sharedNumGte,
        min: _sharedNumGte,
        lt: _sharedNumLt,
        lte: _sharedNumLte,
        max: _sharedNumLte,
        int: _sharedNumInt,
        safe: _sharedNumInt,
        positive: _sharedNumPositive,
        nonnegative: _sharedNumNonnegative,
        negative: _sharedNumNegative,
        nonpositive: _sharedNumNonpositive,
        multipleOf: _sharedNumMultipleOf,
        step: _sharedNumMultipleOf,
        finite: _sharedNumFinite,
    });
});
export function number(params) {
    return core._number(ZodNumber, params);
}
export const ZodNumberFormat = /*@__PURE__*/ core.$constructor("ZodNumberFormat", (inst, def) => {
    core.$ZodNumberFormat.init(inst, def);
    ZodNumber.init(inst, def);
});
export function int(params) {
    return core._int(ZodNumberFormat, params);
}
export function float32(params) {
    return core._float32(ZodNumberFormat, params);
}
export function float64(params) {
    return core._float64(ZodNumberFormat, params);
}
export function int32(params) {
    return core._int32(ZodNumberFormat, params);
}
export function uint32(params) {
    return core._uint32(ZodNumberFormat, params);
}
export const ZodBoolean = /*@__PURE__*/ core.$constructor("ZodBoolean", (inst, def) => {
    core.$ZodBoolean.init(inst, def);
    ZodType.init(inst, def);
    inst._zod.processJSONSchema = (ctx, json, params) => processors.booleanProcessor(inst, ctx, json, params);
});
export function boolean(params) {
    return core._boolean(ZodBoolean, params);
}
export const ZodBigInt = /*@__PURE__*/ core.$constructor("ZodBigInt", (inst, def) => {
    core.$ZodBigInt.init(inst, def);
    ZodType.init(inst, def);
    inst._zod.processJSONSchema = (ctx, json, params) => processors.bigintProcessor(inst, ctx, json, params);
    const bag = inst._zod.bag;
    inst.minValue = bag.minimum ?? null;
    inst.maxValue = bag.maximum ?? null;
    inst.format = bag.format ?? null;
    _initProto(inst, "ZodBigInt", {
        gte: _sharedBigIntGte,
        min: _sharedBigIntGte,
        gt: _sharedBigIntGt,
        lt: _sharedBigIntLt,
        lte: _sharedBigIntLte,
        max: _sharedBigIntLte,
        positive: _sharedBigIntPositive,
        negative: _sharedBigIntNegative,
        nonpositive: _sharedBigIntNonpositive,
        nonnegative: _sharedBigIntNonnegative,
        multipleOf: _sharedBigIntMultipleOf,
    });
});
export function bigint(params) {
    return core._bigint(ZodBigInt, params);
}
export const ZodBigIntFormat = /*@__PURE__*/ core.$constructor("ZodBigIntFormat", (inst, def) => {
    core.$ZodBigIntFormat.init(inst, def);
    ZodBigInt.init(inst, def);
});
// int64
export function int64(params) {
    return core._int64(ZodBigIntFormat, params);
}
// uint64
export function uint64(params) {
    return core._uint64(ZodBigIntFormat, params);
}
export const ZodSymbol = /*@__PURE__*/ core.$constructor("ZodSymbol", (inst, def) => {
    core.$ZodSymbol.init(inst, def);
    ZodType.init(inst, def);
    inst._zod.processJSONSchema = (ctx, json, params) => processors.symbolProcessor(inst, ctx, json, params);
});
export function symbol(params) {
    return core._symbol(ZodSymbol, params);
}
export const ZodUndefined = /*@__PURE__*/ core.$constructor("ZodUndefined", (inst, def) => {
    core.$ZodUndefined.init(inst, def);
    ZodType.init(inst, def);
    inst._zod.processJSONSchema = (ctx, json, params) => processors.undefinedProcessor(inst, ctx, json, params);
});
function _undefined(params) {
    return core._undefined(ZodUndefined, params);
}
export { _undefined as undefined };
export const ZodNull = /*@__PURE__*/ core.$constructor("ZodNull", (inst, def) => {
    core.$ZodNull.init(inst, def);
    ZodType.init(inst, def);
    inst._zod.processJSONSchema = (ctx, json, params) => processors.nullProcessor(inst, ctx, json, params);
});
function _null(params) {
    return core._null(ZodNull, params);
}
export { _null as null };
export const ZodAny = /*@__PURE__*/ core.$constructor("ZodAny", (inst, def) => {
    core.$ZodAny.init(inst, def);
    ZodType.init(inst, def);
    inst._zod.processJSONSchema = (ctx, json, params) => processors.anyProcessor(inst, ctx, json, params);
});
export function any() {
    return core._any(ZodAny);
}
export const ZodUnknown = /*@__PURE__*/ core.$constructor("ZodUnknown", (inst, def) => {
    core.$ZodUnknown.init(inst, def);
    ZodType.init(inst, def);
    inst._zod.processJSONSchema = (ctx, json, params) => processors.unknownProcessor(inst, ctx, json, params);
});
export function unknown() {
    return core._unknown(ZodUnknown);
}
export const ZodNever = /*@__PURE__*/ core.$constructor("ZodNever", (inst, def) => {
    core.$ZodNever.init(inst, def);
    ZodType.init(inst, def);
    inst._zod.processJSONSchema = (ctx, json, params) => processors.neverProcessor(inst, ctx, json, params);
});
export function never(params) {
    return core._never(ZodNever, params);
}
export const ZodVoid = /*@__PURE__*/ core.$constructor("ZodVoid", (inst, def) => {
    core.$ZodVoid.init(inst, def);
    ZodType.init(inst, def);
    inst._zod.processJSONSchema = (ctx, json, params) => processors.voidProcessor(inst, ctx, json, params);
});
function _void(params) {
    return core._void(ZodVoid, params);
}
export { _void as void };
export const ZodDate = /*@__PURE__*/ core.$constructor("ZodDate", (inst, def) => {
    core.$ZodDate.init(inst, def);
    ZodType.init(inst, def);
    inst._zod.processJSONSchema = (ctx, json, params) => processors.dateProcessor(inst, ctx, json, params);
    _initProto(inst, "__min__", { min: _sharedDateMin });
    _initProto(inst, "__max__", { max: _sharedDateMax });
    const c = inst._zod.bag;
    inst.minDate = c.minimum ? new Date(c.minimum) : null;
    inst.maxDate = c.maximum ? new Date(c.maximum) : null;
});
export function date(params) {
    return core._date(ZodDate, params);
}
export const ZodArray = /*@__PURE__*/ core.$constructor("ZodArray", (inst, def) => {
    core.$ZodArray.init(inst, def);
    ZodType.init(inst, def);
    inst._zod.processJSONSchema = (ctx, json, params) => processors.arrayProcessor(inst, ctx, json, params);
    inst.element = def.element;
    _initProto(inst, "__min__", { min: _sharedArrMin });
    _initProto(inst, "__nonempty__", { nonempty: _sharedArrNonempty });
    _initProto(inst, "__max__", { max: _sharedArrMax });
    _initProto(inst, "__length__", { length: _sharedArrLength });
    _initProto(inst, "__unwrap__", { unwrap: _sharedArrUnwrap });
});
export function array(element, params) {
    return core._array(ZodArray, element, params);
}
// .keyof
export function keyof(schema) {
    const shape = schema._zod.def.shape;
    return _enum(Object.keys(shape));
}
export const ZodObject = /*@__PURE__*/ core.$constructor("ZodObject", (inst, def) => {
    core.$ZodObjectJIT.init(inst, def);
    ZodType.init(inst, def);
    inst._zod.processJSONSchema = (ctx, json, params) => processors.objectProcessor(inst, ctx, json, params);
    util.defineLazy(inst, "shape", () => {
        return def.shape;
    });
    _initProto(inst, "__keyof__", { keyof: _sharedObjKeyof });
    _initProto(inst, "__catchall__", { catchall: _sharedObjCatchall });
    _initProto(inst, "__passthrough__", { passthrough: _sharedObjPassthrough });
    _initProto(inst, "__loose__", { loose: _sharedObjLoose });
    _initProto(inst, "__strict__", { strict: _sharedObjStrict });
    _initProto(inst, "__strip__", { strip: _sharedObjStrip });
    _initProto(inst, "__extend__", { extend: _sharedObjExtend });
    _initProto(inst, "__safeExtend__", { safeExtend: _sharedObjSafeExtend });
    _initProto(inst, "__merge__", { merge: _sharedObjMerge });
    _initProto(inst, "__pick__", { pick: _sharedObjPick });
    _initProto(inst, "__omit__", { omit: _sharedObjOmit });
    _initProto(inst, "__partial__", { partial: _sharedObjPartial });
    _initProto(inst, "__required__", { required: _sharedObjRequired });
});
export function object(shape, params) {
    const def = {
        type: "object",
        shape: shape ?? {},
        ...util.normalizeParams(params),
    };
    return new ZodObject(def);
}
// strictObject
export function strictObject(shape, params) {
    return new ZodObject({
        type: "object",
        shape,
        catchall: never(),
        ...util.normalizeParams(params),
    });
}
// looseObject
export function looseObject(shape, params) {
    return new ZodObject({
        type: "object",
        shape,
        catchall: unknown(),
        ...util.normalizeParams(params),
    });
}
export const ZodUnion = /*@__PURE__*/ core.$constructor("ZodUnion", (inst, def) => {
    core.$ZodUnion.init(inst, def);
    ZodType.init(inst, def);
    inst._zod.processJSONSchema = (ctx, json, params) => processors.unionProcessor(inst, ctx, json, params);
    inst.options = def.options;
});
export function union(options, params) {
    return new ZodUnion({
        type: "union",
        options: options,
        ...util.normalizeParams(params),
    });
}
export const ZodXor = /*@__PURE__*/ core.$constructor("ZodXor", (inst, def) => {
    ZodUnion.init(inst, def);
    core.$ZodXor.init(inst, def);
    inst._zod.processJSONSchema = (ctx, json, params) => processors.unionProcessor(inst, ctx, json, params);
    inst.options = def.options;
});
/** Creates an exclusive union (XOR) where exactly one option must match.
 * Unlike regular unions that succeed when any option matches, xor fails if
 * zero or more than one option matches the input. */
export function xor(options, params) {
    return new ZodXor({
        type: "union",
        options: options,
        inclusive: false,
        ...util.normalizeParams(params),
    });
}
export const ZodDiscriminatedUnion = /*@__PURE__*/ core.$constructor("ZodDiscriminatedUnion", (inst, def) => {
    ZodUnion.init(inst, def);
    core.$ZodDiscriminatedUnion.init(inst, def);
});
export function discriminatedUnion(discriminator, options, params) {
    // const [options, params] = args;
    return new ZodDiscriminatedUnion({
        type: "union",
        options,
        discriminator,
        ...util.normalizeParams(params),
    });
}
export const ZodIntersection = /*@__PURE__*/ core.$constructor("ZodIntersection", (inst, def) => {
    core.$ZodIntersection.init(inst, def);
    ZodType.init(inst, def);
    inst._zod.processJSONSchema = (ctx, json, params) => processors.intersectionProcessor(inst, ctx, json, params);
});
export function intersection(left, right) {
    return new ZodIntersection({
        type: "intersection",
        left: left,
        right: right,
    });
}
export const ZodTuple = /*@__PURE__*/ core.$constructor("ZodTuple", (inst, def) => {
    core.$ZodTuple.init(inst, def);
    ZodType.init(inst, def);
    inst._zod.processJSONSchema = (ctx, json, params) => processors.tupleProcessor(inst, ctx, json, params);
    _initProto(inst, "__rest__", { rest: _sharedTupleRest });
});
export function tuple(items, _paramsOrRest, _params) {
    const hasRest = _paramsOrRest instanceof core.$ZodType;
    const params = hasRest ? _params : _paramsOrRest;
    const rest = hasRest ? _paramsOrRest : null;
    return new ZodTuple({
        type: "tuple",
        items: items,
        rest,
        ...util.normalizeParams(params),
    });
}
export const ZodRecord = /*@__PURE__*/ core.$constructor("ZodRecord", (inst, def) => {
    core.$ZodRecord.init(inst, def);
    ZodType.init(inst, def);
    inst._zod.processJSONSchema = (ctx, json, params) => processors.recordProcessor(inst, ctx, json, params);
    inst.keyType = def.keyType;
    inst.valueType = def.valueType;
});
export function record(keyType, valueType, params) {
    return new ZodRecord({
        type: "record",
        keyType,
        valueType: valueType,
        ...util.normalizeParams(params),
    });
}
// type alksjf = core.output<core.$ZodRecordKey>;
export function partialRecord(keyType, valueType, params) {
    const k = core.clone(keyType);
    k._zod.values = undefined;
    return new ZodRecord({
        type: "record",
        keyType: k,
        valueType: valueType,
        ...util.normalizeParams(params),
    });
}
export function looseRecord(keyType, valueType, params) {
    return new ZodRecord({
        type: "record",
        keyType,
        valueType: valueType,
        mode: "loose",
        ...util.normalizeParams(params),
    });
}
export const ZodMap = /*@__PURE__*/ core.$constructor("ZodMap", (inst, def) => {
    core.$ZodMap.init(inst, def);
    ZodType.init(inst, def);
    inst._zod.processJSONSchema = (ctx, json, params) => processors.mapProcessor(inst, ctx, json, params);
    inst.keyType = def.keyType;
    inst.valueType = def.valueType;
    _initProto(inst, "__min__", { min: _sharedSizeMin });
    _initProto(inst, "__nonempty__", { nonempty: _sharedSizeNonempty });
    _initProto(inst, "__max__", { max: _sharedSizeMax });
    _initProto(inst, "__size__", { size: _sharedSize });
});
export function map(keyType, valueType, params) {
    return new ZodMap({
        type: "map",
        keyType: keyType,
        valueType: valueType,
        ...util.normalizeParams(params),
    });
}
export const ZodSet = /*@__PURE__*/ core.$constructor("ZodSet", (inst, def) => {
    core.$ZodSet.init(inst, def);
    ZodType.init(inst, def);
    inst._zod.processJSONSchema = (ctx, json, params) => processors.setProcessor(inst, ctx, json, params);
    _initProto(inst, "__min__", { min: _sharedSizeMin });
    _initProto(inst, "__nonempty__", { nonempty: _sharedSizeNonempty });
    _initProto(inst, "__max__", { max: _sharedSizeMax });
    _initProto(inst, "__size__", { size: _sharedSize });
});
export function set(valueType, params) {
    return new ZodSet({
        type: "set",
        valueType: valueType,
        ...util.normalizeParams(params),
    });
}
export const ZodEnum = /*@__PURE__*/ core.$constructor("ZodEnum", (inst, def) => {
    core.$ZodEnum.init(inst, def);
    ZodType.init(inst, def);
    inst._zod.processJSONSchema = (ctx, json, params) => processors.enumProcessor(inst, ctx, json, params);
    inst.enum = def.entries;
    inst.options = Object.values(def.entries);
    _initProto(inst, "__extract__", { extract: _sharedEnumExtract });
    _initProto(inst, "__exclude__", { exclude: _sharedEnumExclude });
});
function _enum(values, params) {
    const entries = Array.isArray(values) ? Object.fromEntries(values.map((v) => [v, v])) : values;
    return new ZodEnum({
        type: "enum",
        entries,
        ...util.normalizeParams(params),
    });
}
export { _enum as enum };
/** @deprecated This API has been merged into `z.enum()`. Use `z.enum()` instead.
 *
 * ```ts
 * enum Colors { red, green, blue }
 * z.enum(Colors);
 * ```
 */
export function nativeEnum(entries, params) {
    return new ZodEnum({
        type: "enum",
        entries,
        ...util.normalizeParams(params),
    });
}
export const ZodLiteral = /*@__PURE__*/ core.$constructor("ZodLiteral", (inst, def) => {
    core.$ZodLiteral.init(inst, def);
    ZodType.init(inst, def);
    inst._zod.processJSONSchema = (ctx, json, params) => processors.literalProcessor(inst, ctx, json, params);
    inst.values = new Set(def.values);
    Object.defineProperty(inst, "value", {
        get() {
            if (def.values.length > 1) {
                throw new Error("This schema contains multiple valid literal values. Use `.values` instead.");
            }
            return def.values[0];
        },
    });
});
export function literal(value, params) {
    return new ZodLiteral({
        type: "literal",
        values: Array.isArray(value) ? value : [value],
        ...util.normalizeParams(params),
    });
}
export const ZodFile = /*@__PURE__*/ core.$constructor("ZodFile", (inst, def) => {
    core.$ZodFile.init(inst, def);
    ZodType.init(inst, def);
    inst._zod.processJSONSchema = (ctx, json, params) => processors.fileProcessor(inst, ctx, json, params);
    _initProto(inst, "__min__", { min: _sharedFileMin });
    _initProto(inst, "__max__", { max: _sharedFileMax });
    _initProto(inst, "__mime__", { mime: _sharedFileMime });
});
export function file(params) {
    return core._file(ZodFile, params);
}
export const ZodTransform = /*@__PURE__*/ core.$constructor("ZodTransform", (inst, def) => {
    core.$ZodTransform.init(inst, def);
    ZodType.init(inst, def);
    inst._zod.processJSONSchema = (ctx, json, params) => processors.transformProcessor(inst, ctx, json, params);
    inst._zod.parse = (payload, _ctx) => {
        if (_ctx.direction === "backward") {
            throw new core.$ZodEncodeError(inst.constructor.name);
        }
        payload.addIssue = (issue) => {
            if (typeof issue === "string") {
                payload.issues.push(util.issue(issue, payload.value, def));
            }
            else {
                // for Zod 3 backwards compatibility
                const _issue = issue;
                if (_issue.fatal)
                    _issue.continue = false;
                _issue.code ?? (_issue.code = "custom");
                _issue.input ?? (_issue.input = payload.value);
                _issue.inst ?? (_issue.inst = inst);
                // _issue.continue ??= true;
                payload.issues.push(util.issue(_issue));
            }
        };
        const output = def.transform(payload.value, payload);
        if (output instanceof Promise) {
            return output.then((output) => {
                payload.value = output;
                return payload;
            });
        }
        payload.value = output;
        return payload;
    };
});
export function transform(fn) {
    return new ZodTransform({
        type: "transform",
        transform: fn,
    });
}
export const ZodOptional = /*@__PURE__*/ core.$constructor("ZodOptional", (inst, def) => {
    core.$ZodOptional.init(inst, def);
    ZodType.init(inst, def);
    inst._zod.processJSONSchema = (ctx, json, params) => processors.optionalProcessor(inst, ctx, json, params);
    _initProto(inst, "__unwrap__", { unwrap: _sharedUnwrap });
});
export function optional(innerType) {
    return new ZodOptional({
        type: "optional",
        innerType: innerType,
    });
}
export const ZodExactOptional = /*@__PURE__*/ core.$constructor("ZodExactOptional", (inst, def) => {
    core.$ZodExactOptional.init(inst, def);
    ZodType.init(inst, def);
    inst._zod.processJSONSchema = (ctx, json, params) => processors.optionalProcessor(inst, ctx, json, params);
    _initProto(inst, "__unwrap__", { unwrap: _sharedUnwrap });
});
export function exactOptional(innerType) {
    return new ZodExactOptional({
        type: "optional",
        innerType: innerType,
    });
}
export const ZodNullable = /*@__PURE__*/ core.$constructor("ZodNullable", (inst, def) => {
    core.$ZodNullable.init(inst, def);
    ZodType.init(inst, def);
    inst._zod.processJSONSchema = (ctx, json, params) => processors.nullableProcessor(inst, ctx, json, params);
    _initProto(inst, "__unwrap__", { unwrap: _sharedUnwrap });
});
export function nullable(innerType) {
    return new ZodNullable({
        type: "nullable",
        innerType: innerType,
    });
}
// nullish
export function nullish(innerType) {
    return optional(nullable(innerType));
}
export const ZodDefault = /*@__PURE__*/ core.$constructor("ZodDefault", (inst, def) => {
    core.$ZodDefault.init(inst, def);
    ZodType.init(inst, def);
    inst._zod.processJSONSchema = (ctx, json, params) => processors.defaultProcessor(inst, ctx, json, params);
    _initProto(inst, "__unwrap__", { unwrap: _sharedUnwrap });
    _initProto(inst, "__removeDefault__", { removeDefault: _sharedUnwrap });
});
export function _default(innerType, defaultValue) {
    return new ZodDefault({
        type: "default",
        innerType: innerType,
        get defaultValue() {
            return typeof defaultValue === "function" ? defaultValue() : util.shallowClone(defaultValue);
        },
    });
}
export const ZodPrefault = /*@__PURE__*/ core.$constructor("ZodPrefault", (inst, def) => {
    core.$ZodPrefault.init(inst, def);
    ZodType.init(inst, def);
    inst._zod.processJSONSchema = (ctx, json, params) => processors.prefaultProcessor(inst, ctx, json, params);
    _initProto(inst, "__unwrap__", { unwrap: _sharedUnwrap });
});
export function prefault(innerType, defaultValue) {
    return new ZodPrefault({
        type: "prefault",
        innerType: innerType,
        get defaultValue() {
            return typeof defaultValue === "function" ? defaultValue() : util.shallowClone(defaultValue);
        },
    });
}
export const ZodNonOptional = /*@__PURE__*/ core.$constructor("ZodNonOptional", (inst, def) => {
    core.$ZodNonOptional.init(inst, def);
    ZodType.init(inst, def);
    inst._zod.processJSONSchema = (ctx, json, params) => processors.nonoptionalProcessor(inst, ctx, json, params);
    _initProto(inst, "__unwrap__", { unwrap: _sharedUnwrap });
});
export function nonoptional(innerType, params) {
    return new ZodNonOptional({
        type: "nonoptional",
        innerType: innerType,
        ...util.normalizeParams(params),
    });
}
export const ZodSuccess = /*@__PURE__*/ core.$constructor("ZodSuccess", (inst, def) => {
    core.$ZodSuccess.init(inst, def);
    ZodType.init(inst, def);
    inst._zod.processJSONSchema = (ctx, json, params) => processors.successProcessor(inst, ctx, json, params);
    _initProto(inst, "__unwrap__", { unwrap: _sharedUnwrap });
});
export function success(innerType) {
    return new ZodSuccess({
        type: "success",
        innerType: innerType,
    });
}
export const ZodCatch = /*@__PURE__*/ core.$constructor("ZodCatch", (inst, def) => {
    core.$ZodCatch.init(inst, def);
    ZodType.init(inst, def);
    inst._zod.processJSONSchema = (ctx, json, params) => processors.catchProcessor(inst, ctx, json, params);
    _initProto(inst, "__unwrap__", { unwrap: _sharedUnwrap });
    _initProto(inst, "__removeCatch__", { removeCatch: _sharedUnwrap });
});
function _catch(innerType, catchValue) {
    return new ZodCatch({
        type: "catch",
        innerType: innerType,
        catchValue: (typeof catchValue === "function" ? catchValue : () => catchValue),
    });
}
export { _catch as catch };
export const ZodNaN = /*@__PURE__*/ core.$constructor("ZodNaN", (inst, def) => {
    core.$ZodNaN.init(inst, def);
    ZodType.init(inst, def);
    inst._zod.processJSONSchema = (ctx, json, params) => processors.nanProcessor(inst, ctx, json, params);
});
export function nan(params) {
    return core._nan(ZodNaN, params);
}
export const ZodPipe = /*@__PURE__*/ core.$constructor("ZodPipe", (inst, def) => {
    core.$ZodPipe.init(inst, def);
    ZodType.init(inst, def);
    inst._zod.processJSONSchema = (ctx, json, params) => processors.pipeProcessor(inst, ctx, json, params);
    inst.in = def.in;
    inst.out = def.out;
});
export function pipe(in_, out) {
    return new ZodPipe({
        type: "pipe",
        in: in_,
        out: out,
        // ...util.normalizeParams(params),
    });
}
export const ZodCodec = /*@__PURE__*/ core.$constructor("ZodCodec", (inst, def) => {
    ZodPipe.init(inst, def);
    core.$ZodCodec.init(inst, def);
});
export function codec(in_, out, params) {
    return new ZodCodec({
        type: "pipe",
        in: in_,
        out: out,
        transform: params.decode,
        reverseTransform: params.encode,
    });
}
export const ZodReadonly = /*@__PURE__*/ core.$constructor("ZodReadonly", (inst, def) => {
    core.$ZodReadonly.init(inst, def);
    ZodType.init(inst, def);
    inst._zod.processJSONSchema = (ctx, json, params) => processors.readonlyProcessor(inst, ctx, json, params);
    _initProto(inst, "__unwrap__", { unwrap: _sharedUnwrap });
});
export function readonly(innerType) {
    return new ZodReadonly({
        type: "readonly",
        innerType: innerType,
    });
}
export const ZodTemplateLiteral = /*@__PURE__*/ core.$constructor("ZodTemplateLiteral", (inst, def) => {
    core.$ZodTemplateLiteral.init(inst, def);
    ZodType.init(inst, def);
    inst._zod.processJSONSchema = (ctx, json, params) => processors.templateLiteralProcessor(inst, ctx, json, params);
});
export function templateLiteral(parts, params) {
    return new ZodTemplateLiteral({
        type: "template_literal",
        parts,
        ...util.normalizeParams(params),
    });
}
export const ZodLazy = /*@__PURE__*/ core.$constructor("ZodLazy", (inst, def) => {
    core.$ZodLazy.init(inst, def);
    ZodType.init(inst, def);
    inst._zod.processJSONSchema = (ctx, json, params) => processors.lazyProcessor(inst, ctx, json, params);
    _initProto(inst, "__unwrap__", { unwrap: _sharedLazyUnwrap });
});
export function lazy(getter) {
    return new ZodLazy({
        type: "lazy",
        getter: getter,
    });
}
export const ZodPromise = /*@__PURE__*/ core.$constructor("ZodPromise", (inst, def) => {
    core.$ZodPromise.init(inst, def);
    ZodType.init(inst, def);
    inst._zod.processJSONSchema = (ctx, json, params) => processors.promiseProcessor(inst, ctx, json, params);
    _initProto(inst, "__unwrap__", { unwrap: _sharedUnwrap });
});
export function promise(innerType) {
    return new ZodPromise({
        type: "promise",
        innerType: innerType,
    });
}
export const ZodFunction = /*@__PURE__*/ core.$constructor("ZodFunction", (inst, def) => {
    core.$ZodFunction.init(inst, def);
    ZodType.init(inst, def);
    inst._zod.processJSONSchema = (ctx, json, params) => processors.functionProcessor(inst, ctx, json, params);
});
export function _function(params) {
    return new ZodFunction({
        type: "function",
        input: Array.isArray(params?.input) ? tuple(params?.input) : (params?.input ?? array(unknown())),
        output: params?.output ?? unknown(),
    });
}
export { _function as function };
export const ZodCustom = /*@__PURE__*/ core.$constructor("ZodCustom", (inst, def) => {
    core.$ZodCustom.init(inst, def);
    ZodType.init(inst, def);
    inst._zod.processJSONSchema = (ctx, json, params) => processors.customProcessor(inst, ctx, json, params);
});
// custom checks
export function check(fn) {
    const ch = new core.$ZodCheck({
        check: "custom",
        // ...util.normalizeParams(params),
    });
    ch._zod.check = fn;
    return ch;
}
export function custom(fn, _params) {
    return core._custom(ZodCustom, fn ?? (() => true), _params);
}
export function refine(fn, _params = {}) {
    return core._refine(ZodCustom, fn, _params);
}
// superRefine
export function superRefine(fn) {
    return core._superRefine(fn);
}
// Re-export describe and meta from core
export const describe = core.describe;
export const meta = core.meta;
function _instanceof(cls, params = {}) {
    const inst = new ZodCustom({
        type: "custom",
        check: "custom",
        fn: (data) => data instanceof cls,
        abort: true,
        ...util.normalizeParams(params),
    });
    inst._zod.bag.Class = cls;
    // Override check to emit invalid_type instead of custom
    inst._zod.check = (payload) => {
        if (!(payload.value instanceof cls)) {
            payload.issues.push({
                code: "invalid_type",
                expected: cls.name,
                input: payload.value,
                inst,
                path: [...(inst._zod.def.path ?? [])],
            });
        }
    };
    return inst;
}
export { _instanceof as instanceof };
// stringbool
export const stringbool = (...args) => core._stringbool({
    Codec: ZodCodec,
    Boolean: ZodBoolean,
    String: ZodString,
}, ...args);
export function json(params) {
    const jsonSchema = lazy(() => {
        return union([string(params), number(), boolean(), _null(), array(jsonSchema), record(string(), jsonSchema)]);
    });
    return jsonSchema;
}
// preprocess
// /** @deprecated Use `z.pipe()` and `z.transform()` instead. */
export function preprocess(fn, schema) {
    return pipe(transform(fn), schema);
}
