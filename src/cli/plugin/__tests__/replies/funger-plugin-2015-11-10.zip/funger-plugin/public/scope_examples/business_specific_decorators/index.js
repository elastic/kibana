define(function (require) {
  require('plugins/funger-plugin/scope_examples/business_specific_decorators/index.less')

  require('ui/routes')
  .when('/scope_examples/business_specific_decorators', {
    template: require('plugins/funger-plugin/scope_examples/business_specific_decorators/index.html'),
    controller: function($scope) {
      $scope.user1 = {
        name: 'Jim',
        selected: false,
        state: 0
      };

      $scope.changeState = function() {
        $scope.user1.state += 1;
        $scope.user1.state = $scope.user1.state % 4;
      };
    }
  });

  var app = require('ui/modules').get('app/scope_examples', []);

  app.directive('userTile', function() {
    return {
      restrict: 'E',
      scope: {
        user: '='
      },
      template: require('plugins/funger-plugin/scope_examples/business_specific_decorators/userTile.html')
    };
  });

  app.directive('selectable', function() {
    return {
      restrict: 'A',
      link: function(scope, ele, attr) {
        var obj = scope[attr['selectable']];

        $(ele).addClass('selectable');

        $(ele).on('click', function(){
          scope.$apply(function() {
            obj.selected = !obj.selected;
          });
        });
      }
    }
  });

  app.directive('stateDisplay', function() {
    return {
      link: function(scope, ele, attr) {
        var parms = attr['stateDisplay'].split(' ');
        var linkVar = parms[0];
        parms.splice(0, 1);
        classes = parms;
        var classList = classes.join(' ');

        scope.$watch(linkVar, function(newVal) {
          ele.removeClass(classList);
          ele.addClass(classes[newVal]);
        });
      }
    }
  });
});
