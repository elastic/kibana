define(function (require) {
  require('plugins/funger-plugin/scope_examples/index.less');
  require('plugins/funger-plugin/scope_examples/shared/index');
  require('plugins/funger-plugin/scope_examples/inherited/index');
  require('plugins/funger-plugin/scope_examples/isolated/index');
  require('plugins/funger-plugin/scope_examples/decorator_directives/index');
  require('plugins/funger-plugin/scope_examples/custom_ng_click/index');
  require('plugins/funger-plugin/scope_examples/business_specific_decorators/index');
  require('plugins/funger-plugin/scope_examples/transclusion/index');
  require('plugins/funger-plugin/scope_examples/transclusion2/index');

  require('ui/routes')
  .when('/scope_examples', {
    template: require('plugins/funger-plugin/scope_examples/index.html')
  });
});
