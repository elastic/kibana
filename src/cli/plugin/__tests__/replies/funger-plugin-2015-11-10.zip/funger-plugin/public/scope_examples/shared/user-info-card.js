define(function (require) {
  var app = require('ui/modules').get('app/scope_examples', []);

  app.directive('userInfoCard', function () {
    return {
      restrict: 'E',
      template: require('plugins/funger-plugin/scope_examples/shared/user-info-card.html'),
      controller: function($scope) {
        $scope.primitive = 'new value';

        $scope.knightMe = function(user) {
          user.rank = 'knight';
        }

        console.log('child scope', $scope);
      }
    };
  });
});
