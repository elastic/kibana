define(function (require) {
  require('plugins/funger-plugin/scope_examples/isolated/user-info-card');

  require('ui/routes')
  .when('/scope_examples/isolated', {
    template: require('plugins/funger-plugin/scope_examples/isolated/index.html'),
    controller: function($scope) {
      $scope.primitive = 'old value';

      $scope.user1 = {
        name: 'Luke Skywalker',
        address: {
          street: 'PO Box 123',
          city: 'Secret Rebel Base',
          planet: 'Yavin 4'
        },
        friends: [
          'Han',
          'Leia',
          'Chewbacca'
        ]
      };

        $scope.user2 = {
        name: 'Han Solo',
        address: {
          street: 'PO Box 123',
          city: 'Secret Rebel Base',
          planet: 'Yavin 4'
        },
        friends: [
          'Luke',
          'Leia',
          'Chewbacca'
        ]
      };

      console.log('parent scope', $scope);
    }
  });
});
