Funger's plugin for Kibana >= 4.2.0

Installation: $ bin/kibana plugin -i BigFunger/funger-plugin