"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.EuiComboBoxInput = void 0;
var _typeof2 = _interopRequireDefault(require("@babel/runtime/helpers/typeof"));
var _extends2 = _interopRequireDefault(require("@babel/runtime/helpers/extends"));
var _objectWithoutProperties2 = _interopRequireDefault(require("@babel/runtime/helpers/objectWithoutProperties"));
var _classCallCheck2 = _interopRequireDefault(require("@babel/runtime/helpers/classCallCheck"));
var _createClass2 = _interopRequireDefault(require("@babel/runtime/helpers/createClass"));
var _possibleConstructorReturn2 = _interopRequireDefault(require("@babel/runtime/helpers/possibleConstructorReturn"));
var _getPrototypeOf2 = _interopRequireDefault(require("@babel/runtime/helpers/getPrototypeOf"));
var _inherits2 = _interopRequireDefault(require("@babel/runtime/helpers/inherits"));
var _defineProperty2 = _interopRequireDefault(require("@babel/runtime/helpers/defineProperty"));
var _toConsumableArray2 = _interopRequireDefault(require("@babel/runtime/helpers/toConsumableArray"));
var _propTypes = _interopRequireDefault(require("prop-types"));
var _react = _interopRequireWildcard(require("react"));
var _classnames = _interopRequireDefault(require("classnames"));
var _services = require("../../../services");
var _accessibility = require("../../accessibility");
var _badge = require("../../badge");
var _i18n = require("../../i18n");
var _popover = require("../../popover");
var _resize_observer = require("../../observer/resize_observer");
var _form_control_layout = require("../../form/form_control_layout");
var _utils = require("../utils");
var _combo_box_pill = require("./combo_box_pill");
var _get_visible_count = require("./get_visible_count");
var _combo_box_input = require("./combo_box_input.styles");
var _react2 = require("@emotion/react");
var _excluded = ["key", "label", "color", "onClick", "className", "append", "prepend", "truncationProps", "toolTipContent", "toolTipProps", "id", "data-test-subj"];
var cache;
function _interopRequireWildcard(e, t) { if (!t && e && e.__esModule) return e; var r, c, a = Object.defineProperty, n = { __proto__: null, default: e }; if (Object(e) !== e) return n; if (cache || "function" != typeof WeakMap || (cache = new WeakMap()), cache) { if (cache.has(e)) return cache.get(e); cache.set(e, n); } for (c in e) "default" !== c && {}.hasOwnProperty.call(e, c) && ((r = a && Object.getOwnPropertyDescriptor(e, c)) && (r.get || r.set) ? a(n, c, r) : n[c] = e[c]); return n; }
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { (0, _defineProperty2.default)(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
function _callSuper(t, o, e) { return o = (0, _getPrototypeOf2.default)(o), (0, _possibleConstructorReturn2.default)(t, _isNativeReflectConstruct() ? Reflect.construct(o, e || [], (0, _getPrototypeOf2.default)(t).constructor) : o.apply(t, e)); }
function _isNativeReflectConstruct() { try { var t = !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {})); } catch (t) {} return (_isNativeReflectConstruct = function _isNativeReflectConstruct() { return !!t; })(); } /*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */
/**
 * Width an element would have without being shrunk. Content that is clipped
 * (`overflow: hidden`) still counts towards `scrollWidth`, so this doesn't need
 * the element to be unshrunk while measuring.
 */
var getNaturalWidth = function getNaturalWidth(pill) {
  var width = Math.max(pill.offsetWidth, pill.getBoundingClientRect().width);
  var clipped = Math.max.apply(Math, [0].concat((0, _toConsumableArray2.default)(Array.from(pill.querySelectorAll('.euiBadge__content, .eui-textTruncate')).map(function (el) {
    return el.scrollWidth - el.clientWidth;
  }))));
  return width + clipped;
};
var EuiComboBoxInput = exports.EuiComboBoxInput = /*#__PURE__*/function (_Component) {
  function EuiComboBoxInput() {
    var _this;
    (0, _classCallCheck2.default)(this, EuiComboBoxInput);
    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }
    _this = _callSuper(this, EuiComboBoxInput, [].concat(args));
    (0, _defineProperty2.default)(_this, "state", {
      inputWidth: 2,
      hasFocus: false,
      isCollapsedPopoverOpen: false
    });
    (0, _defineProperty2.default)(_this, "widthUtils", void 0);
    (0, _defineProperty2.default)(_this, "wrapRef", {
      current: null
    });
    (0, _defineProperty2.default)(_this, "searchInputRef", null);
    (0, _defineProperty2.default)(_this, "resizeRefSource", void 0);
    (0, _defineProperty2.default)(_this, "wrapRefCallback", void 0);
    /**
     * Combines our own ref with the one `EuiResizeObserver` hands out. The callback
     * is only recreated when the observer's ref changes, so React doesn't detach
     * and re-attach the observer on every render.
     *
     * Note: this caches the callback on the instance while rendering. That is a
     * deliberate trade-off: it is a pure memoization (the same input always gives
     * the same callback) and the only way to keep a stable ref in a class component
     * that has to use the `EuiResizeObserver` render prop. It can be replaced with
     * `useCombinedRefs` once this component is converted to a functional component.
     */
    (0, _defineProperty2.default)(_this, "getWrapRef", function (resizeRef) {
      if (!_this.wrapRefCallback || _this.resizeRefSource !== resizeRef) {
        _this.resizeRefSource = resizeRef;
        _this.wrapRefCallback = function (node) {
          _this.wrapRef.current = node;
          resizeRef(node);
        };
      }
      return _this.wrapRefCallback;
    });
    /**
     * Measures the (always rendered) pills and works out how many fit on a
     * single row, leaving room for the input and the "+N" badge
     */
    (0, _defineProperty2.default)(_this, "updateVisibleCount", function () {
      var wrap = _this.wrapRef.current;
      var visibleCount;
      var badgeAndGapWidth = 0;
      if (_this.isCollapsed && wrap) {
        var _input$style$inlineSi;
        var pills = Array.from(wrap.children).filter(function (el) {
          return el.classList.contains('euiComboBoxPill');
        });
        var style = window.getComputedStyle(wrap);
        var gap = parseFloat(style.columnGap) || 0;
        var available = wrap.clientWidth - (parseFloat(style.paddingLeft) || 0) - (parseFloat(style.paddingRight) || 0);
        // A hidden badge with the widest possible label is always rendered, so the
        // result doesn't depend on which count is currently shown
        var badge = wrap.querySelector('.euiComboBoxCollapsedBadgeMeasure');
        var badgeWidth = badge ? Math.max(badge.offsetWidth, badge.getBoundingClientRect().width) : 0;
        badgeAndGapWidth = badgeWidth + gap;
        var input = wrap.querySelector('.euiComboBox__input');
        var inputWidthFromStyle = parseFloat((_input$style$inlineSi = input === null || input === void 0 ? void 0 : input.style.inlineSize) !== null && _input$style$inlineSi !== void 0 ? _input$style$inlineSi : '');
        var inputWidth = Number.isFinite(inputWidthFromStyle) ? Math.max(_combo_box_input.COLLAPSE_INPUT_MIN_WIDTH, inputWidthFromStyle) : _combo_box_input.COLLAPSE_INPUT_MIN_WIDTH;

        // Skip when not laid out (e.g. hidden or unit tests) to avoid hiding everything
        if (available > 0 && pills.length) {
          // Read-only: a shrunk pill clips its content, so add the clipped part
          var widths = pills.map(getNaturalWidth);
          visibleCount = (0, _get_visible_count.getVisibleCount)({
            widths: widths,
            available: available,
            gap: gap,
            badgeWidth: badgeWidth,
            inputWidth: inputWidth,
            pillMinWidth: _combo_box_input.COLLAPSE_PILL_MIN_WIDTH
          });
        }
      }
      var hasHiddenOptions = _this.isCollapsed && visibleCount != null && visibleCount < _this.props.selectedOptions.length;
      var shouldClosePopover = _this.state.isCollapsedPopoverOpen && !hasHiddenOptions;
      var collapsedBadgeSpace = hasHiddenOptions ? badgeAndGapWidth : undefined;
      if (visibleCount !== _this.state.visibleCount || collapsedBadgeSpace !== _this.state.collapsedBadgeSpace || shouldClosePopover) {
        var stateUpdate = {
          visibleCount: visibleCount,
          collapsedBadgeSpace: collapsedBadgeSpace,
          isCollapsedPopoverOpen: _this.state.isCollapsedPopoverOpen
        };
        if (shouldClosePopover) {
          stateUpdate.isCollapsedPopoverOpen = false;
        }
        _this.setState(stateUpdate, function () {
          var _this$searchInputRef;
          if (shouldClosePopover) (_this$searchInputRef = _this.searchInputRef) === null || _this$searchInputRef === void 0 || _this$searchInputRef.focus();
        });
      }
    });
    (0, _defineProperty2.default)(_this, "inputRefCallback", function (el) {
      var _this$props$inputRef, _this$props;
      _this.searchInputRef = el;
      _this.widthUtils = new _services.CanvasTextUtils({
        container: el
      });
      (_this$props$inputRef = (_this$props = _this.props).inputRef) === null || _this$props$inputRef === void 0 || _this$props$inputRef.call(_this$props, el);
    });
    (0, _defineProperty2.default)(_this, "updateInputSize", function (inputValue) {
      if (!_this.widthUtils) return;
      if (_this.asPlainText) return;
      _this.widthUtils.setTextToCheck(inputValue);
      // Canvas has minute subpixel differences in rendering compared to DOM
      // We'll buffer the input by ~2px just to ensure sufficient width
      var inputWidth = Math.ceil(_this.widthUtils.textWidth) + 2;
      _this.setState({
        inputWidth: inputWidth
      });
    });
    (0, _defineProperty2.default)(_this, "onFocus", function (event) {
      _this.props.onFocus(event);
      _this.setState({
        hasFocus: true
      });
    });
    (0, _defineProperty2.default)(_this, "onBlur", function (event) {
      if (_this.props.onBlur) {
        _this.props.onBlur(event);
      }
      _this.setState({
        hasFocus: false
      });
    });
    (0, _defineProperty2.default)(_this, "onKeyDown", function (event) {
      var _this$props2 = _this.props,
        searchValue = _this$props2.searchValue,
        hasSelectedOptions = _this$props2.hasSelectedOptions,
        selectedOptions = _this$props2.selectedOptions,
        onRemoveOption = _this$props2.onRemoveOption,
        singleSelection = _this$props2.singleSelection,
        isListOpen = _this$props2.isListOpen,
        onOpenListClick = _this$props2.onOpenListClick,
        onChange = _this$props2.onChange;
      var searchIsEmpty = !searchValue.length;
      if (event.key === _services.keys.BACKSPACE) {
        // When backspacing in a plain text combobox, change normally and remove the selection
        if (_this.asPlainText) {
          onChange(event.currentTarget.value);
          if (hasSelectedOptions) {
            onRemoveOption(selectedOptions[selectedOptions.length - 1]);
          }
        }
        // When backspacing from an empty input, delete the last pill option in the list
        else if (searchIsEmpty && hasSelectedOptions) {
          onRemoveOption(selectedOptions[selectedOptions.length - 1]);
          if (!!singleSelection && !isListOpen) {
            onOpenListClick();
          }
        }
      }
    });
    (0, _defineProperty2.default)(_this, "renderPills", function () {
      // Don't render a pill for plain text comboboxes - use the input instead
      if (_this.asPlainText) return null;
      // Don't render the single pill selection while searching
      if (_this.props.singleSelection && _this.props.searchValue) return null;
      var selectedOptions = _this.props.selectedOptions;
      if (!selectedOptions || !selectedOptions.length) return null;
      var visibleCount = _this.state.visibleCount;
      var isCollapsed = _this.isCollapsed;
      var pills = selectedOptions.map(function (option, index) {
        return _this.renderPill(option, isCollapsed && visibleCount != null && index >= visibleCount, isCollapsed && visibleCount != null && index === visibleCount - 1);
      });
      if (!isCollapsed) return pills;

      // Hidden badge with the widest possible label (every selection hidden), only
      // rendered so that its width can be measured
      var measureBadge = (0, _react2.jsx)(_badge.EuiBadge, {
        key: "euiComboBoxCollapsedBadgeMeasure",
        className: "euiComboBoxCollapsedBadgeMeasure"
      }, "+", selectedOptions.length);
      var hiddenOptions = visibleCount == null ? [] : selectedOptions.slice(visibleCount);
      if (!hiddenOptions.length) return [].concat((0, _toConsumableArray2.default)(pills), [measureBadge]);
      return [].concat((0, _toConsumableArray2.default)(pills), [measureBadge, _this.renderCollapsedBadge(hiddenOptions)]);
    });
    (0, _defineProperty2.default)(_this, "closeCollapsedPopover", function () {
      _this.setState({
        isCollapsedPopoverOpen: false
      });
    });
    (0, _defineProperty2.default)(_this, "toggleCollapsedPopover", function (event) {
      // Don't let the click bubble to the control, which would open the options list
      event.preventDefault();
      event.stopPropagation();

      // Close the options list on opening the collapsed pill popover
      if (_this.props.isListOpen && !_this.state.isCollapsedPopoverOpen) {
        _this.props.onCloseListClick();
      }
      _this.setState(function (_ref) {
        var isCollapsedPopoverOpen = _ref.isCollapsedPopoverOpen;
        return {
          isCollapsedPopoverOpen: !isCollapsedPopoverOpen
        };
      });
    });
    (0, _defineProperty2.default)(_this, "renderPill", function (option) {
      var isCollapsed = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : false;
      var isLastVisible = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : false;
      var key = option.key,
        label = option.label,
        color = option.color,
        onClick = option.onClick,
        className = option.className,
        append = option.append,
        prepend = option.prepend,
        truncationProps = option.truncationProps,
        toolTipContent = option.toolTipContent,
        toolTipProps = option.toolTipProps,
        id = option.id,
        dataTestSubj = option['data-test-subj'],
        rest = (0, _objectWithoutProperties2.default)(option, _excluded);
      var _this$props3 = _this.props,
        isDisabled = _this$props3.isDisabled,
        onRemoveOption = _this$props3.onRemoveOption,
        singleSelection = _this$props3.singleSelection;
      return (0, _react2.jsx)(_combo_box_pill.EuiComboBoxPill, (0, _extends2.default)({
        option: option,
        onClose: isDisabled || singleSelection || onClick ? undefined : onRemoveOption,
        key: key !== null && key !== void 0 ? key : label.toLowerCase(),
        className: (0, _classnames.default)(className, isCollapsed && 'euiComboBoxPill--collapsed', isLastVisible && 'euiComboBoxPill--shrinkable'),
        color: color,
        onClick: onClick,
        onClickAriaLabel: onClick ? 'Change' : undefined
      }, rest, !isCollapsed && id !== undefined && {
        id: id
      }, !isCollapsed && dataTestSubj !== undefined && {
        'data-test-subj': dataTestSubj
      }), label);
    });
    (0, _defineProperty2.default)(_this, "renderCollapsedBadge", function (hiddenOptions) {
      var badge = (0, _react2.jsx)(_i18n.EuiI18n, {
        token: "euiComboBoxInput.collapsedSelections",
        default: "Show {count} hidden selections",
        values: {
          count: hiddenOptions.length
        }
      }, function (collapsedSelections) {
        return (0, _react2.jsx)(_badge.EuiBadge, {
          color: "default",
          "data-test-subj": "comboBoxCollapsedBadge",
          onClick: _this.toggleCollapsedPopover,
          onClickAriaLabel: collapsedSelections,
          "aria-haspopup": "dialog",
          "aria-expanded": _this.state.isCollapsedPopoverOpen
        }, "+", hiddenOptions.length);
      });
      return (0, _react2.jsx)(_i18n.EuiI18n, {
        key: "euiComboBoxCollapsedSelectionsDialog",
        token: "euiComboBoxInput.collapsedSelectionsDialog",
        default: "Hidden selections"
      }, function (collapsedSelectionsDialog) {
        return (0, _react2.jsx)(_popover.EuiPopover, {
          key: "euiComboBoxCollapsedBadge",
          className: "euiComboBoxCollapsedBadge",
          "aria-label": collapsedSelectionsDialog,
          button: badge,
          isOpen: _this.state.isCollapsedPopoverOpen,
          closePopover: _this.closeCollapsedPopover,
          anchorPosition: "downLeft",
          panelPaddingSize: "s",
          panelProps: {
            className: 'euiComboBoxCollapsedPopover',
            'data-test-subj': 'comboBoxCollapsedPopover'
          }
        }, (0, _react2.jsx)(_services.RenderWithEuiStylesMemoizer, null, function (stylesMemoizer) {
          return (
            // Clicks in the popover (rendered in a portal) bubble through the React
            // tree to the control - stop them so they don't open the options list
            // eslint-disable-next-line jsx-a11y/no-static-element-interactions, jsx-a11y/click-events-have-key-events
            (0, _react2.jsx)("div", {
              css: stylesMemoizer(_combo_box_input.euiComboBoxInputStyles).collapsedList,
              className: "euiComboBoxCollapsedList",
              onClick: function onClick(event) {
                return event.stopPropagation();
              }
            }, hiddenOptions.map(function (option) {
              return _this.renderPill(option);
            }))
          );
        }));
      });
    });
    return _this;
  }
  (0, _inherits2.default)(EuiComboBoxInput, _Component);
  return (0, _createClass2.default)(EuiComboBoxInput, [{
    key: "componentDidMount",
    value: function componentDidMount() {
      this.updateVisibleCount();
    }
  }, {
    key: "isCollapsed",
    get: function get() {
      var _this$props4 = this.props,
        selectionDisplay = _this$props4.selectionDisplay,
        singleSelection = _this$props4.singleSelection;
      return selectionDisplay === 'collapse' && !singleSelection;
    }
  }, {
    key: "componentDidUpdate",
    value: function componentDidUpdate(prevProps, prevState) {
      if (prevProps.searchValue !== this.props.searchValue) {
        this.updateInputSize(this.props.searchValue);
      }
      if (prevState.isCollapsedPopoverOpen !== this.state.isCollapsedPopoverOpen) {
        var _this$props$onCollaps, _this$props5;
        (_this$props$onCollaps = (_this$props5 = this.props).onCollapsedPopoverToggle) === null || _this$props$onCollaps === void 0 || _this$props$onCollaps.call(_this$props5, this.state.isCollapsedPopoverOpen);
      }

      // Only re-measure when something that affects the fit changed. Width changes
      // of the control itself are handled by `EuiResizeObserver`, but it can't see
      // icons (loading, invalid, clear button, ...) being added: they change the
      // padding, and with it the space for the pills, not the size of the control.
      var props = this.props;
      if (prevProps.selectedOptions !== props.selectedOptions || prevProps.compressed !== props.compressed || prevProps.selectionDisplay !== props.selectionDisplay || prevProps.singleSelection !== props.singleSelection || prevProps.placeholder !== props.placeholder || prevProps.isLoading !== props.isLoading || prevProps.isInvalid !== props.isInvalid || prevProps.isDisabled !== props.isDisabled || prevProps.noIcon !== props.noIcon || prevProps.hasSelectedOptions !== props.hasSelectedOptions || !!prevProps.onClear !== !!props.onClear || prevState.inputWidth !== this.state.inputWidth) {
        this.updateVisibleCount();
      }
    }
  }, {
    key: "asPlainText",
    get: function get() {
      var singleSelection = this.props.singleSelection;
      var isSingleSelectionConfig = singleSelection && (0, _typeof2.default)(singleSelection) === 'object';
      return !!(isSingleSelectionConfig && singleSelection.asPlainText);
    }
  }, {
    key: "searchValue",
    get: function get() {
      var _this$props6 = this.props,
        searchValue = _this$props6.searchValue,
        selectedOptions = _this$props6.selectedOptions;
      if (this.asPlainText) {
        var _selectedOptions$;
        return searchValue || (selectedOptions === null || selectedOptions === void 0 || (_selectedOptions$ = selectedOptions[0]) === null || _selectedOptions$ === void 0 ? void 0 : _selectedOptions$.label) || '';
      } else {
        return searchValue;
      }
    }
  }, {
    key: "render",
    value: function render() {
      var _this2 = this;
      var _this$props7 = this.props,
        compressed = _this$props7.compressed,
        focusedOptionId = _this$props7.focusedOptionId,
        fullWidth = _this$props7.fullWidth,
        hasSelectedOptions = _this$props7.hasSelectedOptions,
        id = _this$props7.id,
        isDisabled = _this$props7.isDisabled,
        isListOpen = _this$props7.isListOpen,
        noIcon = _this$props7.noIcon,
        _onChange = _this$props7.onChange,
        onClear = _this$props7.onClear,
        onClick = _this$props7.onClick,
        onFocus = _this$props7.onFocus,
        onCloseListClick = _this$props7.onCloseListClick,
        onOpenListClick = _this$props7.onOpenListClick,
        placeholder = _this$props7.placeholder,
        rootId = _this$props7.rootId,
        searchValue = _this$props7.searchValue,
        selectedOptions = _this$props7.selectedOptions,
        singleSelection = _this$props7.singleSelection,
        value = _this$props7.value,
        prepend = _this$props7.prepend,
        append = _this$props7.append,
        isLoading = _this$props7.isLoading,
        isInvalid = _this$props7.isInvalid,
        autoFocus = _this$props7.autoFocus,
        ariaLabel = _this$props7['aria-label'],
        ariaLabelledby = _this$props7['aria-labelledby'],
        ariaDescribedby = _this$props7['aria-describedby'];
      var removeOptionMessage;
      var removeOptionMessageId;
      if (this.state.hasFocus) {
        var readPlaceholder = placeholder ? "".concat(placeholder, ".") : '';
        var removeOptionMessageContent = "Combo box. Selected. ".concat(searchValue ? "".concat(searchValue, ". Selected. ") : '').concat(selectedOptions && selectedOptions.length > 0 ? "".concat(value, ". Press Backspace to delete ").concat(selectedOptions[selectedOptions.length - 1].label, ". ") : '', "Combo box input. ").concat(readPlaceholder, " Type some text or, to display a list of choices, press Down Arrow. ") + 'To exit the list of choices, press Escape.';
        removeOptionMessageId = rootId('removeOptionMessage');

        // aria-live="assertive" will read this message aloud immediately once it enters the DOM.
        // We'll render to the DOM when the input gains focus and remove it when the input loses focus.
        // We'll use aria-hidden to prevent default aria information from being read by the screen
        // reader.
        removeOptionMessage = (0, _react2.jsx)(_accessibility.EuiScreenReaderOnly, null, (0, _react2.jsx)("span", {
          "aria-live": "polite",
          id: removeOptionMessageId
        }, removeOptionMessageContent));
      }
      var isInGroup = !!(prepend || append);
      var showPlaceholder = placeholder && !(selectedOptions !== null && selectedOptions !== void 0 && selectedOptions.length) && !searchValue;
      var clickProps = {};
      if (!isDisabled && onClear && hasSelectedOptions) {
        clickProps.clear = {
          'data-test-subj': 'comboBoxClearButton',
          onClick: onClear
        };
      }
      var icon;
      if (!noIcon && !isDisabled) {
        icon = {
          'aria-label': isListOpen ? 'Close list of options' : 'Open list of options',
          'data-test-subj': 'comboBoxToggleListButton',
          disabled: isDisabled,
          onClick: isListOpen && !isDisabled ? onCloseListClick : onOpenListClick,
          side: 'right',
          tabIndex: -1,
          type: 'chevronSingleDown'
        };
      }
      var wrapClasses = (0, _classnames.default)('euiComboBox__inputWrap', {
        'euiComboBox__inputWrap--plainText': this.asPlainText
      });
      return (0, _react2.jsx)(_services.RenderWithEuiStylesMemoizer, null, function (stylesMemoizer) {
        var styles = stylesMemoizer(_combo_box_input.euiComboBoxInputStyles);
        var stateCss = isListOpen ? styles.open : isInvalid ? styles.invalid : undefined;
        var cssStyles = [styles.euiComboBoxInputWrapper, !singleSelection && styles.multiSelect, _this2.isCollapsed && styles.collapsed, compressed ? styles.compressed : styles.uncompressed].concat((0, _toConsumableArray2.default)(_this2.asPlainText || showPlaceholder ? [styles.plainText.plainText, compressed ? styles.plainText.compressed : styles.plainText.uncompressed] : []), [isDisabled ? styles.disabled : stateCss, isInGroup && styles.inGroup]);
        var formLayoutStyles = [styles.formLayout.euiComboBox__formControlLayout, !singleSelection && styles.formLayout.multiSelect, !singleSelection && isInGroup && styles.formLayout.multiSelectGroup, !singleSelection && compressed && styles.formLayout.multiSelectCompressed];
        return (0, _react2.jsx)(_form_control_layout.EuiFormControlLayout, (0, _extends2.default)({
          icon: icon
        }, clickProps, {
          inputId: id,
          isLoading: isLoading,
          isInvalid: isInvalid,
          isDisabled: isDisabled,
          compressed: compressed,
          fullWidth: fullWidth,
          prepend: prepend,
          append: append,
          css: formLayoutStyles
        }), (0, _react2.jsx)(_resize_observer.EuiResizeObserver, {
          onResize: _this2.updateVisibleCount
        }, function (resizeRef) {
          return (0, _react2.jsx)("div", {
            ref: _this2.getWrapRef(resizeRef),
            css: cssStyles,
            className: wrapClasses,
            "data-test-subj": "comboBoxInput",
            onClick: onClick,
            tabIndex: -1 // becomes onBlur event's relatedTarget, otherwise relatedTarget is null when clicking on this div
          }, _this2.renderPills(), (0, _react2.jsx)(_utils.EuiComboBoxOptionAppendPrepend, {
            option: _this2.asPlainText ? selectedOptions === null || selectedOptions === void 0 ? void 0 : selectedOptions[0] : undefined,
            classNamePrefix: "euiComboBoxPlainTextSelection",
            marginSize: "xxs"
          }, (0, _react2.jsx)("input", {
            "aria-activedescendant": focusedOptionId,
            "aria-autocomplete": "list",
            "aria-controls": isListOpen ? rootId('listbox') : '',
            "aria-expanded": isListOpen,
            "aria-label": ariaLabel,
            "aria-labelledby": ariaLabelledby,
            "aria-describedby": ariaDescribedby,
            "aria-invalid": isInvalid,
            "aria-haspopup": "listbox",
            css: styles.euiComboBoxInput,
            className: "euiComboBox__input",
            "data-test-subj": "comboBoxSearchInput",
            disabled: isDisabled,
            id: id,
            onBlur: _this2.onBlur,
            onChange: function onChange(event) {
              return _onChange(event.target.value);
            },
            onFocus: _this2.onFocus,
            onKeyDown: _this2.onKeyDown,
            ref: _this2.inputRefCallback,
            role: "combobox",
            style: _objectSpread({
              inlineSize: _this2.asPlainText || showPlaceholder ? '100%' : _this2.state.inputWidth
            }, _this2.state.collapsedBadgeSpace ? {
              maxInlineSize: "calc(100% - ".concat(_this2.state.collapsedBadgeSpace, "px)")
            } : {}),
            placeholder: showPlaceholder ? placeholder : undefined,
            value: _this2.searchValue,
            autoFocus: autoFocus,
            autoComplete: "off"
            // Force the menu to re-open on every input click - only necessary when plain text
            ,
            onClick: _this2.asPlainText ? onFocus : undefined // Type shenanigans - event should be mostly the same
          })), removeOptionMessage);
        }));
      });
    }
  }]);
}(_react.Component);
EuiComboBoxInput.propTypes = {
  compressed: _propTypes.default.bool.isRequired,
  focusedOptionId: _propTypes.default.string,
  fullWidth: _propTypes.default.bool,
  hasSelectedOptions: _propTypes.default.bool.isRequired,
  id: _propTypes.default.string,
  inputRef: _propTypes.default.any,
  isDisabled: _propTypes.default.bool,
  isListOpen: _propTypes.default.bool.isRequired,
  noIcon: _propTypes.default.bool.isRequired,
  onBlur: _propTypes.default.any,
  onChange: _propTypes.default.func.isRequired,
  onClear: _propTypes.default.func,
  onClick: _propTypes.default.func.isRequired,
  onCloseListClick: _propTypes.default.func.isRequired,
  onFocus: _propTypes.default.any.isRequired,
  onOpenListClick: _propTypes.default.func.isRequired,
  /** Called when the hidden selections popover (`selectionDisplay="collapse"`) opens or closes */onCollapsedPopoverToggle: _propTypes.default.func,
  onRemoveOption: _propTypes.default.func.isRequired,
  placeholder: _propTypes.default.string,
  rootId: _propTypes.default.any.isRequired,
  searchValue: _propTypes.default.string.isRequired,
  selectedOptions: _propTypes.default.arrayOf(_propTypes.default.shape({
    isGroupLabelOption: _propTypes.default.bool,
    label: _propTypes.default.string.isRequired,
    key: _propTypes.default.string,
    options: _propTypes.default.arrayOf(_propTypes.default.shape({
      isGroupLabelOption: _propTypes.default.bool,
      label: _propTypes.default.string.isRequired,
      key: _propTypes.default.string,
      options: _propTypes.default.arrayOf(_propTypes.default.any.isRequired),
      value: _propTypes.default.any,
      prepend: _propTypes.default.node,
      append: _propTypes.default.node,
      truncationProps: _propTypes.default.any,
      /**
         * Optional custom tooltip content for the button
         */
      toolTipContent: _propTypes.default.node,
      /**
         * Optional props to pass to the underlying **[EuiToolTip](https://eui.elastic.co/docs/components/display/tooltip/)**
         */
      toolTipProps: _propTypes.default.any,
      className: _propTypes.default.string,
      "aria-label": _propTypes.default.string,
      "data-test-subj": _propTypes.default.string,
      css: _propTypes.default.any
    }).isRequired),
    value: _propTypes.default.any,
    prepend: _propTypes.default.node,
    append: _propTypes.default.node,
    truncationProps: _propTypes.default.any,
    /**
       * Optional custom tooltip content for the button
       */
    toolTipContent: _propTypes.default.node,
    /**
       * Optional props to pass to the underlying **[EuiToolTip](https://eui.elastic.co/docs/components/display/tooltip/)**
       */
    toolTipProps: _propTypes.default.any,
    className: _propTypes.default.string,
    "aria-label": _propTypes.default.string,
    "data-test-subj": _propTypes.default.string,
    css: _propTypes.default.any
  }).isRequired).isRequired,
  singleSelection: _propTypes.default.oneOfType([_propTypes.default.bool.isRequired, _propTypes.default.shape({
    asPlainText: _propTypes.default.bool
  }).isRequired]),
  selectionDisplay: _propTypes.default.oneOf(["wrap", "collapse"]),
  toggleButtonRef: _propTypes.default.any,
  value: _propTypes.default.string,
  prepend: _propTypes.default.oneOfType([_propTypes.default.oneOfType([_propTypes.default.string.isRequired, _propTypes.default.element.isRequired]).isRequired, _propTypes.default.arrayOf(_propTypes.default.oneOfType([_propTypes.default.string.isRequired, _propTypes.default.element.isRequired]).isRequired).isRequired]),
  append: _propTypes.default.oneOfType([_propTypes.default.oneOfType([_propTypes.default.string.isRequired, _propTypes.default.element.isRequired]).isRequired, _propTypes.default.arrayOf(_propTypes.default.oneOfType([_propTypes.default.string.isRequired, _propTypes.default.element.isRequired]).isRequired).isRequired]),
  isLoading: _propTypes.default.bool,
  isInvalid: _propTypes.default.bool,
  autoFocus: _propTypes.default.bool,
  "aria-label": _propTypes.default.string,
  "aria-labelledby": _propTypes.default.string,
  "aria-describedby": _propTypes.default.string,
  className: _propTypes.default.string,
  "data-test-subj": _propTypes.default.string,
  css: _propTypes.default.any
};