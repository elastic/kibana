"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.euiFacetButton__disabled = exports.euiFacetButtonTextStyles = exports.euiFacetButtonStyles = void 0;
var _react = require("@emotion/react");
var _global_styling = require("../../global_styling");
function _EMOTION_STRINGIFIED_CSS_ERROR__() { return "You have tried to stringify object returned from `css` function. It isn't supposed to be used directly (e.g. as value of the `className` prop), but rather handed to emotion so it can handle it (e.g. as value of `css` prop)."; } /*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */
var euiFacetButtonStyles = exports.euiFacetButtonStyles = function euiFacetButtonStyles(_ref) {
  var euiTheme = _ref.euiTheme;
  return {
    // Base
    euiFacetButton: /*#__PURE__*/(0, _react.css)((0, _global_styling.logicalTextAlignCSS)('left'), " &:not(:disabled){&:hover,&:focus{text-decoration:none;.euiFacetButton__text{text-decoration:underline;}}&:focus .euiFacetButton__text{text-decoration-thickness:", euiTheme.border.width.thick, ";}}&:disabled{color:", euiTheme.colors.textDisabled, ";pointer-events:none;};label:euiFacetButton;")
  };
};
var euiFacetButtonTextStyles = exports.euiFacetButtonTextStyles = function euiFacetButtonTextStyles(_ref2) {
  var euiTheme = _ref2.euiTheme;
  return {
    euiFacetButton__text: /*#__PURE__*/(0, _react.css)((0, _global_styling.euiTextShift)('bold', 'data-text', euiTheme), " ", (0, _global_styling.euiTextTruncate)(), " flex-grow:1;;label:euiFacetButton__text;"),
    isSelected: /*#__PURE__*/(0, _react.css)("font-weight:", euiTheme.font.weight.bold, ";;label:isSelected;"),
    unSelected: /*#__PURE__*/(0, _react.css)(";label:unSelected;")
  };
};

// Used by both icon and quantity siblings
var euiFacetButton__disabled = exports.euiFacetButton__disabled = process.env.NODE_ENV === "production" ? {
  name: "1622f2l-euiFacetButton__disabled",
  styles: "opacity:0.5;label:euiFacetButton__disabled;"
} : {
  name: "1622f2l-euiFacetButton__disabled",
  styles: "opacity:0.5;label:euiFacetButton__disabled;",
  toString: _EMOTION_STRINGIFIED_CSS_ERROR__
};