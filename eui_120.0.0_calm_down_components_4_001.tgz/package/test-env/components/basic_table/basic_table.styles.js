"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.safariLoadingWorkaround = exports.euiBasicTableWrapperPanelledStyles = exports.euiBasicTableBodyLoading = void 0;
var _taggedTemplateLiteral2 = _interopRequireDefault(require("@babel/runtime/helpers/taggedTemplateLiteral"));
var _react = require("@emotion/react");
var _global_styling = require("../../global_styling");
var _use_panel_props = require("./use_panel_props");
var _templateObject;
function _EMOTION_STRINGIFIED_CSS_ERROR__() { return "You have tried to stringify object returned from `css` function. It isn't supposed to be used directly (e.g. as value of the `className` prop), but rather handed to emotion so it can handle it (e.g. as value of `css` prop)."; } /*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */
var tableLoadingLine = (0, _react.keyframes)(_templateObject || (_templateObject = (0, _taggedTemplateLiteral2.default)(["\n  from {\n    ", "\n    ", "\n  }\n\n  20% {\n    ", "\n    ", "\n  }\n\n  80% {\n    ", "\n    ", "\n  }\n\n  100% {\n    ", "\n    ", "\n  }\n"])), (0, _global_styling.logicalCSS)('left', 0), (0, _global_styling.logicalCSS)('width', 0), (0, _global_styling.logicalCSS)('left', 0), (0, _global_styling.logicalCSS)('width', '40%'), (0, _global_styling.logicalCSS)('left', '60%'), (0, _global_styling.logicalCSS)('width', '40%'), (0, _global_styling.logicalCSS)('left', '100%'), (0, _global_styling.logicalCSS)('width', 0));
var euiBasicTableBodyLoading = exports.euiBasicTableBodyLoading = function euiBasicTableBodyLoading(euiThemeContext) {
  var euiTheme = euiThemeContext.euiTheme;
  return /*#__PURE__*/(0, _react.css)("position:relative;overflow:hidden;&::before{position:absolute;content:'';", (0, _global_styling.logicalCSS)('width', '100%'), " ", (0, _global_styling.logicalCSS)('height', euiTheme.border.width.thick), " background-color:", euiTheme.colors.primary, ";animation:", tableLoadingLine, " 1s linear infinite;", _global_styling.euiCantAnimate, "{animation:none;background:repeating-linear-gradient(\n          -45deg,\n          ", euiTheme.colors.backgroundBasePlain, ",\n          ", euiTheme.colors.backgroundBasePlain, " ", euiTheme.size.xs, ",\n          ", euiTheme.colors.primary, " ", euiTheme.size.xs, ",\n          ", euiTheme.colors.primary, " ", euiTheme.size.s, "\n        );", (0, _global_styling.highContrastModeStyles)(euiThemeContext, {
    forced: "\n              ".concat((0, _global_styling.preventForcedColors)(euiThemeContext), "\n            ")
  }), ";}};label:euiBasicTableBodyLoading;");
};

/**
 * @internal
 */
var euiBasicTableWrapperPanelledStyles = exports.euiBasicTableWrapperPanelledStyles = function euiBasicTableWrapperPanelledStyles(responsiveBreakpoint) {
  return function (theme) {
    var euiTheme = theme.euiTheme;
    var styles = /*#__PURE__*/(0, _react.css)("border:", euiTheme.border.thin, ";padding-block-start:", euiTheme.border.width.thin, ";border-radius:", euiTheme.border.radius.panel, ";&:not(:last-child){border-block-end-width:0;}.euiTable{border-radius:", euiTheme.border.radius.panel, ";}.", _use_panel_props.EUI_BASIC_TABLE_PANEL_CLASS_NAME, "+.euiBasicTable &{border-start-start-radius:0;border-start-end-radius:0;.euiTable,.euiTable__wrapper,.euiTableStickyHeader__container{border-start-start-radius:0;border-start-end-radius:0;}.euiTableHeaderCell[data-sticky='start']{border-start-start-radius:0;}.euiTableHeaderCell[data-sticky='end']{border-start-end-radius:0;}}&:not(:last-child),&:has(+ .", _use_panel_props.EUI_BASIC_TABLE_PANEL_CLASS_NAME, "){border-end-start-radius:0;border-end-end-radius:0;.euiTable{border-end-start-radius:0;border-end-end-radius:0;}.euiTableFooterCell{&[data-sticky='start'],&:first-child{border-end-start-radius:0;}&[data-sticky='end'],&:last-child{border-end-end-radius:0;}}}.euiTable__wrapper,.euiTableStickyHeader__container{border-start-start-radius:", euiTheme.border.radius.panel, ";border-start-end-radius:", euiTheme.border.radius.panel, ";}.euiTableHeaderCell{&[data-sticky='start']{border-start-start-radius:", euiTheme.border.radius.panel, ";}&[data-sticky='end']{border-start-end-radius:", euiTheme.border.radius.panel, ";}.euiTableCellContent{border-radius:inherit;}}.euiTableFooterCell{&[data-sticky='start'],&:first-child{border-end-start-radius:", euiTheme.border.radius.panel, ";}&[data-sticky='end'],&:last-child{border-end-end-radius:", euiTheme.border.radius.panel, ";}.euiTableCellContent{border-radius:inherit;}};label:styles;");
    if (responsiveBreakpoint === true) {
      return null;
    }
    if (!responsiveBreakpoint) {
      return styles;
    }
    return /*#__PURE__*/(0, _react.css)((0, _global_styling.euiMinBreakpoint)(theme, responsiveBreakpoint), "{", styles, ";};label:euiBasicTableWrapperPanelledStyles;");
  };
};

// Fix to make the loading indicator position correctly in Safari
// For whatever annoying reason, Safari doesn't respect `position: relative;`
// on `tbody` without `position: relative` on the parent `table`
var safariLoadingWorkaround = exports.safariLoadingWorkaround = process.env.NODE_ENV === "production" ? {
  name: "6xbnw4-safariLoadingWorkaround",
  styles: "position:relative;label:safariLoadingWorkaround;"
} : {
  name: "6xbnw4-safariLoadingWorkaround",
  styles: "position:relative;label:safariLoadingWorkaround;",
  toString: _EMOTION_STRINGIFIED_CSS_ERROR__
};