import { _EuiThemeBreakpoints } from './breakpoint';
export declare const breakpoint: _EuiThemeBreakpoints;
