export declare type EuiThemeVariantFlags = {
    shadowVariant: 'classic' | 'refresh';
};
/**
 * Theme specific setting flags
 */
export declare type _EuiThemeFlags = EuiThemeVariantFlags;
