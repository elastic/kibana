import { CSSProperties } from 'react';
import { ColorModeSwitch } from '../../services/theme/types';
export declare const EuiThemeShadowSizes: readonly ["xs", "s", "m", "l", "xl"];
export declare type _EuiThemeShadowSize = (typeof EuiThemeShadowSizes)[number];
export declare const EuiThemeShadowHoverSizes: readonly ["s", "m", "l", "xl", "xxl"];
export declare type _EuiThemeShadowHoverSize = (typeof EuiThemeShadowHoverSizes)[number];
/**
 * Shadow t-shirt sizes descriptions
 */
export declare const _EuiShadowSizesDescriptions: Record<_EuiThemeShadowSize, string>;
export interface _EuiThemeShadowCustomColor {
    color?: string;
    property?: 'box-shadow' | 'filter';
    borderAllInHighContrastMode?: boolean;
}
export declare type _EuiThemeShadow = {
    /** Default direction of the shadow */
    down: CSSProperties['boxShadow'];
    /** Reverse direction */
    up: CSSProperties['boxShadow'];
};
export declare type _EuiThemeShadows = ColorModeSwitch<{
    colors: {
        base: string;
    };
    xs: _EuiThemeShadow;
    s: _EuiThemeShadow;
    m: _EuiThemeShadow;
    l: _EuiThemeShadow;
    xl: _EuiThemeShadow;
    hover: {
        base: _EuiThemeShadow;
        xl: _EuiThemeShadow;
    };
    /** @deprecated - Defined only to support the legacy `euiShadowFlat` mixin;
     * will be removed in the future
     */
    flat: _EuiThemeShadow;
}>;
/**
 * Represents a single shadow
 * @see https://tr.designtokens.org/format/#shadow
 */
export declare type _EuiThemeShadowLayer = {
    opacity: number;
    x: number;
    y: number;
    blur: number;
    spread: number;
};
export declare type _EuiThemeShadowPrimitive = {
    light: _EuiThemeShadowLayer[];
    dark: _EuiThemeShadowLayer[];
};
export declare type _EuiThemeShadowPrimitives = {
    xs: _EuiThemeShadowPrimitive;
    s: _EuiThemeShadowPrimitive;
    m: _EuiThemeShadowPrimitive;
    l: _EuiThemeShadowPrimitive;
    xl: _EuiThemeShadowPrimitive;
    xxl: _EuiThemeShadowPrimitive;
    flat: _EuiThemeShadowPrimitive;
};
