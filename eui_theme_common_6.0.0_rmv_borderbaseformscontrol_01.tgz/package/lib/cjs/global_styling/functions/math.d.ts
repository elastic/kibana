/**
 * Utility for performing math callbacks on a string with CSS units
 * and returning a string with its unit preserved.
 *
 * Example usage:
 * mathWithUnits('4px', (x) => x / 2) = '2px';
 * mathWithUnits(euiTheme.size.xs, (x) => x + 2) = '6px';
 * mathWithUnits([euiTheme.size.l, euiTheme.size.s], (x, y) => x - y) = '16px';
 */
declare type ValueTypes = string | number | undefined;
export declare const mathWithUnits: (values: ValueTypes | ValueTypes[], callback: (...args: number[]) => number, unit?: string) => string;
export {};
