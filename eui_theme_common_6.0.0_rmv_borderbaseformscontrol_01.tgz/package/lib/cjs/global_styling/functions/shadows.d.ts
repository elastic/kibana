import { EuiThemeColorModeStandard } from '../../services/theme/types';
export declare const getShadowColor: (color: string, opacity: number, colorMode: EuiThemeColorModeStandard) => string;
/**
 * Converts a `box-shadow` string to a `filter: drop-shadow()` string.
 *
 * @todo check whether this is actually needed in +2025, the original code replacing
 * box-shadow with filter: drop-shadow() had the following comment:
 * > Using only one drop-shadow filter instead of multiple is more
 * > performant & prevents Safari bugs
 *
 * @param boxShadow The `box-shadow` string to convert.
 * @returns The converted `filter` string.
 */
export declare const boxShadowToFilterDropShadow: (boxShadow: string) => string;
