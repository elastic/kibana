import { UseEuiTheme } from '../../services/theme/types';
export declare const getBorderSide: (side: BorderSides) => string;
export declare type BorderSides = 'left' | 'right' | 'top' | 'bottom' | 'horizontal' | 'vertical' | 'all';
/**
 * Defines styles for floating boarders applied in DARK mode via EUI shadow utils
 */
export declare const euiShadowFloatingBorderStyles: (euiThemeContext: UseEuiTheme, options: {
    side?: BorderSides;
    borderColor?: string;
    borderWidth?: string;
    borderStyle?: string;
}) => string;
/**
 * Shared style for floating borders.
 * Uses a pseudo element with `border` attribute to prevent both dimension changes due to
 * the border width as well as visible gaps due to the need of a transparent border in LIGHT mode.
 */
export declare const euiBorderStyles: (euiThemeContext: UseEuiTheme, options: {
    side?: BorderSides;
    borderColor?: string;
    borderWidth?: string;
    borderStyle?: string;
}) => string;
