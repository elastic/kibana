import type { UseEuiTheme } from '../../services/theme/types';
import { _EuiThemeShadowSize } from '../variables/shadow';
import { BorderSides } from './borders';
export interface EuiShadowOptions {
    /** @deprecated */
    color?: string;
    /** @default `down` */
    direction?: 'down' | 'up';
    /**
     * Note: not supported by all shadow utilities.
     */
    property?: 'box-shadow' | 'filter';
    borderAllInHighContrastMode?: boolean;
    border?: BorderSides | 'none';
}
/**
 * x-small shadow
 */
export declare const euiShadowXSmall: (euiThemeContext: UseEuiTheme, options?: EuiShadowOptions | undefined) => string;
/**
 * small shadow
 */
export declare const euiShadowSmall: (euiThemeContext: UseEuiTheme, options?: EuiShadowOptions | undefined) => string;
/**
 * medium shadow
 */
export declare const euiShadowMedium: (euiThemeContext: UseEuiTheme, options?: EuiShadowOptions | undefined) => string;
/**
 * large shadow
 */
export declare const euiShadowLarge: (euiThemeContext: UseEuiTheme, options?: EuiShadowOptions | undefined) => string;
/**
 * x-large shadow
 */
export interface EuiShadowXLarge extends EuiShadowOptions {
    reverse?: boolean;
}
export declare const euiShadowXLarge: (euiThemeContext: UseEuiTheme, options?: EuiShadowXLarge | undefined) => string;
/**
 * flat shadow
 * @deprecated - use euiShadowHover instead
 */
export declare const euiSlightShadowHover: (euiThemeContext: UseEuiTheme, options?: EuiShadowOptions | undefined) => string;
/**
 * @deprecated - use euiShadowXSmall instead
 *
 * Similar to shadow medium but without the bottom depth.
 * Useful for popovers that drop UP rather than DOWN.
 */
export declare const euiShadowFlat: (euiThemeContext: UseEuiTheme, options?: EuiShadowOptions | undefined) => string;
export declare const euiShadow: (euiThemeContext: UseEuiTheme, size?: _EuiThemeShadowSize, options?: EuiShadowOptions | undefined) => string;
/** Hover shadows */
export declare const euiShadowHover: (euiThemeContext: UseEuiTheme, size?: _EuiThemeShadowSize | 'base', options?: EuiShadowOptions | undefined) => string;
