import { _EuiThemeVisColors } from '../global_styling';
export declare const VIS_COLOR_STORE_EVENTS: {
    readonly UPDATE: "UPDATE";
};
export declare type VisColorStoreEvents = keyof typeof VIS_COLOR_STORE_EVENTS;
declare type EventId = string;
export declare type _EuiVisColorStore = {
    visColors: _EuiThemeVisColors;
    setVisColors: (colors: _EuiThemeVisColors) => void;
    subscribe: (eventName: VisColorStoreEvents, callback: any) => EventId;
    unsubscribe: (eventName: VisColorStoreEvents, id: EventId) => void;
};
declare class EuiVisColorStoreImpl implements _EuiVisColorStore {
    private _visColors;
    private events;
    constructor(dependencies: {
        defaultColors: _EuiThemeVisColors;
    });
    get visColors(): _EuiVisColorStore['visColors'];
    setVisColors: (colors: _EuiThemeVisColors) => void;
    subscribe: (eventName: VisColorStoreEvents, callback: NonNullable<any>) => string;
    unsubscribe: (eventName: VisColorStoreEvents, id: EventId) => void;
    private publishUpdate;
}
export declare class EuiVisColorStore {
    private static instance;
    static getInstance(defaultColors: _EuiThemeVisColors): EuiVisColorStoreImpl;
}
export {};
