import { TSESTree } from '@typescript-eslint/typescript-estree';
export declare const resolveMemberExpressionRoot: (node: TSESTree.MemberExpression) => TSESTree.Identifier;
//# sourceMappingURL=resolve_member_expression_root.d.ts.map