/**
 * A list of standard HTML tags that are considered **non-interactive** elements.
 *
 * These tags generally do not provide any built-in user interaction
 * (such as click, input, or focus behavior) and are typically used for
 * layout, structure, or content presentation rather than direct
 * interactivity.
 *
 * This constant can be useful when:
 * - Determining whether an element should be treated as interactive.
 * - Enforcing accessibility rules (e.g., ensuring interactive behavior is only applied to proper elements).
 * - Filtering DOM nodes when processing or analyzing HTML structures.
 */
export declare const NON_INTERACTIVE_HTML_TAGS: string[];
/**
 * A list of Elastic UI (EUI) React components that are considered **interactive**.
 *
 * These components are designed to be focusable and respond to user actions
 * such as clicks, keyboard events, or other interactions. Use this constant
 * when you need to determine if a given EUI component is inherently interactive,
 * for example, when enforcing accessibility rules or filtering components
 * for focus management.
 *
 * This list should be kept up to date with EUI's interactive component offerings.
 */
export declare const INTERACTIVE_EUI_COMPONENTS: string[];
/**
 * EUI components that are only interactive when `onClick` or `href` is provided.
 * Without those props they render as a plain non-focusable element (span/div),
 * so rules that need to distinguish unconditionally-interactive components should
 * exclude these.
 */
export declare const CONDITIONALLY_INTERACTIVE_EUI_COMPONENTS: string[];
//# sourceMappingURL=constants.d.ts.map