import { TSESTree } from '@typescript-eslint/utils';
export declare function isInConditionalRendering(node: TSESTree.JSXElement): boolean;
//# sourceMappingURL=is_in_conditional_rendering.d.ts.map