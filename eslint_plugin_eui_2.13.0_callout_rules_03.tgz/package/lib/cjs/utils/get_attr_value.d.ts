import { type TSESTree, type TSESLint } from '@typescript-eslint/utils';
export declare function findAttrValue<TContext extends TSESLint.RuleContext<string, unknown[]>>(context: TContext, attributes: TSESTree.JSXOpeningElement['attributes'], attrName: string): string | undefined;
export declare function extractAttrValue<TContext extends TSESLint.RuleContext<string, unknown[]>>(context: TContext, attr: TSESTree.JSXAttribute | undefined): string | undefined;
//# sourceMappingURL=get_attr_value.d.ts.map