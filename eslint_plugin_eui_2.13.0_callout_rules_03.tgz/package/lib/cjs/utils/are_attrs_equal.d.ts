export declare const areAttrsEqual: (...strings: Array<string | undefined>) => boolean;
//# sourceMappingURL=are_attrs_equal.d.ts.map