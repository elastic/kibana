import { TSESLint } from '@typescript-eslint/utils';
type Option = {
    patterns: string[];
    message: string;
};
export declare const NoRestrictedEuiImports: TSESLint.RuleModule<never, Readonly<Option>[]>;
export {};
//# sourceMappingURL=no_restricted_eui_imports.d.ts.map