import { ESLintUtils } from '@typescript-eslint/utils';
export declare const HrefOnClick: ESLintUtils.RuleModule<"hrefOrOnClick", [], unknown, ESLintUtils.RuleListener>;
//# sourceMappingURL=href_or_on_click.d.ts.map