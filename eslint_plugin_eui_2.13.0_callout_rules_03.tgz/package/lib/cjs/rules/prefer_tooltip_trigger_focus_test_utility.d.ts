import { ESLintUtils } from '@typescript-eslint/utils';
export declare const PreferTooltipTriggerFocusTestUtility: ESLintUtils.RuleModule<"preferTooltipTriggerFocusTestUtility", [], unknown, ESLintUtils.RuleListener>;
//# sourceMappingURL=prefer_tooltip_trigger_focus_test_utility.d.ts.map