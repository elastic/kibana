import { ESLintUtils } from '@typescript-eslint/utils';
export declare const AccessibleInteractiveElements: ESLintUtils.RuleModule<"disallowTabIndex", [], unknown, ESLintUtils.RuleListener>;
//# sourceMappingURL=accessible_interactive_element.d.ts.map