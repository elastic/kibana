import { ESLintUtils } from '@typescript-eslint/utils';
export declare const TooltipButtonIconWrap: ESLintUtils.RuleModule<"useEuiToolTipInsteadOfTitle" | "wrapWithEuiToolTip", [], unknown, ESLintUtils.RuleListener>;
//# sourceMappingURL=tooltip_button_icon_wrap.d.ts.map