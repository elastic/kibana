import { ESLintUtils } from '@typescript-eslint/utils';
export declare const TooltipFocusableAnchor: ESLintUtils.RuleModule<"requiresFocusableAnchor", [], unknown, ESLintUtils.RuleListener>;
//# sourceMappingURL=tooltip_focusable_anchor.d.ts.map