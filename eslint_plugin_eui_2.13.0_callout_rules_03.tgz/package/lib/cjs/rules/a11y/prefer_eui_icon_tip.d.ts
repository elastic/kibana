import { ESLintUtils } from '@typescript-eslint/utils';
export declare const PreferEuiIconTip: ESLintUtils.RuleModule<"preferEuiIconTip", [], unknown, ESLintUtils.RuleListener>;
//# sourceMappingURL=prefer_eui_icon_tip.d.ts.map