import { ESLintUtils } from '@typescript-eslint/utils';
export declare const NoUnnamedRadioGroup: ESLintUtils.RuleModule<"missingRadioName", [], unknown, ESLintUtils.RuleListener>;
//# sourceMappingURL=no_unnamed_radio_group.d.ts.map