import { ESLintUtils } from '@typescript-eslint/utils';
export declare const TooltipNoInteractiveContent: ESLintUtils.RuleModule<"noInteractiveContent", [], unknown, ESLintUtils.RuleListener>;
//# sourceMappingURL=tooltip_no_interactive_content.d.ts.map