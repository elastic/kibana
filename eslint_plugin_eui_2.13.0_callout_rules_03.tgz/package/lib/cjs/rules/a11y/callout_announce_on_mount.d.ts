import { ESLintUtils } from '@typescript-eslint/utils';
export declare const CallOutAnnounceOnMount: ESLintUtils.RuleModule<"missingAnnounceOnMount", [], unknown, ESLintUtils.RuleListener>;
//# sourceMappingURL=callout_announce_on_mount.d.ts.map