import { ESLintUtils } from '@typescript-eslint/utils';
export declare const EuiBadgeAccessibilityRules: ESLintUtils.RuleModule<"sameCallback" | "iconOnClickAriaLabelWithoutIconOnClick" | "onClickAriaLabelWithoutOnClick", [], unknown, ESLintUtils.RuleListener>;
//# sourceMappingURL=badge_accessibility_rules.d.ts.map