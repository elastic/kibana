import { ESLintUtils } from '@typescript-eslint/utils';
export declare const ConsistentIsInvalidProps: ESLintUtils.RuleModule<"inconsistentIsInvalid", [], unknown, ESLintUtils.RuleListener>;
//# sourceMappingURL=consistent_is_invalid_props.d.ts.map