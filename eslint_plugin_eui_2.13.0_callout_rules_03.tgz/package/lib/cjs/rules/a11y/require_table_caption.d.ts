import { ESLintUtils } from '@typescript-eslint/utils';
export declare const RequireTableCaption: ESLintUtils.RuleModule<"missingTableCaption", [], unknown, ESLintUtils.RuleListener>;
//# sourceMappingURL=require_table_caption.d.ts.map