import { ESLintUtils } from '@typescript-eslint/utils';
export declare const ScreenReaderOutputDisabledTooltip: ESLintUtils.RuleModule<"requireDisableScreenReader", [], unknown, ESLintUtils.RuleListener>;
//# sourceMappingURL=sr_output_disabled_tooltip.d.ts.map