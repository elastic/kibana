import { ESLintUtils } from '@typescript-eslint/utils';
export declare const EuiIconAccessibilityRules: ESLintUtils.RuleModule<"missingTitleOrAriaHidden" | "tabIndexWithAriaHidden", [], unknown, ESLintUtils.RuleListener>;
//# sourceMappingURL=icon_accessibility_rules.d.ts.map