import { ESLintUtils } from '@typescript-eslint/utils';
export declare const NoUnnamedInteractiveElement: ESLintUtils.RuleModule<"missingA11y", [], unknown, ESLintUtils.RuleListener>;
//# sourceMappingURL=no_unnamed_interactive_element.d.ts.map