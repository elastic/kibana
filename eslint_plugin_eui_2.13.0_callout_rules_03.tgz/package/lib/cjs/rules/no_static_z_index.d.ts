import { ESLintUtils } from '@typescript-eslint/utils';
export declare const NoStaticZIndex: ESLintUtils.RuleModule<"noStaticZIndex" | "noStaticZIndexSpecific" | "noStaticZIndexSpecificDeclaredVariable", [], unknown, ESLintUtils.RuleListener>;
//# sourceMappingURL=no_static_z_index.d.ts.map