import { ESLintUtils } from '@typescript-eslint/utils';
export declare const CallOutPreferPropsForContent: ESLintUtils.RuleModule<"childrenHavePlainText" | "childrenHaveText" | "childrenHaveActions", [], unknown, ESLintUtils.RuleListener>;
//# sourceMappingURL=callout_prefer_props_for_content.d.ts.map