import { TSESTree } from '@typescript-eslint/typescript-estree';
export declare const resolveMemberExpressionRoot: (node: TSESTree.MemberExpression) => TSESTree.Identifier;
