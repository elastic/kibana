import { TSESTree } from '@typescript-eslint/utils';
export declare function isInConditionalRendering(node: TSESTree.JSXElement): boolean;
