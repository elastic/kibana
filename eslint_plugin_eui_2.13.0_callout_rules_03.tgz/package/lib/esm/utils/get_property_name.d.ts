import { TSESTree } from '@typescript-eslint/utils';
export declare const getPropertyName: (propertyNode: TSESTree.Property | TSESTree.SpreadElement) => string | null;
