import type { TSESTree } from '@typescript-eslint/utils';
/**
 * Checks whether a JSX opening element contains a spread attribute
 * (e.g., `...props`). Spreads make it impossible to statically know
 * all props present on an element, so ESLint rules often use this as
 * a quick bail-out to avoid false positives.
 *
 * @param attrs - The attributes array from a `JSXOpeningElement` node (ESTree).
 * @returns `true` if any attribute is a `JSXSpreadAttribute`; otherwise `false`.
 */
export declare function hasSpread(attrs: TSESTree.JSXOpeningElement['attributes']): boolean;
