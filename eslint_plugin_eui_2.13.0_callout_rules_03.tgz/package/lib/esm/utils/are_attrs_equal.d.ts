export declare const areAttrsEqual: (...strings: Array<string | undefined>) => boolean;
