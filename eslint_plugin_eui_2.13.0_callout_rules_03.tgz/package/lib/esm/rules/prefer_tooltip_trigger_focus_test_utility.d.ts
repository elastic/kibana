import { ESLintUtils } from '@typescript-eslint/utils';
export declare const PreferTooltipTriggerFocusTestUtility: ESLintUtils.RuleModule<"preferTooltipTriggerFocusTestUtility", [], unknown, ESLintUtils.RuleListener>;
