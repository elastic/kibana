import { ESLintUtils } from '@typescript-eslint/utils';
export declare const NoCssColor: ESLintUtils.RuleModule<"noCssColor" | "noCssColorSpecific" | "noCSSColorSpecificDeclaredVariable", [], unknown, ESLintUtils.RuleListener>;
