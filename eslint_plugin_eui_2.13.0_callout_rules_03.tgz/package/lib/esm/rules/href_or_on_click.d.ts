import { ESLintUtils } from '@typescript-eslint/utils';
export declare const HrefOnClick: ESLintUtils.RuleModule<"hrefOrOnClick", [], unknown, ESLintUtils.RuleListener>;
