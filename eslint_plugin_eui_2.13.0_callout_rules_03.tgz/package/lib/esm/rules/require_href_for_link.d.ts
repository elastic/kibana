import { ESLintUtils } from '@typescript-eslint/utils';
export declare const RequireHrefForLink: ESLintUtils.RuleModule<"requireHrefForLink", [], unknown, ESLintUtils.RuleListener>;
