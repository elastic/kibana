import { ESLintUtils } from '@typescript-eslint/utils';
export declare const RequireTableCaption: ESLintUtils.RuleModule<"missingTableCaption", [], unknown, ESLintUtils.RuleListener>;
