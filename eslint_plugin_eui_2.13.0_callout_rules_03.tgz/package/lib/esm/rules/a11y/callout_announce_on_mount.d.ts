import { ESLintUtils } from '@typescript-eslint/utils';
export declare const CallOutAnnounceOnMount: ESLintUtils.RuleModule<"missingAnnounceOnMount", [], unknown, ESLintUtils.RuleListener>;
