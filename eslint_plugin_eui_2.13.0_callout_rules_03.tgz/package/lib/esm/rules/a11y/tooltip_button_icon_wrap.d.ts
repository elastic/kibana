import { ESLintUtils } from '@typescript-eslint/utils';
export declare const TooltipButtonIconWrap: ESLintUtils.RuleModule<"useEuiToolTipInsteadOfTitle" | "wrapWithEuiToolTip", [], unknown, ESLintUtils.RuleListener>;
