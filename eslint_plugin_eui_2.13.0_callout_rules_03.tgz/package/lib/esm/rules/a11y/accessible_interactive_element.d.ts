import { ESLintUtils } from '@typescript-eslint/utils';
export declare const AccessibleInteractiveElements: ESLintUtils.RuleModule<"disallowTabIndex", [], unknown, ESLintUtils.RuleListener>;
