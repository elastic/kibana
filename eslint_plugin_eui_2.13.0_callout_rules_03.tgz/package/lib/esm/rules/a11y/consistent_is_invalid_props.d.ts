import { ESLintUtils } from '@typescript-eslint/utils';
export declare const ConsistentIsInvalidProps: ESLintUtils.RuleModule<"inconsistentIsInvalid", [], unknown, ESLintUtils.RuleListener>;
