import { ESLintUtils } from '@typescript-eslint/utils';
export declare const TooltipNoInteractiveContent: ESLintUtils.RuleModule<"noInteractiveContent", [], unknown, ESLintUtils.RuleListener>;
