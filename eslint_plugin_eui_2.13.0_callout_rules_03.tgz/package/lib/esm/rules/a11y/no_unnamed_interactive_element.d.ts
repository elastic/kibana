import { ESLintUtils } from '@typescript-eslint/utils';
export declare const NoUnnamedInteractiveElement: ESLintUtils.RuleModule<"missingA11y", [], unknown, ESLintUtils.RuleListener>;
