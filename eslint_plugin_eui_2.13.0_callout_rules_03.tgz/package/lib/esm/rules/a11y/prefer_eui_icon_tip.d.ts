import { ESLintUtils } from '@typescript-eslint/utils';
export declare const PreferEuiIconTip: ESLintUtils.RuleModule<"preferEuiIconTip", [], unknown, ESLintUtils.RuleListener>;
