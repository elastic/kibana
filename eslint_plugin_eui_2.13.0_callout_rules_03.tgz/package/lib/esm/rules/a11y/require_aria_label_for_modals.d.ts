import { ESLintUtils } from '@typescript-eslint/utils';
export declare const RequireAriaLabelForModals: ESLintUtils.RuleModule<"modalAriaMissing" | "confirmModalAriaMissing" | "popoverAriaMissing", [], unknown, ESLintUtils.RuleListener>;
