import { ESLintUtils } from '@typescript-eslint/utils';
export declare const CallOutPreferPropsForContent: ESLintUtils.RuleModule<"childrenHavePlainText" | "childrenHaveText" | "childrenHaveActions", [], unknown, ESLintUtils.RuleListener>;
