"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.SIZES = exports.EuiButton = exports.COLORS = void 0;
var _extends2 = _interopRequireDefault(require("@babel/runtime/helpers/extends"));
var _defineProperty2 = _interopRequireDefault(require("@babel/runtime/helpers/defineProperty"));
var _objectWithoutProperties2 = _interopRequireDefault(require("@babel/runtime/helpers/objectWithoutProperties"));
var _react = _interopRequireDefault(require("react"));
var _propTypes = _interopRequireDefault(require("prop-types"));
var _classnames = _interopRequireDefault(require("classnames"));
var _button = require("../../global_styling/mixins/_button");
var _button_display = require("./button_display/_button_display");
var _use_button_common_props = require("./use_button_common_props");
var _react2 = require("@emotion/react");
var _excluded = ["className", "buttonRef", "size", "color", "fill", "isDisabled", "hasAriaDisabled", "fullWidth", "id", "onClick", "isSelected"];
/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { (0, _defineProperty2.default)(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
var COLORS = exports.COLORS = _button.BUTTON_COLORS;
var SIZES = exports.SIZES = ['s', 'm'];

// For some reason, Storybook doesn't parse `EuiButtonDisplayCommonProps` unless we include it here

/**
 * EuiButton is largely responsible for providing relevant props
 * and the logic for element-specific attributes
 * @see {@link https://eui.elastic.co/docs/components/navigation/buttons/button/|EuiButton documentation}
 */
var EuiButton = exports.EuiButton = function EuiButton(_ref) {
  var className = _ref.className,
    buttonRef = _ref.buttonRef,
    _ref$size = _ref.size,
    _size = _ref$size === void 0 ? 'm' : _ref$size,
    _ref$color = _ref.color,
    _color = _ref$color === void 0 ? 'primary' : _ref$color,
    _fill = _ref.fill,
    _isDisabled = _ref.isDisabled,
    _hasAriaDisabled = _ref.hasAriaDisabled,
    _fullWidth = _ref.fullWidth,
    id = _ref.id,
    _onClick = _ref.onClick,
    _isSelected = _ref.isSelected,
    rest = (0, _objectWithoutProperties2.default)(_ref, _excluded);
  var _useEuiButtonCommonPr = (0, _use_button_common_props.useEuiButtonCommonProps)({
      size: _size,
      color: _color,
      isDisabled: _isDisabled,
      hasAriaDisabled: _hasAriaDisabled,
      fullWidth: _fullWidth,
      fill: _fill,
      isSelected: _isSelected,
      href: rest.href,
      disabled: rest.disabled,
      isLoading: rest.isLoading,
      id: id,
      onClick: _onClick
    }),
    size = _useEuiButtonCommonPr.size,
    color = _useEuiButtonCommonPr.color,
    isDisabled = _useEuiButtonCommonPr.isDisabled,
    hasAriaDisabled = _useEuiButtonCommonPr.hasAriaDisabled,
    fullWidth = _useEuiButtonCommonPr.fullWidth,
    fill = _useEuiButtonCommonPr.fill,
    isSelected = _useEuiButtonCommonPr.isSelected,
    onClick = _useEuiButtonCommonPr.onClick;
  var buttonColorStyles = (0, _button.useEuiButtonColorCSS)({
    display: fill ? 'fill' : 'base'
  })[isDisabled ? 'disabled' : color];
  var buttonFocusStyle = (0, _button.useEuiButtonFocusCSS)();
  var classes = (0, _classnames.default)('euiButton', className);
  var cssStyles = [buttonColorStyles, buttonFocusStyle];
  var buttonProps = _objectSpread({
    onClick: onClick
  }, rest);
  var anchorProps = _objectSpread({
    onClick: onClick
  }, rest);
  return (0, _react2.jsx)(_button_display.EuiButtonDisplay, (0, _extends2.default)({
    ref: buttonRef,
    className: classes,
    css: cssStyles,
    size: size,
    isDisabled: isDisabled,
    hasAriaDisabled: hasAriaDisabled,
    fullWidth: fullWidth,
    id: id,
    isSelected: isSelected
  }, rest.href ? anchorProps : buttonProps));
};
EuiButton.propTypes = {
  href: _propTypes.default.string,
  onClick: _propTypes.default.func,
  children: _propTypes.default.node,
  /**
     * Make button a solid color for prominence
     */
  /**
     * Make button a solid color for prominence
     */
  fill: _propTypes.default.bool,
  /**
     * Any of the named color palette options.
     *
     * Do not use the following colors for standalone buttons directly,
     * they exist to serve other components:
     *  - accent
     *  - warning
     *  - neutral
     *  - risk
     */
  color: _propTypes.default.any,
  /**
     * Use size `s` in confined spaces
     */
  /**
     * Use size `s` in confined spaces
     */
  size: _propTypes.default.any,
  /**
     * Controls the disabled behavior via the native `disabled` attribute.
     */
  /**
     * Controls the disabled behavior via the native `disabled` attribute.
     */
  isDisabled: _propTypes.default.oneOfType([_propTypes.default.bool, _propTypes.default.oneOfType([_propTypes.default.bool, _propTypes.default.bool])]),
  /**
     * NOTE: Beta feature, may be changed or removed in the future
     *
     * Changes the native `disabled` attribute to `aria-disabled` to preserve focusability.
     * This results in a semantically disabled button without the default browser handling of the disabled state.
     *
     * Use e.g. when a disabled button should have a tooltip.
     */
  /**
     * NOTE: Beta feature, may be changed or removed in the future
     *
     * Changes the native `disabled` attribute to `aria-disabled` to preserve focusability.
     * This results in a semantically disabled button without the default browser handling of the disabled state.
     *
     * Use e.g. when a disabled button should have a tooltip.
     */
  hasAriaDisabled: _propTypes.default.oneOfType([_propTypes.default.bool, _propTypes.default.oneOfType([_propTypes.default.bool, _propTypes.default.bool])]),
  className: _propTypes.default.oneOfType([_propTypes.default.string, _propTypes.default.oneOfType([_propTypes.default.string, _propTypes.default.string])]),
  "aria-label": _propTypes.default.oneOfType([_propTypes.default.string, _propTypes.default.oneOfType([_propTypes.default.string, _propTypes.default.string])]),
  "data-test-subj": _propTypes.default.oneOfType([_propTypes.default.string, _propTypes.default.oneOfType([_propTypes.default.string, _propTypes.default.string])]),
  css: _propTypes.default.oneOfType([_propTypes.default.any, _propTypes.default.oneOfType([_propTypes.default.any, _propTypes.default.any])]),
  buttonRef: _propTypes.default.any,
  element: _propTypes.default.oneOf(["a", "button", "span"]),
  /**
     * Applies the boolean state as the `aria-pressed` property to create a toggle button.
     * *Only use when the readable text does not change between states.*
     */
  isSelected: _propTypes.default.bool,
  /**
     * Extends the button to 100% width
     */
  fullWidth: _propTypes.default.bool,
  /**
     * Override the default minimum width
     */
  minWidth: _propTypes.default.oneOfType([_propTypes.default.any.isRequired, _propTypes.default.oneOf([false])]),
  /**
     * Force disables the button and changes the icon to a loading spinner
     */
  isLoading: _propTypes.default.bool,
  /**
     * Object of props passed to the <span/> wrapping the button's content
     */
  contentProps: _propTypes.default.shape({
    className: _propTypes.default.string,
    "aria-label": _propTypes.default.string,
    "data-test-subj": _propTypes.default.string,
    css: _propTypes.default.any
  }),
  style: _propTypes.default.any,
  type: _propTypes.default.any
};
EuiButton.displayName = 'EuiButton';