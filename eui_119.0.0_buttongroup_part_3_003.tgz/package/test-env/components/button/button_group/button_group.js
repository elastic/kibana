"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
var _typeof = require("@babel/runtime/helpers/typeof");
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.EuiButtonGroupChildren = exports.EuiButtonGroup = exports.BUTTON_GROUP_GUTTER_SIZES = void 0;
var _defineProperty2 = _interopRequireDefault(require("@babel/runtime/helpers/defineProperty"));
var _extends2 = _interopRequireDefault(require("@babel/runtime/helpers/extends"));
var _objectWithoutProperties2 = _interopRequireDefault(require("@babel/runtime/helpers/objectWithoutProperties"));
var _classnames = _interopRequireDefault(require("classnames"));
var _propTypes = _interopRequireDefault(require("prop-types"));
var _react = _interopRequireWildcard(require("react"));
var _services = require("../../../services");
var _accessibility = require("../../accessibility");
var _button_context = require("../button_context");
var _button_group_button = require("./button_group_button");
var _use_button_group_selection = require("./use_button_group_selection");
var _button_group = require("./button_group.styles");
var _react2 = require("@emotion/react");
var _excluded = ["className", "buttonSize", "color", "idSelected", "idToSelectedMap", "isDisabled", "hasAriaDisabled", "isFullWidth", "isIconOnly", "legend", "name", "onChange", "options", "type"],
  _excluded2 = ["className", "children", "legend", "buttonSize", "variant", "gutterSize", "isDisabled", "hasAriaDisabled", "isFullWidth", "showDividers", "wrap", "layout", "display", "type", "idSelected", "idToSelectedMap", "onChange"];
/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */
// removes outer fragment wrappers only; no nested traversal of children
// uses forEach over .toArray() to avoid mutating keys; only unwraps one Fragment level
function _getRequireWildcardCache(e) { if ("function" != typeof WeakMap) return null; var r = new WeakMap(), t = new WeakMap(); return (_getRequireWildcardCache = function _getRequireWildcardCache(e) { return e ? t : r; })(e); }
function _interopRequireWildcard(e, r) { if (!r && e && e.__esModule) return e; if (null === e || "object" != _typeof(e) && "function" != typeof e) return { default: e }; var t = _getRequireWildcardCache(r); if (t && t.has(e)) return t.get(e); var n = { __proto__: null }, a = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var u in e) if ("default" !== u && {}.hasOwnProperty.call(e, u)) { var i = a ? Object.getOwnPropertyDescriptor(e, u) : null; i && (i.get || i.set) ? Object.defineProperty(n, u, i) : n[u] = e[u]; } return n.default = e, t && t.set(e, n), n; }
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { (0, _defineProperty2.default)(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
function flattenButtonGroupChildren(children) {
  var result = [];
  _react.default.Children.forEach(children, function (child) {
    if (! /*#__PURE__*/_react.default.isValidElement(child)) return;
    if (child.type === _react.default.Fragment) {
      _react.default.Children.forEach(child.props.children, function (fragmentChild) {
        if ( /*#__PURE__*/_react.default.isValidElement(fragmentChild)) result.push(fragmentChild);
      });
    } else {
      result.push(child);
    }
  });
  return result;
}
var EuiButtonGroupOptions = function EuiButtonGroupOptions(_ref) {
  var className = _ref.className,
    _ref$buttonSize = _ref.buttonSize,
    buttonSize = _ref$buttonSize === void 0 ? 's' : _ref$buttonSize,
    _ref$color = _ref.color,
    color = _ref$color === void 0 ? 'text' : _ref$color,
    _ref$idSelected = _ref.idSelected,
    idSelected = _ref$idSelected === void 0 ? '' : _ref$idSelected,
    _ref$idToSelectedMap = _ref.idToSelectedMap,
    idToSelectedMap = _ref$idToSelectedMap === void 0 ? {} : _ref$idToSelectedMap,
    _ref$isDisabled = _ref.isDisabled,
    isDisabled = _ref$isDisabled === void 0 ? false : _ref$isDisabled,
    _ref$hasAriaDisabled = _ref.hasAriaDisabled,
    hasAriaDisabled = _ref$hasAriaDisabled === void 0 ? false : _ref$hasAriaDisabled,
    _ref$isFullWidth = _ref.isFullWidth,
    isFullWidth = _ref$isFullWidth === void 0 ? false : _ref$isFullWidth,
    _ref$isIconOnly = _ref.isIconOnly,
    isIconOnly = _ref$isIconOnly === void 0 ? false : _ref$isIconOnly,
    legend = _ref.legend,
    name = _ref.name,
    onChange = _ref.onChange,
    _ref$options = _ref.options,
    options = _ref$options === void 0 ? [] : _ref$options,
    _ref$type = _ref.type,
    type = _ref$type === void 0 ? 'single' : _ref$type,
    rest = (0, _objectWithoutProperties2.default)(_ref, _excluded);
  var wrapperCssStyles = [_button_group.euiButtonGroupStyles.euiButtonGroup, isFullWidth && _button_group.euiButtonGroupStyles.fullWidth];
  var styles = (0, _services.useEuiMemoizedStyles)(_button_group.euiButtonGroupButtonsStyles);
  var cssStyles = [styles.euiButtonGroup__buttons, isFullWidth && styles.fullWidth, styles.size[buttonSize]];
  var classes = (0, _classnames.default)('euiButtonGroup', {
    'euiButtonGroup-isDisabled': isDisabled
  }, className);
  var typeIsSingle = type === 'single';
  var groupDisabledProps = {
    disabled: hasAriaDisabled ? undefined : isDisabled,
    'aria-disabled': hasAriaDisabled ? isDisabled : undefined
  };
  return (0, _react2.jsx)("fieldset", (0, _extends2.default)({
    css: wrapperCssStyles,
    className: classes
  }, rest, groupDisabledProps), (0, _react2.jsx)(_accessibility.EuiScreenReaderOnly, null, (0, _react2.jsx)("legend", null, legend)), (0, _react2.jsx)("div", {
    css: cssStyles,
    className: "euiButtonGroup__buttons"
  }, options.map(function (option) {
    return (0, _react2.jsx)(_button_group_button.EuiButtonGroupButton, (0, _extends2.default)({
      key: option.id,
      isDisabled: isDisabled,
      hasAriaDisabled: hasAriaDisabled
    }, option, {
      onClick: typeIsSingle ? function () {
        return onChange(option.id, option.value);
      } : function () {
        return onChange(option.id);
      },
      isSelected: typeIsSingle ? option.id === idSelected : idToSelectedMap[option.id],
      color: color,
      size: buttonSize,
      isIconOnly: isIconOnly
    }));
  })));
};
EuiButtonGroupOptions.propTypes = {
  className: _propTypes.default.string,
  "aria-label": _propTypes.default.string,
  "data-test-subj": _propTypes.default.string,
  css: _propTypes.default.any,
  isDisabled: _propTypes.default.bool,
  hasAriaDisabled: _propTypes.default.bool,
  /**
       * Typical sizing is `s`. Medium `m` size should be reserved for major features.
       * `compressed` is meant to be used alongside and within compressed forms.
       */
  buttonSize: _propTypes.default.oneOf(["s", "m", "compressed"]),
  /**
       * Expands the whole group to the full width of the container.
       * Each button gets equal widths no matter the content
       */
  isFullWidth: _propTypes.default.bool,
  /**
       * Hides the label to only show the `iconType` provided by the `option`
       */
  isIconOnly: _propTypes.default.bool,
  /**
       * A hidden group title (required for accessibility)
       */
  legend: _propTypes.default.string.isRequired,
  /**
       * Any of the named color palette options.
       *
       * Do not use the following colors for standalone buttons directly,
       * they exist to serve other components:
       *  - accent
       *  - warning
       */
  color: _propTypes.default.any,
  /**
           * Default for `type` is single so it can also be excluded
           */
  /**
       * Actual type is `'single' | 'multi'`.
       * Determines how the selection of the group should be handled.
       * With `'single'` only one option can be selected at a time (similar to radio group).
       * With `'multi'` multiple options selected (similar to checkbox group).
       */
  type: _propTypes.default.oneOfType([_propTypes.default.oneOfType([_propTypes.default.oneOf(["single", "multi"]), _propTypes.default.oneOf(["single"])]), _propTypes.default.oneOf(["multi"])]),
  /**
       * An array of {@link EuiButtonGroupOptionProps}
       */
  options: _propTypes.default.arrayOf(_propTypes.default.shape({
    /**
       * Each option must have a unique `id` for maintaining selection
       */
    id: _propTypes.default.string.isRequired,
    /**
       * Each option must have a `label` even for icons which will be applied as the `aria-label`
       */
    label: _propTypes.default.node.isRequired,
    /**
       * The value of the radio input.
       */
    value: _propTypes.default.any,
    /**
       * The type of the underlying HTML button
       */
    type: _propTypes.default.any,
    /**
       * By default, will use the button text for the native browser title.
       *
       * This can be either customized or unset via `title: ''` if necessary.
       */
    title: _propTypes.default.any,
    /**
       * Optional custom tooltip content for the button
       */
    toolTipContent: _propTypes.default.node,
    /**
       * Optional props to pass to the underlying **[EuiToolTip](https://eui.elastic.co/docs/components/display/tooltip/)**
       */
    toolTipProps: _propTypes.default.any,
    className: _propTypes.default.string,
    "aria-label": _propTypes.default.string,
    "data-test-subj": _propTypes.default.string,
    css: _propTypes.default.any,
    /**
       * Controls the disabled behavior via the native `disabled` attribute.
       */
    isDisabled: _propTypes.default.bool,
    /**
       * NOTE: Beta feature, may be changed or removed in the future
       *
       * Changes the native `disabled` attribute to `aria-disabled` to preserve focusability.
       * This results in a semantically disabled button without the default browser handling of the disabled state.
       *
       * Use e.g. when a disabled button should have a tooltip.
       */
    hasAriaDisabled: _propTypes.default.bool
  }).isRequired).isRequired,
  /**
           * @deprecated No longer needed. You can safely remove this prop entirely
           */
  name: _propTypes.default.string,
  /**
           * Styles the selected option to look selected (usually with `fill`)
           * Required by and only used in `type='single'`.
           */
  idSelected: _propTypes.default.string,
  /**
           * Multi: Returns the `id` of the clicked option
           */
  /**
           * Single: Returns the `id` of the clicked option and the `value`
           */
  onChange: _propTypes.default.func,
  /**
           * A map of `id`s as keys with the selected boolean values.
           * Required by and only used in `type='multi'`.
           */
  idToSelectedMap: _propTypes.default.shape({})
};
var BUTTON_GROUP_GUTTER_SIZES = exports.BUTTON_GROUP_GUTTER_SIZES = ['none', 'xs', 's', 'm', 'l', 'xl'];
var EuiButtonGroupChildren = exports.EuiButtonGroupChildren = function EuiButtonGroupChildren(_ref2) {
  var className = _ref2.className,
    _children = _ref2.children,
    legend = _ref2.legend,
    _ref2$buttonSize = _ref2.buttonSize,
    buttonSize = _ref2$buttonSize === void 0 ? 's' : _ref2$buttonSize,
    _ref2$variant = _ref2.variant,
    variant = _ref2$variant === void 0 ? 'default' : _ref2$variant,
    _ref2$gutterSize = _ref2.gutterSize,
    gutterSize = _ref2$gutterSize === void 0 ? 's' : _ref2$gutterSize,
    _ref2$isDisabled = _ref2.isDisabled,
    isDisabled = _ref2$isDisabled === void 0 ? false : _ref2$isDisabled,
    _ref2$hasAriaDisabled = _ref2.hasAriaDisabled,
    hasAriaDisabled = _ref2$hasAriaDisabled === void 0 ? false : _ref2$hasAriaDisabled,
    _ref2$isFullWidth = _ref2.isFullWidth,
    isFullWidth = _ref2$isFullWidth === void 0 ? false : _ref2$isFullWidth,
    _ref2$showDividers = _ref2.showDividers,
    showDividers = _ref2$showDividers === void 0 ? false : _ref2$showDividers,
    _ref2$wrap = _ref2.wrap,
    wrap = _ref2$wrap === void 0 ? true : _ref2$wrap,
    _ref2$layout = _ref2.layout,
    layout = _ref2$layout === void 0 ? 'horizontal' : _ref2$layout,
    _ref2$display = _ref2.display,
    display = _ref2$display === void 0 ? 'regular' : _ref2$display,
    type = _ref2.type,
    idSelected = _ref2.idSelected,
    idToSelectedMap = _ref2.idToSelectedMap,
    onChange = _ref2.onChange,
    rest = (0, _objectWithoutProperties2.default)(_ref2, _excluded2);
  var isSegmented = variant === 'segmented';
  var isSelection = variant === 'selection';
  var hasSegmentedStyle = isSegmented || isSelection;
  var hasGutterSize = variant === 'default' && gutterSize !== 'none';
  var _useEuiButtonGroupSel = (0, _use_button_group_selection.useEuiButtonGroupSelection)({
      type: type,
      idSelected: idSelected,
      idToSelectedMap: idToSelectedMap,
      onChange: onChange
    }),
    isSelected = _useEuiButtonGroupSel.isSelected,
    _onSelect = _useEuiButtonGroupSel.onSelect;
  var wrapperCssStyles = [_button_group.euiButtonGroupStyles.euiButtonGroup, isFullWidth && _button_group.euiButtonGroupStyles.fullWidth];
  var styles = (0, _services.useEuiMemoizedStyles)(_button_group.euiButtonGroupButtonsStyles);
  var cssStyles = [styles.euiButtonGroup__buttons, hasGutterSize && styles.gutterSize[gutterSize], hasSegmentedStyle && !wrap && styles.noWrap];
  var containerCssStyles = [styles.euiButtonGroup__container, isFullWidth && layout !== 'vertical' && styles.fullWidth];
  var classes = (0, _classnames.default)('euiButtonGroup', {
    'euiButtonGroup-isDisabled': isDisabled
  }, className);
  var contextValue = (0, _react.useMemo)(function () {
    return _objectSpread(_objectSpread(_objectSpread({
      size: buttonSize,
      isDisabled: isDisabled || undefined,
      hasAriaDisabled: hasAriaDisabled || undefined,
      fullWidth: isFullWidth
    }, (isSegmented || isSelection) && {
      color: 'text'
    }), isSegmented && {
      display: 'base',
      fill: false
    }), isSelection && {
      getSelectionProps: function getSelectionProps(id) {
        var selected = isSelected(id);
        var isInverse = display === 'inverse';
        var hasFill = selected && display === 'highlighted';
        return {
          isSelected: selected,
          fill: isInverse ? false : hasFill,
          display: isInverse ? 'base' : hasFill ? 'fill' : undefined,
          onSelect: function onSelect() {
            return _onSelect(id);
          }
        };
      }
    });
  }, [buttonSize, isDisabled, hasAriaDisabled, isFullWidth, isSegmented, isSelection, isSelected, _onSelect, display]);

  // wrap children in a wrapper to apply required inset styles
  var children = isSegmented || isSelection ? flattenButtonGroupChildren(_children).map(function (child, index) {
    var _child$key;
    return (0, _react2.jsx)("div", {
      key: (_child$key = child.key) !== null && _child$key !== void 0 ? _child$key : "euiButtonGroupItem-".concat(index),
      className: "euiButtonGroup__item"
    }, child);
  }) : _children;
  return (0, _react2.jsx)("div", (0, _extends2.default)({
    css: wrapperCssStyles,
    className: classes,
    role: "group",
    "data-variant": variant,
    "data-size": buttonSize,
    "data-display": isSelection ? display : undefined,
    "data-layout": hasSegmentedStyle ? layout : undefined,
    "data-dividers": hasSegmentedStyle && showDividers || undefined,
    "aria-label": legend,
    "aria-disabled": isDisabled || undefined
  }, rest), (0, _react2.jsx)("div", {
    css: containerCssStyles,
    className: "euiButtonGroup__container"
  }, (0, _react2.jsx)("div", {
    css: cssStyles,
    className: "euiButtonGroup__buttons"
  }, (0, _react2.jsx)(_button_context.EuiButtonContext.Provider, {
    value: contextValue
  }, children))));
};

/* Overloaded call signatures let one `EuiButtonGroup` component support both
the `options` API and the `children` API, each with its own precise prop
type, without adding another union layer. */
EuiButtonGroupChildren.propTypes = {
  className: _propTypes.default.string,
  "aria-label": _propTypes.default.string,
  "data-test-subj": _propTypes.default.string,
  css: _propTypes.default.any,
  isDisabled: _propTypes.default.bool,
  hasAriaDisabled: _propTypes.default.bool,
  // Prevents the `options` API from being used in this mode
  /**
       * A group title (required for accessibility).
       * Rendered as `aria-label` on the group element.
       */
  legend: _propTypes.default.string.isRequired,
  /**
       * Pass button components (`EuiButton`, `EuiButtonEmpty`, `EuiButtonIcon`) as children,
       * some specific wrappers, like `EuiToolTip` and `EuiPopover` are allowed.
       *
       * Do not pass children as combined custom component. Each child needs to be a standalone component.
       */
  children: _propTypes.default.node.isRequired,
  /**
       * Typical sizing is `s`. Medium `m` size should be reserved for major features.
       * @default 's'
       */
  buttonSize: _propTypes.default.oneOf(["s", "m"]),
  /**
       * Defines the type of a button group, which renders visually and functionally different:
       * - default: arranges buttons in a horizontal row with optional gutter via `gutterSize`
       * - segmented: arranges buttons in a horizontal or vertical row with no gutter.
       *   The buttons are placed inset and dividers can optionally be shown between them.
       * - selection: arranges buttons inset with toggle selection state (single or multi).
       *   Each child button must have a unique `id` prop.
       * @default 'default'
       */
  variant: _propTypes.default.oneOf(["default", "segmented", "selection"]),
  /**
       * Defines the gutter size between children buttons.
       * Applies only when `variant="default"`.
       * @default 's'
       */
  gutterSize: _propTypes.default.any,
  /**
       * Expands the whole group to the full width of the container.
       * Only `EuiButton` children will stretch to fill the available space.
       * `EuiButtonIcon` groups will not stretch.
       * Does not apply when `layout="vertical"`.
       * @default false
       */
  isFullWidth: _propTypes.default.bool,
  /**
       * Shows dividers between buttons.
       * Applies only when `variant="segmented"`.
       * @default false
       */
  showDividers: _propTypes.default.bool,
  /**
       * Defines the layout direction of the button group.
       * `layout="vertical"` should only be used with EuiButtonIcon children.
       * Applies only when `variant="segmented"`.
       * @default 'horizontal'
       */
  layout: _propTypes.default.oneOf(["horizontal", "vertical"]),
  /**
       * Defines if buttons wrap or shrink.
       * Applies only when `variant="segmented"`.
       * @default true
       */
  wrap: _propTypes.default.bool,
  /**
           * Determines selection behavior.
           * With `'multi'` multiple buttons can be selected simultaneously.
           * Applies only when `variant="selection"`.
           */
  /**
           * Determines selection behavior.
           * With `'single'` only one button can be selected at a time.
           * Applies only when `variant="selection"`.
           * @default 'single'
           */
  type: _propTypes.default.oneOfType([_propTypes.default.oneOf(["single"]), _propTypes.default.oneOf(["multi"])]),
  /**
           * The currently selected button `id`.
           * Omit or pass `undefined` for no initial selection.
           * Applies only when `variant="selection"` and `type="single"`.
           */
  idSelected: _propTypes.default.string,
  /**
     * Visual display variant for the selection container background.
     * Applies only when `variant="selection"`.
     * - `'regular'`: subdued toggle state, light container background
     * - `'highlighted'`: highlighted toggle state, light container background
     * - `'inverse'`: light toggle state, dark container background
     * @default 'regular'
     */
  /**
     * Visual display variant for the selection container background.
     * Applies only when `variant="selection"`.
     * - `'regular'`: subdued toggle state, light container background
     * - `'highlighted'`: highlighted toggle state, light container background
     * - `'inverse'`: light toggle state, dark container background
     * @default 'regular'
     */
  display: _propTypes.default.oneOf(["regular", "highlighted", "inverse"]),
  /**
     * Callback fired when a child button is selected.
     * Returns the `id` of the clicked option.
     * Applies only when `variant="selection"`.
     */
  /**
     * Callback fired when a child button is selected.
     * Returns the `id` of the clicked option.
     * Applies only when `variant="selection"`.
     */
  onChange: _propTypes.default.func,
  /**
           * A map of button `id`s to their selected boolean values.
           * Omit or pass `{}` for no initial selection.
           * The consumer must update this value via `onChange` to reflect new selections.
           * Applies only when `variant="selection"` and `type="multi"`.
           */
  idToSelectedMap: _propTypes.default.any
};
// Renders either the (legacy) `options` API or the `children` API depending on which props are provided.
var EuiButtonGroup = exports.EuiButtonGroup = function EuiButtonGroup(props) {
  var options = props.options;
  if (options) {
    return (0, _react2.jsx)(EuiButtonGroupOptions, props);
  }
  return (0, _react2.jsx)(EuiButtonGroupChildren, props);
};