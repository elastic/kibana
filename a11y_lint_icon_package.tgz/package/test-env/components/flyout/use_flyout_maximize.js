"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.useEuiFlyoutMaximize = exports.resolveFlyoutWidth = exports.getIsManagedFlyoutMaximized = exports.getIsManagedChildFlyout = exports.getFlyoutPixelWidth = void 0;
var _slicedToArray2 = _interopRequireDefault(require("@babel/runtime/helpers/slicedToArray"));
var _react = require("react");
var _const = require("./manager/const");
var _layout_mode = require("./manager/layout_mode");
/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */

/**
 * Whether a flyout is a managed child, read from its own store entry. A
 * flyout's level never changes, unlike which session is in the foreground.
 * @internal
 */
var getIsManagedChildFlyout = exports.getIsManagedChildFlyout = function getIsManagedChildFlyout(managerState, flyoutId) {
  var _managerState$flyouts;
  return (managerState === null || managerState === void 0 || (_managerState$flyouts = managerState.flyouts.find(function (f) {
    return f.flyoutId === flyoutId;
  })) === null || _managerState$flyouts === void 0 ? void 0 : _managerState$flyouts.level) === _const.LEVEL_CHILD;
};

/**
 * Whether a managed flyout is maximized. Both the managed wrapper and the
 * flyout component read this so they agree on the same render. Only main
 * flyouts can be maximized.
 * @internal
 */
var getIsManagedFlyoutMaximized = exports.getIsManagedFlyoutMaximized = function getIsManagedFlyoutMaximized(flyoutMenuProps, managerState, flyoutId) {
  if (!(flyoutMenuProps !== null && flyoutMenuProps !== void 0 && flyoutMenuProps.showMaximizeButton)) return false;
  var flyout = managerState === null || managerState === void 0 ? void 0 : managerState.flyouts.find(function (f) {
    return f.flyoutId === flyoutId;
  });
  return !!(flyout !== null && flyout !== void 0 && flyout.maximized) && flyout.level !== _const.LEVEL_CHILD;
};

/**
 * @internal
 */

/**
 * Holds the maximized state for a flyout. Unmanaged flyouts keep it in local
 * state; managed flyouts keep it in their manager store entry so the managed
 * wrapper and the layout mode see the same value.
 * @internal
 */
var useEuiFlyoutMaximize = exports.useEuiFlyoutMaximize = function useEuiFlyoutMaximize(_ref) {
  var enabled = _ref.enabled,
    flyoutId = _ref.flyoutId,
    isInManagedContext = _ref.isInManagedContext,
    isChildFlyout = _ref.isChildFlyout,
    maximized = _ref.maximized,
    setMaximized = _ref.setMaximized,
    onMaximizeChange = _ref.onMaximizeChange;
  var _useState = (0, _react.useState)(false),
    _useState2 = (0, _slicedToArray2.default)(_useState, 2),
    localMaximized = _useState2[0],
    setLocalMaximized = _useState2[1];
  var isMaximized = isInManagedContext ? !!maximized : enabled && localMaximized;
  var canMaximize = enabled && !isChildFlyout;

  // Turning the button back on starts from the restored state
  (0, _react.useEffect)(function () {
    if (!enabled) setLocalMaximized(false);
  }, [enabled]);
  var toggleMaximize = (0, _react.useCallback)(function () {
    if (isInManagedContext) {
      setMaximized === null || setMaximized === void 0 || setMaximized(flyoutId, !isMaximized);
    } else {
      setLocalMaximized(!isMaximized);
    }
  }, [isInManagedContext, setMaximized, flyoutId, isMaximized]);

  // The flag can change without a click (through the store API, or when
  // `showMaximizeButton` is turned off), so the callback follows the flag.
  var onMaximizeChangeRef = (0, _react.useRef)(onMaximizeChange);
  (0, _react.useEffect)(function () {
    onMaximizeChangeRef.current = onMaximizeChange;
  }, [onMaximizeChange]);
  var prevIsMaximizedRef = (0, _react.useRef)(isMaximized);
  (0, _react.useEffect)(function () {
    var _onMaximizeChangeRef$;
    if (prevIsMaximizedRef.current === isMaximized) return;
    prevIsMaximizedRef.current = isMaximized;
    (_onMaximizeChangeRef$ = onMaximizeChangeRef.current) === null || _onMaximizeChangeRef$ === void 0 || _onMaximizeChangeRef$.call(onMaximizeChangeRef, isMaximized);
  }, [isMaximized]);
  return {
    isMaximized: isMaximized,
    canMaximize: canMaximize,
    toggleMaximize: toggleMaximize
  };
};

/**
 * @internal
 */

/**
 * Resolves the width used for push padding. While maximized, the measured
 * width is the full container, so the last restored width stands in for it.
 * The first measurement after restoring is treated the same way because the
 * resize observer has not yet seen the restored layout. A missing measurement
 * (the observer is detached) drops the hold so a stale width never persists.
 * @internal
 */
var resolveFlyoutWidth = exports.resolveFlyoutWidth = function resolveFlyoutWidth(hold, isMaximized, width) {
  var _hold$trusted;
  if (!width) return {
    hold: {},
    width: width
  };
  if (isMaximized) {
    return {
      hold: {
        trusted: hold.trusted,
        held: width
      },
      width: hold.trusted
    };
  }
  if (width === hold.held) return {
    hold: hold,
    width: (_hold$trusted = hold.trusted) !== null && _hold$trusted !== void 0 ? _hold$trusted : width
  };
  return {
    hold: {
      trusted: width
    },
    width: width
  };
};

/**
 * Estimates the pixel width a flyout paints for a resolved `size`: a number
 * of pixels, a percentage of `referenceWidth` from the resize hook, or a named
 * size. A `fill` flyout leaves room for a side-by-side sibling. Used to update
 * the manager store before paint, so it can be corrected by the next resize
 * observer measurement.
 * @internal
 */
var getFlyoutPixelWidth = exports.getFlyoutPixelWidth = function getFlyoutPixelWidth(size, referenceWidth) {
  var siblingFlyoutWidth = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : 0;
  if (typeof size === 'number') return size;
  if (size.endsWith('%')) {
    return Math.round(referenceWidth * parseFloat(size) / 100);
  }
  var width = (0, _layout_mode.getWidthFromSize)(size, referenceWidth);
  return size === 'fill' ? Math.max(0, width - siblingFlyoutWidth) : width;
};