"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.EuiColorPickerSwatch = void 0;
var _extends2 = _interopRequireDefault(require("@babel/runtime/helpers/extends"));
var _defineProperty2 = _interopRequireDefault(require("@babel/runtime/helpers/defineProperty"));
var _objectWithoutProperties2 = _interopRequireDefault(require("@babel/runtime/helpers/objectWithoutProperties"));
var _react = _interopRequireWildcard(require("react"));
var _propTypes = _interopRequireDefault(require("prop-types"));
var _classnames = _interopRequireDefault(require("classnames"));
var _services = require("../../services");
var _i18n = require("../i18n");
var _utils = require("./utils");
var _color_picker_swatch = require("./color_picker_swatch.styles");
var _tool_tip = require("../tool_tip");
var _react2 = require("@emotion/react");
var _excluded = ["className", "color", "style", "toolTipProps", "showToolTip"];
/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */
var cache;
function _interopRequireWildcard(e, t) { if (!t && e && e.__esModule) return e; var r, c, a = Object.defineProperty, n = { __proto__: null, default: e }; if (Object(e) !== e) return n; if (cache || "function" != typeof WeakMap || (cache = new WeakMap()), cache) { if (cache.has(e)) return cache.get(e); cache.set(e, n); } for (c in e) "default" !== c && {}.hasOwnProperty.call(e, c) && ((r = a && Object.getOwnPropertyDescriptor(e, c)) && (r.get || r.set) ? a(n, c, r) : n[c] = e[c]); return n; }
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { (0, _defineProperty2.default)(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
var EuiColorPickerSwatch = exports.EuiColorPickerSwatch = /*#__PURE__*/(0, _react.forwardRef)(function (_ref, ref) {
  var _toolTipProps$anchorP;
  var className = _ref.className,
    color = _ref.color,
    style = _ref.style,
    toolTipProps = _ref.toolTipProps,
    _ref$showToolTip = _ref.showToolTip,
    showToolTip = _ref$showToolTip === void 0 ? true : _ref$showToolTip,
    rest = (0, _objectWithoutProperties2.default)(_ref, _excluded);
  var classes = (0, _classnames.default)('euiColorPickerSwatch', className);
  var styles = (0, _services.useEuiMemoizedStyles)(_color_picker_swatch.euiColorPickerSwatchStyles);
  var chromaColor = (0, _react.useMemo)(function () {
    return (0, _utils.getChromaColor)(color, true);
  }, [color]);
  var background = (0, _react.useMemo)(function () {
    return chromaColor ? chromaColor.css() : 'transparent';
  }, [chromaColor]);
  var ariaLabel = (0, _i18n.useEuiI18n)('euiColorPickerSwatch.ariaLabel', 'Select {color} as the color', {
    color: color
  });
  var element = (0, _react2.jsx)("button", (0, _extends2.default)({
    type: "button",
    css: styles.euiColorPickerSwatch,
    className: classes,
    "aria-label": ariaLabel,
    ref: ref,
    style: _objectSpread({
      background: background
    }, style)
  }, rest));
  return showToolTip ? (0, _react2.jsx)(_tool_tip.EuiToolTip, (0, _extends2.default)({
    content: color
  }, toolTipProps, {
    anchorProps: _objectSpread(_objectSpread({}, toolTipProps === null || toolTipProps === void 0 ? void 0 : toolTipProps.anchorProps), {}, {
      css: [toolTipProps === null || toolTipProps === void 0 || (_toolTipProps$anchorP = toolTipProps.anchorProps) === null || _toolTipProps$anchorP === void 0 ? void 0 : _toolTipProps$anchorP.css, styles.tooltip]
    })
    // since the button already has a descriptive `ariaLabel` we can disable
    // the tooltip content from being read additionally by screen readers
    ,
    disableScreenReaderOutput: true
  }), element) : element;
});
EuiColorPickerSwatch.propTypes = {
  className: _propTypes.default.string,
  "aria-label": _propTypes.default.string,
  "data-test-subj": _propTypes.default.string,
  css: _propTypes.default.any,
  color: _propTypes.default.string,
  /**
       * renders a tooltip with the color value to provide a visual text alternative
       * @default true
       */
  showToolTip: _propTypes.default.bool,
  /** Additional props for the EuiToolTip when `showToolTip={true}` */toolTipProps: _propTypes.default.shape({
    /**
       * Passes onto the span wrapping the trigger.
       */
    anchorClassName: _propTypes.default.string,
    /**
       * Passes onto the span wrapping the trigger.
       */
    anchorProps: _propTypes.default.shape({
      className: _propTypes.default.string,
      "aria-label": _propTypes.default.string,
      "data-test-subj": _propTypes.default.string,
      css: _propTypes.default.any
    }),
    /**
       * Passes onto the tooltip itself, not the trigger.
       */
    className: _propTypes.default.string,
    /**
       * The main content of your tooltip.
       */
    content: _propTypes.default.node,
    /**
       * Common display alternatives for the anchor wrapper
       */
    display: _propTypes.default.any,
    /**
       * An optional title for your tooltip.
       */
    title: _propTypes.default.node,
    /**
       * Unless you provide one, this will be randomly generated.
       */
    id: _propTypes.default.string,
    /**
       * When `true`, the tooltip's position is re-calculated when the user
       * scrolls. This supports having fixed-position tooltip anchors.
       *
       * When nesting an `EuiTooltip` in a scrollable container, `repositionOnScroll` should be `true`
       */
    repositionOnScroll: _propTypes.default.bool,
    /**
       * Disables the tooltip content being read by screen readers when focusing the trigger element.
       * Do not use when the trigger `aria-label` and tooltip `content` can be rephrased to be standalone
       * information (action & additional information).
       * Enable this prop only when the trigger has a descriptive label that either duplicates or includes
       * the tooltip content and would result in repetitive output.
       * @default false
       */
    disableScreenReaderOutput: _propTypes.default.bool,
    /**
       * If supplied, called when mouse movement causes the tool tip to be
       * hidden.
       */
    onMouseOut: _propTypes.default.func,
    /**
       * If supplied, called when the trigger loses focus.
       */
    onBlur: _propTypes.default.func,
    /**
       * Offset in pixels from the anchor. Defaults to 16.
       */
    offset: _propTypes.default.number,
    "aria-label": _propTypes.default.string,
    "data-test-subj": _propTypes.default.string,
    css: _propTypes.default.any,
    position: _propTypes.default.any
  })
};
EuiColorPickerSwatch.displayName = 'EuiColorPickerSwatch';