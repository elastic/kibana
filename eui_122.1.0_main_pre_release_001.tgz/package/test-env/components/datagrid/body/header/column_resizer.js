"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
var _typeof = require("@babel/runtime/helpers/typeof");
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.EuiDataGridColumnResizer = void 0;
var _slicedToArray2 = _interopRequireDefault(require("@babel/runtime/helpers/slicedToArray"));
var _react = _interopRequireWildcard(require("react"));
var _propTypes = _interopRequireDefault(require("prop-types"));
var _services = require("../../../../services");
var _global_styling = require("../../../../global_styling");
var _draggable_columns = require("./draggable_columns");
var _column_resizer = require("./column_resizer.styles");
var _react2 = require("@emotion/react");
function _getRequireWildcardCache(e) { if ("function" != typeof WeakMap) return null; var r = new WeakMap(), t = new WeakMap(); return (_getRequireWildcardCache = function _getRequireWildcardCache(e) { return e ? t : r; })(e); }
function _interopRequireWildcard(e, r) { if (!r && e && e.__esModule) return e; if (null === e || "object" != _typeof(e) && "function" != typeof e) return { default: e }; var t = _getRequireWildcardCache(r); if (t && t.has(e)) return t.get(e); var n = { __proto__: null }, a = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var u in e) if ("default" !== u && {}.hasOwnProperty.call(e, u)) { var i = a ? Object.getOwnPropertyDescriptor(e, u) : null; i && (i.get || i.set) ? Object.defineProperty(n, u, i) : n[u] = e[u]; } return n.default = e, t && t.set(e, n), n; }
/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */

var MINIMUM_COLUMN_WIDTH = 40;
var EuiDataGridColumnResizer = exports.EuiDataGridColumnResizer = function EuiDataGridColumnResizer(_ref) {
  var columnId = _ref.columnId,
    columnWidth = _ref.columnWidth,
    setColumnWidth = _ref.setColumnWidth,
    isLastColumn = _ref.isLastColumn;
  var styles = (0, _services.useEuiMemoizedStyles)(_column_resizer.euiDataGridColumnResizerStyles);
  var _useState = (0, _react.useState)(0),
    _useState2 = (0, _slicedToArray2.default)(_useState, 2),
    offset = _useState2[0],
    setOffset = _useState2[1];
  var initialX = (0, _react.useRef)(0);

  // Handlers are bound to `window`, so they must stay stable to be removed
  // and read current values from a ref
  var latest = (0, _services.useLatest)({
    columnId: columnId,
    columnWidth: columnWidth,
    setColumnWidth: setColumnWidth,
    offset: offset
  });
  var onMouseMove = (0, _react.useCallback)(function (e) {
    var _ref2 = latest.current,
      columnWidth = _ref2.columnWidth;
    setOffset(Math.max(e.pageX - initialX.current, -(columnWidth - MINIMUM_COLUMN_WIDTH)));
  }, [latest]);
  var onMouseUp = (0, _react.useCallback)(function () {
    var _ref3 = latest.current,
      columnId = _ref3.columnId,
      columnWidth = _ref3.columnWidth,
      setColumnWidth = _ref3.setColumnWidth,
      offset = _ref3.offset;
    setColumnWidth(columnId, Math.max(MINIMUM_COLUMN_WIDTH, columnWidth + offset));
    setOffset(0);
    window.removeEventListener('mouseup', onMouseUp);
    window.removeEventListener('blur', onMouseUp);
    window.removeEventListener('mousemove', onMouseMove);
  }, [latest, onMouseMove]);
  var onMouseDown = (0, _react.useCallback)(function (e) {
    initialX.current = e.pageX;
    window.addEventListener('mouseup', onMouseUp);
    window.addEventListener('blur', onMouseUp);
    window.addEventListener('mousemove', onMouseMove);

    // don't let this action steal focus
    e.preventDefault();
  }, [onMouseUp, onMouseMove]);

  // Clean up listeners if unmounted mid-drag
  (0, _react.useEffect)(function () {
    return function () {
      window.removeEventListener('mouseup', onMouseUp);
      window.removeEventListener('blur', onMouseUp);
      window.removeEventListener('mousemove', onMouseMove);
    };
  }, [onMouseUp, onMouseMove]);
  var cssStyles = [styles.euiDataGridColumnResizer, isLastColumn && styles.isLastColumn, offset && styles.isDragging];
  return (0, _react2.jsx)("div", {
    css: cssStyles,
    className: "euiDataGridColumnResizer",
    "data-test-subj": "dataGridColumnResizer",
    style: offset ? (0, _global_styling.logicalStyle)('margin-right', "".concat(-offset, "px")) : undefined,
    onMouseDown: onMouseDown
  }, (0, _react2.jsx)(_draggable_columns.DragOverlay, {
    isDragging: !!offset,
    cursor: "ew-resize"
  }));
};
EuiDataGridColumnResizer.propTypes = {
  columnId: _propTypes.default.string.isRequired,
  columnWidth: _propTypes.default.number.isRequired,
  setColumnWidth: _propTypes.default.func.isRequired,
  isLastColumn: _propTypes.default.bool.isRequired
};