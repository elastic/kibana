import { _EuiThemeVisColors } from '../global_styling';
export declare type EuiPalette = string[];
export declare type EuiPaletteCommonProps = {
    /**
     * Defines the default set of colors the palette uses.
     * Defaults to vis colors from `EUI_VIS_COLOR_STORE`.
     * Use this to specify colors when you can't rely on the EuiProvider updates.
     */
    colors?: _EuiThemeVisColors;
};
export declare type EuiPaletteRotationProps = {
    /**
     * How many variations of the series is needed
     */
    rotations?: number;
    /**
     * Order similar colors as `group`s or just `append` each variation
     */
    order?: 'append' | 'group';
    /**
     * Specifies if the direction of the color variations
     */
    direction?: 'lighter' | 'darker' | 'both';
    /**
     * Use the default sort order, or re-sort them based on the color wheel (natural)
     */
    sortBy?: 'default' | 'natural';
    /**
     * Shift the sorting order by a certain number when used in conjunction with `'natural'` `sortBy`.
     * Defaults to a number close to green.
     */
    sortShift?: string;
};
export declare type EuiPaletteColorBlindProps = EuiPaletteCommonProps & EuiPaletteRotationProps;
/**
 * For usage in React use the `useEuiPaletteColorBlind` hook instead.
 *
 * NOTE: These functions rely on base vis colors of the theme which are provided via a global
 * singleton instance `EUI_VIS_COLOR_STORE` that's updated by the EuiProvider on theme change.
 * Make sure the function is recalled on theme change to retrieve theme-related colors.
 *
 * Outside of a react component you can use the `subscibe()` method on the `EUI_VIS_COLOR_STORE`
 * to subscribe to updates and update your usages to ensure latest colors are loaded.
 */
export declare const euiPaletteColorBlind: ({ rotations, order, direction, sortBy, sortShift, colors, }?: EuiPaletteColorBlindProps) => EuiPalette;
/**
 * For usage in React use the `useEuiPaletteColorBlindBehindText` hook instead.
 *
 * Color blind palette with text is meant for use when text is applied on top of the color.
 * It increases the brightness of the color to give the text more contrast.
 *
 * NOTE: This function is not pure. It relies on `EUI_VIS_COLOR_STORE` which is updated by the
 * EuiProvider on theme change. Ensure to recall the function on theme change or subscribe to the store.
 */
export declare const euiPaletteColorBlindBehindText: (paletteProps?: EuiPaletteColorBlindProps) => EuiPalette;
/**
 * For usage in React use the `useEuiPaletteForStatus` hook instead.
 *
 * NOTE: This function is not pure. It relies on `EUI_VIS_COLOR_STORE` which is updated by the
 * EuiProvider on theme change. Ensure to recall the function on theme change or subscribe to the store.
 */
export declare const euiPaletteForStatus: (steps: number, { colors }?: EuiPaletteCommonProps) => EuiPalette;
/**
 * For usage in React use the `useEuiPaletteForTemperature` hook instead.
 *
 * NOTE: This function is not pure. It relies on `EUI_VIS_COLOR_STORE` which is updated by the
 * EuiProvider on theme change. Ensure to recall the function on theme change or subscribe to the store.
 */
export declare const euiPaletteForTemperature: (steps: any, { colors }?: EuiPaletteCommonProps) => EuiPalette;
/**
 * For usage in React use the `useEuiPaletteComplementary` hook instead.
 *
 * NOTE: This function is not pure. It relies on `EUI_VIS_COLOR_STORE` which is updated by the
 * EuiProvider on theme change. Ensure to recall the function on theme change or subscribe to the store.
 */
export declare const euiPaletteComplementary: (steps: number, { colors }?: EuiPaletteCommonProps) => EuiPalette;
/**
 * For usage in React use the `useEuiPaletteRed` hook instead.
 *
 * NOTE: This function is not pure. It relies on `EUI_VIS_COLOR_STORE` which is updated by the
 * EuiProvider on theme change. Ensure to recall the function on theme change or subscribe to the store.
 */
export declare const euiPaletteRed: (steps: number, { colors }?: EuiPaletteCommonProps) => EuiPalette;
/**
 * For usage in React use the `useEuiPaletteGreen` hook instead.
 *
 * NOTE: This function is not pure. It relies on `EUI_VIS_COLOR_STORE` which is updated by the
 * EuiProvider on theme change. Ensure to recall the function on theme change or subscribe to the store.
 */
export declare const euiPaletteGreen: (steps: number, { colors }?: EuiPaletteCommonProps) => EuiPalette;
/**
 * For usage in React use the `useEuiPaletteSkyBlue` hook instead.
 *
 * NOTE: This function is not pure. It relies on `EUI_VIS_COLOR_STORE` which is updated by the
 * EuiProvider on theme change. Ensure to recall the function on theme change or subscribe to the store.
 */
export declare const euiPaletteSkyBlue: (steps: number, { colors }?: EuiPaletteCommonProps) => EuiPalette;
/**
 * For usage in React use the `useEuiPaletteYellow` hook instead.
 *
 * NOTE: This function is not pure. It relies on `EUI_VIS_COLOR_STORE` which is updated by the
 * EuiProvider on theme change. Ensure to recall the function on theme change or subscribe to the store.
 */
export declare const euiPaletteYellow: (steps: number, { colors }?: EuiPaletteCommonProps) => EuiPalette;
/**
 * For usage in React use the `useEuiPaletteOrange` hook instead.
 *
 * NOTE: This function is not pure. It relies on `EUI_VIS_COLOR_STORE` which is updated by the
 * EuiProvider on theme change. Ensure to recall the function on theme change or subscribe to the store.
 */
export declare const euiPaletteOrange: (steps: number, { colors }?: EuiPaletteCommonProps) => EuiPalette;
/**
 * For usage in React use the `useEuiPaletteCool` hook instead.
 *
 * NOTE: This function is not pure. It relies on `EUI_VIS_COLOR_STORE` which is updated by the
 * EuiProvider on theme change. Ensure to recall the function on theme change or subscribe to the store.
 */
export declare const euiPaletteCool: (steps: number, { colors }?: EuiPaletteCommonProps) => EuiPalette;
/**
 * For usage in React use the `useEuiPaletteWarm` hook instead.
 *
 * NOTE: This function is not pure. It relies on `EUI_VIS_COLOR_STORE` which is updated by the
 * EuiProvider on theme change. Ensure to recall the function on theme change or subscribe to the store.
 */
export declare const euiPaletteWarm: (steps: number, { colors }?: EuiPaletteCommonProps) => EuiPalette;
/**
 * For usage in React use the `useEuiPaletteGray` hook instead.
 *
 * NOTE: This function is not pure. It relies on `EUI_VIS_COLOR_STORE` which is updated by the
 * EuiProvider on theme change. Ensure to recall the function on theme change or subscribe to the store.
 */
export declare const euiPaletteGray: (steps: number, { colors }?: EuiPaletteCommonProps) => EuiPalette;
