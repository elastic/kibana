export declare const MID_COLOR_STOP = "#EBEFF5";
/**
 * This function takes an array of colors and returns an array of interpolated
 * colors based on the number of steps/len needed for use in UI elements such as charts.
 * Derived from https://github.com/gka/palettes (Unlicensed)
 */
export declare function colorPalette(
/**
 * The main color code or array of codes
 */
colors: string[], 
/**
 * The number of colors in the resulting array (default 10)
 */
len?: number, 
/**
 * Forces color interpolation to be calculated separately for each half (default false)
 */
diverging?: boolean, 
/**
 * Uses a more static interpolation for non-continuous spectrums
 */
categorical?: boolean): string[];
