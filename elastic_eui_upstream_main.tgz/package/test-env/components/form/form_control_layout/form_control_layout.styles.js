"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.textSelector = exports.euiFormControlLayoutStyles = exports.euiFormControlLayoutSideNodeStyles = exports.buttonSelector = exports.appendPrependSelector = void 0;
var _react = require("@emotion/react");
var _global_styling = require("../../../global_styling");
var _form = require("../form.styles");
function _EMOTION_STRINGIFIED_CSS_ERROR__() { return "You have tried to stringify object returned from `css` function. It isn't supposed to be used directly (e.g. as value of the `className` prop), but rather handed to emotion so it can handle it (e.g. as value of `css` prop)."; } /*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */
var buttonSelector = exports.buttonSelector = '*:is(.euiButton, .euiButtonEmpty, .euiButtonIcon, .euiFormAppend, .euiFormPrepend)';
var emptyButtonSelector = '*:is(.euiButtonEmpty, .euiButtonIcon:not([class*="fill"]))';
var textSelector = exports.textSelector = '*:is(.euiFormLabel, .euiText)';
var appendPrependSelector = exports.appendPrependSelector = '*:is(.euiFormAppend, .euiFormPrepend)';
var _ref = process.env.NODE_ENV === "production" ? {
  name: "1iumk9q-euiFormControlLayout__childrenWrapper",
  styles: "position:relative;border-radius:inherit;label:euiFormControlLayout__childrenWrapper;"
} : {
  name: "1iumk9q-euiFormControlLayout__childrenWrapper",
  styles: "position:relative;border-radius:inherit;label:euiFormControlLayout__childrenWrapper;",
  toString: _EMOTION_STRINGIFIED_CSS_ERROR__
};
var _ref2 = process.env.NODE_ENV === "production" ? {
  name: "12dhv84-euiFormControlLayout",
  styles: "position:relative;z-index:0;label:euiFormControlLayout;"
} : {
  name: "12dhv84-euiFormControlLayout",
  styles: "position:relative;z-index:0;label:euiFormControlLayout;",
  toString: _EMOTION_STRINGIFIED_CSS_ERROR__
};
var euiFormControlLayoutStyles = exports.euiFormControlLayoutStyles = function euiFormControlLayoutStyles(euiThemeContext) {
  var euiTheme = euiThemeContext.euiTheme,
    highContrastMode = euiThemeContext.highContrastMode;
  var form = (0, _form.euiFormVariables)(euiThemeContext);
  return {
    euiFormControlLayout: _ref2,
    // Skip the css`` on the default height to avoid generating a className
    uncompressed: "\n      ".concat((0, _global_styling.logicalCSS)('height', form.controlHeight), "\n    "),
    compressed: /*#__PURE__*/(0, _react.css)((0, _global_styling.logicalCSS)('height', form.controlCompressedHeight), ";;label:compressed;"),
    // Skip the css`` on the default width to avoid generating a className
    formWidth: "\n      ".concat((0, _global_styling.logicalCSS)('max-width', form.maxWidth), "\n      ").concat((0, _global_styling.logicalCSS)('width', '100%'), "\n    "),
    fullWidth: /*#__PURE__*/(0, _react.css)((0, _global_styling.logicalCSS)('max-width', '100%'), " ", (0, _global_styling.logicalCSS)('width', '100%'), ";;label:fullWidth;"),
    group: {
      group: /*#__PURE__*/(0, _react.css)("position:relative;display:flex;align-items:stretch;border:none;background-color:", form.backgroundColor, ";overflow:hidden;&::after{content:'';position:absolute;inset:0;z-index:0;border:", euiTheme.border.width.thin, " solid ", form.borderColor, ";border-radius:inherit;pointer-events:none;}&:where(:not(:has(*:is(", _global_styling.euiDisabledSelector, "), [readOnly])):hover){&::after{border:", highContrastMode ? euiTheme.border.width.thick : euiTheme.border.width.thin, " solid ", highContrastMode ? form.borderColor : form.borderHovered, ";}}&:has(:autofill){background:", form.backgroundAutoFilled, ";&:not(:hover)::after{border-color:", form.borderAutofilled, ";}*:-webkit-autofill,*:autofill{--euiFormControlStateAutofillColor:", form.backgroundAutoFilled, ";background-clip:content-box;&:hover,&:focus{--euiFormControlStateAutofillColor:", form.backgroundAutoFilled, ";}}}.euiFilterGroup{border-radius:0;", (0, _global_styling.logicalCSS)('padding-right', euiTheme.border.width.thin), " &::after{display:none;}}.euiFilterButton__wrapper:first-of-type::before,.euiFilterButton__wrapper::after{display:none;}>*{", (0, _global_styling.logicalCSS)('height', '100%'), ";};label:group;"),
      // Skipping css`` to avoid repeated compressed/uncompressed classNames
      uncompressed: "\n        border-radius: ".concat(form.controlBorderRadius, ";\n      "),
      compressed: "\n        border-radius: ".concat(form.controlCompressedBorderRadius, ";\n      ")
    },
    children: {
      euiFormControlLayout__childrenWrapper: _ref,
      inGroup: /*#__PURE__*/(0, _react.css)("flex-grow:1;overflow:hidden;--euiFormControlStateColor:transparent;--euiFormControlStateHoverColor:transparent;.euiFormControlButton{box-shadow:none;", (0, _global_styling.highContrastModeStyles)(euiThemeContext, {
        none: 'box-shadow: none;',
        preferred: 'border: none;'
      }), ";};label:inGroup;")
    }
  };
};
var euiFormControlLayoutSideNodeStyles = exports.euiFormControlLayoutSideNodeStyles = function euiFormControlLayoutSideNodeStyles(euiThemeContext) {
  var euiTheme = euiThemeContext.euiTheme;
  var form = (0, _form.euiFormVariables)(euiThemeContext);
  var buttonSizes = (0, _global_styling.euiButtonSizeMap)(euiThemeContext);
  var uncompressedHeight = (0, _global_styling.mathWithUnits)([form.controlHeight, euiTheme.size.s], function (x, y) {
    return x - y;
  });
  var compressedHeight = (0, _global_styling.mathWithUnits)([form.controlCompressedHeight, euiTheme.size.s], function (x, y) {
    return x - y;
  });
  var buttons = buttonSelector;
  var text = textSelector;
  var appendPrepend = appendPrependSelector;
  var _buttonPadding = function _buttonPadding(size) {
    return (0, _global_styling.logicalCSS)('padding-horizontal', buttonSizes[size].padding);
  };
  var dividerStyles = function dividerStyles(side, compressed) {
    return "\n      position: relative;\n      ".concat("margin-inline-".concat(side), ": -", euiTheme.border.width.thin, ";\n\n      &::before {\n        content: '';\n        position: absolute;\n        inset-inline-").concat(side, ": 0;\n        z-index: ").concat(side === 'end' ? 1 : 0, ";\n        block-size: ").concat(compressed ? euiTheme.size.base : euiTheme.size.l, ";\n        inline-size: ").concat(euiTheme.border.width.thin, ";\n        pointer-events: none;\n        border-inline-").concat(side, ": \n          ").concat(euiTheme.border.width.thin, " solid ").concat(form.borderColor, ";\n      }\n    ");
  };
  return {
    euiFormControlLayout__side: /*#__PURE__*/(0, _react.css)((0, _global_styling.logicalCSS)('height', '100%'), " ", (0, _global_styling.euiTextTruncate)('50%'), " flex-shrink:0;display:flex;align-items:center;gap:", euiTheme.size.s, ";padding:", euiTheme.size.xs, ";", buttons, "{block-size:100%;border-radius:", form.controlLayoutInnerBorderRadius, ";transform:none!important;&:focus-visible{z-index:1;outline-offset:", euiTheme.focus.width, ";}}", text, "{cursor:default;overflow:hidden;text-overflow:ellipsis;}&:where(:has(", buttons, ":focus-visible):has(> *:only-child)){*:not(", appendPrepend, "){outline:none;}&::after{", (0, _form.euiFormControlFocusStyles)(euiThemeContext), " content:'';position:absolute;inset:0;border-radius:", form.controlLayoutBorderRadius, ";pointer-events:none;}}:where(:not(:has(:disabled))) label{color:", form.labelColor, ";};label:euiFormControlLayout__side;"),
    uncompressed: {
      uncompressed: "\n        &:not(:has(> ".concat(buttons, ":first-child, > *:first-child ").concat(buttons, ")) {\n          ").concat((0, _global_styling.logicalCSS)('padding-left', euiTheme.size.s), "\n        }\n\n        &:not(:has(> ").concat(buttons, ":last-child, > *:last-child ").concat(buttons, ")) {\n          ").concat((0, _global_styling.logicalCSS)('padding-right', euiTheme.size.s), "\n        }\n\n        ").concat(text, " {\n          line-height: ").concat(uncompressedHeight, ";\n\n          &:first-child {\n            ").concat((0, _global_styling.logicalCSS)('padding-left', euiTheme.size.xs), "\n          }\n\n          &:last-child {\n            ").concat((0, _global_styling.logicalCSS)('padding-right', euiTheme.size.xs), "\n          }\n        }\n\n        ").concat(buttons, " {\n          ").concat((0, _global_styling.logicalCSS)('height', uncompressedHeight), "\n          ").concat(_buttonPadding('s'), "\n        }\n\n        .euiButtonIcon {\n          flex-shrink: 0;\n          ").concat((0, _global_styling.logicalCSS)('width', uncompressedHeight), "\n        }\n      "),
      append: "\n       ".concat(dividerStyles('start'), "\n      "),
      prepend: "\n        ".concat(dividerStyles('end'), "\n      ")
    },
    compressed: {
      compressed: /*#__PURE__*/(0, _react.css)("&:not(:has(", appendPrepend, ")):not(\n            :has(> ", buttons, ":first-child, > *:first-child ", buttons, ")\n          ){", (0, _global_styling.logicalCSS)('padding-left', euiTheme.size.s), ";}&:not(:has(", appendPrepend, ")):not(\n            :has(> ", buttons, ":last-child, > *:last-child ", buttons, ")\n          ){", (0, _global_styling.logicalCSS)('padding-right', euiTheme.size.s), ";}", text, "{line-height:", compressedHeight, ";&:first-child{", (0, _global_styling.logicalCSS)('padding-left', euiTheme.size.xxs), ";}&:last-child{", (0, _global_styling.logicalCSS)('padding-right', euiTheme.size.xxs), ";}}", buttons, "{", (0, _global_styling.logicalCSS)('height', compressedHeight), " &:where(:not(.euiButtonIcon)){", _buttonPadding('xs'), ";}}.euiButtonIcon{flex-shrink:0;", (0, _global_styling.logicalCSS)('width', compressedHeight), ";};label:compressed;"),
      append: "\n       ".concat(dividerStyles('start', true), "\n      "),
      prepend: "\n        ".concat(dividerStyles('end', true), "\n      ")
    },
    disabled: /*#__PURE__*/(0, _react.css)("background-color:", form.backgroundDisabledColor, ";&:where(:not(:has(", appendPrepend, ", ", buttonSelector, ")))>*,&:where(:not(:has(", appendPrepend, "))) .euiFormLabel{color:", form.textColorDisabled, ";}", emptyButtonSelector, ":not(\n          ", _global_styling.euiDisabledSelector, "\n        ){background-color:", form.backgroundColor, ";};label:disabled;"),
    readOnly: /*#__PURE__*/(0, _react.css)("background-color:", form.backgroundDisabledColor, ";", emptyButtonSelector, ":not(\n          ", _global_styling.euiDisabledSelector, "\n        ){background-color:", form.backgroundColor, ";};label:readOnly;")
  };
};