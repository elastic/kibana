"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.EuiFormControlLayoutClearButton = void 0;
var _extends2 = _interopRequireDefault(require("@babel/runtime/helpers/extends"));
var _objectWithoutProperties2 = _interopRequireDefault(require("@babel/runtime/helpers/objectWithoutProperties"));
var _react = _interopRequireDefault(require("react"));
var _propTypes = _interopRequireDefault(require("prop-types"));
var _classnames = _interopRequireDefault(require("classnames"));
var _services = require("../../../services");
var _icon = require("../../icon");
var _i18n = require("../../i18n");
var _form_control_layout_clear_button = require("./form_control_layout_clear_button.styles");
var _react2 = require("@emotion/react");
var _excluded = ["className", "onClick", "size"];
/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */
var EuiFormControlLayoutClearButton = exports.EuiFormControlLayoutClearButton = function EuiFormControlLayoutClearButton(_ref) {
  var className = _ref.className,
    onClick = _ref.onClick,
    _ref$size = _ref.size,
    size = _ref$size === void 0 ? 'm' : _ref$size,
    rest = (0, _objectWithoutProperties2.default)(_ref, _excluded);
  var classes = (0, _classnames.default)('euiFormControlLayoutClearButton', className);
  var styles = (0, _services.useEuiMemoizedStyles)(_form_control_layout_clear_button.EuiFormControlLayoutClearButtonStyles);
  var cssStyles = [styles.euiFormControlLayoutClearButton, styles.size[size]];
  var iconStyles = [styles.icon.euiFormControlLayoutClearButton__icon, styles.icon.size[size]];
  var ariaLabel = (0, _i18n.useEuiI18n)('euiFormControlLayoutClearButton.label', 'Clear input');
  return (0, _react2.jsx)("button", (0, _extends2.default)({
    type: "button",
    css: cssStyles,
    className: classes,
    onClick: onClick,
    "aria-label": ariaLabel
  }, rest), (0, _react2.jsx)(_icon.EuiIcon, {
    css: iconStyles,
    className: "euiFormControlLayoutClearButton__icon",
    type: "cross",
    size: size
  }));
};
EuiFormControlLayoutClearButton.propTypes = {
  className: _propTypes.default.string,
  "aria-label": _propTypes.default.string,
  "data-test-subj": _propTypes.default.string,
  css: _propTypes.default.any,
  size: _propTypes.default.oneOf(["s", "m"])
};