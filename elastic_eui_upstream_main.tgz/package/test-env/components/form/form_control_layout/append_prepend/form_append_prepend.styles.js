"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.euiFormAppendPrependStyles = void 0;
var _react = require("@emotion/react");
var _global_styling = require("../../../../global_styling");
var _form_control_layout = require("../form_control_layout.styles");
var _form = require("../../form.styles");
/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */

var euiFormAppendPrependStyles = exports.euiFormAppendPrependStyles = function euiFormAppendPrependStyles(euiThemeContext) {
  var euiTheme = euiThemeContext.euiTheme;
  var form = (0, _form.euiFormVariables)(euiThemeContext);
  var appendPrepend = _form_control_layout.appendPrependSelector;
  var buttons = _form_control_layout.buttonSelector;
  var text = _form_control_layout.textSelector;
  var buttonStyles = (0, _global_styling.euiButtonDisplaysColors)(euiThemeContext);
  return {
    side: /*#__PURE__*/(0, _react.css)("position:relative;display:flex;align-items:center;gap:", euiTheme.size.s, ";block-size:100%;max-inline-size:100%;border-radius:", form.controlLayoutInnerBorderRadius, ";&:focus-visible{outline:none;};label:side;"),
    uncompressed: /*#__PURE__*/(0, _react.css)("&:not(:has(> ", buttons, ":first-child, > *:first-child ", buttons, ")){", (0, _global_styling.logicalCSS)('padding-left', euiTheme.size.s), ";}&:not(:has(> ", buttons, ":last-child, > *:last-child ", buttons, ")){", (0, _global_styling.logicalCSS)('padding-right', euiTheme.size.s), ";};label:uncompressed;"),
    compressed: /*#__PURE__*/(0, _react.css)("&:not(:has(> ", buttons, ":first-child, > *:first-child ", buttons, ")){", (0, _global_styling.logicalCSS)('padding-left', euiTheme.size.xs), ";}&:not(:has(> ", buttons, ":last-child, > *:last-child ", buttons, ")){", (0, _global_styling.logicalCSS)('padding-right', euiTheme.size.xs), ";};label:compressed;"),
    wrapper: /*#__PURE__*/(0, _react.css)("position:relative;max-inline-size:100%;&:has(", appendPrepend, ":focus-visible){&::after{", (0, _form.euiFormControlFocusStyles)(euiThemeContext), " content:'';position:absolute;inset:-", euiTheme.size.xs, ";border-radius:", form.controlLayoutBorderRadius, ";pointer-events:none;}};label:wrapper;"),
    isInteractive: /*#__PURE__*/(0, _react.css)(buttonStyles.empty.primary, ";background-color:", form.backgroundColor, ";*{cursor:pointer;}", text, "{color:currentColor;cursor:pointer;};label:isInteractive;"),
    disabled: /*#__PURE__*/(0, _react.css)("color:", form.textColorDisabled, ";.euiFormLabel,.euiNotificationBadge{color:", form.textColorDisabled, ";};label:disabled;")
  };
};