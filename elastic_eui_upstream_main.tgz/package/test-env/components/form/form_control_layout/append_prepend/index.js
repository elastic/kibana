"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "EuiFormAppend", {
  enumerable: true,
  get: function get() {
    return _form_append_prepend.EuiFormAppend;
  }
});
Object.defineProperty(exports, "EuiFormPrepend", {
  enumerable: true,
  get: function get() {
    return _form_append_prepend.EuiFormPrepend;
  }
});
var _form_append_prepend = require("./form_append_prepend");