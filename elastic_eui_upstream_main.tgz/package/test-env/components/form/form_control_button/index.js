"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "EuiFormControlButton", {
  enumerable: true,
  get: function get() {
    return _form_control_button.EuiFormControlButton;
  }
});
var _form_control_button = require("./form_control_button");