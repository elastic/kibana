import { type _EuiThemeShadows, type _EuiThemeShadowPrimitives } from '@elastic/eui-theme-common';
/**
 * This structure holds "primitives" (or actual design tokens as they
 * would be stored in a design token repository).
 * Not exposing them in the theme object is intentional.
 */
export declare const shadowPrimitives: _EuiThemeShadowPrimitives;
export declare const shadows: _EuiThemeShadows;
