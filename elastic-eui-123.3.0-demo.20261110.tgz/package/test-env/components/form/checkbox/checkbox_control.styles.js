"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.euiCheckboxControlStyles = void 0;
var _react = require("@emotion/react");
var _global_styling = require("../../../global_styling");
var _form = require("../form.styles");
function _EMOTION_STRINGIFIED_CSS_ERROR__() { return "You have tried to stringify object returned from `css` function. It isn't supposed to be used directly (e.g. as value of the `className` prop), but rather handed to emotion so it can handle it (e.g. as value of `css` prop)."; } /*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */
var _ref = process.env.NODE_ENV === "production" ? {
  name: "u54glv-indeterminate",
  styles: "transform:scale(0.5);label:indeterminate;"
} : {
  name: "u54glv-indeterminate",
  styles: "transform:scale(0.5);label:indeterminate;",
  toString: _EMOTION_STRINGIFIED_CSS_ERROR__
};
var euiCheckboxControlStyles = exports.euiCheckboxControlStyles = function euiCheckboxControlStyles(euiThemeContext) {
  var euiTheme = euiThemeContext.euiTheme;
  var controlStyles = (0, _form.euiFormCustomControlStyles)(euiThemeContext);
  var _euiFormCustomControl = (0, _form.euiFormCustomControlVariables)(euiThemeContext),
    _euiFormCustomControl2 = _euiFormCustomControl.colors,
    selected = _euiFormCustomControl2.selected,
    selectedIcon = _euiFormCustomControl2.selectedIcon,
    unselected = _euiFormCustomControl2.unselected;

  // POC: motion study suggested fast; using normal so the fill and stroke read more clearly.
  var speed = euiTheme.animation.normal;
  var ease = euiTheme.animation.resistance;
  return {
    euiCheckboxControl: /*#__PURE__*/(0, _react.css)(controlStyles.input.fauxInput, " border-radius:", euiTheme.border.radius.inline, ";&::before{content:'';position:absolute;inset:calc(-1 * ", euiTheme.border.width.thin, ");background:", selected, ";border-radius:inherit;transform:scale(0);pointer-events:none;}", _global_styling.euiCanAnimate, "{transition-property:background-color,color,border-color;transition-duration:", speed, ";transition-timing-function:", ease, ";&::before{transition:transform ", speed, " ", ease, ";}.euiCheckbox__stroke path{transition:stroke-dashoffset calc(", speed, " * 0.5) ", ease, ";}}&.euiCheckboxControl-isChecked{", _global_styling.euiCanAnimate, "{.euiCheckbox__stroke path{transition:stroke-dashoffset calc(", speed, " * 1.5) ", ease, " calc(", speed, " * 0.4);}}};label:euiCheckboxControl;"),
    enabled: {
      selected: /*#__PURE__*/(0, _react.css)(controlStyles.input.enabled.selected, " &::before{content:none;};label:selected;"),
      unselected: /*#__PURE__*/(0, _react.css)(controlStyles.input.enabled.unselected, ";label:unselected;"),
      checked: /*#__PURE__*/(0, _react.css)("color:", selectedIcon, ";background-color:", unselected, ";border-color:", selected, ";&::before{transform:scale(1);}.euiCheckbox__stroke path{stroke-dashoffset:0;};label:checked;"),
      excluded: /*#__PURE__*/(0, _react.css)(controlStyles.input.enabled.selected, " background-color:", euiTheme.colors.backgroundFilledDanger, ";border-color:", euiTheme.colors.backgroundFilledDanger, ";&::before{content:none;};label:excluded;")
    },
    disabled: {
      selected: /*#__PURE__*/(0, _react.css)(controlStyles.input.disabled.selected, " &::before{content:none;};label:selected;"),
      unselected: /*#__PURE__*/(0, _react.css)(controlStyles.input.disabled.unselected, " &::before{content:none;};label:unselected;")
    },
    // POC: pen-stroke check from the motion study. The filled check icon cannot draw.
    stroke: /*#__PURE__*/(0, _react.css)("position:absolute;inset:0;width:100%;height:100%;pointer-events:none;path{fill:none;stroke:", selectedIcon, ";stroke-width:1.7;stroke-linecap:round;stroke-linejoin:round;stroke-dasharray:1;stroke-dashoffset:1;};label:stroke;"),
    icon: {
      euiCheckbox__icon: /*#__PURE__*/(0, _react.css)(";label:euiCheckbox__icon;"),
      check: /*#__PURE__*/(0, _react.css)(controlStyles.input.icon, " stroke:currentColor;;label:check;"),
      indeterminate: _ref
    }
  };
};