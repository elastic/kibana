"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.useButtonGroupSelectionTravel = exports.useButtonGroupHoverHighlight = void 0;
var _toConsumableArray2 = _interopRequireDefault(require("@babel/runtime/helpers/toConsumableArray"));
var _defineProperty2 = _interopRequireDefault(require("@babel/runtime/helpers/defineProperty"));
var _slicedToArray2 = _interopRequireDefault(require("@babel/runtime/helpers/slicedToArray"));
var _react = require("react");
var _services = require("../../../services");
var _global_styling = require("../../../global_styling");
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { (0, _defineProperty2.default)(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; } /*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */
var BUTTON_SELECTOR = '.euiButton, .euiButtonIcon, .euiButtonGroupButton';
var FINE_POINTER_QUERY = '(hover: hover) and (pointer: fine)';
var REDUCED_MOTION_QUERY = '(prefers-reduced-motion: reduce)';
var HIDDEN_HIGHLIGHT = {
  x: 0,
  y: 0,
  width: 0,
  height: 0,
  radius: 0,
  visible: false,
  animate: false
};
var measureButton = function measureButton(container, button) {
  var containerBox = container.getBoundingClientRect();
  var buttonBox = button.getBoundingClientRect();
  var radius = parseFloat(window.getComputedStyle(button).borderTopLeftRadius) || 0;
  return {
    x: buttonBox.left - containerBox.left - container.clientLeft + container.scrollLeft,
    y: buttonBox.top - containerBox.top - container.clientTop + container.scrollTop,
    width: buttonBox.width,
    height: buttonBox.height,
    radius: radius
  };
};
var hoverHighlightAllowed = function hoverHighlightAllowed() {
  return typeof window !== 'undefined' && window.matchMedia(FINE_POINTER_QUERY).matches && !window.matchMedia(REDUCED_MOTION_QUERY).matches;
};

/**
 * Slides one hover highlight across a button group.
 * Measures only when the button under the pointer changes.
 */
var useButtonGroupHoverHighlight = exports.useButtonGroupHoverHighlight = function useButtonGroupHoverHighlight(enabled) {
  var containerRef = (0, _react.useRef)(null);
  var buttonRef = (0, _react.useRef)(null);
  var _useState = (0, _react.useState)(HIDDEN_HIGHLIGHT),
    _useState2 = (0, _slicedToArray2.default)(_useState, 2),
    highlight = _useState2[0],
    setHighlight = _useState2[1];
  var place = (0, _react.useCallback)(function (button, animate) {
    var container = containerRef.current;
    if (!container) return;
    setHighlight(_objectSpread(_objectSpread({}, measureButton(container, button)), {}, {
      visible: true,
      animate: animate
    }));
  }, []);
  var hide = (0, _react.useCallback)(function () {
    buttonRef.current = null;
    setHighlight(function (current) {
      return current.visible ? _objectSpread(_objectSpread({}, current), {}, {
        visible: false,
        animate: true
      }) : current;
    });
  }, []);
  var onPointerOver = (0, _react.useCallback)(function (event) {
    if (!enabled || !hoverHighlightAllowed()) return;
    var target = event.target;
    if (!(target instanceof Element)) return;
    var button = target.closest(BUTTON_SELECTOR);
    var container = containerRef.current;
    if (!(button instanceof HTMLElement) || !(container !== null && container !== void 0 && container.contains(button))) {
      return;
    }
    if (button.matches(_global_styling.euiDisabledSelector)) {
      hide();
      return;
    }
    if (button === buttonRef.current) return;
    var animate = buttonRef.current !== null;
    buttonRef.current = button;
    place(button, animate);
  }, [enabled, hide, place]);
  var onPointerLeave = (0, _react.useCallback)(function () {
    if (!enabled) return;
    hide();
  }, [enabled, hide]);
  (0, _react.useEffect)(function () {
    if (!highlight.visible || highlight.animate) return;
    var frame = window.requestAnimationFrame(function () {
      setHighlight(function (current) {
        return current.visible ? _objectSpread(_objectSpread({}, current), {}, {
          animate: true
        }) : current;
      });
    });
    return function () {
      return window.cancelAnimationFrame(frame);
    };
  }, [highlight.visible, highlight.animate]);
  (0, _react.useEffect)(function () {
    if (!highlight.visible) return;
    var container = containerRef.current;
    var button = buttonRef.current;
    if (!container || !button || typeof ResizeObserver === 'undefined') return;
    var observer = new ResizeObserver(function () {
      var current = buttonRef.current;
      var container = containerRef.current;
      if (!current || !container) return;
      var box = measureButton(container, current);
      setHighlight(function (highlight) {
        return highlight.visible ? _objectSpread(_objectSpread({}, highlight), box) : highlight;
      });
    });
    observer.observe(container);
    return function () {
      return observer.disconnect();
    };
  }, [highlight.visible, place]);
  return {
    containerRef: containerRef,
    highlight: highlight,
    onPointerOver: onPointerOver,
    onPointerLeave: onPointerLeave
  };
};
var buttonSelectionId = function buttonSelectionId(button, index) {
  return button.id || button.getAttribute('data-test-subj') || "selected-".concat(index);
};
var pillCenter = function pillCenter(pill) {
  return {
    x: pill.x + pill.width / 2,
    y: pill.y + pill.height / 2
  };
};
var nearestPill = function nearestPill(target, pills) {
  var targetCenter = pillCenter(target);
  return pills.reduce(function (nearest, pill) {
    if (!nearest) return pill;
    var candidate = pillCenter(pill);
    var current = pillCenter(nearest);
    var candidateDistance = Math.pow(candidate.x - targetCenter.x, 2) + Math.pow(candidate.y - targetCenter.y, 2);
    var currentDistance = Math.pow(current.x - targetCenter.x, 2) + Math.pow(current.y - targetCenter.y, 2);
    return candidateDistance < currentDistance ? pill : nearest;
  }, undefined);
};

/**
 * Selected pills sit on the pressed buttons. A new selection travels from the
 * nearest selected pill. The first placement does not travel. Hover is not involved.
 */
var useButtonGroupSelectionTravel = exports.useButtonGroupSelectionTravel = function useButtonGroupSelectionTravel(enabled, selectionKey) {
  var _useEuiTheme = (0, _services.useEuiTheme)(),
    euiTheme = _useEuiTheme.euiTheme;
  var hideAfter = Math.round(parseFloat(euiTheme.animation.slow));
  var containerRef = (0, _react.useRef)(null);
  var placed = (0, _react.useRef)(false);
  var pillsRef = (0, _react.useRef)([]);
  var _useState3 = (0, _react.useState)([]),
    _useState4 = (0, _slicedToArray2.default)(_useState3, 2),
    pills = _useState4[0],
    setPills = _useState4[1];
  var commit = (0, _react.useCallback)(function (next) {
    pillsRef.current = next;
    setPills(next);
  }, []);
  (0, _react.useLayoutEffect)(function () {
    if (!enabled) {
      placed.current = false;
      commit([]);
      return;
    }
    var container = containerRef.current;
    if (!container) return;
    var previous = pillsRef.current.filter(function (pill) {
      return pill.visible;
    });
    var buttons = (0, _toConsumableArray2.default)(container.querySelectorAll('[aria-pressed="true"]'));
    if (!buttons.length) {
      placed.current = false;
      commit(previous.map(function (pill) {
        return _objectSpread(_objectSpread({}, pill), {}, {
          visible: false,
          animate: true
        });
      }));
      return;
    }
    var next = buttons.map(function (button, index) {
      return _objectSpread(_objectSpread({
        id: buttonSelectionId(button, index)
      }, measureButton(container, button)), {}, {
        visible: true,
        animate: false
      });
    });
    var nextIds = new Set(next.map(function (pill) {
      return pill.id;
    }));
    var previousById = new Map(previous.map(function (pill) {
      return [pill.id, pill];
    }));
    var staying = previous.filter(function (pill) {
      return nextIds.has(pill.id);
    });
    var added = next.filter(function (pill) {
      return !previousById.has(pill.id);
    });
    var removed = previous.filter(function (pill) {
      return !nextIds.has(pill.id);
    });
    var isFirst = !placed.current;
    var anchors = staying.length ? staying : previous;
    var replacesSingleSelection = added.length === 1 && removed.length === 1 && next.length === 1;
    var placedNext = next.map(function (pill) {
      if (isFirst || previousById.has(pill.id)) {
        return _objectSpread(_objectSpread({}, pill), {}, {
          animate: !isFirst
        });
      }
      var origin = nearestPill(pill, anchors);
      if (!origin) return pill;
      return _objectSpread(_objectSpread({}, pill), {}, {
        x: origin.x,
        y: origin.y,
        width: origin.width,
        height: origin.height,
        radius: origin.radius,
        animate: true
      });
    });
    var fading = replacesSingleSelection ? [] : removed.map(function (pill) {
      return _objectSpread(_objectSpread({}, pill), {}, {
        visible: false,
        animate: true
      });
    });
    var frame = placedNext.some(function (pill, index) {
      var target = next[index];
      return pill.x !== target.x || pill.y !== target.y || pill.width !== target.width || pill.height !== target.height;
    }) ? window.requestAnimationFrame(function () {
      commit([].concat((0, _toConsumableArray2.default)(next.map(function (pill) {
        return _objectSpread(_objectSpread({}, pill), {}, {
          animate: true
        });
      })), (0, _toConsumableArray2.default)(pillsRef.current.filter(function (pill) {
        return !pill.visible;
      }))));
    }) : undefined;
    commit([].concat((0, _toConsumableArray2.default)(placedNext), (0, _toConsumableArray2.default)(fading)));
    placed.current = true;
    return function () {
      if (frame) window.cancelAnimationFrame(frame);
    };
  }, [commit, enabled, selectionKey]);
  (0, _react.useEffect)(function () {
    if (!pills.some(function (pill) {
      return pill.visible && !pill.animate;
    })) return;
    var frame = window.requestAnimationFrame(function () {
      setPills(function (current) {
        var next = current.map(function (pill) {
          return pill.visible ? _objectSpread(_objectSpread({}, pill), {}, {
            animate: true
          }) : pill;
        });
        pillsRef.current = next;
        return next;
      });
    });
    return function () {
      return window.cancelAnimationFrame(frame);
    };
  }, [pills]);
  (0, _react.useEffect)(function () {
    if (!pills.some(function (pill) {
      return !pill.visible;
    })) return;
    var timeout = window.setTimeout(function () {
      setPills(function (current) {
        var next = current.filter(function (pill) {
          return pill.visible;
        });
        pillsRef.current = next;
        return next;
      });
    }, hideAfter);
    return function () {
      return window.clearTimeout(timeout);
    };
  }, [hideAfter, pills]);
  (0, _react.useEffect)(function () {
    if (!enabled) return;
    var container = containerRef.current;
    if (!container || typeof ResizeObserver === 'undefined') return;
    var observer = new ResizeObserver(function () {
      var host = containerRef.current;
      if (!host) return;
      var boxes = new Map((0, _toConsumableArray2.default)(host.querySelectorAll('[aria-pressed="true"]')).map(function (button, index) {
        return [buttonSelectionId(button, index), measureButton(host, button)];
      }));
      setPills(function (current) {
        var changed = false;
        var next = current.map(function (pill) {
          var box = boxes.get(pill.id);
          if (!pill.visible || !box) return pill;
          if (pill.x === box.x && pill.y === box.y && pill.width === box.width && pill.height === box.height && pill.radius === box.radius) {
            return pill;
          }
          changed = true;
          return _objectSpread(_objectSpread({}, pill), box);
        });
        if (!changed) return current;
        pillsRef.current = next;
        return next;
      });
    });
    observer.observe(container);
    return function () {
      return observer.disconnect();
    };
  }, [enabled]);
  return {
    containerRef: containerRef,
    pills: pills
  };
};