"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.euiAccordionArrowStyles = void 0;
var _react = require("@emotion/react");
var _global_styling = require("../../../global_styling");
function _EMOTION_STRINGIFIED_CSS_ERROR__() { return "You have tried to stringify object returned from `css` function. It isn't supposed to be used directly (e.g. as value of the `className` prop), but rather handed to emotion so it can handle it (e.g. as value of `css` prop)."; } /*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */
var _ref = process.env.NODE_ENV === "production" ? {
  name: "w8mqzq-isOpen",
  styles: ".euiButtonIcon__icon{transform:rotate(90deg);opacity:1;};label:isOpen;"
} : {
  name: "w8mqzq-isOpen",
  styles: ".euiButtonIcon__icon{transform:rotate(90deg);opacity:1;};label:isOpen;",
  toString: _EMOTION_STRINGIFIED_CSS_ERROR__
};
var _ref2 = process.env.NODE_ENV === "production" ? {
  name: "zmuis1-isClosed",
  styles: ".euiButtonIcon__icon{transform:rotate(0deg);opacity:0.7;};label:isClosed;"
} : {
  name: "zmuis1-isClosed",
  styles: ".euiButtonIcon__icon{transform:rotate(0deg);opacity:0.7;};label:isClosed;",
  toString: _EMOTION_STRINGIFIED_CSS_ERROR__
};
var euiAccordionArrowStyles = exports.euiAccordionArrowStyles = function euiAccordionArrowStyles(_ref3) {
  var euiTheme = _ref3.euiTheme;
  return {
    euiAccordion__arrow: /*#__PURE__*/(0, _react.css)("flex-shrink:0;.euiButtonIcon__icon{inline-size:5px;block-size:6px;", _global_styling.euiCanAnimate, "{transition:transform ", euiTheme.animation.normal, " ", euiTheme.animation.resistance, ",opacity ", euiTheme.animation.normal, " ", euiTheme.animation.resistance, ";}};label:euiAccordion__arrow;"),
    left: /*#__PURE__*/(0, _react.css)((0, _global_styling.logicalCSS)('margin-right', euiTheme.size.xs), ";;label:left;"),
    right: /*#__PURE__*/(0, _react.css)((0, _global_styling.logicalCSS)('margin-left', euiTheme.size.xs), ";;label:right;"),
    // POC: closed opacity 0.7 is from the motion study, not a theme token.
    isClosed: _ref2,
    isOpen: _ref
  };
};