"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
var _typeof = require("@babel/runtime/helpers/typeof");
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.useCopy = void 0;
var _slicedToArray2 = _interopRequireDefault(require("@babel/runtime/helpers/slicedToArray"));
var _extends2 = _interopRequireDefault(require("@babel/runtime/helpers/extends"));
var _objectWithoutProperties2 = _interopRequireDefault(require("@babel/runtime/helpers/objectWithoutProperties"));
var _react = _interopRequireWildcard(require("react"));
var _propTypes = _interopRequireDefault(require("prop-types"));
var _services = require("../../services");
var _inner_text = require("../inner_text");
var _copy = require("../copy");
var _i18n = require("../i18n");
var _button = require("../button");
var _icon = require("../icon");
var _utils = require("./utils");
var _code_block_copy = require("./code_block_copy.styles");
var _react2 = require("@emotion/react");
var _excluded = ["css"];
/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */
function _getRequireWildcardCache(e) { if ("function" != typeof WeakMap) return null; var r = new WeakMap(), t = new WeakMap(); return (_getRequireWildcardCache = function _getRequireWildcardCache(e) { return e ? t : r; })(e); }
function _interopRequireWildcard(e, r) { if (!r && e && e.__esModule) return e; if (null === e || "object" != _typeof(e) && "function" != typeof e) return { default: e }; var t = _getRequireWildcardCache(r); if (t && t.has(e)) return t.get(e); var n = { __proto__: null }, a = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var u in e) if ("default" !== u && {}.hasOwnProperty.call(e, u)) { var i = a ? Object.getOwnPropertyDescriptor(e, u) : null; i && (i.get || i.set) ? Object.defineProperty(n, u, i) : n[u] = e[u]; } return n.default = e, t && t.set(e, n), n; }
var CodeBlockCopiedContext = /*#__PURE__*/(0, _react.createContext)(false);
// POC: motion study held the check for about 1.8s. 0.75s keeps the confirmation brief.
var COPY_CHECK_HOLD_MS = 750;
var CodeBlockCopyIcon = function CodeBlockCopyIcon(_ref) {
  var iconCss = _ref.css,
    rest = (0, _objectWithoutProperties2.default)(_ref, _excluded);
  var showCheck = (0, _react.useContext)(CodeBlockCopiedContext);
  var styles = (0, _services.useEuiMemoizedStyles)(_code_block_copy.euiCodeBlockCopyIconStyles);
  return (0, _react2.jsx)("span", (0, _extends2.default)({}, rest, {
    css: iconCss
  }), (0, _react2.jsx)("span", {
    css: styles.frame
  }, (0, _react2.jsx)("span", {
    css: [styles.layer, showCheck ? styles.hidden : styles.visible, ";label:CodeBlockCopyIcon;"]
  }, (0, _react2.jsx)(_icon.EuiIcon, {
    type: "copy",
    color: "inherit",
    "aria-hidden": "true"
  })), (0, _react2.jsx)("span", {
    css: [styles.layer, showCheck ? styles.visible : styles.hidden, ";label:CodeBlockCopyIcon;"]
  }, (0, _react2.jsx)(_icon.EuiIcon, {
    type: "check",
    color: "inherit",
    "aria-hidden": "true"
  }))));
};
CodeBlockCopyIcon.propTypes = {
  css: _propTypes.default.oneOfType([_propTypes.default.any.isRequired, _propTypes.default.arrayOf(_propTypes.default.any.isRequired).isRequired])
};
var CodeBlockCopyButton = function CodeBlockCopyButton(_ref2) {
  var copy = _ref2.copy,
    copyCount = _ref2.copyCount,
    label = _ref2.label;
  var _useState = (0, _react.useState)(false),
    _useState2 = (0, _slicedToArray2.default)(_useState, 2),
    showCheck = _useState2[0],
    setShowCheck = _useState2[1];
  var timer = (0, _react.useRef)();
  (0, _react.useEffect)(function () {
    if (!copyCount) return;
    setShowCheck(true);
    window.clearTimeout(timer.current);
    timer.current = window.setTimeout(function () {
      return setShowCheck(false);
    }, COPY_CHECK_HOLD_MS);
  }, [copyCount]);
  (0, _react.useEffect)(function () {
    return function () {
      window.clearTimeout(timer.current);
    };
  }, []);
  return (0, _react2.jsx)(CodeBlockCopiedContext.Provider, {
    value: showCheck
  }, (0, _react2.jsx)(_button.EuiButtonIcon, {
    onClick: copy,
    iconType: CodeBlockCopyIcon,
    color: "text",
    "aria-label": label,
    "data-test-subj": "euiCodeBlockCopy"
  }));
};

/**
 * Hook that returns copy-related state/logic/utils
 */
CodeBlockCopyButton.propTypes = {
  copy: _propTypes.default.func.isRequired,
  copyCount: _propTypes.default.number.isRequired,
  label: _propTypes.default.string.isRequired
};
var useCopy = exports.useCopy = function useCopy(_ref3) {
  var copyAriaLabel = _ref3.copyAriaLabel,
    isCopyable = _ref3.isCopyable,
    isVirtualized = _ref3.isVirtualized,
    children = _ref3.children;
  var _useInnerText = (0, _inner_text.useInnerText)(''),
    _useInnerText2 = (0, _slicedToArray2.default)(_useInnerText, 2),
    innerTextRef = _useInnerText2[0],
    _innerText = _useInnerText2[1];
  var innerText = (0, _react.useMemo)(function () {
    var _innerText$replace;
    if (!_innerText) return;
    return (_innerText
    // remove text that should not be copied (e.g. screen reader instructions)
    === null || _innerText
    // remove text that should not be copied (e.g. screen reader instructions)
    === void 0 || (_innerText$replace = _innerText
    // remove text that should not be copied (e.g. screen reader instructions)
    .replace(_services.noCopyBoundsRegex, '')
    // Normalize line terminations to match native JS format
    ) === null || _innerText$replace === void 0 || (_innerText$replace = _innerText$replace.replace(_utils.NEW_LINE_REGEX_GLOBAL, '\n')
    // remove initial line break (if there was hidden content removed)
    ) === null || _innerText$replace === void 0 || (_innerText$replace = _innerText$replace.replace(/^\n/, '')
    // Reduce two or more consecutive new line characters to a single one
    // This is needed primarily because of how syntax highlighting
    // generated DOM elements affect `innerText` output.
    ) === null || _innerText$replace === void 0 ? void 0 : _innerText$replace.replace(/\n{2,}/g, '\n')) || '';
  }, [_innerText]);
  var textToCopy = isVirtualized ? "".concat(children) : innerText; // Virtualized code blocks do not have inner text

  var showCopyButton = isCopyable && textToCopy;
  var copyDefaultAriaLabel = (0, _i18n.useEuiI18n)('euiCodeBlockCopy.copy', 'Copy');
  var copyButton = (0, _react.useMemo)(function () {
    return showCopyButton ? (0, _react2.jsx)("div", {
      className: "euiCodeBlock__copyButton"
    }, (0, _react2.jsx)(_copy.EuiCopy, {
      textToCopy: textToCopy
    }, function (copy, _isCopied, copyCount) {
      return (0, _react2.jsx)(CodeBlockCopyButton, {
        copy: copy,
        copyCount: copyCount,
        label: copyAriaLabel || copyDefaultAriaLabel
      });
    })) : null;
  }, [copyAriaLabel, copyDefaultAriaLabel, showCopyButton, textToCopy]);
  return {
    innerTextRef: innerTextRef,
    copyButton: copyButton
  };
};