"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.euiCodeBlockCopyIconStyles = void 0;
var _react = require("@emotion/react");
var _global_styling = require("../../global_styling");
function _EMOTION_STRINGIFIED_CSS_ERROR__() { return "You have tried to stringify object returned from `css` function. It isn't supposed to be used directly (e.g. as value of the `className` prop), but rather handed to emotion so it can handle it (e.g. as value of `css` prop)."; } /*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */
var _ref = process.env.NODE_ENV === "production" ? {
  name: "tgggzx-hidden",
  styles: "opacity:0;filter:blur(2px);transform:scale(0.25);label:hidden;"
} : {
  name: "tgggzx-hidden",
  styles: "opacity:0;filter:blur(2px);transform:scale(0.25);label:hidden;",
  toString: _EMOTION_STRINGIFIED_CSS_ERROR__
};
var _ref2 = process.env.NODE_ENV === "production" ? {
  name: "onxgqw-visible",
  styles: "opacity:1;filter:blur(0);transform:scale(1);label:visible;"
} : {
  name: "onxgqw-visible",
  styles: "opacity:1;filter:blur(0);transform:scale(1);label:visible;",
  toString: _EMOTION_STRINGIFIED_CSS_ERROR__
};
var _ref3 = process.env.NODE_ENV === "production" ? {
  name: "1vfby4e-frame",
  styles: "position:relative;display:block;inline-size:100%;block-size:100%;label:frame;"
} : {
  name: "1vfby4e-frame",
  styles: "position:relative;display:block;inline-size:100%;block-size:100%;label:frame;",
  toString: _EMOTION_STRINGIFIED_CSS_ERROR__
};
var euiCodeBlockCopyIconStyles = exports.euiCodeBlockCopyIconStyles = function euiCodeBlockCopyIconStyles(_ref4) {
  var euiTheme = _ref4.euiTheme;
  var speed = euiTheme.animation.normal;
  // Motion study: ease-in-out. This swap does not use the resistance curve.
  var easing = 'ease-in-out';
  return {
    frame: _ref3,
    layer: /*#__PURE__*/(0, _react.css)("position:absolute;inset:0;display:flex;align-items:center;justify-content:center;", _global_styling.euiCanAnimate, "{transition:opacity ", speed, " ", easing, ",filter ", speed, " ", easing, ",transform ", speed, " ", easing, ";};label:layer;"),
    visible: _ref2,
    // Motion study: the hidden icon sits at scale .25 with a 2px blur.
    hidden: _ref
  };
};