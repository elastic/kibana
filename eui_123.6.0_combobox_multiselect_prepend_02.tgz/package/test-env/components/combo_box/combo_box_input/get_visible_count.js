"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.getVisibleCount = void 0;
/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */

/**
 * Works out how many pills to show in a single row (`selectionDisplay="collapse"`).
 * All but the last visible pill are shown in full. The last one may be
 * truncated to use the remaining space, as long as it stays at least
 * `pillMinWidth` wide (or fits in full). The rest are hidden behind "+N".
 */
var getVisibleCount = exports.getVisibleCount = function getVisibleCount(_ref) {
  var widths = _ref.widths,
    available = _ref.available,
    gap = _ref.gap,
    badgeWidth = _ref.badgeWidth,
    inputWidth = _ref.inputWidth,
    pillMinWidth = _ref.pillMinWidth;
  var total = widths.length;
  var prefixWidths = [0];
  widths.forEach(function (width) {
    prefixWidths.push(prefixWidths[prefixWidths.length - 1] + width);
  });
  for (var count = total; count >= 1; count--) {
    var hasHiddenOptions = count < total;
    // Every pill and the badge are followed by a gap
    var gaps = gap * (count + Number(hasHiddenOptions));
    var spaceForLastPill = available - prefixWidths[count - 1] - (hasHiddenOptions ? badgeWidth : 0) - gaps - inputWidth;
    if (spaceForLastPill >= Math.min(widths[count - 1], pillMinWidth)) {
      return count;
    }
  }
  return 0;
};