"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.euiComboBoxInputStyles = exports.COLLAPSE_PILL_MIN_WIDTH = exports.COLLAPSE_INPUT_MIN_WIDTH = void 0;
var _react = require("@emotion/react");
var _global_styling = require("../../../global_styling");
var _form = require("../../form/form.styles");
function _EMOTION_STRINGIFIED_CSS_ERROR__() { return "You have tried to stringify object returned from `css` function. It isn't supposed to be used directly (e.g. as value of the `className` prop), but rather handed to emotion so it can handle it (e.g. as value of `css` prop)."; } /*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */
/* Minimum widths (px) used by `selectionDisplay="collapse"` and shared with the
 * fit calculation in `EuiComboBoxInput`.
 * TODO: derive these from `euiTheme.size` once the component is converted to a
 * functional component, where the theme is available outside of render */
// Room kept free for the caret and the first typed characters
var COLLAPSE_INPUT_MIN_WIDTH = exports.COLLAPSE_INPUT_MIN_WIDTH = 12;
// A lone pill may truncate to fit, but not below this width
var COLLAPSE_PILL_MIN_WIDTH = exports.COLLAPSE_PILL_MIN_WIDTH = 64;
var _ref = process.env.NODE_ENV === "production" ? {
  name: "kedu1h-plainText",
  styles: "align-items:center;cursor:text;label:plainText;"
} : {
  name: "kedu1h-plainText",
  styles: "align-items:center;cursor:text;label:plainText;",
  toString: _EMOTION_STRINGIFIED_CSS_ERROR__
};
var _ref2 = process.env.NODE_ENV === "production" ? {
  name: "dkzr1g-multiSelect",
  styles: "flex-wrap:wrap;label:multiSelect;"
} : {
  name: "dkzr1g-multiSelect",
  styles: "flex-wrap:wrap;label:multiSelect;",
  toString: _EMOTION_STRINGIFIED_CSS_ERROR__
};
var euiComboBoxInputStyles = exports.euiComboBoxInputStyles = function euiComboBoxInputStyles(euiThemeContext) {
  var euiTheme = euiThemeContext.euiTheme;
  var formStyles = (0, _form.euiFormControlStyles)(euiThemeContext);
  var formVariables = (0, _form.euiFormVariables)(euiThemeContext);
  var pillHeight = (0, _global_styling.mathWithUnits)(euiTheme.size.l, function (x) {
    return x - 2;
  });
  var pillLineHeight = (0, _global_styling.mathWithUnits)(pillHeight, function (x) {
    return x - 2;
  });

  // Align the content of prepend/append to the first row of the control
  var sideContentTop = function sideContentTop(rowHeight) {
    return "\n    > .euiFormControlLayout__prepend,\n    > .euiFormControlLayout__append {\n      align-items: flex-start;\n\n      > * {\n        /* The sides have vertical padding, subtract it so the content is\n           exactly one row high and doesn't make the control taller */\n        ".concat((0, _global_styling.logicalCSS)('height', "calc(".concat(rowHeight, " - ").concat(euiTheme.size.xs, " * 2)")), "\n      }\n    }\n  ");
  };
  return {
    // Wrapper which visually mimics a form control
    euiComboBoxInputWrapper: /*#__PURE__*/(0, _react.css)((0, _form.euiFormControlDefaultShadow)(euiThemeContext), " display:flex;&:focus-within{", formStyles.focus, ";};label:euiComboBoxInputWrapper;"),
    multiSelect: _ref2,
    // `selectionDisplay="collapse"`: single row, pills that don't fit are hidden
    // (but stay rendered so they can be measured) and folded into a "+N" badge
    collapsed: /*#__PURE__*/(0, _react.css)("position:relative;flex-wrap:nowrap;overflow:hidden;.euiComboBox__input{flex-shrink:0;", (0, _global_styling.logicalCSS)('min-width', "".concat(COLLAPSE_INPUT_MIN_WIDTH, "px")), ";}.euiComboBoxCollapsedBadge{display:flex;align-items:center;flex-shrink:0;.euiBadge{", (0, _global_styling.logicalCSS)('height', pillHeight), " line-height:", pillLineHeight, ";", (0, _global_styling.logicalCSS)('margin-vertical', '1px'), " margin-inline:0;&:is(", _global_styling.euiDisabledSelector, "){border-color:", euiTheme.components.badgeBorderColorHollow, ";}}}.euiComboBoxPill{flex-shrink:0;", (0, _global_styling.logicalCSS)('min-width', '0'), ";}.euiComboBoxPill--shrinkable{flex-shrink:1;}.euiComboBoxCollapsedBadgeMeasure{position:absolute;visibility:hidden;pointer-events:none;}.euiComboBoxPill--collapsed{position:absolute;visibility:hidden;pointer-events:none;};label:collapsed;"),
    // Hidden selections listed in the "+N" popover
    collapsedList: /*#__PURE__*/(0, _react.css)("display:flex;flex-direction:column;align-items:flex-start;", (0, _global_styling.logicalCSS)('width', 'max-content'), " ", (0, _global_styling.logicalCSS)('max-width', 'min(300px, calc(100vw - 32px))'), " gap:", euiTheme.size.xs, ";", (0, _global_styling.logicalCSS)('max-height', '240px'), " ", (0, _global_styling.logicalCSSWithFallback)('overflow-y', 'auto'), " .euiComboBoxPill{flex-shrink:0;", (0, _global_styling.logicalCSS)('max-width', '100%'), ";};label:collapsedList;"),
    uncompressed: "\n      ".concat(formStyles.uncompressed, "\n      ").concat((0, _global_styling.logicalCSS)('height', 'auto'), "\n      ").concat((0, _global_styling.logicalCSS)('padding-vertical', euiTheme.size.s), "\n      ").concat((0, _global_styling.logicalCSS)('padding-left', euiTheme.size.m), "\n      column-gap: ").concat(euiTheme.size.s, ";\n      row-gap: ").concat(euiTheme.size.xs, ";\n    "),
    compressed: /*#__PURE__*/(0, _react.css)(formStyles.compressed, " ", (0, _global_styling.logicalCSS)('height', 'auto'), " ", (0, _global_styling.logicalCSS)('padding-vertical', euiTheme.size.xs), " ", (0, _global_styling.logicalCSS)('padding-left', euiTheme.size.xs), " column-gap:", euiTheme.size.xs, ";row-gap:", euiTheme.size.xxs, ";;label:compressed;"),
    plainText: {
      plainText: _ref,
      compressed: "\n        ".concat((0, _global_styling.logicalCSS)('padding-left', euiTheme.size.s), "\n      "),
      uncompressed: "\n        ".concat((0, _global_styling.logicalCSS)('padding-left', euiTheme.size.m), "\n      ")
    },
    invalid: /*#__PURE__*/(0, _react.css)(formStyles.invalid, ";label:invalid;"),
    disabled: /*#__PURE__*/(0, _react.css)(formStyles.disabled, ";label:disabled;"),
    open: /*#__PURE__*/(0, _react.css)(formStyles.focus, ";;label:open;"),
    inGroup: /*#__PURE__*/(0, _react.css)(formStyles.inGroup, ";label:inGroup;"),
    // Actual input element, which has variable width depending on its value
    euiComboBoxInput: /*#__PURE__*/(0, _react.css)((0, _global_styling.logicalCSS)('height', euiTheme.size.l), " ", (0, _global_styling.logicalCSS)('min-width', '2px'), " ", (0, _global_styling.logicalCSS)('max-width', '100%'), (0, _form.euiFormControlText)(euiThemeContext), " background:transparent;&:disabled{color:", euiTheme.colors.textDisabled, ";}appearance:none!important;border:none!important;box-shadow:none!important;outline:none!important;;label:euiComboBoxInput;"),
    // EuiFormControlLayout overrides
    formLayout: {
      euiComboBox__formControlLayout: /*#__PURE__*/(0, _react.css)(";label:euiComboBox__formControlLayout;"),
      // Allow the form control to expand to any height to accommodate multiple rows of pills
      multiSelect: /*#__PURE__*/(0, _react.css)((0, _global_styling.logicalCSS)('height', 'auto'), ";;label:multiSelect;"),
      multiSelectGroup: /*#__PURE__*/(0, _react.css)(">.euiFormControlLayout__prepend,>.euiFormControlLayout__append{", (0, _global_styling.logicalCSS)('height', 'auto'), " align-self:stretch;flex-shrink:1;>*{", (0, _global_styling.logicalCSS)('max-width', '100%'), " ", (0, _global_styling.logicalCSS)('min-width', '0'), ";}}>.euiFormControlLayout__childrenWrapper{flex:1 1 0%;", (0, _global_styling.logicalCSS)('min-width', (0, _global_styling.mathWithUnits)(euiTheme.size.xxxxl, function (x) {
        return x * 2;
      })), ";}", sideContentTop(formVariables.controlHeight), ";;label:multiSelectGroup;"),
      multiSelectCompressed: /*#__PURE__*/(0, _react.css)(sideContentTop(formVariables.controlCompressedHeight), ";;label:multiSelectCompressed;")
    }
  };
};