"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.SIZES = exports.EuiButtonIcon = exports.DISPLAYS = void 0;
var _extends2 = _interopRequireDefault(require("@babel/runtime/helpers/extends"));
var _objectWithoutProperties2 = _interopRequireDefault(require("@babel/runtime/helpers/objectWithoutProperties"));
var _react = _interopRequireDefault(require("react"));
var _classnames = _interopRequireDefault(require("classnames"));
var _services = require("../../../services");
var _useEuiDisabledElement = require("../../../services/hooks/useEuiDisabledElement");
var _button = require("../../../global_styling/mixins/_button");
var _icon = require("../../icon");
var _loading = require("../../loading");
var _use_button_common_props = require("../use_button_common_props");
var _button_icon = require("./button_icon.styles");
var _react2 = require("@emotion/react");
var _excluded = ["className", "iconType", "iconSize", "color", "isDisabled", "disabled", "hasAriaDisabled", "href", "type", "display", "target", "rel", "size", "buttonRef", "isSelected", "isLoading"],
  _excluded2 = ["ref"];
/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */
var SIZES = exports.SIZES = ['xs', 's', 'm'];
var DISPLAYS = exports.DISPLAYS = ['base', 'empty', 'fill'];
var EuiButtonIcon = exports.EuiButtonIcon = function EuiButtonIcon(_ref) {
  var className = _ref.className,
    iconType = _ref.iconType,
    _ref$iconSize = _ref.iconSize,
    iconSize = _ref$iconSize === void 0 ? 'm' : _ref$iconSize,
    _ref$color = _ref.color,
    _color = _ref$color === void 0 ? 'primary' : _ref$color,
    _isDisabled = _ref.isDisabled,
    disabled = _ref.disabled,
    _hasAriaDisabled = _ref.hasAriaDisabled,
    href = _ref.href,
    _ref$type = _ref.type,
    type = _ref$type === void 0 ? 'button' : _ref$type,
    _ref$display = _ref.display,
    _display = _ref$display === void 0 ? 'empty' : _ref$display,
    target = _ref.target,
    rel = _ref.rel,
    _ref$size = _ref.size,
    _size = _ref$size === void 0 ? 'xs' : _ref$size,
    buttonRef = _ref.buttonRef,
    isSelected = _ref.isSelected,
    isLoading = _ref.isLoading,
    rest = (0, _objectWithoutProperties2.default)(_ref, _excluded);
  var _useEuiButtonCommonPr = (0, _use_button_common_props.useEuiButtonCommonProps)({
      size: _size,
      color: _color,
      isDisabled: _isDisabled,
      hasAriaDisabled: _hasAriaDisabled,
      display: _display,
      href: href,
      disabled: disabled,
      isLoading: isLoading
    }),
    size = _useEuiButtonCommonPr.size,
    color = _useEuiButtonCommonPr.color,
    isDisabled = _useEuiButtonCommonPr.isDisabled,
    _useEuiButtonCommonPr2 = _useEuiButtonCommonPr.hasAriaDisabled,
    hasAriaDisabled = _useEuiButtonCommonPr2 === void 0 ? false : _useEuiButtonCommonPr2,
    display = _useEuiButtonCommonPr.display;
  var _useEuiDisabledElemen = (0, _useEuiDisabledElement.useEuiDisabledElement)({
      isDisabled: isDisabled,
      hasAriaDisabled: hasAriaDisabled,
      onKeyDown: rest.onKeyDown
    }),
    disabledRef = _useEuiDisabledElemen.ref,
    disabledButtonProps = (0, _objectWithoutProperties2.default)(_useEuiDisabledElemen, _excluded2);
  var setCombinedRef = (0, _services.useCombinedRefs)([disabledRef, buttonRef]);
  var ariaHidden = rest['aria-hidden'];
  var isAriaHidden = ariaHidden === 'true' || ariaHidden === true;
  if (!rest['aria-label'] && !rest['aria-labelledby'] && !isAriaHidden) {
    console.warn("EuiButtonIcon requires aria-label or aria-labelledby to be specified because icon-only\n      buttons are screen-reader-inaccessible without them.");
  }
  var buttonColorStyles = (0, _button.useEuiButtonColorCSS)({
    display: display
  });
  var buttonFocusStyle = (0, _button.useEuiButtonFocusCSS)();
  var styles = (0, _services.useEuiMemoizedStyles)(_button_icon.euiButtonIconStyles);
  var cssStyles = [styles.euiButtonIcon, styles[size], buttonColorStyles[isDisabled ? 'disabled' : color], buttonFocusStyle, isDisabled && styles.isDisabled];
  var classes = (0, _classnames.default)('euiButtonIcon', className);

  // Add an icon to the button if one exists.
  var buttonIcon;
  if (iconType && !isLoading) {
    buttonIcon = (0, _react2.jsx)(_icon.EuiIcon, {
      className: "euiButtonIcon__icon",
      type: iconType,
      size: iconSize,
      "aria-hidden": "true",
      color: "inherit" // forces the icon to inherit its parent color
    });
  }
  if (iconType && isLoading) {
    // `original` size doesn't exist in `EuiLoadingSpinner`
    // when the `iconSize` is `original` we don't pass any size to the `EuiLoadingSpinner`
    // so it gets the default size
    var loadingSize = iconSize === 'original' ? undefined : iconSize;

    // When the button is disabled the text gets gray
    // and in some buttons the background gets a light gray
    // for better contrast we want to change the border of the spinner
    // to have the same color of the text. This way we ensure the borders
    // are always visible. The default spinner color could be very light.
    var loadingSpinnerColor = isDisabled ? {
      border: 'currentcolor'
    } : undefined;
    buttonIcon = (0, _react2.jsx)(_loading.EuiLoadingSpinner, {
      size: loadingSize,
      color: loadingSpinnerColor
    });
  }

  // <a> elements don't respect the `disabled` attribute. So if we're disabled, we'll just pretend
  // this is a button and piggyback off its disabled styles.
  if (href && !isDisabled) {
    var secureRel = (0, _services.getSecureRelForTarget)({
      href: href,
      target: target,
      rel: rel
    });
    return (0, _react2.jsx)("a", (0, _extends2.default)({
      css: cssStyles,
      tabIndex: isAriaHidden ? -1 : undefined,
      className: classes,
      href: href,
      target: target,
      rel: secureRel,
      ref: setCombinedRef
    }, rest), buttonIcon);
  }
  var buttonType;
  return (0, _react2.jsx)("button", (0, _extends2.default)({
    css: cssStyles,
    tabIndex: isAriaHidden ? -1 : undefined,
    disabled: isDisabled,
    className: classes,
    "aria-pressed": isSelected,
    type: type,
    ref: setCombinedRef
  }, rest, disabledButtonProps), buttonIcon);
};