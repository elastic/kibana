"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.EuiDataGridToolbarControl = void 0;
var _extends2 = _interopRequireDefault(require("@babel/runtime/helpers/extends"));
var _objectWithoutProperties2 = _interopRequireDefault(require("@babel/runtime/helpers/objectWithoutProperties"));
var _propTypes = _interopRequireDefault(require("prop-types"));
var _react = _interopRequireDefault(require("react"));
var _classnames = _interopRequireDefault(require("classnames"));
var _react2 = require("@emotion/react");
var _services = require("../../../services");
var _button = require("../../button");
var _badge = require("../../badge");
var _i18n = require("../../i18n");
var _excluded = ["children", "className", "badgeContent", "textProps"];
function _EMOTION_STRINGIFIED_CSS_ERROR__() { return "You have tried to stringify object returned from `css` function. It isn't supposed to be used directly (e.g. as value of the `className` prop), but rather handed to emotion so it can handle it (e.g. as value of `css` prop)."; } /*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */
var EuiDataGridToolbarControl = exports.EuiDataGridToolbarControl = function EuiDataGridToolbarControl(_ref) {
  var children = _ref.children,
    className = _ref.className,
    badgeContent = _ref.badgeContent,
    textProps = _ref.textProps,
    rest = (0, _objectWithoutProperties2.default)(_ref, _excluded);
  var euiThemeContext = (0, _services.useEuiTheme)();
  var classes = (0, _classnames.default)('euiDataGridToolbarControl', className);
  var cssStyles = interactiveStyles(euiThemeContext);
  var badgeAriaLabel = (0, _i18n.useEuiI18n)('euiDataGridToolbarControl.badgeAriaLabel', 'Active: {count}', {
    count: typeof badgeContent === 'string' ? betterScreenReaderSlashes(badgeContent) : badgeContent
  });
  return (0, _react2.jsx)(_button.EuiButtonEmpty, (0, _extends2.default)({
    className: classes,
    size: "xs",
    color: "text",
    textProps: false,
    css: cssStyles
  }, rest), (0, _react2.jsx)("span", (0, _extends2.default)({}, textProps, {
    className: (0, _classnames.default)('euiDataGridToolbarControl__text', 'eui-textTruncate', textProps && textProps.className)
  }), children), Boolean(badgeContent) && (0, _react2.jsx)(_badge.EuiNotificationBadge, {
    className: "euiDataGridToolbarControl__badge",
    css: badgeStyles,
    color: "subdued",
    "aria-label": "- ".concat(badgeAriaLabel) // Punctuation helps add pauses for screen readers
    ,
    role: "marquee" // https://developer.mozilla.org/en-US/docs/Web/Accessibility/ARIA/Roles/marquee_role
  }, badgeContent));
};

// The columns control specifically passes (e.g.) `5/10` when some columns
// are being hidden. We can make this a bit more legible to SRs with this quick util
EuiDataGridToolbarControl.propTypes = {
  badgeContent: _propTypes.default.oneOfType([_propTypes.default.number.isRequired, _propTypes.default.string.isRequired])
};
var betterScreenReaderSlashes = function betterScreenReaderSlashes(badgeContent) {
  return badgeContent.replaceAll('/', ' out of ');
};
var interactiveStyles = function interactiveStyles(_ref2) {
  var euiTheme = _ref2.euiTheme;
  return /*#__PURE__*/(0, _react2.css)("&:focus,&:hover:not(:disabled){.euiDataGridToolbarControl__badge{background-color:", euiTheme.components.filterButtonBadgeBackgroundHover, ";}};label:interactiveStyles;");
};
var badgeStyles = process.env.NODE_ENV === "production" ? {
  name: "1968nw3-badgeStyles",
  styles: "cursor:inherit;label:badgeStyles;"
} : {
  name: "1968nw3-badgeStyles",
  styles: "cursor:inherit;label:badgeStyles;",
  toString: _EMOTION_STRINGIFIED_CSS_ERROR__
};