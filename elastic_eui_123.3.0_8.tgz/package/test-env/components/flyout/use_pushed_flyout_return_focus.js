"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.usePushedFlyoutReturnFocus = void 0;
var _typeof2 = _interopRequireDefault(require("@babel/runtime/helpers/typeof"));
var _react = require("react");
var _const = require("./manager/const");
var _selectors = require("./manager/selectors");
var _store = require("./manager/store");
/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */

/**
 * Focus returns scheduled by pushed flyouts that just unmounted, keyed by
 * timeout. A flyout mounting before they run (e.g. one remounted by a changed
 * `key`) cancels them, so focus isn't pulled away from a flyout that is open.
 */
var pendingReturnFocus = new Map();

/**
 * Step 1, at unmount, before the DOM is removed: whether the user left focus
 * somewhere a return is appropriate. Focus in another flyout passes because
 * that flyout may be closing too; step 2 catches it if not.
 */
var mayReturnFocusOnUnmount = function mayReturnFocusOnUnmount(isFocusOwned) {
  var active = document.activeElement;
  return isFocusOwned || !active || active === document.body || !!active.closest('.euiFlyout');
};

/** Step 2, once everything closing alongside the flyout has unmounted. */
var isFocusStranded = function isFocusStranded() {
  var active = document.activeElement;
  return !active || active === document.body || !active.isConnected;
};

/**
 * Inactive managed sessions stay mounted but are moved off-screen, so focus
 * inside one would be invisible.
 */
var isInInactiveSession = function isInInactiveSession(element) {
  var owner = element.closest("[".concat(_const.PROPERTY_FLYOUT, "]"));
  return !!owner && !(0, _selectors.isFlyoutInCurrentSession)((0, _store.getFlyoutManagerStore)().getState(), owner.id);
};

/**
 * A flyout opened while nothing was focused captures `<body>`, which isn't
 * a trigger worth returning to.
 */
var isUsableTrigger = function isUsableTrigger(element) {
  return !!element && element.isConnected && element !== document.body;
};

/** Step 3: apply `returnFocus` the way `react-focus-lock` does. */
var returnFocusToTrigger = function returnFocusToTrigger(trigger, returnFocus) {
  var howToReturnFocus = typeof returnFocus === 'function' ? returnFocus(trigger) : returnFocus;
  if (!howToReturnFocus || !(trigger instanceof HTMLElement) || !isUsableTrigger(trigger) || isInInactiveSession(trigger)) {
    return;
  }
  trigger.focus((0, _typeof2.default)(howToReturnFocus) === 'object' ? howToReturnFocus : undefined);
};
/**
 * Returns focus to the trigger element when a pushed flyout unmounts.
 *
 * Pushed flyouts disable their `EuiFocusTrap`, so nothing else returns focus
 * for them. Overlay flyouts are skipped because their active trap already
 * does. Focus is returned only when:
 * - the flyout owned focus, or focus was on `<body>` or in another flyout,
 *   when it unmounted, and
 * - after everything closing with it has unmounted, focus is on `<body>` or
 *   a removed element, and
 * - `returnFocus` allows it, and the trigger is connected and not in an
 *   inactive managed session.
 *
 * Returns `onFocus` and `onBlur` handlers for the flyout element, composed
 * with the ones passed in.
 */
var usePushedFlyoutReturnFocus = exports.usePushedFlyoutReturnFocus = function usePushedFlyoutReturnFocus(_ref) {
  var isPushed = _ref.isPushed,
    _ref$returnFocus = _ref.returnFocus,
    returnFocus = _ref$returnFocus === void 0 ? true : _ref$returnFocus,
    triggerRef = _ref.triggerRef,
    _onFocus = _ref.onFocus,
    _onBlur = _ref.onBlur;
  var latest = (0, _react.useRef)({
    isPushed: isPushed,
    returnFocus: returnFocus
  });
  latest.current.isPushed = isPushed;
  latest.current.returnFocus = returnFocus;

  // React focus events bubble through portals, so this also covers focus in
  // content the flyout renders elsewhere in the DOM, such as popovers and
  // child flyouts.
  var isFocusOwnedRef = (0, _react.useRef)(false);
  var onFocus = (0, _react.useCallback)(function (event) {
    isFocusOwnedRef.current = true;
    _onFocus === null || _onFocus === void 0 || _onFocus(event);
  }, [_onFocus]);
  var onBlur = (0, _react.useCallback)(function (event) {
    isFocusOwnedRef.current = false;
    _onBlur === null || _onBlur === void 0 || _onBlur(event);
  }, [_onBlur]);
  (0, _react.useLayoutEffect)(function () {
    // A flyout replacing one that just closed captured its trigger after the
    // closing flyout's DOM was removed, which is `<body>` or a removed
    // element, so take over the closing flyout's trigger.
    pendingReturnFocus.forEach(function (pendingTrigger, timeout) {
      clearTimeout(timeout);
      if (!isUsableTrigger(triggerRef.current) && isUsableTrigger(pendingTrigger)) {
        triggerRef.current = pendingTrigger;
      }
    });
    pendingReturnFocus.clear();
  }, [triggerRef]);

  // Layout cleanup runs before the DOM is removed, while focus still shows
  // where the user left it.
  (0, _react.useLayoutEffect)(function () {
    return function () {
      var _latest$current = latest.current,
        isPushed = _latest$current.isPushed,
        returnFocus = _latest$current.returnFocus;
      var trigger = triggerRef.current;
      if (!isPushed || !returnFocus || !trigger) return;
      if (!mayReturnFocusOnUnmount(isFocusOwnedRef.current)) return;

      // Wait for sibling flyouts in the same history group, portalled
      // content, and child flyout focus traps that pull focus back to
      // themselves before releasing it.
      var timeout = setTimeout(function () {
        pendingReturnFocus.delete(timeout);
        if (isFocusStranded()) returnFocusToTrigger(trigger, returnFocus);
      });
      pendingReturnFocus.set(timeout, trigger);
    };
  }, [triggerRef]);
  return {
    onFocus: onFocus,
    onBlur: onBlur
  };
};