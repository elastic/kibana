"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.useEuiFlyoutResizable = exports.clampFlyoutWidth = void 0;
var _slicedToArray2 = _interopRequireDefault(require("@babel/runtime/helpers/slicedToArray"));
var _react = require("react");
var _services = require("../../services");
var _helpers = require("../resizable_container/helpers");
/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */

/**
 * Clamps a resizable flyout's width between `minWidth` and the space left
 * beside its sibling, within 90% of the reference width. `minWidth` takes
 * precedence: if the available space is smaller, the flyout stays at
 * `minWidth`, and a fill sibling's CSS adjusts accordingly.
 * Layout mode also uses this to decide from the width the clamp will apply.
 * @internal
 */
var clampFlyoutWidth = exports.clampFlyoutWidth = function clampFlyoutWidth(width, _ref) {
  var _ref$minWidth = _ref.minWidth,
    minWidth = _ref$minWidth === void 0 ? 0 : _ref$minWidth,
    maxWidth = _ref.maxWidth,
    referenceWidth = _ref.referenceWidth,
    siblingWidth = _ref.siblingWidth;
  var maxResizeWidth = referenceWidth * 0.9 - (siblingWidth || 0);
  var upperBound = Math.min(maxWidth || Infinity, maxResizeWidth);
  return Math.max(minWidth, Math.min(width, upperBound));
};
/**
 * @internal
 */
var useEuiFlyoutResizable = exports.useEuiFlyoutResizable = function useEuiFlyoutResizable(_ref2) {
  var enabled = _ref2.enabled,
    _ref2$minWidth = _ref2.minWidth,
    minWidth = _ref2$minWidth === void 0 ? 0 : _ref2$minWidth,
    maxWidth = _ref2.maxWidth,
    siblingFlyoutWidth = _ref2.siblingFlyoutWidth,
    referenceWidth = _ref2.referenceWidth,
    onResize = _ref2.onResize,
    side = _ref2.side,
    _size = _ref2.size,
    _ref2$isChildFlyout = _ref2.isChildFlyout,
    isChildFlyout = _ref2$isChildFlyout === void 0 ? false : _ref2$isChildFlyout;
  // Without a `referenceWidth` (standalone flyouts), nothing else re-renders
  // the flyout on window resize, so track the viewport width here
  var _useState = (0, _react.useState)(function () {
      return typeof window !== 'undefined' ? window.innerWidth : Infinity;
    }),
    _useState2 = (0, _slicedToArray2.default)(_useState, 2),
    windowWidth = _useState2[0],
    setWindowWidth = _useState2[1];
  var tracksWindow = enabled && referenceWidth === undefined;
  (0, _react.useEffect)(function () {
    if (!tracksWindow) return;
    var rafId = 0;
    var onWindowResize = function onWindowResize() {
      cancelAnimationFrame(rafId);
      rafId = requestAnimationFrame(function () {
        return setWindowWidth(window.innerWidth);
      });
    };
    // Catch up on resizes that happened while the window was not tracked
    setWindowWidth(window.innerWidth);
    window.addEventListener('resize', onWindowResize);
    return function () {
      cancelAnimationFrame(rafId);
      window.removeEventListener('resize', onWindowResize);
    };
  }, [tracksWindow]);

  // Use container width when provided. When referenceWidth is 0 (e.g. container
  // not yet measured by ResizeObserver), do not fall back to viewport — that
  // would allow resizing beyond the container (e.g. over a sidebar). Use 0 so
  // the clamp keeps the flyout at minWidth until the real width is available.
  var _referenceWidth = referenceWidth !== undefined ? referenceWidth : windowWidth;
  var getFlyoutMinMaxWidth = (0, _react.useCallback)(function (width) {
    return clampFlyoutWidth(width, {
      minWidth: minWidth,
      maxWidth: maxWidth,
      referenceWidth: _referenceWidth,
      siblingWidth: siblingFlyoutWidth
    });
  }, [minWidth, maxWidth, siblingFlyoutWidth, _referenceWidth]);
  var _useState3 = (0, _react.useState)(0),
    _useState4 = (0, _slicedToArray2.default)(_useState3, 2),
    flyoutWidth = _useState4[0],
    _setFlyoutWidth = _useState4[1];

  // The last width set, even before it renders. Handlers read it instead of
  // `flyoutWidth`, which is stale until then (e.g. a key press right after
  // mount, before the width from `size` has rendered).
  var flyoutWidthRef = (0, _react.useRef)(0);
  var setFlyoutWidth = (0, _react.useCallback)(function (width) {
    flyoutWidthRef.current = width;
    _setFlyoutWidth(width);
  }, []);

  // Must use state for the flyout ref in order for the useEffect to be correctly called after render
  var _useState5 = (0, _react.useState)(null),
    _useState6 = (0, _slicedToArray2.default)(_useState5, 2),
    flyoutRef = _useState6[0],
    setFlyoutRef = _useState6[1];
  (0, _react.useEffect)(function () {
    if (!enabled) return; // Don't measure when resizing is disabled
    if (!flyoutWidth && flyoutRef) {
      setFlyoutWidth(getFlyoutMinMaxWidth(flyoutRef.offsetWidth));
    }
  }, [flyoutWidth, flyoutRef, getFlyoutMinMaxWidth, enabled, setFlyoutWidth]);

  // Track the previous `_size` prop to distinguish between a consumer size
  // change (which should reset the width) and a reference-width / constraint
  // change (which should re-clamp the existing width).
  // Initialized to `null` so the first render always takes the "reset" path.
  var prevSizeRef = (0, _react.useRef)(null);

  // Track the previous reference width so we can scale proportionally when
  // the container / viewport resizes (both shrink AND grow).
  var prevReferenceWidthRef = (0, _react.useRef)(_referenceWidth);

  // The width last set by a numeric `size` or by the user, before clamping.
  // Clamping always starts from it, so a squeezed flyout returns to this width
  // once there is room again. With a named `size`, it scales with the
  // reference width.
  var requestedWidthRef = (0, _react.useRef)(null);

  // Update flyout width when consumers pass in a new `size`, or re-clamp
  // when constraints change (e.g. container resize, sibling width change).
  (0, _react.useEffect)(function () {
    if (!enabled) return; // Don't update width when resizing is disabled

    if (prevSizeRef.current !== _size) {
      // The consumer's `size` prop actually changed — reset so the new size takes effect
      prevSizeRef.current = _size;
      prevReferenceWidthRef.current = _referenceWidth;
      requestedWidthRef.current = typeof _size === 'number' ? _size : null;
      setFlyoutWidth(typeof _size === 'number' ? getFlyoutMinMaxWidth(_size) : 0);
    } else if (typeof _size === 'number') {
      // A numeric `size` is a pixel width, so it is only re-clamped, not scaled
      if (_referenceWidth > 0) {
        var _requestedWidthRef$cu;
        setFlyoutWidth(getFlyoutMinMaxWidth((_requestedWidthRef$cu = requestedWidthRef.current) !== null && _requestedWidthRef$cu !== void 0 ? _requestedWidthRef$cu : _size));
      }
    } else {
      var _prevReferenceWidthRe;
      // Named sizes are percentages — scale the pixel width proportionally to
      // the reference width change and then clamp. This preserves the flyout's
      // percentage position in both directions (viewport shrink AND grow).
      // A user-dragged width is scaled and clamped from the requested width,
      // so it survives a clamp just as it does for a numeric `size`. A child
      // flyout keeps its clamped width: the main flyout and the child each
      // clamp against the other's measured width, so if both grew back toward
      // their requested widths, they would shrink and grow in turn forever.
      var prevRefWidth = (_prevReferenceWidthRe = prevReferenceWidthRef.current) !== null && _prevReferenceWidthRe !== void 0 ? _prevReferenceWidthRe : _referenceWidth;
      prevReferenceWidthRef.current = _referenceWidth;
      var currentWidth = flyoutWidthRef.current;
      if (currentWidth && prevRefWidth > 0 && _referenceWidth > 0) {
        var scaleFactor = _referenceWidth / prevRefWidth;
        var requestedWidth = isChildFlyout ? null : requestedWidthRef.current;
        var scaledWidth = (requestedWidth !== null && requestedWidth !== void 0 ? requestedWidth : currentWidth) * scaleFactor;
        if (requestedWidth !== null) {
          requestedWidthRef.current = scaledWidth;
        }
        setFlyoutWidth(getFlyoutMinMaxWidth(scaledWidth));
      } else if (_referenceWidth > 0) {
        // When reference width was 0 (e.g. container not yet measured), now
        // that we have a real width, reset from the size prop instead of scaling.
        requestedWidthRef.current = null;
        setFlyoutWidth(0);
      }
    }
  }, [_size, getFlyoutMinMaxWidth, enabled, _referenceWidth, setFlyoutWidth, isChildFlyout]);

  // `onResize` is only called from user interactions, never for width changes
  // caused by the consumer or by layout constraints
  var onResizeRef = (0, _services.useLatest)(onResize);
  var onUserResize = (0, _react.useCallback)(function (width) {
    var _onResizeRef$current;
    requestedWidthRef.current = width;
    (_onResizeRef$current = onResizeRef.current) === null || _onResizeRef$current === void 0 || _onResizeRef$current.call(onResizeRef, width);
  }, [onResizeRef]);

  // Initial numbers to calculate from, on resize drag start
  var initialWidth = (0, _react.useRef)(0);
  var initialMouseX = (0, _react.useRef)(0);
  var drag = (0, _react.useRef)({
    startWidth: 0,
    width: 0
  });

  // Account for flyout side and logical property direction
  var direction = (0, _react.useMemo)(function () {
    var modifier = side === 'right' ? -1 : 1;
    if (flyoutRef) {
      var languageDirection = window.getComputedStyle(flyoutRef).direction;
      if (languageDirection === 'rtl') modifier *= -1;
    }
    return modifier;
  }, [side, flyoutRef]);
  var onMouseMove = (0, _react.useCallback)(function (e) {
    if (!enabled) {
      return;
    }
    var mouseOffset = (0, _helpers.getPosition)(e, true) - initialMouseX.current;
    var changedFlyoutWidth = initialWidth.current + mouseOffset * direction;
    drag.current.width = getFlyoutMinMaxWidth(changedFlyoutWidth);
    setFlyoutWidth(drag.current.width);
  }, [getFlyoutMinMaxWidth, direction, enabled, setFlyoutWidth]);
  var onMouseUp = (0, _react.useCallback)(function () {
    if (!enabled) {
      return;
    }
    initialMouseX.current = 0;

    // Clicking the handle, or dragging against the clamp, changes nothing
    var _drag$current = drag.current,
      startWidth = _drag$current.startWidth,
      width = _drag$current.width;
    if (width !== startWidth) onUserResize(width);
    window.removeEventListener('mousemove', onMouseMove);
    window.removeEventListener('mouseup', onMouseUp);
    window.removeEventListener('touchmove', onMouseMove);
    window.removeEventListener('touchend', onMouseUp);
  }, [onMouseMove, onUserResize, enabled]);
  var onMouseDown = (0, _react.useCallback)(function (e) {
    var _flyoutRef$offsetWidt;
    if (!enabled) {
      return;
    }
    initialMouseX.current = (0, _helpers.getPosition)(e, true);
    initialWidth.current = (_flyoutRef$offsetWidt = flyoutRef === null || flyoutRef === void 0 ? void 0 : flyoutRef.offsetWidth) !== null && _flyoutRef$offsetWidt !== void 0 ? _flyoutRef$offsetWidt : 0;
    var startWidth = flyoutWidthRef.current;
    drag.current = {
      startWidth: startWidth,
      width: startWidth
    };

    // Window event listeners instead of React events are used
    // in case the user's mouse leaves the component
    window.addEventListener('mousemove', onMouseMove);
    window.addEventListener('mouseup', onMouseUp);
    window.addEventListener('touchmove', onMouseMove);
    window.addEventListener('touchend', onMouseUp);
  }, [flyoutRef, onMouseMove, onMouseUp, enabled]);
  var onKeyDown = (0, _react.useCallback)(function (e) {
    if (!enabled) {
      return;
    }
    var KEYBOARD_OFFSET = 10;
    var offset;
    switch (e.key) {
      case _services.keys.ARROW_RIGHT:
        offset = KEYBOARD_OFFSET * direction;
        break;
      case _services.keys.ARROW_LEFT:
        offset = -KEYBOARD_OFFSET * direction;
        break;
      default:
        return;
    }
    e.preventDefault(); // Safari+VO will screen reader navigate off the button otherwise

    var currentWidth = flyoutWidthRef.current;
    var newWidth = getFlyoutMinMaxWidth(currentWidth + offset);
    if (newWidth === currentWidth) return; // Already at the clamp
    setFlyoutWidth(newWidth);
    onUserResize(newWidth);
  }, [getFlyoutMinMaxWidth, direction, enabled, onUserResize, setFlyoutWidth]);
  var size = (0, _react.useMemo)(function () {
    if (enabled && flyoutWidth && _referenceWidth > 0) {
      var pctValue = flyoutWidth / _referenceWidth * 100;
      return "".concat(pctValue, "%");
    }
    return _size;
  }, [enabled, flyoutWidth, _referenceWidth, _size]);
  return {
    onKeyDown: onKeyDown,
    onMouseDown: onMouseDown,
    setFlyoutRef: setFlyoutRef,
    size: size
  };
};