import { UseEuiTheme } from '../../services/theme/types';
export declare const getBorderSide: (direction: BorderDirection) => string;
export declare type BorderDirection = 'left' | 'right' | 'top' | 'bottom' | 'horizontal' | 'vertical' | 'all';
export declare const euiBorderStyles: (euiThemeContext: UseEuiTheme, options: {
    direction?: BorderDirection;
    borderColor?: string;
    borderWidth?: string;
    borderStyle?: string;
}) => string;
