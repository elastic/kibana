export declare type EuiThemeVariantFlags = {
    buttonVariant: 'classic' | 'refresh';
    formVariant: 'classic' | 'refresh';
};
/**
 * Theme specific setting flags
 */
export declare type _EuiThemeFlags = {
    hasGlobalFocusColor: boolean;
    hasVisColorAdjustment: boolean;
    hasShadowFloatingBorder: boolean;
} & EuiThemeVariantFlags;
