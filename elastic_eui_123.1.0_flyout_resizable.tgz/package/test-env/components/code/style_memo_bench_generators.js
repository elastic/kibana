"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.GENERATORS = void 0;
var _accordion_arrow = require("../accordion/accordion_trigger/accordion_arrow.styles");
var _accordion_button = require("../accordion/accordion_trigger/accordion_button.styles");
var _accordion_children = require("../accordion/accordion_children/accordion_children.styles");
var _card = require("../card/card.styles");
var _card_select = require("../card/card_select/card_select.styles");
var _checkable_card = require("../card/checkable_card/checkable_card.styles");
var _code_block_line = require("../code/code_block_line.styles");
var _dual_range = require("../form/range/dual_range.styles");
var _filter_group = require("../filter_group/filter_group.styles");
var _filter_select_item = require("../filter_group/filter_select_item.styles");
var _form_control_layout_icons = require("../form/form_control_layout/form_control_layout_icons.styles");
var _header_section = require("../header/header_section/header_section.styles");
var _mark = require("../mark/mark.styles");
var _modal_body = require("../modal/modal_body.styles");
var _modal_footer = require("../modal/modal_footer.styles");
var _modal_header = require("../modal/modal_header.styles");
var _modal = require("../modal/modal.styles");
var _page_body = require("../page/page_body/page_body.styles");
var _page_header = require("../page/page_header/page_header.styles");
var _page_inner = require("../page_template/inner/page_inner.styles");
var _page_section = require("../page/page_section/page_section.styles");
var _page_sidebar = require("../page/page_sidebar/page_sidebar.styles");
var _page = require("../page/page.styles");
var _pagination_button = require("../pagination/pagination_button.styles");
var _pagination = require("../pagination/pagination.styles");
var _popover_arrow = require("../popover/popover_arrow/_popover_arrow.styles");
var _popover_footer = require("../popover/popover_footer.styles");
var _popover_panel = require("../popover/popover_panel/_popover_panel.styles");
var _popover = require("../popover/popover.styles");
var _popover_title = require("../popover/popover_title.styles");
var _progress = require("../progress/progress.styles");
var _range_highlight = require("../form/range/range_highlight.styles");
var _range_input = require("../form/range/range_input.styles");
var _range_label = require("../form/range/range_label.styles");
var _range_levels = require("../form/range/range_levels.styles");
var _range_slider = require("../form/range/range_slider.styles");
var _range = require("../form/range/range.styles");
var _range_thumb = require("../form/range/range_thumb.styles");
var _range_ticks = require("../form/range/range_ticks.styles");
var _range_tooltip = require("../form/range/range_tooltip.styles");
var _range_track = require("../form/range/range_track.styles");
var _range_wrapper = require("../form/range/range_wrapper.styles");
var _side_nav = require("../side_nav/side_nav.styles");
var _split_button = require("../button/split_button/split_button.styles");
var _step = require("../steps/step.styles");
var _steps_horizontal = require("../steps/steps_horizontal.styles");
var _sub_steps = require("../steps/sub_steps.styles");
var _timeline_item_event = require("../timeline/timeline_item_event.styles");
var _timeline_item_icon = require("../timeline/timeline_item_icon.styles");
var _timeline_item = require("../timeline/timeline_item.styles");
var _timeline = require("../timeline/timeline.styles");
var _token = require("../token/token.styles");
var _tool_tip = require("../tool_tip/tool_tip.styles");
var _tree_view = require("../tree_view/tree_view.styles");
// Temporary benchmark — do not commit

var GENERATORS = exports.GENERATORS = {
  euiAccordionArrowStyles: function euiAccordionArrowStyles(ctx) {
    return (0, _accordion_arrow.euiAccordionArrowStyles)(ctx);
  },
  euiAccordionButtonStyles: function euiAccordionButtonStyles(ctx) {
    return (0, _accordion_button.euiAccordionButtonStyles)(ctx);
  },
  euiAccordionChildWrapperStyles: function euiAccordionChildWrapperStyles(ctx) {
    return (0, _accordion_children.euiAccordionChildWrapperStyles)(ctx);
  },
  euiAccordionChildrenStyles: function euiAccordionChildrenStyles(ctx) {
    return (0, _accordion_children.euiAccordionChildrenStyles)(ctx);
  },
  euiCardBetaBadgeStyles: function euiCardBetaBadgeStyles(ctx) {
    return (0, _card.euiCardBetaBadgeStyles)(ctx, 'm');
  },
  euiCardSelectStyles: function euiCardSelectStyles(ctx) {
    return (0, _card_select.euiCardSelectStyles)();
  },
  euiCardStyles: function euiCardStyles(ctx) {
    return (0, _card.euiCardStyles)(ctx, 'm');
  },
  euiCardTextStyles: function euiCardTextStyles(ctx) {
    return (0, _card.euiCardTextStyles)(ctx);
  },
  euiCheckableCardStyles: function euiCheckableCardStyles(ctx) {
    return (0, _checkable_card.euiCheckableCardStyles)(ctx);
  },
  euiCodeBlockLineStyles: function euiCodeBlockLineStyles(ctx) {
    return (0, _code_block_line.euiCodeBlockLineStyles)(ctx);
  },
  euiDualRangeStyles: function euiDualRangeStyles(ctx) {
    return (0, _dual_range.euiDualRangeStyles)();
  },
  euiFilterGroupStyles: function euiFilterGroupStyles(ctx) {
    return (0, _filter_group.euiFilterGroupStyles)(ctx);
  },
  euiFilterSelectItemStyles: function euiFilterSelectItemStyles(ctx) {
    return (0, _filter_select_item.euiFilterSelectItemStyles)(ctx);
  },
  euiFormControlLayoutIconsStyles: function euiFormControlLayoutIconsStyles(ctx) {
    return (0, _form_control_layout_icons.euiFormControlLayoutIconsStyles)(ctx);
  },
  euiHeaderSectionStyles: function euiHeaderSectionStyles(ctx) {
    return (0, _header_section.euiHeaderSectionStyles)();
  },
  euiMarkScreenReaderStyles: function euiMarkScreenReaderStyles(ctx) {
    return (0, _mark.euiMarkScreenReaderStyles)('start', 'end');
  },
  euiModalBodyStyles: function euiModalBodyStyles(ctx) {
    return (0, _modal_body.euiModalBodyStyles)(ctx);
  },
  euiModalFooterStyles: function euiModalFooterStyles(ctx) {
    return (0, _modal_footer.euiModalFooterStyles)(ctx);
  },
  euiModalHeaderStyles: function euiModalHeaderStyles(ctx) {
    return (0, _modal_header.euiModalHeaderStyles)(ctx);
  },
  euiModalStyles: function euiModalStyles(ctx) {
    return (0, _modal.euiModalStyles)(ctx);
  },
  euiPageBodyStyles: function euiPageBodyStyles(ctx) {
    return (0, _page_body.euiPageBodyStyles)();
  },
  euiPageHeaderStyles: function euiPageHeaderStyles(ctx) {
    return (0, _page_header.euiPageHeaderStyles)(ctx);
  },
  euiPageInnerStyles: function euiPageInnerStyles(ctx) {
    return (0, _page_inner.euiPageInnerStyles)(ctx);
  },
  euiPageSectionContentStyles: function euiPageSectionContentStyles(ctx) {
    return (0, _page_section.euiPageSectionContentStyles)();
  },
  euiPageSectionStyles: function euiPageSectionStyles(ctx) {
    return (0, _page_section.euiPageSectionStyles)(ctx);
  },
  euiPageSidebarStyles: function euiPageSidebarStyles(ctx) {
    return (0, _page_sidebar.euiPageSidebarStyles)(ctx);
  },
  euiPageStyles: function euiPageStyles(ctx) {
    return (0, _page.euiPageStyles)(ctx);
  },
  euiPaginationButtonStyles: function euiPaginationButtonStyles(ctx) {
    return (0, _pagination_button.euiPaginationButtonStyles)(ctx);
  },
  euiPaginationStyles: function euiPaginationStyles(ctx) {
    return (0, _pagination.euiPaginationStyles)(ctx);
  },
  euiPopoverArrowStyles: function euiPopoverArrowStyles(ctx) {
    return (0, _popover_arrow.euiPopoverArrowStyles)(ctx);
  },
  euiPopoverFooterStyles: function euiPopoverFooterStyles(ctx) {
    return (0, _popover_footer.euiPopoverFooterStyles)(ctx);
  },
  euiPopoverPanelStyles: function euiPopoverPanelStyles(ctx) {
    return (0, _popover_panel.euiPopoverPanelStyles)(ctx);
  },
  euiPopoverStyles: function euiPopoverStyles(ctx) {
    return (0, _popover.euiPopoverStyles)();
  },
  euiPopoverTitleStyles: function euiPopoverTitleStyles(ctx) {
    return (0, _popover_title.euiPopoverTitleStyles)(ctx);
  },
  euiProgressDataStyles: function euiProgressDataStyles(ctx) {
    return (0, _progress.euiProgressDataStyles)(ctx);
  },
  euiProgressStyles: function euiProgressStyles(ctx) {
    return (0, _progress.euiProgressStyles)(ctx, false);
  },
  euiProgressValueTextStyles: function euiProgressValueTextStyles(ctx) {
    return (0, _progress.euiProgressValueTextStyles)(ctx);
  },
  euiRangeHighlightLevelsStyles: function euiRangeHighlightLevelsStyles(ctx) {
    return (0, _range_highlight.euiRangeHighlightLevelsStyles)(ctx);
  },
  euiRangeHighlightLevelsWrapperStyles: function euiRangeHighlightLevelsWrapperStyles(ctx) {
    return (0, _range_highlight.euiRangeHighlightLevelsWrapperStyles)(ctx);
  },
  euiRangeHighlightProgressStyles: function euiRangeHighlightProgressStyles(ctx) {
    return (0, _range_highlight.euiRangeHighlightProgressStyles)(ctx);
  },
  euiRangeHighlightStyles: function euiRangeHighlightStyles(ctx) {
    return (0, _range_highlight.euiRangeHighlightStyles)(ctx);
  },
  euiRangeInputStyles: function euiRangeInputStyles(ctx) {
    return (0, _range_input.euiRangeInputStyles)(ctx);
  },
  euiRangeLabelStyles: function euiRangeLabelStyles(ctx) {
    return (0, _range_label.euiRangeLabelStyles)(ctx);
  },
  euiRangeLevelStyles: function euiRangeLevelStyles(ctx) {
    return (0, _range_levels.euiRangeLevelStyles)(ctx);
  },
  euiRangeLevelsStyles: function euiRangeLevelsStyles(ctx) {
    return (0, _range_levels.euiRangeLevelsStyles)(ctx);
  },
  euiRangeSliderStyles: function euiRangeSliderStyles(ctx) {
    return (0, _range_slider.euiRangeSliderStyles)(ctx);
  },
  euiRangeStyles: function euiRangeStyles(ctx) {
    return (0, _range.euiRangeStyles)(ctx);
  },
  euiRangeThumbStyles: function euiRangeThumbStyles(ctx) {
    return (0, _range_thumb.euiRangeThumbStyles)(ctx);
  },
  euiRangeTickStyles: function euiRangeTickStyles(ctx) {
    return (0, _range_ticks.euiRangeTickStyles)(ctx);
  },
  euiRangeTicksStyles: function euiRangeTicksStyles(ctx) {
    return (0, _range_ticks.euiRangeTicksStyles)(ctx);
  },
  euiRangeTooltipStyles: function euiRangeTooltipStyles(ctx) {
    return (0, _range_tooltip.euiRangeTooltipStyles)(ctx);
  },
  euiRangeTooltipValueStyles: function euiRangeTooltipValueStyles(ctx) {
    return (0, _range_tooltip.euiRangeTooltipValueStyles)(ctx);
  },
  euiRangeTrackStyles: function euiRangeTrackStyles(ctx) {
    return (0, _range_track.euiRangeTrackStyles)(ctx);
  },
  euiRangeWrapperStyles: function euiRangeWrapperStyles(ctx) {
    return (0, _range_wrapper.euiRangeWrapperStyles)(ctx);
  },
  euiSideNavMobileStyles: function euiSideNavMobileStyles(ctx) {
    return (0, _side_nav.euiSideNavMobileStyles)(ctx);
  },
  euiSplitButtonActionStyles: function euiSplitButtonActionStyles(ctx) {
    return (0, _split_button.euiSplitButtonActionStyles)(ctx, 'm');
  },
  euiSplitButtonDividerStyles: function euiSplitButtonDividerStyles(ctx) {
    return (0, _split_button.euiSplitButtonDividerStyles)(ctx, '#000');
  },
  euiSplitButtonStyles: function euiSplitButtonStyles(ctx) {
    return (0, _split_button.euiSplitButtonStyles)(ctx, '#fff');
  },
  euiStepContentStyles: function euiStepContentStyles(ctx) {
    return (0, _step.euiStepContentStyles)(ctx);
  },
  euiStepStyles: function euiStepStyles(ctx) {
    return (0, _step.euiStepStyles)(ctx);
  },
  euiStepTitleStyles: function euiStepTitleStyles(ctx) {
    return (0, _step.euiStepTitleStyles)(ctx);
  },
  euiStepsHorizontalStyles: function euiStepsHorizontalStyles(ctx) {
    return (0, _steps_horizontal.euiStepsHorizontalStyles)();
  },
  euiSubStepsStyles: function euiSubStepsStyles(ctx) {
    return (0, _sub_steps.euiSubStepsStyles)(ctx);
  },
  euiTimelineItemEventStyles: function euiTimelineItemEventStyles(ctx) {
    return (0, _timeline_item_event.euiTimelineItemEventStyles)();
  },
  euiTimelineItemIconStyles: function euiTimelineItemIconStyles(ctx) {
    return (0, _timeline_item_icon.euiTimelineItemIconStyles)(ctx);
  },
  euiTimelineItemStyles: function euiTimelineItemStyles(ctx) {
    return (0, _timeline_item.euiTimelineItemStyles)();
  },
  euiTimelineStyles: function euiTimelineStyles(ctx) {
    return (0, _timeline.euiTimelineStyles)(ctx);
  },
  euiTokenStyles: function euiTokenStyles(ctx) {
    return (0, _token.euiTokenStyles)(ctx, 'light');
  },
  euiToolTipStyles: function euiToolTipStyles(ctx) {
    return (0, _tool_tip.euiToolTipStyles)(ctx);
  },
  euiTreeViewStyles: function euiTreeViewStyles(ctx) {
    return (0, _tree_view.euiTreeViewStyles)(ctx);
  }
};