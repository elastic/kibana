# XSOAR → Elastic Workflows gap metrics (all non-deprecated playbooks)

Generated: 2026-08-27T12:36:30.102Z

## Corpus

- Playbooks: 1375
- Packs: 370
- Connector brands: 370
- Gap events: 6024 (4442 blockers, 1582 non-blockers, 4442 on happy path)
- Blocked playbooks (any blocker gap): 1191
- Human-approval tasks: 513
- Tech-preview Kibana mappings: 1301

A **blocker** is an unsupported step on the default success path that is not optional. Optional vendor fan-out (`skipunavailable`), off-path branches, and layout/SLA/ML side tasks are **non-blockers**.

## Gap buckets

- connector_gap: 4578
- mapping_debt: 1138
- platform_primitive_gap: 308

## Top connector brands

| Connector Brand | Tasks | Blocker tasks | Playbooks | Packs | Elastic match | Connector id |
| --- | ---: | ---: | ---: | ---: | --- | --- |
| PAN-OS | 387 | 206 | 84 | 16 | none |  |
| Cortex XDR | 255 | 154 | 84 | 28 | none |  |
| Prisma Cloud | 159 | 106 | 45 | 9 | none |  |
| QRadar | 116 | 44 | 33 | 16 | none |  |
| ServiceNow | 106 | 48 | 42 | 20 | stack_connector | .servicenow |
| Splunk | 101 | 15 | 27 | 20 | none |  |
| Active Directory | 83 | 33 | 32 | 21 | none |  |
| Email | 82 | 59 | 54 | 42 | stack_connector | .email |
| Hurukai | 69 | 67 | 23 | 1 | none |  |
| CrowdStrike Falcon | 65 | 35 | 24 | 5 | stack_connector | .crowdstrike |
| Recorded Future | 60 | 48 | 19 | 1 | none |  |
| Slack | 57 | 23 | 22 | 9 | stack_connector | .slack |
| Code42 | 42 | 29 | 19 | 2 | none |  |
| MITRE ATT&CK | 39 | 39 | 12 | 1 | none |  |
| Azure Log Analytics | 38 | 2 | 10 | 10 | none |  |
| ReliaQuest GreyMatter DRP Incidents | 35 | 35 | 7 | 1 | none |  |
| Darkmon | 33 | 23 | 15 | 1 | none |  |
| Jira | 32 | 16 | 17 | 13 | stack_connector | .jira |
| Rapid7 InsightIDR | 31 | 27 | 5 | 1 | none |  |
| Microsoft Graph | 30 | 10 | 11 | 7 | none |  |
| Qualys | 29 | 27 | 13 | 2 | none |  |
| Rasterize | 29 | 18 | 18 | 14 | none |  |
| VirusTotal | 29 | 17 | 12 | 5 | connector_spec | .virustotal |
| Gmail | 28 | 16 | 12 | 6 | connector_spec | .gmail |
| Google Cloud Compute | 28 | 13 | 11 | 5 | none |  |

## Brands with no Elastic connector (backlog candidates)

- PAN-OS (387 tasks, 84 playbooks)
- Cortex XDR (255 tasks, 84 playbooks)
- Prisma Cloud (159 tasks, 45 playbooks)
- QRadar (116 tasks, 33 playbooks)
- Splunk (101 tasks, 27 playbooks)
- Active Directory (83 tasks, 32 playbooks)
- Hurukai (69 tasks, 23 playbooks)
- Recorded Future (60 tasks, 19 playbooks)
- Code42 (42 tasks, 19 playbooks)
- MITRE ATT&CK (39 tasks, 12 playbooks)
- Azure Log Analytics (38 tasks, 10 playbooks)
- ReliaQuest GreyMatter DRP Incidents (35 tasks, 7 playbooks)
- Darkmon (33 tasks, 15 playbooks)
- Rapid7 InsightIDR (31 tasks, 5 playbooks)
- Microsoft Graph (30 tasks, 11 playbooks)
- Qualys (29 tasks, 13 playbooks)
- Rasterize (29 tasks, 18 playbooks)
- Google Cloud Compute (28 tasks, 11 playbooks)
- EWS (27 tasks, 12 playbooks)
- Palo Alto Networks IoT 3rd Party (27 tasks, 4 playbooks)
- AWS - EC2 (26 tasks, 7 playbooks)
- Azure (26 tasks, 13 playbooks)
- Expanse (26 tasks, 11 playbooks)
- AWS (25 tasks, 9 playbooks)
- Cortex Data Lake (25 tasks, 5 playbooks)

## Unmapped brandless commands

- Unmapped command: ip (21)
- Unmapped command: file (12)
- Unmapped command: win-regedit (11)
- Unmapped command: domain (10)
- Unmapped command: logzio-search-logs (10)
- Unmapped command: es-eql-search (9)
- Unmapped command: aws-iam-update-account-password-policy (9)
- Unmapped command: tidy-git-clone (9)
- Unmapped command: send-notification (8)
- Unmapped command: microsoft-atp-advanced-hunting-persistence-evidence (8)
- Unmapped command: core-get-endpoints (7)
- Unmapped command: endpoint (7)
- Unmapped command: url (7)
- Unmapped command: prisma-sase-candidate-config-push (7)
- Unmapped command: tz-get-result (7)
- Unmapped command: gcp-logging-log-entries-list (6)
- Unmapped command: CreateIndicatorRelationship (6)
- Unmapped command: trello-create-label (6)
- Unmapped command: redlock-get-rql-response (5)
- Unmapped command: core-get-cloud-original-alerts (5)
