import type { EuiIllustrationSource } from '../types';
export declare const dashboard: EuiIllustrationSource;
