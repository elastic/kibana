import type { EuiIllustrationSource } from '../types';
export { dashboard } from './dashboard';
export declare const illustrations: Readonly<Record<string, EuiIllustrationSource>>;
