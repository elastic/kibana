export type { EuiIllustrationSource, EuiIllustrationColorMode } from './types';
export { illustrations } from './generated';
export * from './generated';
