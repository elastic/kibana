"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.EuiDatePopoverButton = void 0;
var _extends2 = _interopRequireDefault(require("@babel/runtime/helpers/extends"));
var _objectWithoutProperties2 = _interopRequireDefault(require("@babel/runtime/helpers/objectWithoutProperties"));
var _react = _interopRequireDefault(require("react"));
var _propTypes = _interopRequireDefault(require("prop-types"));
var _classnames = _interopRequireDefault(require("classnames"));
var _services = require("../../../../services");
var _i18n = require("../../../i18n");
var _popover = require("../../../popover");
var _pretty_duration = require("../pretty_duration");
var _date_popover_content = require("./date_popover_content");
var _date_popover_button = require("./date_popover_button.styles");
var _react2 = require("@emotion/react");
var _excluded = ["position", "isDisabled", "isInvalid", "needsUpdating", "value", "buttonProps", "canRoundRelativeUnits", "roundUp", "onChange", "locale", "dateFormat", "utcOffset", "minDate", "maxDate", "timeFormat", "isOpen", "onPopoverToggle", "onPopoverClose", "compressed", "timeOptions", "timeZoneDisplayProps"];
/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */
// eslint-disable-line import/named
var EuiDatePopoverButton = exports.EuiDatePopoverButton = function EuiDatePopoverButton(props) {
  var position = props.position,
    isDisabled = props.isDisabled,
    isInvalid = props.isInvalid,
    needsUpdating = props.needsUpdating,
    value = props.value,
    buttonProps = props.buttonProps,
    canRoundRelativeUnits = props.canRoundRelativeUnits,
    roundUp = props.roundUp,
    onChange = props.onChange,
    locale = props.locale,
    dateFormat = props.dateFormat,
    utcOffset = props.utcOffset,
    minDate = props.minDate,
    maxDate = props.maxDate,
    timeFormat = props.timeFormat,
    isOpen = props.isOpen,
    onPopoverToggle = props.onPopoverToggle,
    onPopoverClose = props.onPopoverClose,
    compressed = props.compressed,
    timeOptions = props.timeOptions,
    _props$timeZoneDispla = props.timeZoneDisplayProps,
    timeZoneDisplayProps = _props$timeZoneDispla === void 0 ? {} : _props$timeZoneDispla,
    rest = (0, _objectWithoutProperties2.default)(props, _excluded);
  var classes = (0, _classnames.default)(['euiDatePopoverButton', "euiDatePopoverButton--".concat(position), {
    'euiDatePopoverButton--compressed': compressed,
    'euiDatePopoverButton-isSelected': isOpen,
    'euiDatePopoverButton-isInvalid': isInvalid,
    'euiDatePopoverButton-needsUpdating': needsUpdating,
    'euiDatePopoverButton-disabled': isDisabled
  }]);
  var styles = (0, _services.useEuiMemoizedStyles)(_date_popover_button.euiDatePopoverButtonStyles);
  var cssStyles = [styles.euiDatePopoverButton, buttonProps === null || buttonProps === void 0 ? void 0 : buttonProps.css];
  var formattedValue = (0, _pretty_duration.useFormatTimeString)(value, dateFormat, {
    roundUp: roundUp,
    locale: locale,
    canRoundRelativeUnits: canRoundRelativeUnits
  });
  var title = formattedValue;
  var invalidTitle = (0, _i18n.useEuiI18n)('euiDatePopoverButton.invalidTitle', 'Invalid date: {title}', {
    title: title
  });
  var outdatedTitle = (0, _i18n.useEuiI18n)('euiDatePopoverButton.outdatedTitle', 'Update needed: {title}', {
    title: title
  });
  if (isInvalid) {
    title = invalidTitle;
  } else if (needsUpdating) {
    title = outdatedTitle;
  }
  var button = (0, _react2.jsx)("button", (0, _extends2.default)({
    type: "button",
    onClick: onPopoverToggle,
    className: classes,
    title: title,
    disabled: isDisabled,
    "data-test-subj": "superDatePicker".concat(position, "DatePopoverButton")
  }, buttonProps, {
    css: cssStyles
  }), formattedValue);
  return (0, _react2.jsx)(_popover.EuiPopover, (0, _extends2.default)({
    button: button,
    isOpen: isOpen,
    closePopover: onPopoverClose,
    anchorPosition: position === 'start' ? 'downLeft' : 'downRight',
    display: "block",
    panelPaddingSize: "none"
  }, rest, {
    css: value === 'now' && styles.now
  }), (0, _react2.jsx)(_date_popover_content.EuiDatePopoverContent, {
    value: value,
    roundUp: roundUp,
    canRoundRelativeUnits: canRoundRelativeUnits,
    onChange: onChange,
    dateFormat: dateFormat,
    timeFormat: timeFormat,
    locale: locale,
    position: position,
    utcOffset: utcOffset,
    timeOptions: timeOptions,
    minDate: minDate,
    maxDate: maxDate,
    timeZoneDisplayProps: timeZoneDisplayProps
  }));
};
EuiDatePopoverButton.propTypes = {
  className: _propTypes.default.string,
  buttonProps: _propTypes.default.shape({
    className: _propTypes.default.string,
    "aria-label": _propTypes.default.string,
    "data-test-subj": _propTypes.default.string,
    css: _propTypes.default.any
  }),
  dateFormat: _propTypes.default.string.isRequired,
  isDisabled: _propTypes.default.bool,
  isInvalid: _propTypes.default.bool,
  isOpen: _propTypes.default.bool.isRequired,
  needsUpdating: _propTypes.default.bool,
  locale: _propTypes.default.any,
  onChange: _propTypes.default.func.isRequired,
  onPopoverClose: _propTypes.default.any.isRequired,
  onPopoverToggle: _propTypes.default.func.isRequired,
  position: _propTypes.default.oneOf(["start", "end"]).isRequired,
  canRoundRelativeUnits: _propTypes.default.bool,
  roundUp: _propTypes.default.bool,
  timeFormat: _propTypes.default.string.isRequired,
  value: _propTypes.default.string.isRequired,
  utcOffset: _propTypes.default.number,
  minDate: _propTypes.default.any,
  maxDate: _propTypes.default.any,
  compressed: _propTypes.default.bool,
  timeOptions: _propTypes.default.shape({
    timeTenseOptions: _propTypes.default.arrayOf(_propTypes.default.any.isRequired).isRequired,
    timeUnitsOptions: _propTypes.default.arrayOf(_propTypes.default.any.isRequired).isRequired,
    relativeOptions: _propTypes.default.arrayOf(_propTypes.default.shape({
      text: _propTypes.default.string.isRequired,
      value: _propTypes.default.oneOfType([_propTypes.default.oneOf(["s", "m", "h", "d", "w", "M", "y"]).isRequired, _propTypes.default.oneOf(["s+", "m+", "h+", "d+", "w+", "M+", "y+"]).isRequired]).isRequired
    }).isRequired).isRequired,
    relativeRoundingLabels: _propTypes.default.any.isRequired,
    refreshUnitsOptions: _propTypes.default.arrayOf(_propTypes.default.any.isRequired).isRequired,
    commonDurationRanges: _propTypes.default.arrayOf(_propTypes.default.shape({
      end: _propTypes.default.oneOfType([_propTypes.default.oneOf(["now"]), _propTypes.default.string.isRequired]).isRequired,
      label: _propTypes.default.string,
      start: _propTypes.default.oneOfType([_propTypes.default.oneOf(["now"]), _propTypes.default.string.isRequired]).isRequired
    }).isRequired).isRequired
  }).isRequired,
  timeZoneDisplayProps: _propTypes.default.shape({
    /**
       * A valid time zone name, from the IANA database, e.g. "America/Los_Angeles".
       *
       * @link https://en.wikipedia.org/wiki/List_of_tz_database_time_zones
       */
    timeZone: _propTypes.default.string,
    /**
       * Render prop function to add additional content to the time zone display.
       * Useful for e.g. adding links to documentation or setting pages.
       */
    customRender: _propTypes.default.func,
    /**
       * Reference date to be used while resolving the UTC offset.
       * Only useful for edge cases involving daylight saving time.
       */
    date: _propTypes.default.any
  })
};
EuiDatePopoverButton.displayName = 'EuiDatePopoverButton';